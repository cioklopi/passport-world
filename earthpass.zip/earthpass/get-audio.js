/* EarthPass: downloads the game sounds (voices, effects, radio and club music made with ElevenLabs) into public/assets/audio.
   Run on the server:  node get-audio.js
   With a new list of links:  node get-audio.js https://.../audio-links.json */
const fs = require("fs"), path = require("path"), https = require("https");
const OUT = path.join(__dirname, "public", "assets", "audio");
function fetchBuf(url, n) {
  return new Promise((ok, bad) => {
    https.get(url, { headers: { "User-Agent": "earthpass-audio" } }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && (n || 0) < 5) { res.resume(); return fetchBuf(new URL(res.headers.location, url).toString(), (n || 0) + 1).then(ok, bad); }
      if (res.statusCode !== 200) { res.resume(); return bad(new Error("HTTP " + res.statusCode)); }
      const parts = []; res.on("data", c => parts.push(c)); res.on("end", () => ok(Buffer.concat(parts))); res.on("error", bad);
    }).on("error", bad).setTimeout(60000, function () { this.destroy(new Error("timeout")); });
  });
}
(async () => {
  let list;
  if (process.argv[2]) list = JSON.parse((await fetchBuf(process.argv[2])).toString("utf8"));
  else list = JSON.parse(fs.readFileSync(path.join(__dirname, "audio-links.json"), "utf8"));
  fs.mkdirSync(OUT, { recursive: true });
  const q = list.files.map(f => f.slice()), base = list.base, tail = list.tail;
  let got = 0, have = 0, expired = 0; const fail = [];
  async function worker() {
    while (q.length) {
      const f = q.shift(), name = f[0], dest = path.join(OUT, name + ".mp3");
      if (fs.existsSync(dest) && fs.statSync(dest).size > 2000) { have++; continue; }
      const url = f[3] ? f[3] : base + f[1] + "/" + f[2] + "/content.mp3" + tail + f[4];
      let ok = false;
      for (let t = 0; t < 3 && !ok; t++) {
        try { const b = await fetchBuf(url); if (b.length < 2000) throw new Error("too small"); fs.writeFileSync(dest + ".part", b); fs.renameSync(dest + ".part", dest); got++; ok = true; }
        catch (e) { if (/HTTP 4\d\d/.test(e.message)) { expired++; break; } }
      }
      if (!ok) fail.push(name);
    }
  }
  await Promise.all([0, 1, 2, 3, 4, 5].map(worker));
  if (!fail.length) console.log("AUDIO OK: " + (got + have) + " sound files ready (" + got + " new)");
  else { console.log("AUDIO: " + (got + have) + " ready, " + fail.length + " missing" + (expired ? " - the download links have expired, ask for new links" : " - run the same command again")); process.exitCode = 1; }
})().catch(e => { console.log("AUDIO ERROR: " + e.message); process.exitCode = 1; });
