(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  };
  var D2R = Math.PI / 180;
  function hash(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6d2b79f5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function smooth(t) { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); }

  /* ================= Clock ================= */
  var clk = store.get("pw2_clock", { offset: 0, speed: 1, base: Date.now() });
  function now() { var r = Date.now(); return r + clk.offset + (r - clk.base) * (clk.speed - 1); }
  function setSpeed(s) { var n = now(); clk.base = Date.now(); clk.offset = n - clk.base; clk.speed = s; store.set("pw2_clock", clk); }

  /* ================= Airports ================= */
  var AP = [
    ["JFK","New York","United States",40.6413,-73.7781,"America/New_York","John F. Kennedy International"],
    ["LAX","Los Angeles","United States",33.9416,-118.4085,"America/Los_Angeles","Los Angeles International"],
    ["ORD","Chicago","United States",41.9742,-87.9073,"America/Chicago","O'Hare International"],
    ["ATL","Atlanta","United States",33.6407,-84.4277,"America/New_York","Hartsfield-Jackson International"],
    ["SFO","San Francisco","United States",37.6213,-122.379,"America/Los_Angeles","San Francisco International"],
    ["MIA","Miami","United States",25.7959,-80.287,"America/New_York","Miami International"],
    ["LAS","Las Vegas","United States",36.084,-115.1537,"America/Los_Angeles","Harry Reid International"],
    ["SEA","Seattle","United States",47.4502,-122.3088,"America/Los_Angeles","Seattle-Tacoma International"],
    ["YYZ","Toronto","Canada",43.6777,-79.6248,"America/Toronto","Toronto Pearson International"],
    ["MEX","Mexico City","Mexico",19.4361,-99.0719,"America/Mexico_City","Benito Ju\u00e1rez International"],
    ["GRU","S\u00e3o Paulo","Brazil",-23.4356,-46.4731,"America/Sao_Paulo","Guarulhos International"],
    ["LHR","London","United Kingdom",51.47,-0.4543,"Europe/London","London Heathrow"],
    ["CDG","Paris","France",49.0097,2.5479,"Europe/Paris","Paris Charles de Gaulle"],
    ["FRA","Frankfurt","Germany",50.0379,8.5622,"Europe/Berlin","Frankfurt am Main"],
    ["MAD","Madrid","Spain",40.4983,-3.5676,"Europe/Madrid","Adolfo Su\u00e1rez Madrid-Barajas"],
    ["FCO","Rome","Italy",41.8003,12.2389,"Europe/Rome","Rome Fiumicino"],
    ["IST","Istanbul","Turkey",41.2753,28.7519,"Europe/Istanbul","Istanbul Airport"],
    ["CAI","Cairo","Egypt",30.1219,31.4056,"Africa/Cairo","Cairo International"],
    ["JNB","Johannesburg","South Africa",-26.1392,28.246,"Africa/Johannesburg","O. R. Tambo International"],
    ["LOS","Lagos","Nigeria",6.5774,3.3212,"Africa/Lagos","Murtala Muhammed International"],
    ["DXB","Dubai","United Arab Emirates",25.2532,55.3657,"Asia/Dubai","Dubai International"],
    ["DOH","Doha","Qatar",25.2731,51.6081,"Asia/Qatar","Hamad International"],
    ["DEL","Delhi","India",28.5562,77.1,"Asia/Kolkata","Indira Gandhi International"],
    ["DAC","Dhaka","Bangladesh",23.8433,90.3978,"Asia/Dhaka","Hazrat Shahjalal International"],
    ["BKK","Bangkok","Thailand",13.69,100.7501,"Asia/Bangkok","Suvarnabhumi"],
    ["SIN","Singapore","Singapore",1.3644,103.9915,"Asia/Singapore","Singapore Changi"],
    ["HKG","Hong Kong","Hong Kong",22.308,113.9185,"Asia/Hong_Kong","Hong Kong International"],
    ["PEK","Beijing","China",40.0799,116.6031,"Asia/Shanghai","Beijing Capital International"],
    ["ICN","Seoul","South Korea",37.4602,126.4407,"Asia/Seoul","Incheon International"],
    ["NRT","Tokyo","Japan",35.772,140.3929,"Asia/Tokyo","Tokyo Narita"],
    ["SYD","Sydney","Australia",-33.9399,151.1753,"Australia/Sydney","Sydney Kingsford Smith"]
  ].map(function (a) { return { code: a[0], city: a[1], country: a[2], lat: a[3], lon: a[4], tz: a[5], name: a[6], us: a[2] === "United States" }; });
  var AIR = {}; AP.forEach(function (a) { AIR[a.code] = a; });
  function distKm(a, b) {
    var p1 = a.lat * D2R, p2 = b.lat * D2R, dp = p2 - p1, dl = (b.lon - a.lon) * D2R;
    var h = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
    return 2 * 6371 * Math.asin(Math.sqrt(h));
  }
  function flightMs(a, b) { return Math.round((distKm(a, b) / 850 + 0.5) * 3600000); }
  function fmtT(ms, tz) { try { return new Intl.DateTimeFormat("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: tz }).format(ms); } catch (e) { return new Date(ms).toISOString().slice(11, 16); } }
  function fmtD(ms, tz) { try { return new Intl.DateTimeFormat("en-GB", { weekday: "short", day: "2-digit", month: "short", timeZone: tz }).format(ms); } catch (e) { return ""; } }
  function localHour(ms, tz) { try { var p = new Intl.DateTimeFormat("en-GB", { hour: "numeric", minute: "numeric", hourCycle: "h23", timeZone: tz }).formatToParts(ms); var h = 0, m = 0; p.forEach(function (x) { if (x.type === "hour") h = +x.value; if (x.type === "minute") m = +x.value; }); return h + m / 60; } catch (e) { return new Date(ms).getHours(); } }
  function dur(ms) { ms = Math.max(0, ms); var h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, s = Math.floor(ms / 1000) % 60; return h ? h + "h " + String(m).padStart(2, "0") + "m" : m + "m " + String(s).padStart(2, "0") + "s"; }

  /* ================= State ================= */
  var LEG = "#b8860b", EPI = "#7b4fd6", RAR = "#2f6fd6", COM = "#4b5568";
  var JOBS = [
    ["Oil Field Owner","Legendary",1,LEG,140],["Gold Mine Owner","Legendary",1,LEG,140],["Company Owner","Legendary",1.2,LEG,130],["Bank Owner","Legendary",0.8,LEG,135],
    ["Factory Owner","Epic",2,EPI,90],["Airline Pilot","Epic",2,EPI,95],["Doctor","Epic",2,EPI,95],["Hotel Owner","Epic",1.5,EPI,90],["Tech Founder","Epic",1.5,EPI,92],
    ["Real Estate Agent","Rare",3,RAR,60],["Restaurant Owner","Rare",3,RAR,60],["Grocery Store Owner","Rare",3,RAR,55],["Farm Owner","Rare",3,RAR,55],
    ["Software Engineer","Rare",3,RAR,62],["Lawyer","Rare",2.5,RAR,62],["Nurse","Rare",3,RAR,55],["Banker","Rare",2.5,RAR,58],
    ["Taxi Driver","Common",5,COM,35],["Truck Driver","Common",4,COM,35],["Delivery Driver","Common",4,COM,32],["Farmer","Common",5,COM,30],["Miner","Common",5,COM,32],
    ["Oil Rig Worker","Common",4,COM,34],["Factory Worker","Common",4,COM,30],["Construction Worker","Common",5,COM,32],["Chef","Common",4,COM,30],
    ["Shop Assistant","Common",4,COM,28],["Mechanic","Common",4,COM,30],["Teacher","Common",4,COM,32],["Barista","Common",4,COM,28],
    ["Hotel Receptionist","Common",4,COM,28],["Security Guard","Common",4,COM,30]
  ];
  var FIRST = ["James","Olivia","Liam","Emma","Noah","Ava","Mason","Sophia","Ethan","Mia","Lucas","Amelia","Logan","Harper","Elijah","Evelyn","Caleb","Ella","Jordan","Maya","Ryan","Zoe","Nathan","Layla","Isaac","Nora","Owen","Riley"];
  var LAST = ["Carter","Brooks","Hayes","Reed","Morgan","Bennett","Foster","Rivera","Coleman","Price","Hughes","Ward","Bryant","Russell","Griffin","Diaz","Hunt","Palmer","Stone","Fisher","Wells","Porter","Knight","Lane","Grant","Shaw","Ross","Pierce"];
  function makePassport(id) {
    var r = rng(id * 2654435761 + 17), roll = r() * 100, acc = 0, job = JOBS[JOBS.length - 1];
    for (var i = 0; i < JOBS.length; i++) { acc += JOBS[i][2]; if (roll < acc) { job = JOBS[i]; break; } }
    var y = 1966 + Math.floor(r() * 38), m = 1 + Math.floor(r() * 12), d = 1 + Math.floor(r() * 28);
    return { id: id, first: FIRST[Math.floor(r() * FIRST.length)], last: LAST[Math.floor(r() * LAST.length)], sex: r() < 0.5 ? "F" : "M", dob: [y, m, d], no: "PW" + String(1000000 + Math.floor(r() * 8999999)), job: job,
      skin: ["#f1c9a5", "#e0ac83", "#c68a5e", "#9a6440", "#6e452b"][Math.floor(r() * 5)], hair: ["#1f1a17", "#4a2f1f", "#8a5a2b", "#c99a4a", "#6b6b6b"][Math.floor(r() * 5)], suit: ["#1f2a44", "#3a3f4b", "#5a2e2e", "#2e4a3a", "#2f3e66"][Math.floor(r() * 5)], style: Math.floor(r() * 3) };
  }
  var G = store.get("pw2_state", null);
  if (!G || !G.passport) {
    G = { city: "JFK", balance: 600, food: 80, foodT: now(), trip: null, flags: {}, stamps: [], passport: makePassport(1 + Math.floor(Math.random() * 3333)), arrival: false };
  }
  function save() { store.set("pw2_state", G); }
  if (!G.tx) G.tx = []; if (!(G.balance >= 0)) G.balance = 600; if (G.mapv !== 2) { G.pos = null; G.wp = null; G.mapv = 2; } if (!G.msgs) G.msgs = []; if (!G.done) G.done = {};
  function logTx(amt, label) { G.tx.unshift({ a: amt, l: label, t: now(), c: G.city }); if (G.tx.length > 60) G.tx.length = 60; }
  var SND = null; function sfx(k, a, b) { if (SND) try { SND.ev(k, a, b); } catch (e) { } }
  function earn(amt, label) { G.balance += amt; logTx(amt, label); save(); sfx("earn", amt); }
  function spend(amt, label) { amt = Math.max(0, Math.min(amt, Math.max(0, G.balance))); if (!amt) return 0; G.balance -= amt; if (TEST_TOK) G.balance = TEST_BAL; logTx(-amt, label); save(); sfx("cash", amt); return amt; }
  /* test mode (set on the admin page): unlimited tokens; the real balance is kept aside and comes back when test mode ends */
  var TEST_TOK = false, TEST_BAL = 9999999;
  function setTestTokens(on) {
    if (on) { if (G.realBal === undefined) G.realBal = G.balance; G.balance = TEST_BAL; }
    else if (G.realBal !== undefined) { G.balance = G.realBal; delete G.realBal; }
    TEST_TOK = !!on; save();
  }
  function here() { return AIR[G.city] || AIR.JFK; }

  /* ================= Renderer ================= */
  var canvas = $("gl");
  var renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, powerPreference: "high-performance" });
  var DPR = Math.min(window.devicePixelRatio || 1, 1.75);
  renderer.setPixelRatio(DPR);
  renderer.outputEncoding = THREE.sRGBEncoding;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 0.78;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  var scene = new THREE.Scene();
  var camera = new THREE.PerspectiveCamera(52, 1, 0.1, 2200);
  scene.fog = new THREE.Fog(0xbfd3e6, 140, 700);

  var skyU = { top: { value: new THREE.Color() }, mid: { value: new THREE.Color() }, bot: { value: new THREE.Color() }, sunDir: { value: new THREE.Vector3(0, 1, 0) }, sunCol: { value: new THREE.Color(1, 0.95, 0.85) }, sunVis: { value: 1 },
    moonDir: { value: new THREE.Vector3(0, -1, 0) }, moonVis: { value: 0 }, uTime: { value: 0 }, cover: { value: 0.3 }, cloudLit: { value: new THREE.Color(1, 1, 1) }, cloudShade: { value: new THREE.Color(0.6, 0.62, 0.68) },
    wind: { value: new THREE.Vector2() }, stars: { value: 0 }, starRot: { value: new THREE.Matrix3() }, flash: { value: 0 } };
  var sky = new THREE.Mesh(new THREE.SphereGeometry(1500, 48, 24), new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false, uniforms: skyU,
    vertexShader: "varying vec3 vP; void main(){ vP=normalize(position); gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.); }",
    fragmentShader: [
      "uniform vec3 top; uniform vec3 mid; uniform vec3 bot; uniform vec3 sunDir; uniform vec3 sunCol; uniform float sunVis; uniform vec3 moonDir; uniform float moonVis;",
      "uniform float uTime; uniform float cover; uniform vec3 cloudLit; uniform vec3 cloudShade; uniform vec2 wind; uniform float stars; uniform mat3 starRot; uniform float flash; varying vec3 vP;",
      "float h21(vec2 p){ p=fract(p*vec2(123.34,456.21)); p+=dot(p,p+45.32); return fract(p.x*p.y); }",
      "float h31(vec3 p){ p=fract(p*0.3183099+0.1); p*=17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }",
      "float vn(vec2 p){ vec2 i=floor(p), f=fract(p); vec2 u=f*f*(3.-2.*f); return mix(mix(h21(i),h21(i+vec2(1.,0.)),u.x), mix(h21(i+vec2(0.,1.)),h21(i+vec2(1.,1.)),u.x), u.y); }",
      "float fbm(vec2 p){ float v=0., a=0.5; for(int i=0;i<5;i++){ v+=a*vn(p); p=p*2.03+vec2(1.7,9.2); a*=0.5; } return v; }",
      "void main(){",
      "  vec3 d=normalize(vP); float h=d.y;",
      "  vec3 c = h>0. ? mix(mid, top, pow(h,0.55)) : mix(mid, bot, pow(-h,0.4));",
      "  if (stars>0.01 && h>0.) { vec3 sd=starRot*d*260.; vec3 g=floor(sd); float r=h31(g); if (r>0.9965) { float dd=length(fract(sd)-0.5); float tw=0.65+0.35*sin(uTime*2.5+r*400.); c+=vec3(0.92,0.95,1.)*stars*tw*smoothstep(0.45,0.0,dd)*(r>0.9992?1.6:0.8)*(1.-cover*0.95)*smoothstep(0.,0.15,h); } }",
      "  float s0=max(dot(d,sunDir),0.);",
      "  c += sunCol*(smoothstep(0.99935,0.99965,s0)*5.0 + pow(s0,90.)*0.45 + pow(s0,7.)*0.14)*sunVis*(1.-cover*0.8);",
      "  float md=dot(d,moonDir);",
      "  if (moonVis>0. && md>0.999) { vec3 rt=normalize(cross(moonDir,vec3(0.,1.,0.))); vec3 up=cross(rt,moonDir); vec2 o=vec2(dot(d,rt),dot(d,up))/0.0215; float rr=dot(o,o); if (rr<1.) { vec3 n=o.x*rt+o.y*up-sqrt(1.-rr)*moonDir; float lit=smoothstep(-0.05,0.15,dot(n,sunDir)); float cr=0.72+0.28*vn(o*5.+3.)-0.12*smoothstep(0.55,0.6,vn(o*3.1)); c=mix(c, vec3(0.95,0.94,0.88)*cr*(0.05+0.95*lit), moonVis*(1.-cover*0.9)*smoothstep(1.,0.92,rr)); } }",
      "  c += vec3(0.55,0.62,0.85)*pow(max(md,0.),500.)*0.35*moonVis*(1.-cover);",
      "  if (h>0.) { vec2 uv=d.xz/(h+0.1)*0.85+wind; float n=fbm(uv*0.5); float n2=fbm(uv*1.6+3.1);",
      "    float dens=smoothstep(1.02-cover*0.92, 1.14-cover*0.62, n*0.8+n2*0.32);",
      "    float shade=clamp((n2-0.32)*1.7,0.,1.); vec3 cc=mix(cloudShade,cloudLit,shade); cc+=sunCol*pow(s0,9.)*0.4*sunVis*(1.-dens*0.5);",
      "    c=mix(c, cc, dens*smoothstep(0.0,0.16,h)); }",
      "  c += vec3(0.75,0.8,1.0)*flash*(0.35+0.65*smoothstep(-0.1,0.4,h));",
      "  gl_FragColor=vec4(c,1.);",
      "}"].join("\n")
  }));
  scene.add(sky);
  var hemi = new THREE.HemisphereLight(0xdfeeff, 0x6b6150, 0.9); scene.add(hemi);
  var pmrem = new THREE.PMREMGenerator(renderer);
  if (THREE.RoomEnvironment) scene.environment = pmrem.fromScene(new THREE.RoomEnvironment(), 0.04).texture;
  var sun = new THREE.DirectionalLight(0xfff1dc, 1.6);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  var sc = sun.shadow.camera; sc.left = -48; sc.right = 48; sc.top = 48; sc.bottom = -48; sc.near = 1; sc.far = 260;
  sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.03;
  scene.add(sun); scene.add(sun.target);

  /* ================= Materials & textures ================= */
  function canvasTex(w, h, draw, repeat) {
    var c = document.createElement("canvas"); c.width = w; c.height = h;
    draw(c.getContext("2d"), w, h);
    var t = new THREE.CanvasTexture(c);
    t.encoding = THREE.sRGBEncoding;
    t.anisotropy = renderer.capabilities.getMaxAnisotropy();
    if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; }
    return t;
  }
  var nightMats = [];
  /* ===================== NFT-style stickers (original designs) for cars, aircraft and walls ===================== */
  var STK_N = 16, STK_CV = document.createElement("canvas"); STK_CV.width = 1024; STK_CV.height = 1024;
  var PIX = {
    robot: ["....aaaa....", "...a....a...", "..bbbbbbbb..", ".bccccccccb.", ".bcwwccwwcb.", ".bcwkccwkcb.", ".bccccccccb.", ".bcckkkkccb.", ".bccccccccb.", "..bbbbbbbb..", "...b....b...", "..bb....bb.."],
    ghost: ["...pppppp...", "..pppppppp..", ".pppppppppp.", ".ppwwppwwpp.", ".ppwkppwkpp.", ".pppppppppp.", ".pppppppppp.", ".pppppppppp.", ".pppppppppp.", ".pp.pp.pp.pp", ".p...p...p..", "............"],
    alien: ["....gggg....", "..gggggggg..", ".gggggggggg.", "gggggggggggg", "gkkkggggkkkg", "gkkkkggkkkkg", ".gkkggggkkg.", ".gggggggggg.", "..gggkkggg..", "...gggggg...", "....gggg....", "............"],
    crown: ["............", ".y...y...y..", ".yy..y..yy..", ".yyy.y.yyy..", ".yyyyyyyyy..", ".yyrryybbyy.", ".yyrryybbyy.", ".yyyyyyyyyy.", ".oooooooooo.", "............", "............", "............"],
    cat: ["............", ".o........o.", ".oo......oo.", ".oooooooooo.", ".oooooooooo.", ".okkkookkko.", ".okkkookkko.", ".oooooooooo.", ".ooooppoooo.", "..oooooooo..", "...oooooo...", "............"],
    diamond: ["............", "...cccccc...", "..cwccccwc..", ".cccccccccc.", "cccccccccccc", ".cccccccccc.", "..cccccccc..", "...cccccc...", "....cccc....", ".....cc.....", "............", "............"]
  };
  var PCOL = { a: "#9aa3ad", b: "#3a3546", c: "#2ee6d6", w: "#ffffff", k: "#120a24", p: "#a855f7", g: "#7dffb0", y: "#ffd23f", r: "#ff3d8b", o: "#ff9a3c" };
  function drawStickers() {
    var c = STK_CV.getContext("2d"); c.clearRect(0, 0, 1024, 1024);
    var F = "'Bangers', Impact, 'Arial Black', sans-serif";
    function cell(i, fn) { var x = (i % 4) * 256, y = Math.floor(i / 4) * 256; c.save(); c.translate(x + 128, y + 128); fn(); c.restore(); }
    function outline(path, fill, w) { c.lineJoin = "round"; c.shadowColor = "rgba(0,0,0,0.35)"; c.shadowBlur = 10; c.shadowOffsetY = 4; c.lineWidth = w || 22; c.strokeStyle = "#fff"; path(); c.stroke(); c.shadowColor = "transparent"; path(); c.fillStyle = fill; c.fill(); }
    function rr(x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
    function txt(s, size, col, y, stroke) { c.font = "400 " + size + "px " + F; c.textAlign = "center"; c.textBaseline = "middle"; if (stroke) { c.lineWidth = stroke; c.strokeStyle = "#120a24"; c.strokeText(s, 0, y); } c.fillStyle = col; c.fillText(s, 0, y); }
    function pix(key, s) { var P = PIX[key], n = P.length, u = s / n, o = -s / 2; c.fillStyle = "#fff"; for (var j = 0; j < n; j++) for (var i = 0; i < n; i++) if (P[j][i] !== ".") c.fillRect(o + i * u - 7, o + j * u - 7, u + 14, u + 14);
      for (var j2 = 0; j2 < n; j2++) for (var i2 = 0; i2 < n; i2++) { var ch = P[j2][i2]; if (ch !== ".") { c.fillStyle = PCOL[ch]; c.fillRect(o + i2 * u, o + j2 * u, u + 0.5, u + 0.5); } } }
    function sun() { var g = c.createLinearGradient(0, -90, 0, 90); g.addColorStop(0, "#ffe36b"); g.addColorStop(0.5, "#ff9a3c"); g.addColorStop(1, "#ff3d8b"); return g; }
    cell(0, function () { c.rotate(-0.12); outline(function () { rr(-70, -95, 140, 190, 22); }, "#5a1f8c"); c.strokeStyle = "#ffd9a8"; c.lineWidth = 5; c.beginPath(); c.arc(0, -10, 42, 0, Math.PI * 2); c.stroke(); c.beginPath(); c.ellipse(0, -10, 18, 42, 0, 0, Math.PI * 2); c.stroke(); c.beginPath(); c.moveTo(-42, -10); c.lineTo(42, -10); c.stroke(); txt("EARTHPASS", 26, "#ffe6c2", 62); });
    cell(1, function () { outline(function () { c.beginPath(); c.ellipse(0, -10, 105, 78, 0, 0, Math.PI * 2); c.moveTo(-40, 55); c.lineTo(-70, 100); c.lineTo(5, 64); }, "#120a24"); txt("GM", 120, sun(), -6, 0); });
    cell(2, function () { c.rotate(0.1); outline(function () { rr(-115, -48, 230, 96, 48); }, "#2ee6d6"); txt("WAGMI", 74, "#120a24", 4); });
    cell(3, function () { outline(function () { c.beginPath(); for (var k = 0; k < 8; k++) { var a = k / 8 * Math.PI * 2 + Math.PI / 8; c.lineTo(Math.cos(a) * 100, Math.sin(a) * 100); } c.closePath(); }, "#120a24"); txt("HODL", 78, "#ff3d8b", 4); });
    cell(4, function () { pix("robot", 190); });
    cell(5, function () { c.rotate(-0.2); outline(function () { c.beginPath(); c.arc(0, 0, 100, 0, Math.PI * 2); }, "#fff"); c.strokeStyle = "#d1283c"; c.lineWidth = 10; c.beginPath(); c.arc(0, 0, 88, 0, Math.PI * 2); c.stroke(); c.lineWidth = 4; c.beginPath(); c.arc(0, 0, 72, 0, Math.PI * 2); c.stroke(); txt("MINT", 70, "#d1283c", 6); });
    cell(6, function () { outline(function () { c.beginPath(); c.arc(0, 0, 100, 0, Math.PI * 2); }, sun()); txt("3,333", 64, "#fff", -14, 8); txt("PASSPORTS", 30, "#120a24", 38); });
    cell(7, function () { pix("diamond", 170); txt("DIAMOND HANDS", 26, "#fff", 98, 6); });
    cell(8, function () { c.rotate(-0.6); outline(function () { c.beginPath(); c.moveTo(0, -105); c.quadraticCurveTo(45, -50, 34, 40); c.lineTo(-34, 40); c.quadraticCurveTo(-45, -50, 0, -105); c.moveTo(-34, 10); c.lineTo(-64, 60); c.lineTo(-30, 50); c.moveTo(34, 10); c.lineTo(64, 60); c.lineTo(30, 50); }, "#f4f4f2"); c.fillStyle = "#2ee6d6"; c.beginPath(); c.arc(0, -35, 16, 0, Math.PI * 2); c.fill(); c.fillStyle = "#ff9a3c"; c.beginPath(); c.moveTo(-22, 44); c.lineTo(0, 100); c.lineTo(22, 44); c.fill(); c.rotate(0.6); txt("TO THE MOON", 28, "#ffd23f", 100, 6); });
    cell(9, function () { pix("ghost", 190); });
    cell(10, function () { outline(function () { rr(-105, -55, 210, 110, 18); }, "#ff3d8b"); txt("LFG", 104, "#ffd23f", 6, 10); });
    cell(11, function () { pix("alien", 190); });
    cell(12, function () { pix("crown", 200); });
    cell(13, function () { var g = c.createLinearGradient(-90, -90, 90, 90); g.addColorStop(0, "#ff9ac4"); g.addColorStop(0.35, "#9be7ff"); g.addColorStop(0.7, "#c7a6ff"); g.addColorStop(1, "#ffe36b"); outline(function () { c.beginPath(); c.arc(0, 0, 96, 0, Math.PI * 2); }, g); txt("1/1", 96, "#120a24", 0); txt("RARE", 28, "#120a24", 62); });
    cell(14, function () { pix("cat", 190); c.fillStyle = "#120a24"; c.fillRect(-60, -38, 120, 10); });
    cell(15, function () { c.rotate(-0.08); outline(function () { rr(-118, -62, 236, 124, 14); }, "#120a24"); txt("MINT ON", 50, "#fff", -24); txt("OPENSEA", 58, "#2ee6d6", 28); });
  }
  drawStickers();
  var STK_TEX = new THREE.CanvasTexture(STK_CV); STK_TEX.encoding = THREE.sRGBEncoding; STK_TEX.anisotropy = 4;
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { drawStickers(); STK_TEX.needsUpdate = true; });
  window.EP_STICKER_TEX = STK_TEX;
  var STK_MAT = new THREE.MeshStandardMaterial({ map: STK_TEX, alphaTest: 0.4, roughness: 0.55, metalness: 0.05, polygonOffset: true, polygonOffsetFactor: -2, side: THREE.FrontSide });
  function stkUV(i) { var u0 = (i % 4) / 4, v1 = 1 - Math.floor(i / 4) / 4; return [u0, v1 - 0.25, u0 + 0.25, v1]; }
  function stickerMesh(i, w, h) { var g = new THREE.PlaneGeometry(w, h || w), uv = g.attributes.uv, q = stkUV(i); for (var k = 0; k < uv.count; k++) uv.setXY(k, uv.getX(k) ? q[2] : q[0], uv.getY(k) ? q[3] : q[1]); var m = new THREE.Mesh(g, STK_MAT); m.castShadow = false; m.receiveShadow = true; return m; }
  /* put a sticker on a group: position, facing (+1 = +z side, -1 = -z side, or a y-rotation) */
  function stick(grp, i, w, x, y, z, side, rotZ) { var m = stickerMesh(((i % STK_N) + STK_N) % STK_N, w); m.position.set(x, y, z); m.rotation.y = side === -1 ? Math.PI : side === 1 ? 0 : side; if (rotZ) m.rotation.z = rotZ; grp.add(m); return m; }
  /* batched stickers for walls of hand-built places */
  var MURAL_BG = [[0.07, 0.04, 0.14], [0.93, 0.9, 0.84], [0.11, 0.42, 0.46], [0.8, 0.24, 0.42], [0.98, 0.74, 0.2], [0.33, 0.12, 0.55]], MURAL_BACK_M = null;
  function StickerBatch() { this.p = []; this.u = []; this.n = []; this.bp = []; this.bc = []; this.bn = []; }
  StickerBatch.prototype.add = function (cx, cy, cz, nx, nz, s, i) {
    var rx = nz, rz = -nx, h = s / 2, q = stkUV(i), o = 0.06;
    var P0 = [cx - rx * h + nx * o, cy - h, cz - rz * h + nz * o], P1 = [cx + rx * h + nx * o, cy - h, cz + rz * h + nz * o], P2 = [cx + rx * h + nx * o, cy + h, cz + rz * h + nz * o], P3 = [cx - rx * h + nx * o, cy + h, cz - rz * h + nz * o];
    var self = this; [[P0, q[0], q[1]], [P1, q[2], q[1]], [P2, q[2], q[3]], [P0, q[0], q[1]], [P2, q[2], q[3]], [P3, q[0], q[3]]].forEach(function (v) { self.p.push(v[0][0], v[0][1], v[0][2]); self.u.push(v[1], v[2]); self.n.push(nx, 0, nz); });
    /* a painted wall panel behind every mural, so a sticker never sits on a window or glass */
    var hb = h * 1.18, ob = 0.035, bc = MURAL_BG[i % MURAL_BG.length];
    var B0 = [cx - rx * hb + nx * ob, cy - hb, cz - rz * hb + nz * ob], B1 = [cx + rx * hb + nx * ob, cy - hb, cz + rz * hb + nz * ob], B2 = [cx + rx * hb + nx * ob, cy + hb, cz + rz * hb + nz * ob], B3 = [cx - rx * hb + nx * ob, cy + hb, cz - rz * hb + nz * ob];
    [B0, B1, B2, B0, B2, B3].forEach(function (v) { self.bp.push(v[0], v[1], v[2]); self.bc.push(bc[0], bc[1], bc[2]); self.bn.push(nx, 0, nz); });
  };
  StickerBatch.prototype.mesh = function () { if (!this.p.length) return null;
    if (!MURAL_BACK_M) MURAL_BACK_M = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, polygonOffset: true, polygonOffsetFactor: -1 });
    var bg = new THREE.BufferGeometry(); bg.setAttribute("position", new THREE.Float32BufferAttribute(this.bp, 3)); bg.setAttribute("normal", new THREE.Float32BufferAttribute(this.bn, 3)); bg.setAttribute("color", new THREE.Float32BufferAttribute(this.bc, 3)); var bm = new THREE.Mesh(bg, MURAL_BACK_M); bm.receiveShadow = true; scene.add(bm); var g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.Float32BufferAttribute(this.p, 3)); g.setAttribute("uv", new THREE.Float32BufferAttribute(this.u, 2)); g.setAttribute("normal", new THREE.Float32BufferAttribute(this.n, 3)); var m = new THREE.Mesh(g, STK_MAT); m.receiveShadow = true; scene.add(m); return m; };
  function facade(kind, seed) {
    var r = rng(seed), base, frame, glass;
    if (kind === "glass") { base = "#20343a"; frame = "#9fb3b6"; glass = ["#2f5560", "#3c6773", "#284650"]; }
    else if (kind === "brick") { base = "#7a4434"; frame = "#e8e0d2"; glass = ["#24323b", "#2c3d47", "#1f2b33"]; }
    else if (kind === "stone") { base = "#d8cfbd"; frame = "#7d7462"; glass = ["#2a3a44", "#33454f", "#263540"]; }
    else { base = "#b9bcbd"; frame = "#58606a"; glass = ["#2b3a46", "#35485a", "#22303b"]; }
    var lit = [];
    var map = canvasTex(256, 256, function (g, w, h) {
      g.fillStyle = base; g.fillRect(0, 0, w, h);
      var cols = 4, rows = 4, cw = w / cols, rh = h / rows;
      for (var y = 0; y < rows; y++) for (var x = 0; x < cols; x++) {
        var px = x * cw, py = y * rh;
        if (kind === "glass") {
          g.fillStyle = glass[Math.floor(r() * 3)]; g.fillRect(px + 2, py + 2, cw - 4, rh - 4);
          g.fillStyle = "rgba(255,255,255,0.08)"; g.fillRect(px + 2, py + 2, cw - 4, (rh - 4) * 0.35);
          g.fillStyle = frame; g.fillRect(px, py + rh - 6, cw, 6);
        } else {
          g.fillStyle = frame; g.fillRect(px + 10, py + 12, cw - 20, rh - 22);
          g.fillStyle = glass[Math.floor(r() * 3)]; g.fillRect(px + 14, py + 16, cw - 28, rh - 30);
          g.fillStyle = "rgba(255,255,255,0.12)"; g.fillRect(px + 14, py + 16, cw - 28, 6);
          g.fillStyle = "rgba(0,0,0,0.18)"; g.fillRect(px + 10, py + rh - 10, cw - 20, 3);
        }
        lit.push(r() < 0.42);
      }
      if (kind === "brick") { g.fillStyle = "rgba(0,0,0,0.07)"; for (var k = 0; k < h; k += 6) g.fillRect(0, k, w, 1); }
    }, true);
    var emis = canvasTex(256, 256, function (g, w, h) {
      g.fillStyle = "#000"; g.fillRect(0, 0, w, h);
      var cw = w / 4, rh = h / 4, i = 0;
      for (var y = 0; y < 4; y++) for (var x = 0; x < 4; x++, i++) if (lit[i]) {
        g.fillStyle = ["#ffd9a0", "#fff1cf", "#cfe6ff"][i % 3];
        if (kind === "glass") g.fillRect(x * cw + 2, y * rh + 2, cw - 4, rh - 8); else g.fillRect(x * cw + 14, y * rh + 16, cw - 28, rh - 30);
      }
    }, true);
    var mat = new THREE.MeshStandardMaterial({ map: map, emissiveMap: emis, emissive: new THREE.Color(0xffffff), emissiveIntensity: 0, roughness: kind === "glass" ? 0.25 : 0.85, metalness: kind === "glass" ? 0.4 : 0.05 });
    nightMats.push(mat);
    return mat;
  }
  var M = {
    asphalt: new THREE.MeshStandardMaterial({ color: 0x232529, roughness: 0.88 }),
    tarmac: new THREE.MeshStandardMaterial({ color: 0x3a3d42, roughness: 0.95 }),
    walk: new THREE.MeshStandardMaterial({ color: 0x8f8b82, roughness: 0.9 }),
    curb: new THREE.MeshStandardMaterial({ color: 0x6d6a64, roughness: 0.9 }),
    grass: new THREE.MeshStandardMaterial({ color: 0x46612f, roughness: 1 }),
    white: new THREE.MeshStandardMaterial({ color: 0xf2f2ee, roughness: 0.5 }),
    yellow: new THREE.MeshStandardMaterial({ color: 0xf2c230, roughness: 0.6 }),
    dark: new THREE.MeshStandardMaterial({ color: 0x1c1f22, roughness: 0.6, metalness: 0.3 }),
    metal: new THREE.MeshStandardMaterial({ color: 0x9aa0a6, roughness: 0.35, metalness: 0.8 }),
    floor: new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.22, metalness: 0.05 }),
    shopFloor: new THREE.MeshStandardMaterial({ color: 0xd9d3c7, roughness: 0.4 }),
    wall: new THREE.MeshStandardMaterial({ color: 0xcfcac0, roughness: 0.8 }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0x9fd3d8, roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.22, depthWrite: false }),
    neon: new THREE.MeshStandardMaterial({ color: 0xff3d8b, emissive: 0xff3d8b, emissiveIntensity: 0.6, roughness: 0.4 }),
    wood: new THREE.MeshStandardMaterial({ color: 0x8a6040, roughness: 0.7 }),
    counter: new THREE.MeshStandardMaterial({ color: 0x24282b, roughness: 0.35, metalness: 0.2 }),
    seat: new THREE.MeshStandardMaterial({ color: 0x2b3440, roughness: 0.6 }),
    leaf: new THREE.MeshStandardMaterial({ color: 0x4f7a33, roughness: 0.9, flatShading: true }),
    trunk: new THREE.MeshStandardMaterial({ color: 0x5a4030, roughness: 0.9 }),
    bulb: new THREE.MeshStandardMaterial({ color: 0xfff4d6, emissive: 0xffe2a8, emissiveIntensity: 0, roughness: 0.3 })
  };
  M.floor.map = canvasTex(512, 512, function (g, w, h) { g.fillStyle = '#a9a49a'; g.fillRect(0, 0, w, h); var r = rng(4); for (var y = 0; y < 4; y++) for (var x = 0; x < 4; x++) { var v = 160 + Math.floor(r() * 22); g.fillStyle = 'rgb(' + v + ',' + (v - 4) + ',' + (v - 12) + ')'; g.fillRect(x * 128 + 2, y * 128 + 2, 124, 124); } }, true);
  M.floor.map.repeat.set(40, 30);
  M.shopFloor.map = M.floor.map;

  function box(w, h, d, mat, x, y, z, opts) {
    var m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    m.position.set(x, y, z);
    if (!opts || opts.shadow !== false) { m.castShadow = true; m.receiveShadow = true; }
    scene.add(m);
    return m;
  }
  function plane(w, d, mat, x, y, z) {
    var m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), mat);
    m.rotation.x = -Math.PI / 2; m.position.set(x, y, z); m.receiveShadow = true; scene.add(m); return m;
  }
  function signTex(text, opt) {
    opt = opt || {};
    var w = opt.w || 1024, h = opt.h || 192;
    return canvasTex(w, h, function (g) {
      g.fillStyle = opt.bg || "#0b0d0b"; g.fillRect(0, 0, w, h);
      if (opt.bar) { g.fillStyle = opt.bar; g.fillRect(0, h - 12, w, 12); }
      g.fillStyle = opt.fg || "#ff3d8b";
      var size = opt.size || 86;
      g.font = (opt.weight || 800) + " " + size + "px Unbounded, 'Arial Black', sans-serif";
      while (g.measureText(text).width > w * 0.9 && size > 20) { size -= 4; g.font = (opt.weight || 800) + " " + size + "px Unbounded, 'Arial Black', sans-serif"; }
      g.textAlign = "center"; g.textBaseline = "middle";
      g.fillText(text, w / 2, h / 2 + (opt.sub ? -size * 0.25 : 2));
      if (opt.sub) { g.font = "600 " + Math.round(size * 0.36) + "px 'JetBrains Mono', monospace"; g.fillStyle = opt.subfg || "#ffffff"; g.fillText(opt.sub, w / 2, h / 2 + size * 0.5); }
    });
  }
  var dynSigns = [];
  function sign(textFn, wid, hei, x, y, z, ry, opt) {
    var mat = new THREE.MeshStandardMaterial({ map: signTex(typeof textFn === "function" ? textFn() : textFn, opt), emissive: new THREE.Color(0xffffff), emissiveIntensity: 0.25, roughness: 0.5 });
    mat.emissiveMap = mat.map;
    var m = new THREE.Mesh(new THREE.PlaneGeometry(wid, hei), mat);
    m.position.set(x, y, z); m.rotation.y = ry || 0; scene.add(m);
    if (typeof textFn === "function") dynSigns.push({ m: m, fn: textFn, opt: opt });
    nightMats.push(mat);
    return m;
  }
  function refreshSigns() {
    dynSigns.forEach(function (s) { var t = signTex(s.fn(), s.opt); s.m.material.map.dispose(); s.m.material.map = t; s.m.material.emissiveMap = t; s.m.material.needsUpdate = true; });
  }

  /* ================= Collision ================= */
  var COL = [], MAPB = [];
  function solid(x1, x2, z1, z2, tag) { var c = { x1: Math.min(x1, x2), x2: Math.max(x1, x2), z1: Math.min(z1, z2), z2: Math.max(z1, z2), on: true, tag: tag || "" }; COL.push(c); return c; }
  function collide(p, r) {
    for (var i = 0; i < COL.length; i++) {
      var c = COL[i]; if (!c.on) continue;
      var cx = clamp(p.x, c.x1, c.x2), cz = clamp(p.z, c.z1, c.z2), dx = p.x - cx, dz = p.z - cz, d2 = dx * dx + dz * dz;
      if (d2 < r * r) {
        if (d2 > 1e-8) { var d = Math.sqrt(d2), k = (r - d) / d; p.x += dx * k; p.z += dz * k; }
        else {
          var l = p.x - c.x1, rr = c.x2 - p.x, t = p.z - c.z1, b = c.z2 - p.z, mn = Math.min(l, rr, t, b);
          if (mn === l) p.x = c.x1 - r; else if (mn === rr) p.x = c.x2 + r; else if (mn === t) p.z = c.z1 - r; else p.z = c.z2 + r;
        }
      }
    }
  }

  /* ================= Interiors (fade when inside) ================= */
  var ROOMS = [];
  function room(x1, x2, z1, z2, meshes) { var r = { x1: x1, x2: x2, z1: z1, z2: z2, meshes: meshes, inside: false }; ROOMS.push(r); return r; }
  function fadeMesh(m, a) {
    if (!m.userData.mat0) { m.userData.mat0 = m.material; m.userData.matF = m.material.clone(); m.userData.matF.transparent = true; m.userData.matF.depthWrite = false; }
    if (a >= 0.999) { m.material = m.userData.mat0; m.castShadow = m.userData.cs !== undefined ? m.userData.cs : m.castShadow; }
    else { m.userData.matF.opacity = a; m.material = m.userData.matF; }
  }

  var NPCS = [], ZONES = [], CITY = null;
  /* ================= City style: each city looks different ================= */
  var CS = (function () {
    var EU = ["stone", "stone", "brick", "stone"], US = ["glass", "brick", "stone", "concrete", "glass"], ASIA = ["glass", "glass", "concrete", "glass"], DES = ["stone", "concrete", "glass", "stone"];
    var T = {
      JFK: [1.45, US, "spire", "City Spire", "BROADWAY"], ORD: [1.3, US, "spire", "Lakeside Spire", "MICHIGAN AVE"], ATL: [1.1, US, "spire", "Peach Tower", "PEACHTREE ST"],
      LAX: [0.8, US, "dome", "Hilltop Observatory", "SUNSET BLVD"], SFO: [1.0, US, "gate", "Bay Bridge Tower", "MARKET ST"], MIA: [0.9, US, "lighthouse", "Ocean Lighthouse", "OCEAN DRIVE"],
      LAS: [0.9, US, "needle", "Desert Needle", "THE STRIP"], SEA: [1.0, US, "needle", "Sky Needle", "PIKE ST"], YYZ: [1.2, US, "needle", "Lake Tower", "YONGE ST"],
      MEX: [0.8, DES, "column", "Golden Angel Column", "REFORMA AVE"], GRU: [1.1, US, "column", "Liberty Column", "PAULISTA AVE"],
      LHR: [0.75, EU, "clock", "Clock Tower", "OXFORD ST"], CDG: [0.55, EU, "lattice", "Iron Tower", "CHAMPS AVE"], FRA: [1.15, ["glass", "stone", "glass"], "twin", "Twin Bank Towers", "MAIN QUAY"],
      MAD: [0.65, EU, "arch", "Royal Gate", "GRAN VIA"], FCO: [0.5, EU, "arena", "Old Arena", "VIA ROMA"], IST: [0.7, EU, "dome", "Grand Dome", "BOSPHORUS AVE"],
      CAI: [0.6, DES, "pyramid", "Great Pyramid", "NILE CORNICHE"], JNB: [1.0, US, "needle", "Hill Tower", "COMMISSIONER ST"], LOS: [0.85, DES, "column", "Unity Column", "MARINA RD"],
      DXB: [1.6, ["glass", "glass", "stone"], "supertall", "Sky Tower", "SHEIKH ZAYED RD"], DOH: [1.25, ["glass", "stone", "glass"], "supertall", "Pearl Tower", "CORNICHE ST"],
      DEL: [0.7, DES, "arch", "Victory Gate", "RAJPATH"], DAC: [0.85, ["concrete", "brick", "stone"], "arch", "Martyrs Arch", "MIRPUR RD"],
      BKK: [1.05, ASIA, "pagoda", "Golden Pagoda", "SUKHUMVIT RD"], SIN: [1.3, ASIA, "trio", "Marina Trio", "ORCHARD RD"], HKG: [1.55, ASIA, "twin", "Harbour Twins", "NATHAN RD"],
      PEK: [0.95, ASIA, "pagoda", "Temple of Heaven", "CHANG'AN AVE"], ICN: [1.15, ASIA, "needle", "Hill Tower", "GANGNAM-DAERO"], NRT: [1.15, ASIA, "lattice", "Red Tower", "GINZA DORI"],
      SYD: [1.0, US, "sails", "Harbour Sails", "GEORGE ST"]
    };
    var c = (AIR[G.city] || AIR.JFK).code, d = T[c] || T.JFK;
    return { hm: d[0], kinds: d[1], lm: d[2], lmName: d[3], street: d[4], seed: hash(c) };
  })();
  /* ================= World: city ================= */
  var CITY_X1 = -150, CITY_X2 = 66;
  plane(1400, 1400, M.grass, 200, -0.02, 0);
  plane(CITY_X2 - CITY_X1 + 60, 14, M.asphalt, (CITY_X1 + CITY_X2) / 2 - 20, 0, 0);
  /* the expressway now runs right up to the city's east edge */
  plane(66, 14, M.asphalt, -232, 0.001, 0);
  [-1, 1].forEach(function (sgn) { box(66, 0.16, 4.2, M.walk, -232, 0.08, sgn * 9.1, { shadow: false }).receiveShadow = true; });
  var laneTex = canvasTex(512, 64, function (g, w, h) {
    g.clearRect(0, 0, w, h);
    g.fillStyle = "#f3c63a"; g.fillRect(0, 29, w, 3); g.fillRect(0, 34, w, 3);
  }, true);
  laneTex.repeat.set(30, 1);
  var lane = plane(CITY_X2 - CITY_X1 + 60, 1.2, new THREE.MeshStandardMaterial({ map: laneTex, transparent: true, roughness: 0.9 }), (CITY_X1 + CITY_X2) / 2 - 20, 0.012, 0);
  var dashTex = canvasTex(256, 16, function (g, w, h) { g.clearRect(0, 0, w, h); g.fillStyle = "#e9e9e3"; g.fillRect(0, 5, w * 0.45, 6); }, true);
  dashTex.repeat.set(60, 1);
  [-3.6, 3.6].forEach(function (z) { var d = plane(CITY_X2 - CITY_X1 + 60, 0.25, new THREE.MeshStandardMaterial({ map: dashTex, transparent: true }), (CITY_X1 + CITY_X2) / 2 - 20, 0.013, z); });
  [[-25], [20]].forEach(function (cw) {
    for (var k = -5; k <= 5; k += 1.25) { var s = plane(3, 0.6, M.white, cw[0], 0.014, k); }
  });
  [-1, 1].forEach(function (sgn) {
    box(CITY_X2 - CITY_X1 + 60, 0.16, 4.2, M.walk, (CITY_X1 + CITY_X2) / 2 - 20, 0.08, sgn * 9.1, { shadow: false }).receiveShadow = true;
    box(CITY_X2 - CITY_X1 + 60, 0.18, 0.25, M.curb, (CITY_X1 + CITY_X2) / 2 - 20, 0.09, sgn * 7.05, { shadow: false }).receiveShadow = true;
  });

  var lampGeo = new THREE.CylinderGeometry(0.07, 0.1, 6, 8), armGeo = new THREE.BoxGeometry(1.4, 0.08, 0.08), headGeo = new THREE.BoxGeometry(0.5, 0.12, 0.28), poolTex = canvasTex(128, 128, function (g, w, h) { var gr = g.createRadialGradient(w / 2, h / 2, 2, w / 2, h / 2, w / 2); gr.addColorStop(0, "rgba(255,214,150,0.85)"); gr.addColorStop(1, "rgba(255,214,150,0)"); g.fillStyle = gr; g.fillRect(0, 0, w, h); });
  var poolMat = new THREE.MeshBasicMaterial({ map: poolTex, transparent: true, depthWrite: false, opacity: 0, blending: THREE.AdditiveBlending });
  for (var lx = CITY_X1 + 6; lx < CITY_X2 - 4; lx += 22) {
    [-1, 1].forEach(function (sgn) {
      var z = sgn * 7.6;
      var pole = new THREE.Mesh(lampGeo, M.dark); pole.position.set(lx, 3, z); pole.castShadow = true; scene.add(pole);
      var arm = new THREE.Mesh(armGeo, M.dark); arm.position.set(lx, 5.95, z - sgn * 0.6); arm.rotation.y = Math.PI / 2; scene.add(arm);
      var hd = new THREE.Mesh(headGeo, M.bulb); hd.position.set(lx, 5.88, z - sgn * 1.2); hd.rotation.y = Math.PI / 2; scene.add(hd);
      var pool = new THREE.Mesh(new THREE.PlaneGeometry(9, 9), poolMat); pool.rotation.x = -Math.PI / 2; pool.position.set(lx, 0.03, z - sgn * 1.6); scene.add(pool);
      solid(lx - 0.15, lx + 0.15, z - 0.15, z + 0.15);
    });
  }
  var QUEENS = [], QSTREETS = [];
  (function () {
    var r = rng(4242), fac = canvasTex(128, 128, function (g, w, h) { g.fillStyle = "#ffffff"; g.fillRect(0, 0, w, h); for (var i = 0; i < 900; i++) { g.fillStyle = "rgba(0,0,0," + (Math.random() * 0.05) + ")"; g.fillRect(Math.random() * w, Math.random() * h, 2, 2); } for (var y = 0; y < 2; y++) for (var x = 0; x < 2; x++) { g.fillStyle = "#e9e4d6"; g.fillRect(14 + x * 60, 16 + y * 60, 40, 34); g.fillStyle = "#33414f"; g.fillRect(17 + x * 60, 19 + y * 60, 34, 28); g.fillStyle = "rgba(255,255,255,0.18)"; g.fillRect(17 + x * 60, 19 + y * 60, 14, 12); } }, true);
    var houses = [], streetM = M.asphalt;
    [[-330, -48], [128, 330]].forEach(function (band) {
      for (var bx = -236; bx < 40; bx += 58) for (var bz = band[0]; bz < band[1] - 20; bz += 52) {
        for (var hx = 0; hx < 3; hx++) for (var hz = 0; hz < 2; hz++) {
          if (r() < 0.12) continue;
          var w = 9 + r() * 5, d = 9 + r() * 4, h = 6 + Math.floor(r() * 3) * 3.3, x = bx + 6 + hx * 15 + w / 2, z = bz + 6 + hz * 20 + d / 2;
          if (x + w / 2 > bx + 50 || z + d / 2 > bz + 46) continue;
          houses.push([x, z, w, d, h, bx, bz, hx]);
        }
        plane(58, 6, streetM, bx + 25, 0.004, bz + 49); plane(6, 52, streetM, bx + 53, 0.004, bz + 23); QSTREETS.push([bx - 4, bz + 49, bx + 54, bz + 49], [bx + 53, bz - 3, bx + 53, bz + 49]);
      }
    });
    var geo = new THREE.BoxGeometry(1, 1, 1); geo.translate(0, 0.5, 0);
    var tri = new THREE.Shape(); tri.moveTo(-0.5, 0); tri.lineTo(0.5, 0); tri.lineTo(0, 1); tri.lineTo(-0.5, 0);
    var prism = new THREE.ExtrudeGeometry(tri, { depth: 1, bevelEnabled: false }); prism.translate(0, 0, -0.5);
    var N = houses.length, im = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ map: fac, roughness: 0.85 }), N), roofs = new THREE.InstancedMesh(prism, new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.85 }), N), flat = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ color: 0x55504a, roughness: 0.9 }), N);
    var doors = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ color: 0x3a2a20, roughness: 0.6 }), N), steps = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ color: 0xa09a90, roughness: 0.9 }), N), yw = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ color: 0xe9e4d8, roughness: 0.9 }), N * 4), lawn = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ color: 0x4f7d3a, roughness: 1 }), N);
    var m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), q90 = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI / 2), col = new THREE.Color(), hid = new THREE.Vector3(0, -60, 0), tiny = new THREE.Vector3(0.001, 0.001, 0.001);
    var PALQ = [0xd9cfbd, 0xb9785c, 0xc9c3b6, 0xe6dfcf, 0x9a6a52, 0xd0b48c, 0xa9a49a], RFQ = [0x6b4a3e, 0x4a4f57, 0x7a3b2e, 0x5a5650, 0x3f4a3c];
    function put(mesh, k, x, y, z, sx, sy, sz, rot) { m4.compose(new THREE.Vector3(x, y, z), rot || q, new THREE.Vector3(sx, sy, sz)); mesh.setMatrixAt(k, m4); }
    function hide(mesh, k) { m4.compose(hid, q, tiny); mesh.setMatrixAt(k, m4); }
    houses.forEach(function (hs, i) {
      var x = hs[0], z = hs[1], w = hs[2], d = hs[3], h = hs[4], bx = hs[5], bz = hs[6], hx = hs[7], gable = h < 10 || i % 4 !== 0;
      put(im, i, x, 0, z, w, h, d); im.setColorAt(i, col.setHex(PALQ[i % PALQ.length]));
      if (gable) { var along = w > d; put(roofs, i, x, h, z, along ? d + 0.8 : w + 0.8, Math.min(w, d) * 0.38, along ? w + 0.8 : d + 0.8, along ? q90 : q); hide(flat, i); }
      else { put(flat, i, x, h, z, w + 0.4, 0.5, d + 0.4); hide(roofs, i); }
      roofs.setColorAt(i, col.setHex(RFQ[(i * 7) % RFQ.length]));
      put(doors, i, x, 0.3, z + d / 2 + 0.03, 1.15, 2.2, 0.1); put(steps, i, x, 0, z + d / 2 + 0.6, 1.9, 0.3, 1.2);
      /* front yard: lawn and a low wall with a gate at the door */
      var lx1 = Math.max(x - w / 2 - 1.4, bx + 5.6 + hx * 15), lx2 = Math.min(x + w / 2 + 1.4, bx + 5.6 + (hx + 1) * 15 - 0.4, bx + 49.4), fz = z + d / 2, yz = Math.min(fz + 3, bz + 45.4), gw = 0.9;
      if (yz - fz < 1.2) { hide(yw, i * 4); hide(yw, i * 4 + 1); hide(yw, i * 4 + 2); hide(yw, i * 4 + 3); hide(lawn, i); }
      else {
        put(lawn, i, (lx1 + lx2) / 2, 0, (fz + yz) / 2, lx2 - lx1, 0.03, yz - fz);
        put(yw, i * 4, (lx1 + x - gw) / 2, 0, yz, x - gw - lx1, 0.9, 0.2); put(yw, i * 4 + 1, (x + gw + lx2) / 2, 0, yz, lx2 - x - gw, 0.9, 0.2);
        put(yw, i * 4 + 2, lx1, 0, (fz + yz) / 2, 0.2, 0.9, yz - fz); put(yw, i * 4 + 3, lx2, 0, (fz + yz) / 2, 0.2, 0.9, yz - fz);
        solid(lx1, x - gw, yz - 0.12, yz + 0.12); solid(x + gw, lx2, yz - 0.12, yz + 0.12);
      }
      solid(x - w / 2, x + w / 2, z - d / 2, z + d / 2, "bld"); QUEENS.push([x - w / 2, x + w / 2, z - d / 2, z + d / 2]);
    });
    [im, roofs, flat, doors, steps, yw, lawn].forEach(function (m) { m.castShadow = true; m.receiveShadow = true; scene.add(m); });
    var qsb = new StickerBatch(); houses.forEach(function (hs, i) { if (i % 3) return; var x = hs[0], z = hs[1], w = hs[2], d = hs[3], h = hs[4], sz = Math.min(1.7, w * 0.22); qsb.add(x + (i % 2 ? 1 : -1) * w * 0.27, Math.min(h - sz / 2 - 0.3, 2.9), z + d / 2, 0, 1, sz, (i * 7) % STK_N); if (i % 6 === 0) qsb.add(x - w / 2, Math.min(h - 1.4, 3.4), z, -1, 0, Math.min(2.2, d * 0.3), (i * 3 + 5) % STK_N); }); qsb.mesh();
    /* street trees along the cross streets */
    var tpos = []; [[-330, -48], [128, 330]].forEach(function (band) { for (var bx = -236; bx < 40; bx += 58) for (var bz = band[0]; bz < band[1] - 20; bz += 52) for (var tx = 6; tx < 50; tx += 11) tpos.push([bx + tx, bz + 53]); });
    var tgeo = new THREE.CylinderGeometry(0.15, 0.22, 2.6, 6); tgeo.translate(0, 1.3, 0); var cgeo = new THREE.IcosahedronGeometry(1.7, 1); cgeo.translate(0, 3.6, 0);
    var trI = new THREE.InstancedMesh(tgeo, M.trunk, tpos.length), crI = new THREE.InstancedMesh(cgeo, M.leaf, tpos.length);
    tpos.forEach(function (t, i) { var s2 = 0.85 + (i % 5) * 0.08; put(trI, i, t[0], 0, t[1], 1, s2, 1); put(crI, i, t[0], 0, t[1], s2, s2, s2); solid(t[0] - 0.25, t[0] + 0.25, t[1] - 0.25, t[1] + 0.25); });
    trI.castShadow = crI.castShadow = true; scene.add(trI); scene.add(crI);
    sign("QUEENS", 10, 1.4, -200, 5.2, -9.3, 0, { bg: "#0f5d36", fg: "#ffffff", size: 80, w: 1024, h: 140 });
    sign("JFK AIRPORT  \u2192", 12, 1.4, -170, 5.2, 9.3, Math.PI, { bg: "#0f5d36", fg: "#ffffff", size: 80, w: 1024, h: 140 });
  })();
  function tree(x, z, s) {
    var t = new THREE.Mesh(new THREE.CylinderGeometry(0.12 * s, 0.18 * s, 2.4 * s, 6), M.trunk); t.position.set(x, 1.2 * s, z); t.castShadow = true; scene.add(t);
    var c = new THREE.Mesh(new THREE.IcosahedronGeometry(1.5 * s, 1), M.leaf); c.position.set(x, 3.2 * s, z); c.castShadow = true; scene.add(c);
    var c2 = new THREE.Mesh(new THREE.IcosahedronGeometry(1.1 * s, 1), M.leaf); c2.position.set(x + 0.6 * s, 3.9 * s, z + 0.3 * s); c2.castShadow = true; scene.add(c2);
    box(1.3, 0.35, 1.3, M.curb, x, 0.25, z, { shadow: false });
    solid(x - 0.65, x + 0.65, z - 0.65, z + 0.65);
  }
  for (var tx = CITY_X1 + 17; tx < CITY_X2 - 4; tx += 22) { tree(tx, -9.8, 1); tree(tx + 4, 9.8, 0.95); }

  function building(x1, x2, z1, z2, h, kind, seed) {
    return null;
    if (seed !== 23 && seed !== 31) { var br = rng(seed * 7 + CS.seed); kind = CS.kinds[Math.floor(br() * CS.kinds.length)]; h = clamp(h * CS.hm * (0.75 + br() * 0.5), 9, 120); }
    else h = clamp(h * (0.7 + CS.hm * 0.3), 12, 90);
    var w = x2 - x1, d = z2 - z1, mat = facade(kind, seed + CS.seed % 50);
    var geo = new THREE.BoxGeometry(w, h, d);
    var uv = geo.attributes.uv, pos = geo.attributes.position, nor = geo.attributes.normal;
    for (var i = 0; i < uv.count; i++) {
      var nx = Math.abs(nor.getX(i)), ny = Math.abs(nor.getY(i));
      if (ny > 0.5) { uv.setXY(i, 0.02, 0.02); continue; }
      var horiz = nx > 0.5 ? pos.getZ(i) + d / 2 : pos.getX(i) + w / 2;
      uv.setXY(i, horiz / 12, (pos.getY(i) + h / 2) / 14);
    }
    var m = new THREE.Mesh(geo, mat); m.position.set((x1 + x2) / 2, h / 2, (z1 + z2) / 2); m.castShadow = true; m.receiveShadow = true; scene.add(m);
    box(w + 0.6, 0.5, d + 0.6, M.dark, (x1 + x2) / 2, h + 0.25, (z1 + z2) / 2);
    solid(x1, x2, z1, z2, "bld");
    MAPB.push({ x1: x1, x2: x2, z1: z1, z2: z2, k: kind });
    return m;
  }
  building(-150, -118, -32, -11.2, 22, "brick", 3);
  building(-150, -120, 11.2, 34, 30, "stone", 5);
  building(-116, -84, 11.2, 30, 18, "brick", 7);
  building(-46, -20, 11.2, 34, 38, "glass", 9);
  building(12, 38, 11.2, 34, 52, "glass", 13);
  building(-16, 4, -30, -11.2, 26, "concrete", 17);
  building(8, 30, -34, -11.2, 44, "brick", 19);
  building(34, 62, -30, -11.2, 16, "stone", 21);

  /* City hall / land office (now a real building in the city) */
  (function () {
    return;
    var x1 = -116, x2 = -84, z2 = -11.2, z1 = -36;
    building(x1, x2, z1, z2 - 4, 16, "stone", 23);
    for (var i = 0; i < 6; i++) { var c = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.6, 10, 16), M.white); c.position.set(x1 + 4 + i * 4.8, 5, z2 - 1.6); c.castShadow = true; scene.add(c); solid(c.position.x - 0.6, c.position.x + 0.6, z2 - 2.2, z2 - 1); }
    box(x2 - x1, 1.4, 4, M.white, (x1 + x2) / 2, 10.7, z2 - 1.8);
    for (var s = 0; s < 3; s++) box(x2 - x1 - 2, 0.2, 1.2 - s * 0.3, M.walk, (x1 + x2) / 2, 0.1 + s * 0.2, z2 - 0.2 - s * 0.3, { shadow: false });
    sign("CITY HALL", 16, 2, (x1 + x2) / 2, 12.4, z2 - 3.79, 0, { bg: "#f2efe6", fg: "#1a1d1a", size: 92, w: 1024, h: 128 });
  })();

  /* Enterable shops */
  function shop(x1, x2, depth, h, title, sub, color, interior) {
    return;
    var z2 = -11.2, z1 = z2 - depth, w = x2 - x1, cx = (x1 + x2) / 2, t = 0.3, door = 3.2;
    MAPB.push({ x1: x1, x2: x2, z1: z1, z2: z2, k: "shop" });
    var wallMat = new THREE.MeshStandardMaterial({ color: color, roughness: 0.75 });
    var ms = [];
    ms.push(box(w, h, t, wallMat, cx, h / 2, z1));
    ms.push(box(t, h, depth, wallMat, x1, h / 2, z1 + depth / 2));
    ms.push(box(t, h, depth, wallMat, x2, h / 2, z1 + depth / 2));
    var side = (w - door) / 2;
    ms.push(box(side, 1, t, wallMat, x1 + side / 2, 0.5, z2));
    ms.push(box(side, 1, t, wallMat, x2 - side / 2, 0.5, z2));
    ms.push(box(w, h - 3.4, t, wallMat, cx, 3.4 + (h - 3.4) / 2, z2));
    var gl1 = box(side, 2.4, 0.06, M.glass, x1 + side / 2, 2.2, z2, { shadow: false }); ms.push(gl1);
    var gl2 = box(side, 2.4, 0.06, M.glass, x2 - side / 2, 2.2, z2, { shadow: false }); ms.push(gl2);
    var roof = box(w + 0.4, 0.4, depth + 0.4, M.dark, cx, h + 0.2, z1 + depth / 2); ms.push(roof);
    var awn = box(w, 0.15, 1.6, new THREE.MeshStandardMaterial({ color: 0x111411, roughness: 0.6 }), cx, 3.55, z2 + 0.8); ms.push(awn);
    var sg = sign(title, w * 0.8, w * 0.8 * 0.1875, cx, 4.6, z2 + 0.17, 0, { sub: sub, size: 92 }); ms.push(sg);
    plane(w - 0.6, depth - 0.6, M.shopFloor, cx, 0.17, z1 + depth / 2);
    var lamp = new THREE.PointLight(0xfff2d8, 0.8, 22, 2); lamp.position.set(cx, h - 0.8, z1 + depth / 2); scene.add(lamp);
    solid(x1 - t / 2, x2 + t / 2, z1 - t / 2, z1 + t / 2, "bld");
    solid(x1 - t / 2, x1 + t / 2, z1, z2, "bld");
    solid(x2 - t / 2, x2 + t / 2, z1, z2, "bld");
    solid(x1, x1 + side, z2 - t / 2, z2 + t / 2);
    solid(x2 - side, x2, z2 - t / 2, z2 + t / 2);
    if (interior) interior(x1, x2, z1, z2, ms);
    room(x1, x2, z1, z2 + 0.2, ms);
  }
  shop(-80, -60, 16, 6.5, "FRESH MART", "GROCERY  \u00b7  OPEN 24 HOURS", 0xe9e4d8, function (x1, x2, z1, z2, ms) {
    var cx = (x1 + x2) / 2, foods = [0xe0523f, 0xf0c33c, 0x6aa84f, 0x3d85c6, 0xff9f43, 0xffffff];
    for (var r = 0; r < 3; r++) {
      var sx = x1 + 3.5 + r * 5.2, sz = z1 + 7;
      box(1.1, 2, 7, M.white, sx, 1.17, sz); solid(sx - 0.55, sx + 0.55, sz - 3.5, sz + 3.5);
      for (var lv = 0; lv < 3; lv++) for (var k = 0; k < 9; k++) {
        [-1, 1].forEach(function (sd) {
          var it = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.3, 0.6), new THREE.MeshStandardMaterial({ color: foods[(r * 7 + lv * 3 + k + (sd > 0 ? 2 : 0)) % foods.length], roughness: 0.6 }));
          it.position.set(sx + sd * 0.62, 0.6 + lv * 0.6, sz - 3 + k * 0.75); scene.add(it);
        });
      }
    }
    box(4, 1.05, 1.1, M.counter, x2 - 4, 0.7, z2 - 3.4); solid(x2 - 6, x2 - 2, z2 - 3.95, z2 - 2.85);
    box(0.5, 0.35, 0.4, M.dark, x2 - 4.8, 1.4, z2 - 3.4);
    NPCS.push({ kind: "man", x: x2 - 4, z: z2 - 4.6, yaw: 0, tint: 0x2e6b3a, anim: "Idle" });
    ZONES.push({ id: "grocery", x: x2 - 4, z: z2 - 2.1, r: 1.8 });
  });
  shop(-56, -42, 12, 6, "GLOBAL TRAVEL", "VISAS  \u00b7  FLIGHTS  \u00b7  TOURS", 0xdfe5e8, function (x1, x2, z1, z2) {
    var cx = (x1 + x2) / 2;
    box(5, 1.05, 1.1, M.counter, cx, 0.7, z1 + 4); solid(cx - 2.5, cx + 2.5, z1 + 3.45, z1 + 4.55);
    var map = new THREE.Mesh(new THREE.PlaneGeometry(9, 3.6), new THREE.MeshStandardMaterial({ map: signTex("FLY ANYWHERE", { w: 1024, h: 410, bg: "#0b0d0b", sub: "31 AIRPORTS  \u00b7  REAL FLIGHT TIMES", size: 110 }), roughness: 0.6 }));
    map.position.set(cx, 3.2, z1 + 0.2); scene.add(map);
    NPCS.push({ kind: "woman", x: cx, z: z1 + 2.8, yaw: 0, anim: "Idle", tint: 0x3a4d8a });
    ZONES.push({ id: "agency", x: cx, z: z1 + 5.4, r: 1.9 });
  });
  /* Office tower lobby door */
  (function () {
    return;
    building(-38, -20, -40, -11.2, 64, "glass", 31);
    box(6, 3.4, 0.2, M.glass, -29, 1.8, -11.05, { shadow: false });
    sign("SUMMIT TOWER", 12, 1.4, -29, 4.6, -11.0, 0, { bg: "#111411", fg: "#ffffff", size: 80, w: 1024, h: 120 });
  })();

  /* Global Travel: the travel agency right next to the airport terminal */
  (function () {
    var x1 = 49, x2 = 63, z1 = -29, z2 = -12, cx = (x1 + x2) / 2, h = 9;
    var wall = new THREE.MeshStandardMaterial({ color: 0xe8ecef, roughness: 0.6 }), blue = new THREE.MeshStandardMaterial({ color: 0x1f5fa8, roughness: 0.5 });
    box(x2 - x1, h, z2 - z1 - 1, wall, cx, h / 2, (z1 + z2) / 2 - 0.5);
    box(x2 - x1 + 0.6, 0.5, z2 - z1 + 0.2, blue, cx, h + 0.25, (z1 + z2) / 2 - 0.4);
    box(x2 - x1 - 2, h - 2.6, 0.1, M.glass, cx, (h - 2.6) / 2 + 2.2, z2 - 0.95, { shadow: false });
    box(3, 2.6, 0.12, new THREE.MeshStandardMaterial({ color: 0x0d2a4a, roughness: 0.3, metalness: 0.4 }), cx, 1.3, z2 - 0.93);
    box(x2 - x1, 0.22, 2.4, M.dark, cx, 3.1, z2 + 0.2);
    for (var s2 = 0; s2 < 2; s2++) box(5 - s2, 0.15, 1.2 - s2 * 0.4, M.walk, cx, 0.075 + s2 * 0.15, z2 + 0.2 - s2 * 0.2, { shadow: false });
    sign("GLOBAL TRAVEL", 11, 1.6, cx, 7.6, z2 - 0.88, 0, { bg: "#0d2a4a", fg: "#ffffff", size: 96, w: 1024, h: 150, sub: "FLIGHTS  ·  VISAS  ·  TOURS", subfg: "#ff3d8b" });
    var globe = new THREE.Mesh(new THREE.SphereGeometry(1.4, 24, 16), new THREE.MeshStandardMaterial({ color: 0x3a8ee6, roughness: 0.4, metalness: 0.2 })); globe.position.set(x2 - 2, h + 2, z2 - 3); scene.add(globe);
    var ringG = new THREE.Mesh(new THREE.TorusGeometry(1.75, 0.07, 8, 40), new THREE.MeshStandardMaterial({ color: 0xff3d8b })); ringG.position.copy(globe.position); ringG.rotation.x = 1.2; scene.add(ringG);
    solid(x1, x2, z1, z2 - 0.9, "bld");
    MAPB.push({ x1: x1, x2: x2, z1: z1, z2: z2, k: "shop" });
  })();

  /* Parking + taxi */
  (function () {
    plane(32, 18, M.asphalt, -63, 0.02, 20.2);
    for (var i = 0; i < 6; i++) plane(0.15, 5, M.white, -76 + i * 5.2, 0.03, 16.6);
    sign("TAXI RANK", 6, 0.9, -63, 2.8, 11.6, Math.PI, { bg: "#f2c230", fg: "#111", size: 90, w: 768, h: 116 });
  })();

  /* Tunnel portal at east end of avenue */
  (function () {
    var x = 66;
    box(2, 9, 34, new THREE.MeshStandardMaterial({ color: 0x6f6a62, roughness: 0.9 }), x + 1, 4.5, 0);
    box(4, 5.6, 14, new THREE.MeshBasicMaterial({ color: 0x050505 }), x + 0.2, 2.8, 0, { shadow: false });
    sign("AIRPORT  \u2191  TERMINAL", 12, 1.1, x - 0.01, 7, 0, -Math.PI / 2, { bg: "#0f4d2a", fg: "#ffffff", size: 74, w: 1024, h: 96 });
    solid(x, x + 2, -17, -7); solid(x, x + 2, 7, 17); solid(x - 0.5, x + 2, -7, 7, "tunnel");
  })();

  /* Street name sign */
  sign(function () { return here().city.toUpperCase() + "  \u00b7  " + CS.street; }, 4.5, 0.6, -25, 4.2, 7.3, Math.PI, { bg: "#0f5d36", fg: "#fff", size: 70, w: 768, h: 100 });

  /* ================= World: airport ================= */
  var AX1 = 80, AX2 = 160, AZ = 40, AH = 15;
  var airportLink = { x: 72, z: 0 };
  (function () {
    plane(16, 2 * AZ, M.walk, 72, 0.04, 0);
    plane(AX2 - AX1, AZ * 2, M.floor, (AX1 + AX2) / 2, 0.05, 0);
    var shell = [], frameMat = new THREE.MeshStandardMaterial({ color: 0xe9ecee, roughness: 0.4, metalness: 0.3 });
    function gw(w, h, d, x, y, z) { var m = box(w, h, d, M.glass, x, y, z, { shadow: false }); shell.push(m); return m; }
    gw(0.1, AH, 2 * AZ, AX2, AH / 2, 0);
    var sideGap = 5;
    gw(0.1, AH - 3.4, 2 * AZ, AX1, 3.4 + (AH - 3.4) / 2, 0);
    gw(0.1, 3.4, AZ - sideGap, AX1, 1.7, -(AZ + sideGap) / 2);
    gw(0.1, 3.4, AZ - sideGap, AX1, 1.7, (AZ + sideGap) / 2);
    gw(AX2 - AX1, AH, 0.1, (AX1 + AX2) / 2, AH / 2, -AZ);
    gw(AX2 - AX1, AH, 0.1, (AX1 + AX2) / 2, AH / 2, AZ);
    for (var fx = AX1; fx <= AX2; fx += 8) { [-AZ, AZ].forEach(function (z) { shell.push(box(0.35, AH, 0.35, frameMat, fx, AH / 2, z)); }); }
    for (var fz = -AZ; fz <= AZ; fz += 6) { [AX1, AX2].forEach(function (x) { shell.push(box(0.35, AH, 0.35, frameMat, x, AH / 2, fz)); }); }
    var roof = box(AX2 - AX1 + 6, 0.8, 2 * AZ + 6, new THREE.MeshStandardMaterial({ color: 0xdfe3e6, roughness: 0.5, metalness: 0.2 }), (AX1 + AX2) / 2, AH + 0.4, 0); shell.push(roof);
    for (var bx = AX1 + 6; bx < AX2; bx += 10) shell.push(box(0.5, 0.9, 2 * AZ, frameMat, bx, AH - 0.4, 0));
    var canopy = box(14, 0.4, 26, frameMat, AX1 - 7, 6, 0); shell.push(canopy);
    sign(function () { var a = here(); return a.name.toUpperCase(); }, 30, 3.2, AX1 - 0.3, AH - 2.6, 0, -Math.PI / 2, { bg: "#0b0d0b", fg: "#ffffff", size: 78, w: 1500, h: 160, sub: "", bar: "#ff3d8b" });
    sign(function () { return here().code + "  \u00b7  " + here().city.toUpperCase(); }, 12, 1.4, AX1 - 7, 6.9, -12.8, 0, { size: 80, w: 1024, h: 120 });
    solid(AX1 - 0.1, AX1 + 0.1, -AZ, -sideGap / 2); solid(AX1 - 0.1, AX1 + 0.1, sideGap / 2, AZ);
    solid(AX2 - 0.1, AX2 + 0.1, -AZ, 10); solid(AX2 - 0.1, AX2 + 0.1, 14, AZ); solid(AX2 + 0.15, AX2 + 0.35, 10, 14);
    solid(AX1, AX2, -AZ - 0.1, -AZ + 0.1); solid(AX1, AX2, AZ - 0.1, AZ + 0.1);
    room(AX1, AX2, -AZ, AZ, shell);
    var lights = [[100, -10], [130, 8], [146, -10]];
    lights.forEach(function (l) { var pl = new THREE.PointLight(0xffffff, 0.6, 60, 2); pl.position.set(l[0], AH - 2, l[1]); scene.add(pl); });

    var guide = new THREE.MeshStandardMaterial({ color: 0xff3d8b, emissive: 0xff3d8b, emissiveIntensity: 0.35, roughness: 0.4 });
    plane(AX2 - AX1 - 4, 0.25, guide, (AX1 + AX2) / 2, 0.06, 1.6);
    plane(0.25, 10.4, guide, 156, 0.061, 6.6);
    var glassP = new THREE.MeshStandardMaterial({ color: 0xbfd6e2, transparent: true, opacity: 0.32, roughness: 0.05, metalness: 0.1, depthWrite: false }), chrome = new THREE.MeshStandardMaterial({ color: 0xc9ced3, roughness: 0.25, metalness: 0.8 });
    var wood = new THREE.MeshStandardMaterial({ color: 0x8a6446, roughness: 0.6 }), navy = new THREE.MeshStandardMaterial({ color: 0x1a2b4d, roughness: 0.5 }), white = new THREE.MeshStandardMaterial({ color: 0xf1f2ef, roughness: 0.45 });
    var beltM = new THREE.MeshStandardMaterial({ color: 0x1b2a5c, roughness: 0.6 });
    /* low glass partition with a steel rail on top (replaces the old solid walls) */
    function glassRun(x, z1, z2) { var L = z2 - z1, cz = (z1 + z2) / 2; box(0.06, 1.25, L, glassP, x, 0.72, cz, { shadow: false }); box(0.1, 0.06, L, chrome, x, 1.36, cz, { shadow: false }); box(0.12, 0.1, L, chrome, x, 0.06, cz, { shadow: false }); for (var pz = z1; pz <= z2 + 0.01; pz += 2.5) box(0.08, 1.4, 0.08, chrome, x, 0.7, pz, { shadow: false }); solid(x - 0.15, x + 0.15, z1, z2); }
    /* queue lane posts with a belt between them */
    function lane(x1, x2, z) { for (var x = x1; x <= x2 + 0.01; x += Math.max(2, (x2 - x1) / 4)) { var p = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.07, 0.98, 10), chrome); p.position.set(x, 0.49, z); scene.add(p); } box(x2 - x1, 0.06, 0.03, beltM, (x1 + x2) / 2, 0.9, z, { shadow: false }); }
    /* an airport chair you can sit on: faces +z when yaw = 0 */
    var seatPad = new THREE.MeshStandardMaterial({ color: 0x2f3b4c, roughness: 0.55 }), seatZones = [];
    var CHAIRS = [], seatedN = 0;
    function aChair(x, z, yaw, taken) {
      CHAIRS.push([x, z, yaw]);
      var sp = sitSpot(x, z, yaw, 0.21);
      if (taken && seatedN >= 12) taken = false;
      if (taken) seatedN++;
      if (taken) NPCS.push({ kind: Math.random() < 0.5 ? "man" : "woman", x: sp.x, z: sp.z, yaw: yaw, anim: Math.random() < 0.4 ? "SitTalk" : "Sit", y: 0.035 });
      else seatZones.push({ id: "sit", x: x + Math.sin(yaw) * 0.55, z: z + Math.cos(yaw) * 0.55, r: 0.75, seat: { x: sp.x, z: sp.z, yaw: yaw, anim: "Sit" } });
    }
    function chairRow(x1, n, z, yaw, takenEvery) { for (var i = 0; i < n; i++) aChair(x1 + i * 0.62, z, yaw, takenEvery && (i * 7 + Math.round(z)) % takenEvery === 0); var ln = n * 0.62; box(ln, 0.06, 0.12, chrome, x1 + ln / 2 - 0.31, 0.05, z + Math.cos(yaw) * 0.1, { shadow: false }); solid(x1 - 0.3, x1 + ln - 0.32, z - 0.26, z + 0.26); }
    function plantPot(x, z) { var pot = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.35, 0.8, 14), white); pot.position.set(x, 0.4, z); scene.add(pot); var lf = new THREE.Mesh(new THREE.IcosahedronGeometry(0.75, 1), M.leaf); lf.position.set(x, 1.4, z); scene.add(lf); solid(x - 0.45, x + 0.45, z - 0.45, z + 0.45); }
    function hangSign(text, x, z, ry, w, opt) { sign(text, w || 6, 0.8, x, 4.6, z, ry || 0, opt || { bg: "#0b0d0b", fg: "#ffcf5a", size: 80, w: 1024, h: 136 }); box(0.04, 3, 0.04, chrome, x - (w || 6) / 2 * Math.cos(ry || 0) * 0.9, 6.5, z, { shadow: false }); box(0.04, 3, 0.04, chrome, x + (w || 6) / 2 * Math.cos(ry || 0) * 0.9, 6.5, z, { shadow: false }); }

    /* ---------- entrance security outside the doors: everyone is screened before entering ---------- */
    var EX = AX1 - 3;
    box(0.3, 2.5, 0.3, archMatE(), EX, 1.25, -1.15); box(0.3, 2.5, 0.3, archMatE(), EX, 1.25, 1.15); box(0.3, 0.32, 2.6, archMatE(), EX, 2.55, 0);
    function archMatE() { return chrome; }
    box(3.4, 0.85, 1.0, M.dark, EX - 0.4, 0.43, -3.5); box(1.3, 1.15, 1.15, white, EX - 0.4, 1.2, -3.5); box(1.32, 0.5, 0.06, M.dark, EX - 0.4, 1.05, -2.92, { shadow: false });
    solid(EX - 2.2, EX + 1.4, -4.1, -2.9); solid(EX - 0.2, EX + 0.2, -2.9, -1.3); solid(EX - 0.2, EX + 0.2, 1.3, 2.9);
    box(1.8, 1.0, 0.7, M.counter, EX + 1.6, 0.5, 3.3); solid(EX + 0.7, EX + 2.5, 2.95, 3.65);
    glassRun(EX, -12, -2.9); glassRun(EX, 2.9, 12);
    [-12, 12].forEach(function (gz) { box(AX1 - EX, 1.25, 0.06, glassP, (EX + AX1) / 2, 0.72, gz, { shadow: false }); box(AX1 - EX, 0.06, 0.1, chrome, (EX + AX1) / 2, 1.36, gz, { shadow: false }); solid(EX, AX1, gz - 0.15, gz + 0.15); });
    sign("ENTRANCE SECURITY", 7, 0.8, EX - 0.2, 3.3, 0, -Math.PI / 2, { bg: "#c0392b", fg: "#ffffff", size: 80, w: 1024, h: 116 });
    sign("ALL VISITORS · BAG & BODY SCAN", 7, 0.5, EX - 0.2, 2.75, 0, -Math.PI / 2, { bg: "#0b0d0b", fg: "#ff3d8b", size: 60, w: 1024, h: 74 });
    NPCS.push({ kind: "officer", x: EX + 1.6, z: 2.6, yaw: -Math.PI / 2, anim: "Idle" }); NPCS.push({ kind: "officer", x: EX + 0.6, z: -2.4, yaw: -Math.PI / 2, anim: "Idle" });
    blockEntry = solid(EX - 0.2, EX + 0.2, -1.3, 1.3, "entrysec"); blockEntry.mesh = box(0.08, 0.08, 2.4, M.yellow, EX + 0.35, 1, 0, { shadow: false });
    ZONES.push({ id: "entrySec", x: EX - 1.8, z: 0, r: 2 });
    plane(12, 26, M.floor, EX + 1, 0.045, 0);

    /* ---------- check-in hall ---------- */
    [-16, -26].forEach(function (cz, isl) {
      for (var c = 0; c < 4; c++) {
        var x = 88 + c * 5;
        box(3.6, 1.1, 1.2, M.counter, x, 0.6, cz); box(3.6, 0.06, 1.3, M.neon, x, 1.16, cz, { shadow: false });
        box(1.2, 0.35, 0.9, M.metal, x + 1.9, 0.35, cz + 0.8);
        box(0.5, 0.35, 0.05, M.dark, x - 0.6, 1.4, cz - 0.3, { shadow: false });
        sign("CHECK-IN " + (isl * 4 + c + 1), 3.2, 0.5, x, 2.8, cz - 0.65, 0, { size: 80, w: 768, h: 120 });
        if (!(isl === 0 && c === 2) && (isl === 0 || c % 2 === 0)) NPCS.push({ kind: c % 2 ? "man" : "woman", x: x, z: cz - 1.0, yaw: 0, anim: c % 3 ? "Idle" : "Interact", tint: 0x0f3a6b });
      }
      solid(86, 106, cz - 0.6, cz + 0.6);
      box(22, 0.5, 0.9, M.dark, 96, 0.25, cz - 1.9); for (var r2 = 0; r2 < 11; r2++) box(0.05, 0.02, 0.88, M.metal, 86 + r2 * 2, 0.51, cz - 1.9, { shadow: false });
      box(22, 1.4, 0.1, white, 96, 2.0, cz - 2.5);
      sign("EARTHPASS AIR", 10, 1.0, 96, 3.3, cz - 2.44, 0, { bg: "#0b0d0b", fg: "#ff3d8b", size: 86, w: 1024, h: 104 });
    });
    sign("CHECK-IN", 10, 1.2, 96, 7.5, -20, 0, { size: 96, w: 1024, h: 124 });
    NPCS.push({ kind: "woman", x: 98, z: -17.0, yaw: 0, anim: "Idle", tint: 0x0f3a6b });
    ZONES.push({ id: "checkin", x: 98, z: -13.8, r: 2.2 });
    lane(87, 105, -11); lane(87, 105, -9); lane(87, 105, -21.5);
    /* self check-in kiosks */
    for (var k = 0; k < 5; k++) { var kx = 86 + k * 4.2; box(0.7, 1.1, 0.5, white, kx, 0.55, -5.5); var scr = box(0.62, 0.46, 0.05, new THREE.MeshStandardMaterial({ color: 0x0b1a2a, emissive: 0x1a6aff, emissiveIntensity: 0.45 }), kx, 1.35, -5.3, { shadow: false }); scr.rotation.x = -0.35; solid(kx - 0.35, kx + 0.35, -5.75, -5.25); }
    sign("SELF CHECK-IN", 6, 0.6, 94.4, 2.6, -5.85, 0, { size: 76, w: 1024, h: 102 });
    /* ticket desk (book flights here too) */
    box(6, 1.1, 1.2, M.counter, 89, 0.6, 26); box(6, 0.06, 1.3, M.neon, 89, 1.16, 26, { shadow: false }); solid(86, 92, 25.4, 26.6);
    box(6.4, 2.6, 0.1, white, 89, 2.4, 27.6); sign("AIRLINE TICKETS · GLOBAL TRAVEL", 6, 0.6, 89, 3.4, 27.5, Math.PI, { bg: "#0d2a4a", fg: "#ffffff", size: 56, w: 1024, h: 104 });
    NPCS.push({ kind: "woman", x: 87.8, z: 26.9, yaw: Math.PI, anim: "Idle", tint: 0x0d2a4a }); NPCS.push({ kind: "man", x: 90.4, z: 26.9, yaw: Math.PI, anim: "Talk", tint: 0x0d2a4a });
    ZONES.push({ id: "ticketDesk", x: 89, z: 24.2, r: 2 }); lane(86, 92, 21.8);
    /* information desk */
    var info = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 1.05, 24, 1, true, 0, Math.PI * 1.4), M.counter); info.position.set(97, 0.53, 9); info.rotation.y = 2.2; scene.add(info); solid(95.5, 98.5, 7.5, 10.5);
    NPCS.push({ kind: "woman", x: 97, z: 9.2, yaw: Math.PI / 2 + 0.6, anim: "Talk", tint: 0x2e7d4f }); sign("i  INFORMATION", 5, 0.6, 97, 3.2, 9, -Math.PI / 2, { bg: "#2e7d4f", fg: "#ffffff", size: 70, w: 768, h: 92 });
    /* landside cafe with tables you can sit at */
    box(8, 1.1, 1.1, wood, 103, 0.55, 37); box(8, 0.06, 1.2, white, 103, 1.12, 37, { shadow: false }); solid(99, 107, 36.4, 37.6);
    box(8.4, 3, 0.1, new THREE.MeshStandardMaterial({ color: 0x3a2a20 }), 103, 2.2, 39.6); sign("SKY CAFE · COFFEE · BAKERY", 7, 0.7, 103, 3.2, 39.5, Math.PI, { bg: "#3a2a20", fg: "#ffd89a", size: 66, w: 1024, h: 102 });
    NPCS.push({ kind: "woman", x: 101.5, z: 38.2, yaw: Math.PI, anim: "Interact" }); NPCS.push({ kind: "man", x: 104.5, z: 38.2, yaw: Math.PI, anim: "Idle" });
    ZONES.push({ id: "airCafe", x: 103, z: 35.2, r: 2 });
    [[99, 31], [103, 31], [107, 31], [101, 27.5], [105, 27.5]].forEach(function (t, i) { var tb = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.05, 20), white); tb.position.set(t[0], 0.75, t[1]); scene.add(tb); var lg = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.75, 8), chrome); lg.position.set(t[0], 0.38, t[1]); scene.add(lg); solid(t[0] - 0.5, t[0] + 0.5, t[1] - 0.5, t[1] + 0.5); aChair(t[0], t[1] - 0.95, 0, i === 1); aChair(t[0], t[1] + 0.95, Math.PI, i === 3); });
    /* landside seats */
    chairRow(86, 12, 14, Math.PI, 5); chairRow(86, 12, 16.2, 0, 4);
    plantPot(84, 3.5); plantPot(84, -3.5); plantPot(108, 18); plantPot(108, -36);

    /* ---------- departure security: three lanes, glass partitions ---------- */
    var SX = 112;
    glassRun(SX, -AZ, -2.2); glassRun(SX, 2.2, AZ);
    var archMat = new THREE.MeshStandardMaterial({ color: 0xd8dcdf, roughness: 0.4, metalness: 0.3 });
    [0, -12, 12].forEach(function (lz) {
      box(0.3, 2.4, 0.3, archMat, SX, 1.2, lz - 1.1); box(0.3, 2.4, 0.3, archMat, SX, 1.2, lz + 1.1); box(0.3, 0.3, 2.5, archMat, SX, 2.5, lz);
      box(4, 0.9, 1, M.dark, SX - 1, 0.45, lz - 3.4); box(1.4, 1.2, 1.2, archMat, SX - 1, 1.2, lz - 3.4); for (var tr = 0; tr < 3; tr++) box(0.55, 0.08, 0.4, new THREE.MeshStandardMaterial({ color: 0x5a6b7a }), SX - 2.6 + tr * 0.6, 0.94, lz - 3.4);
      solid(SX - 3, SX + 1, lz - 3.9, lz - 2.9);
      NPCS.push({ kind: "officer", x: SX + 1.6, z: lz - 2.6, yaw: -Math.PI / 2, anim: "Idle" });
      if (lz) { sign("LANE CLOSED", 2.6, 0.4, SX - 0.2, 3.0, lz, -Math.PI / 2, { bg: "#7a1a1a", fg: "#fff", size: 70, w: 512, h: 80 }); solid(SX - 0.25, SX + 0.25, lz - 1.1, lz + 1.1); lane(SX - 9, SX - 3.5, lz - 1.5); lane(SX - 9, SX - 3.5, lz + 1.5); }
    });
    scanLight = box(0.05, 0.05, 2.0, M.neon, SX, 2.3, 0, { shadow: false });
    sign("SECURITY", 9, 1.1, SX - 0.25, 5, 0, -Math.PI / 2, { size: 96, w: 1024, h: 124 });
    blockSec = solid(SX - 0.25, SX + 0.25, -2.2, 2.2, "security");
    var barMesh = box(0.08, 0.08, 4.2, M.yellow, SX + 0.4, 1, 0, { shadow: false }); blockSec.mesh = barMesh;
    ZONES.push({ id: "security", x: SX - 2, z: 0, r: 2 });
    lane(SX - 10, SX - 3.5, -1.6); lane(SX - 10, SX - 3.5, 1.6);

    /* ---------- passport control: glass booths in a row, no walls ---------- */
    var IX = 128;
    function booth(bz, live) {
      box(1.9, 1.1, 1.4, navy, IX, 0.55, bz); box(2.0, 0.05, 1.5, white, IX, 1.12, bz, { shadow: false });
      box(2.0, 1.1, 0.05, glassP, IX, 1.7, bz + (bz < 0 ? 0.72 : -0.72), { shadow: false });
      box(0.05, 2.4, 2.4, glassP, IX - 1.0, 1.2, bz + (bz < 0 ? -0.5 : 0.5), { shadow: false }); box(0.05, 2.4, 2.4, glassP, IX + 1.0, 1.2, bz + (bz < 0 ? -0.5 : 0.5), { shadow: false });
      box(2.1, 0.1, 2.5, white, IX, 2.45, bz + (bz < 0 ? -0.5 : 0.5));
      var lamp = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), new THREE.MeshBasicMaterial({ color: live ? 0x30ff60 : 0xff3030 })); lamp.position.set(IX - 0.9, 2.65, bz); scene.add(lamp);
      solid(IX - 1.0, IX + 1.0, bz - (bz < 0 ? 1.7 : 0.7), bz + (bz < 0 ? 0.7 : 1.7));
      if (!live && Math.abs(bz) < 12) NPCS.push({ kind: "officer", x: IX - 0.3, z: bz - (bz < 0 ? 0.65 : -0.65), yaw: bz < 0 ? 0 : Math.PI, anim: "Idle" });
    }
    booth(-4.2, true); booth(4.2, false); booth(-11, false); booth(11, false); booth(-18, false); booth(18, false);
    glassRun(IX, -AZ, -19.7); glassRun(IX, 19.7, AZ); glassRun(IX, -9.3, -5.9); glassRun(IX, 5.9, 9.3); glassRun(IX, -16.3, -12.7); glassRun(IX, 12.7, 16.3);
    solid(IX - 0.25, IX + 0.25, -12.7, -9.3); solid(IX - 0.25, IX + 0.25, 9.3, 12.7); solid(IX - 0.25, IX + 0.25, -19.7, -16.3); solid(IX - 0.25, IX + 0.25, 16.3, 19.7);
    sign("PASSPORT CONTROL", 11, 1.1, IX - 0.25, 5, 0, -Math.PI / 2, { size: 92, w: 1024, h: 110 });
    sign("ALL PASSPORTS  ▸", 5, 0.5, IX - 0.25, 3.2, 0, -Math.PI / 2, { bg: "#0b0d0b", fg: "#ff3d8b", size: 60, w: 768, h: 78 });
    blockImm = solid(IX - 0.25, IX + 0.25, -2.2, 2.2, "immigration");
    var bar2 = box(0.08, 0.08, 4.2, M.yellow, IX + 0.4, 1, 0, { shadow: false }); blockImm.mesh = bar2;
    NPCS.push({ kind: "officer", x: IX - 0.3, z: -4.05, yaw: 0, anim: "Idle" });
    ZONES.push({ id: "immigration", x: IX - 2.2, z: 0, r: 2 });
    lane(IX - 9, IX - 2.6, -1.8); lane(IX - 9, IX - 2.6, 1.8);

    /* ---------- airside: duty free, food court, gate lounge ---------- */
    /* duty free */
    plane(20, 11, new THREE.MeshStandardMaterial({ color: 0x2a2420, roughness: 0.4 }), 144, 0.052, -33.5);
    box(20, 2.4, 0.5, wood, 144, 1.2, -AZ + 0.6); var prodCols = [0xd4af37, 0xc0392b, 0x1f5fa8, 0xf4f4f2, 0x8e44ad, 0x2e7d4f, 0xe67e22];
    for (var sh = 0; sh < 3; sh++) for (var pi = 0; pi < 16; pi++) box(0.32, 0.36, 0.22, new THREE.MeshStandardMaterial({ color: prodCols[(sh * 5 + pi) % prodCols.length], roughness: 0.35, metalness: 0.2 }), 135 + pi * 1.2, 0.7 + sh * 0.65, -AZ + 1.0, { shadow: false });
    [[139, -33], [149, -33]].forEach(function (t) { box(4, 0.9, 1.6, white, t[0], 0.45, t[1]); for (var b = 0; b < 8; b++) box(0.18, 0.3, 0.18, new THREE.MeshStandardMaterial({ color: prodCols[b % prodCols.length], roughness: 0.2, metalness: 0.4 }), t[0] - 1.6 + b * 0.45, 1.05, t[1] + (b % 2 ? 0.3 : -0.3), { shadow: false }); solid(t[0] - 2, t[0] + 2, t[1] - 0.8, t[1] + 0.8); });
    box(5, 1.05, 1, M.counter, 144, 0.53, -29); solid(141.5, 146.5, -29.5, -28.5);
    NPCS.push({ kind: "woman", x: 143, z: -29.9, yaw: 0, anim: "Interact", tint: 0x6b1f3a }); NPCS.push({ kind: "man", x: 145.2, z: -29.9, yaw: 0, anim: "Idle", tint: 0x6b1f3a }); NPCS.push({ kind: "woman", x: 136, z: -34.5, yaw: Math.PI / 2, anim: "Talk", tint: 0x6b1f3a });
    sign("DUTY FREE", 10, 1.3, 144, 5.0, -27.2, 0, { bg: "#6b1f3a", fg: "#ffe7b0", size: 100, w: 1024, h: 132 });
    ZONES.push({ id: "dutyFree", x: 144, z: -27, r: 2 });
    /* food court */
    [["BURGERS", 137, 0xc0392b], ["NOODLES", 144, 0xe67e22], ["COFFEE", 151, 0x5a3a24]].forEach(function (f) {
      box(5.6, 1.1, 1.1, new THREE.MeshStandardMaterial({ color: f[2], roughness: 0.5 }), f[1], 0.55, AZ - 2.2); box(5.8, 0.06, 1.2, white, f[1], 1.12, AZ - 2.2, { shadow: false }); solid(f[1] - 2.8, f[1] + 2.8, AZ - 2.8, AZ - 1.6);
      sign(f[0], 5, 0.8, f[1], 3.1, AZ - 0.6, Math.PI, { bg: "#" + f[2].toString(16).padStart(6, "0"), fg: "#ffffff", size: 90, w: 768, h: 124 });
      NPCS.push({ kind: Math.random() < 0.5 ? "man" : "woman", x: f[1], z: AZ - 1.2, yaw: Math.PI, anim: "Interact" });
    });
    ZONES.push({ id: "foodCourt", x: 144, z: AZ - 4.2, r: 2.2 });
    [[137, 30], [142, 30], [147, 30], [152, 30], [139.5, 26.5], [149.5, 26.5]].forEach(function (t, i) { var tb = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.05, 1.2), white); tb.position.set(t[0], 0.75, t[1]); scene.add(tb); var lg = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.75, 8), chrome); lg.position.set(t[0], 0.38, t[1]); scene.add(lg); solid(t[0] - 0.6, t[0] + 0.6, t[1] - 0.6, t[1] + 0.6); aChair(t[0], t[1] - 1.0, 0, i % 2 === 0); aChair(t[0], t[1] + 1.0, Math.PI, i === 3); });
    /* gate lounge: rows of chairs you can sit on */
    for (var row = 0; row < 4; row++) chairRow(135.6, 24, -18 + row * 4.4, 0, row % 2 ? 6 : 5);
    for (var row2 = 0; row2 < 2; row2++) chairRow(135.6, 24, 4 + row2 * 2.2, row2 ? 0 : Math.PI, 0);
    seatZones.forEach(function (z) { ZONES.push(z); });
    /* all chairs drawn as a few instanced meshes */
    (function () {
      var parts = [[new THREE.BoxGeometry(0.52, 0.08, 0.5), seatPad, [[0, 0.44, 0, 0]]], [new THREE.BoxGeometry(0.52, 0.55, 0.07), seatPad, [[0, 0.74, -0.24, -0.1]]], [new THREE.BoxGeometry(0.05, 0.05, 0.44), chrome, [[-0.29, 0.62, -0.02, 0], [0.29, 0.62, -0.02, 0]]], [new THREE.BoxGeometry(0.04, 0.6, 0.04), chrome, [[-0.29, 0.3, 0.1, 0], [0.29, 0.3, 0.1, 0]]]];
      var mm = new THREE.Matrix4(), mg = new THREE.Matrix4(), ml = new THREE.Matrix4(), e = new THREE.Euler();
      parts.forEach(function (pt) {
        var im = new THREE.InstancedMesh(pt[0], pt[1], CHAIRS.length * pt[2].length), n = 0;
        CHAIRS.forEach(function (c) { mg.makeRotationY(c[2]).setPosition(c[0], 0.02, c[1]); pt[2].forEach(function (o) { e.set(o[3], 0, 0); ml.makeRotationFromEuler(e).setPosition(o[0], o[1], o[2]); mm.multiplyMatrices(mg, ml); im.setMatrixAt(n++, mm); }); });
        im.castShadow = true; im.receiveShadow = true; scene.add(im);
      });
    })();
    /* gate podium, boarding pass e-gate and gate signs */
    box(2.6, 1.1, 1.0, M.counter, 152.5, 0.55, 8.4); box(2.7, 0.06, 1.1, M.neon, 152.5, 1.12, 8.4, { shadow: false }); solid(151.2, 153.8, 7.9, 8.9);
    NPCS.push({ kind: "woman", x: 152.0, z: 7.6, yaw: 0, anim: "Idle", tint: 0x0f3a6b }); NPCS.push({ kind: "man", x: 153.2, z: 7.6, yaw: 0, anim: "Talk", tint: 0x0f3a6b });
    [10.6, 13.4].forEach(function (gz) { box(0.5, 1.05, 0.3, white, 157.6, 0.53, gz); });
    egateFlaps = [box(0.05, 0.7, 0.9, glassP, 157.6, 0.75, 11.55, { shadow: false }), box(0.05, 0.7, 0.9, glassP, 157.6, 0.75, 12.45, { shadow: false })];
    var egScr = box(0.3, 0.2, 0.04, new THREE.MeshStandardMaterial({ color: 0x07121c, emissive: 0x20ff60, emissiveIntensity: 0.5 }), 157.6, 1.15, 10.6, { shadow: false }); egScr.rotation.y = -Math.PI / 2;
    sign("GATE B12", 6, 1, 157.5, 5.4, 12, -Math.PI / 2, { size: 100, w: 768, h: 128 });
    boardSign = sign(function () { return G.trip ? G.trip.no + "  ·  " + (AIR[G.trip.to] || here()).city.toUpperCase() : "NO DEPARTURES"; }, 8, 0.9, 157.5, 4.2, 12, -Math.PI / 2, { bg: "#000", fg: "#ffcf5a", size: 72, w: 1024, h: 116 });
    box(0.3, 0.5, 4, new THREE.MeshStandardMaterial({ color: 0x2b2f36 }), AX2 - 0.4, 2.95, 12);
    [["GATE B10 · CLOSED", -24], ["GATE B11 · LATER", -8], ["GATE B14 · CLOSED", 22]].forEach(function (gs) { sign(gs[0], 6, 0.8, 157.5, 4.6, gs[1], -Math.PI / 2, { bg: "#0b0d0b", fg: "#9aa3ab", size: 62, w: 1024, h: 136 }); });
    plantPot(134, 9.5); plantPot(158, -36); plantPot(158, 36); plantPot(133.5, -22);
    sign("→ GATES B10–B14  ·  ← DUTY FREE  ·  FOOD COURT →", 14, 0.7, 131, 4.8, 0, -Math.PI / 2, { bg: "#0b0d0b", fg: "#ffcf5a", size: 54, w: 1536, h: 76 });
    ZONES.push({ id: "gate", x: 156, z: 12, r: 2.2 });
    ZONES.push({ id: "exit", x: AX1 + 3, z: 0, r: 2.2 });
    /* jet bridge */
    var jb = new THREE.MeshStandardMaterial({ color: 0xc9ced3, roughness: 0.5, metalness: 0.3 });

    /* departures board */
    depBoard = new THREE.Mesh(new THREE.PlaneGeometry(8, 4.5), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    depBoard.position.set(104, 5.5, -AZ + 0.2); scene.add(depBoard);
    var bd2 = depBoard.clone(); bd2.position.set(150, 5.5, -AZ + 0.2); scene.add(bd2); depBoard2 = bd2;
  })();
  var scanLight, blockSec, blockImm, boardSign, depBoard, depBoard2, blockEntry, egateFlaps, entryOk = false;

  scene.traverse(function (o) { if (o.isMesh && o.material && o.material.isMeshStandardMaterial && !o.material.isMeshPhysicalMaterial) o.material.envMapIntensity = o.material === M.floor ? 0.55 : 0.22; });
  /* ================= Airliner (modern wide-body, EarthPass Air livery) ================= */
  function airliner() {
    var g = new THREE.Group();
    var L0 = -21.5, L1 = 19.8, R = 2.05;
    var prof = [];
    for (var i = 0; i <= 60; i++) {
      var t = i / 60, x = L0 + t * (L1 - L0), r;
      if (x < -12) { var k = (x - L0) / (-12 - L0); r = 0.35 + (R - 0.35) * Math.pow(Math.sin(k * Math.PI / 2), 0.9); }
      else if (x > 13) { var k2 = (L1 - x) / (L1 - 13); r = R * Math.pow(k2, 0.42) * (0.98 + 0.02 * k2); }
      else r = R;
      prof.push(new THREE.Vector2(Math.max(0.02, r), x));
    }
    var geo = new THREE.LatheGeometry(prof, 48); geo.rotateZ(-Math.PI / 2);
    var pa = geo.attributes.position;
    for (var v = 0; v < pa.count; v++) { var px = pa.getX(v); if (px < -12) { var up = Math.pow((-12 - px) / (-12 - L0), 1.5) * 1.35; pa.setY(v, pa.getY(v) * (1 - up * 0.18) + up); } if (px > 15) { pa.setY(v, pa.getY(v) - Math.pow((px - 15) / (L1 - 15), 2) * 0.35); } }
    geo.computeVertexNormals();
    var liv = canvasTex(512, 2048, function (c, w, h) {
      c.fillStyle = "#f5f6f3"; c.fillRect(0, 0, w, h);
      c.fillStyle = "#3a3f44"; c.fillRect(w * 0.13, 0, w * 0.24, h);
      [[0.5, 1], [1.0, -1]].forEach(function (sd) {
        var cx = w * sd[0], up = sd[1] > 0 ? 1 : -1;
        var U = function (du) { var u = cx + up * du * w; return u >= w ? u - w : u < 0 ? u + w : u; };
        c.fillStyle = "#ff3d8b"; c.fillRect(Math.min(U(-0.075), U(-0.06)), h * 0.1, w * 0.015, h * 0.82);
        c.fillStyle = "#1a2230"; for (var y = h * 0.16; y < h * 0.84; y += 15) c.fillRect(Math.min(U(0.022), U(0.052)), y, w * 0.03, 9);
        c.strokeStyle = "rgba(0,0,0,0.35)"; c.lineWidth = 2; [0.18, 0.5, 0.82].forEach(function (d) { c.strokeRect(Math.min(U(-0.012), U(0.062)), h * d, w * 0.074, 34); });
        c.save(); c.translate(U(0.088), h * 0.55); c.rotate(Math.PI / 2); c.textAlign = "center"; c.fillStyle = "#0b0d0b"; c.font = "800 54px Unbounded, Arial Black, sans-serif"; c.fillText("EARTHPASS AIR", 0, up > 0 ? 18 : 18); c.restore();
      });
      c.fillStyle = "#121820"; for (var k = 0; k < 4; k++) { var x0 = w * 0.75 - 46 + k * 23; c.beginPath(); c.moveTo(x0, h * 0.028); c.lineTo(x0 + 20, h * 0.028); c.lineTo(x0 + 18, h * 0.046); c.lineTo(x0 - 2, h * 0.046); c.fill(); }
    });
    var bodyM = new THREE.MeshStandardMaterial({ map: liv, roughness: 0.32, metalness: 0.18 });
    var fus = new THREE.Mesh(geo, bodyM); g.add(fus);
    var white = new THREE.MeshStandardMaterial({ color: 0xf1f2ef, roughness: 0.3, metalness: 0.2 }), neon = new THREE.MeshStandardMaterial({ color: 0xff3d8b, roughness: 0.35, emissive: 0x334400, emissiveIntensity: 0.35 }), grey = new THREE.MeshStandardMaterial({ color: 0xb9bdc0, roughness: 0.4, metalness: 0.4 }), dark = new THREE.MeshStandardMaterial({ color: 0x15181b, roughness: 0.5, metalness: 0.3 });
    function wingGeo(root, tip, span, sweep, thick) {
      var s = new THREE.Shape(); s.moveTo(0, 0); s.lineTo(-root, 0); s.lineTo(-sweep - tip, span); s.lineTo(-sweep, span); s.lineTo(0, 0);
      var gg = new THREE.ExtrudeGeometry(s, { depth: thick, bevelEnabled: true, bevelThickness: thick * 0.45, bevelSize: thick * 0.45, bevelSegments: 2, curveSegments: 4 }); gg.translate(0, 0, -thick / 2); return gg;
    }
    [-1, 1].forEach(function (sd) {
      var w = new THREE.Mesh(wingGeo(8.4, 2.1, 17.5, 9.5, 0.36), white); w.rotation.x = sd > 0 ? Math.PI / 2 : -Math.PI / 2; w.rotation.y = sd * 0.0; w.position.set(5.2, -1.15, sd * 1.2);
      var wg = new THREE.Group(); wg.add(w); wg.rotation.x = sd * -0.09; g.add(wg);
      var wl = new THREE.Mesh(wingGeo(2.0, 0.7, 2.6, 1.6, 0.12), neon); wl.rotation.y = 0; wl.position.set(5.2 - 9.5 - 0.1, -1.15 + 0.05, sd * (1.2 + 17.4)); wl.rotation.x = sd > 0 ? -0.25 : 0.25; wl.position.y += 0.0; wl.rotation.z = 0; wl.scale.set(1, 1, 1); wg.add(wl);
      var nav = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 6), new THREE.MeshBasicMaterial({ color: sd > 0 ? 0x29ff6a : 0xff2a2a })); nav.position.set(5.2 - 10.5, -1.1, sd * 18.7); wg.add(nav);
      var nac = new THREE.Mesh(new THREE.LatheGeometry([new THREE.Vector2(1.18, -2.6), new THREE.Vector2(1.42, -1.6), new THREE.Vector2(1.5, 0), new THREE.Vector2(1.38, 1.6), new THREE.Vector2(1.28, 2.2)], 32).rotateZ(-Math.PI / 2), white);
      nac.position.set(4.6, -2.65, sd * 7.2); g.add(nac);
      var lip = new THREE.Mesh(new THREE.TorusGeometry(1.3, 0.1, 8, 32), grey); lip.rotation.y = Math.PI / 2; lip.position.set(6.8, -2.65, sd * 7.2); g.add(lip);
      var fan = new THREE.Mesh(new THREE.CircleGeometry(1.25, 32), dark); fan.rotation.y = Math.PI / 2; fan.position.set(6.6, -2.65, sd * 7.2); g.add(fan);
      var spin = new THREE.Mesh(new THREE.ConeGeometry(0.38, 0.8, 16).rotateZ(-Math.PI / 2), grey); spin.position.set(6.95, -2.65, sd * 7.2); g.add(spin);
      for (var b = 0; b < 14; b++) { var bl = new THREE.Mesh(new THREE.BoxGeometry(0.02, 1.1, 0.16), grey); bl.position.set(6.62, -2.65 + Math.cos(b / 14 * 6.28) * 0.7, sd * 7.2 + Math.sin(b / 14 * 6.28) * 0.7); bl.rotation.x = b / 14 * 6.28; g.add(bl); }
      var ex = new THREE.Mesh(new THREE.ConeGeometry(0.75, 1.6, 20).rotateZ(Math.PI / 2), grey); ex.position.set(1.9, -2.65, sd * 7.2); g.add(ex);
      var py = new THREE.Mesh(new THREE.BoxGeometry(4.2, 1.1, 0.35), white); py.position.set(3.9, -1.75, sd * 7.2); g.add(py);
      var hs = new THREE.Mesh(wingGeo(4.2, 1.5, 7.4, 4.2, 0.22), white); hs.rotation.x = sd > 0 ? Math.PI / 2 : -Math.PI / 2; hs.position.set(-15.6, 1.15, sd * 0.4); g.add(hs);
      for (var gw = 0; gw < 2; gw++) for (var gz = 0; gz < 2; gz++) { var wh = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.62, 0.42, 20), dark); wh.rotation.x = Math.PI / 2; wh.position.set(-0.6 + gw * 1.5, -3.15, sd * (2.4 + gz * 0.55)); g.add(wh); }
      var st = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 1.7, 8), grey); st.position.set(0.15, -2.2, sd * 2.65); g.add(st);
    });
    var vs = new THREE.Shape(); vs.moveTo(0, 0); vs.lineTo(-7.2, 0); vs.lineTo(-10.2, 8.4); vs.lineTo(-7.6, 8.6); vs.lineTo(0, 0);
    var vg = new THREE.ExtrudeGeometry(vs, { depth: 0.34, bevelEnabled: true, bevelThickness: 0.14, bevelSize: 0.14, bevelSegments: 2 }); vg.translate(0, 0, -0.17);
    var vf = new THREE.Mesh(vg, neon); vf.position.set(-12.6, 1.7, 0); g.add(vf);
    var logoT = canvasTex(256, 256, function (c, w, h) { c.clearRect(0, 0, w, h); c.strokeStyle = "#0b0d0b"; c.lineWidth = 14; c.beginPath(); c.arc(128, 128, 84, 0, 7); c.stroke(); c.beginPath(); c.ellipse(128, 128, 34, 84, 0, 0, 7); c.stroke(); c.beginPath(); c.moveTo(44, 128); c.lineTo(212, 128); c.stroke(); });
    [-1, 1].forEach(function (sd) { var lg = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 3.2), new THREE.MeshBasicMaterial({ map: logoT, transparent: true })); lg.position.set(-19.2, 6.2, sd * 0.34); if (sd < 0) lg.rotation.y = Math.PI; g.add(lg); });
    var beacon = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 6), new THREE.MeshBasicMaterial({ color: 0xff3030 })); beacon.position.set(-2, 2.1, 0); g.add(beacon); g.userData.beacon = beacon;
    var ngw = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.5, 16), dark); ngw.rotation.x = Math.PI / 2; ngw.position.set(14, -3.35, 0); g.add(ngw);
    var ngs = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 1.7, 8), grey); ngs.position.set(14, -2.5, 0); g.add(ngs);
    var bellyF = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.4, 9, 24, 1, false, Math.PI * 0.5, Math.PI), white); bellyF.rotation.z = Math.PI / 2; bellyF.scale.set(1, 1, 0.9); bellyF.position.set(1.5, -1.2, 0); g.add(bellyF);
    /* front-left passenger door (L1), open, where the jet bridge docks */
    var cabT = canvasTex(256, 480, function (c, w, h) {
      var gr = c.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, "#fff3dc"); gr.addColorStop(0.55, "#f1dfc0"); gr.addColorStop(1, "#d9c3a0"); c.fillStyle = gr; c.fillRect(0, 0, w, h);
      c.fillStyle = "#fffaf0"; c.fillRect(70, 0, 116, 24); c.fillStyle = "rgba(255,240,200,0.9)"; c.fillRect(20, 30, w - 40, 10);
      c.fillStyle = "#c9b28c"; c.beginPath(); c.moveTo(0, 0); c.lineTo(60, 70); c.lineTo(60, 360); c.lineTo(0, h); c.fill(); c.beginPath(); c.moveTo(w, 0); c.lineTo(w - 60, 70); c.lineTo(w - 60, 360); c.lineTo(w, h); c.fill();
      c.fillStyle = "#e9d6b4"; c.fillRect(60, 70, w - 120, 290);
      c.fillStyle = "#6b2bd9"; c.fillRect(92, 120, 72, 200); c.fillStyle = "#ff3d8b"; c.fillRect(92, 120, 72, 10);
      c.fillStyle = "#2b3a66"; c.beginPath(); c.moveTo(0, h); c.lineTo(60, 360); c.lineTo(w - 60, 360); c.lineTo(w, h); c.fill();
      c.fillStyle = "rgba(255,255,255,0.15)"; c.fillRect(120, 362, 16, h - 362);
      c.fillStyle = "#43507a"; [[20, 230], [w - 52, 230]].forEach(function (p) { c.fillRect(p[0], p[1], 32, 120); });
      c.fillStyle = "#1b1b20"; c.font = "700 20px Arial"; c.textAlign = "center"; c.fillText("WELCOME", w / 2, 106);
    });
    var dIn = new THREE.Mesh(new THREE.BoxGeometry(1.05, 1.95, 0.12), new THREE.MeshBasicMaterial({ map: cabT })); dIn.position.set(13.2, -0.05, -1.98); g.add(dIn);
    var dFr = new THREE.Mesh(new THREE.BoxGeometry(1.25, 2.15, 0.06), new THREE.MeshStandardMaterial({ color: 0xc9ced3, roughness: 0.4, metalness: 0.4 })); dFr.position.set(13.2, -0.05, -2.0); g.add(dFr); dIn.position.z = -2.03;
    var dP = new THREE.Group(); var dPan = new THREE.Mesh(new THREE.BoxGeometry(1.05, 1.95, 0.1), white); dP.add(dPan);
    var dOut = new THREE.Mesh(new THREE.BoxGeometry(1.1, 2.0, 0.08), new THREE.MeshStandardMaterial({ color: 0x9aa3ad, roughness: 0.4, metalness: 0.5 })); dOut.position.z = 0.012; dP.add(dOut); dPan.position.z = -0.012;
    var dWin = new THREE.Mesh(new THREE.CircleGeometry(0.13, 16), dark); dWin.position.set(0, 0.45, -0.07); dWin.rotation.y = Math.PI; dP.add(dWin);
    var dHan = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.06, 0.05), grey); dHan.position.set(-0.25, 0.0, -0.08); dP.add(dHan);
    var dStr = new THREE.Mesh(new THREE.BoxGeometry(1.06, 0.1, 0.11), new THREE.MeshStandardMaterial({ color: 0xff3d8b, roughness: 0.5 })); dStr.position.set(0, -0.32, 0); dP.add(dStr);
    g.add(dP); g.userData.doorPanel = dP;
    g.userData.setDoor = function (k) { dP.position.set(lerp(13.2, 14.45, k), -0.05, lerp(-2.1, -2.32, k)); dP.rotation.y = 0.12 * k; dIn.visible = k > 0.02; };
    g.userData.setDoor(1);
    var cabinL = new THREE.PointLight(0xfff1d6, 0.6, 6, 2); cabinL.position.set(13.2, 0.4, -0.8); g.add(cabinL);
    [1, -1].forEach(function (sd) { stick(g, sd > 0 ? 6 : 0, 1.5, -10.5, 0.35, sd * 2.1, sd); stick(g, sd > 0 ? 13 : 1, 1.2, 4.2, -2.6, sd * 8.75, sd); });
    g.userData.door = new THREE.Vector3(13.2, -1.0, -2.05);
    g.traverse(function (o) { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    return g;
  }
  /* private business jet (T-tail, rear engines) */
  function bizjet(color) {
    var g = new THREE.Group(), white = new THREE.MeshStandardMaterial({ color: 0xf3f4f1, roughness: 0.28, metalness: 0.25 }), accent = new THREE.MeshStandardMaterial({ color: color || 0xff3d8b, roughness: 0.35 }), dark = new THREE.MeshStandardMaterial({ color: 0x14181d, roughness: 0.3, metalness: 0.4 }), grey = new THREE.MeshStandardMaterial({ color: 0xb9bdc0, roughness: 0.4, metalness: 0.5 });
    var prof = []; for (var i = 0; i <= 40; i++) { var t = i / 40, x = -9 + t * 18.6, r; if (x < -5) r = 0.25 + 0.75 * Math.pow((x + 9) / 4, 0.8); else if (x > 6) r = 1.0 * Math.pow(Math.max(0, (9.6 - x) / 3.6), 0.5); else r = 1.0; prof.push(new THREE.Vector2(Math.max(0.03, r), x)); }
    var fg = new THREE.LatheGeometry(prof, 28); fg.rotateZ(-Math.PI / 2); var fus = new THREE.Mesh(fg, white); g.add(fus);
    var strip = new THREE.Mesh(new THREE.BoxGeometry(14, 0.12, 2.04), accent); strip.position.set(-0.5, -0.25, 0); g.add(strip);
    for (var w = 0; w < 6; w++) [-1, 1].forEach(function (sd) { var wi = new THREE.Mesh(new THREE.SphereGeometry(0.17, 10, 8), dark); wi.scale.set(1.3, 1, 0.3); wi.position.set(3.6 - w * 1.05, 0.18, sd * 0.97); g.add(wi); });
    var cw = new THREE.Mesh(new THREE.SphereGeometry(0.6, 14, 10, 0, Math.PI * 2, 0, Math.PI / 2), dark); cw.scale.set(1.3, 0.55, 1.05); cw.position.set(7.0, 0.35, 0); cw.rotation.z = -0.45; g.add(cw);
    function wingShape(root, tip, span, sweep, th) { var sh = new THREE.Shape(); sh.moveTo(0, 0); sh.lineTo(-root, 0); sh.lineTo(-sweep - tip, span); sh.lineTo(-sweep, span); sh.lineTo(0, 0); var ge = new THREE.ExtrudeGeometry(sh, { depth: th, bevelEnabled: false }); ge.translate(0, 0, -th / 2); return ge; }
    [-1, 1].forEach(function (sd) {
      var wg = new THREE.Mesh(wingShape(3.2, 1.0, 7.6, 2.6, 0.22), white); wg.rotation.x = sd > 0 ? Math.PI / 2 : -Math.PI / 2; wg.position.set(1.6, -0.55, sd * 0.7); g.add(wg);
      var wl = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.1, 0.08), accent); wl.position.set(-1.6, 0.0, sd * 8.25); wl.rotation.x = sd * 0.3; g.add(wl);
      var eng = new THREE.Mesh(new THREE.CylinderGeometry(0.48, 0.42, 2.6, 18), white); eng.rotation.z = Math.PI / 2; eng.position.set(-5.2, 0.55, sd * 1.55); g.add(eng);
      var ei = new THREE.Mesh(new THREE.CircleGeometry(0.42, 18), dark); ei.rotation.y = Math.PI / 2; ei.position.set(-3.89, 0.55, sd * 1.55); g.add(ei);
      var py = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.18, 0.7), white); py.position.set(-5.2, 0.5, sd * 1.05); g.add(py);
      var hs = new THREE.Mesh(wingShape(1.6, 0.8, 3.0, 1.0, 0.12), white); hs.rotation.x = sd > 0 ? Math.PI / 2 : -Math.PI / 2; hs.position.set(-7.6, 3.55, 0); g.add(hs);
      var mw = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.24, 16), dark); mw.rotation.x = Math.PI / 2; mw.position.set(0.4, -1.32, sd * 1.4); g.add(mw);
      var ms = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.8, 6), grey); ms.position.set(0.4, -0.95, sd * 1.3); g.add(ms);
    });
    var vs = new THREE.Shape(); vs.moveTo(0, 0); vs.lineTo(-2.6, 0); vs.lineTo(-3.6, 3.0); vs.lineTo(-2.4, 3.0); vs.lineTo(0, 0);
    var vg = new THREE.ExtrudeGeometry(vs, { depth: 0.2, bevelEnabled: false }); vg.translate(0, 0, -0.1); var vf = new THREE.Mesh(vg, accent); vf.position.set(-5.6, 0.7, 0); g.add(vf); stick(g, 0, 1.3, -7.6, 2.1, 0.12, 1); stick(g, 12, 1.3, -7.6, 2.1, -0.12, -1); stick(g, 7, 0.9, -5.2, 0.55, 2.05, 1); stick(g, 7, 0.9, -5.2, 0.55, -2.05, -1);
    var nw = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.18, 14), dark); nw.rotation.x = Math.PI / 2; nw.position.set(6.6, -1.38, 0); g.add(nw);
    var ns = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.75, 6), grey); ns.position.set(6.6, -1.0, 0); g.add(ns);
    var stair = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.1, 2.2), white); stair.position.set(5.0, -0.85, -1.8); stair.rotation.x = -0.65; g.add(stair);
    g.traverse(function (o) { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    return g;
  }
  /* helicopter */
  function helicopter(color) {
    var g = new THREE.Group(), body = new THREE.MeshStandardMaterial({ color: color || 0x13233f, roughness: 0.35, metalness: 0.35 }), neon = new THREE.MeshStandardMaterial({ color: 0xff3d8b, roughness: 0.4 }), glass = new THREE.MeshStandardMaterial({ color: 0x1e3446, roughness: 0.05, metalness: 0.7, transparent: true, opacity: 0.8 }), dark = new THREE.MeshStandardMaterial({ color: 0x15181b, roughness: 0.5, metalness: 0.4 }), grey = new THREE.MeshStandardMaterial({ color: 0x9aa1a8, roughness: 0.4, metalness: 0.6 });
    var cab = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 18), body); cab.scale.set(2.3, 1.25, 1.2); cab.position.set(0, 1.75, 0); g.add(cab);
    var win = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 18, 0, Math.PI * 2, 0, Math.PI * 0.55), glass); win.scale.set(1.5, 1.15, 1.12); win.rotation.z = -1.0; win.position.set(1.0, 1.85, 0); g.add(win);
    var st = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.12, 2.45), neon); st.position.set(-0.2, 1.4, 0); g.add(st);
    var boom = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.42, 5.6, 14), body); boom.rotation.z = Math.PI / 2; boom.position.set(-4.6, 2.05, 0); g.add(boom);
    var fin = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.5, 0.12), body); fin.position.set(-7.3, 2.6, 0); fin.rotation.z = -0.35; g.add(fin);
    var hst = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.08, 1.8), body); hst.position.set(-6.6, 2.05, 0); g.add(hst);
    var tr = new THREE.Group(); tr.position.set(-7.45, 2.85, 0.16); [0, 1].forEach(function (k) { var b = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.3, 0.04), dark); b.rotation.z = k * Math.PI / 2; tr.add(b); }); g.add(tr);
    var mast = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.2, 0.7, 10), grey); mast.position.set(0.1, 3.1, 0); g.add(mast);
    var rot = new THREE.Group(); rot.position.set(0.1, 3.45, 0); for (var k = 0; k < 4; k++) { var bl = new THREE.Mesh(new THREE.BoxGeometry(5.6, 0.05, 0.34), dark); bl.position.x = 2.8; var arm = new THREE.Group(); arm.rotation.y = k * Math.PI / 2; arm.add(bl); rot.add(arm); } var hub = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.2, 12), grey); rot.add(hub); g.add(rot);
    [-1, 1].forEach(function (sd) { var sk = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 4.2, 8), grey); sk.rotation.z = Math.PI / 2; sk.position.set(0.1, 0.1, sd * 1.05); g.add(sk); [-0.9, 1.0].forEach(function (x) { var s2 = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.9, 6), grey); s2.position.set(x, 0.5, sd * 0.95); s2.rotation.x = sd * 0.25; g.add(s2); }); });
    [1, -1].forEach(function (sd) { var fs = stick(g, sd > 0 ? 0 : 4, 0.85, -7.25, 2.55, sd * 0.075, sd, -0.35); fs.rotation.z = sd > 0 ? -0.35 : 0.35; stick(g, sd > 0 ? 6 : 13, 0.5, -4.0, 2.05, sd * 0.38, sd); });
    g.userData.rotor = rot; g.userData.tail = tr;
    g.traverse(function (o) { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    return g;
  }
  /* motorcycle (x forward, same wheel conventions as carMesh) */
  function motoMesh(color) {
    /* built around the seated "Drive" pose: seat under the hips, bars in the hands, pegs under the feet (rider root sits 0.35 m ahead of the bike centre, 0.29 m up) */
    var g = new THREE.Group(), paint = new THREE.MeshPhysicalMaterial({ color: color, metalness: 0.5, roughness: 0.3, clearcoat: 1 }), dark = new THREE.MeshStandardMaterial({ color: 0x111316, roughness: 0.6 }), chrome = new THREE.MeshStandardMaterial({ color: 0xd8dde2, roughness: 0.15, metalness: 0.95 });
    function rod(a, b, r, m) { var dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2], L = Math.hypot(dx, dy, dz), c = new THREE.Mesh(new THREE.CylinderGeometry(r, r, L, 8), m); c.position.set((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2); c.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(dx / L, dy / L, dz / L)); g.add(c); return c; }
    g.userData.wheels = [];
    [0.74, -0.72].forEach(function (x) { var w = new THREE.Group(); w.add(new THREE.Mesh(new THREE.TorusGeometry(0.27, 0.075, 10, 24), dark)); var hub = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.12, 12), chrome); hub.rotation.x = Math.PI / 2; w.add(hub); for (var k = 0; k < 6; k++) { var sp = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.02, 0.02), chrome); sp.rotation.z = k * Math.PI / 6; w.add(sp); } w.position.set(x, 0.34, 0); g.add(w); g.userData.wheels.push(w); });
    rod([-0.72, 0.34, 0], [-0.1, 0.62, 0], 0.035, dark); rod([-0.1, 0.62, 0], [0.52, 1.0, 0], 0.045, dark); rod([-0.1, 0.45, 0], [0.52, 1.0, 0], 0.04, dark);
    var eng = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.34, 0.26), chrome); eng.position.set(0.08, 0.46, 0); g.add(eng);
    var tank = new THREE.Mesh(new THREE.SphereGeometry(0.28, 18, 12), paint); tank.scale.set(1.2, 0.55, 0.52); tank.position.set(0.33, 0.86, 0); g.add(tank);
    var seat = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.08, 0.28), dark); seat.position.set(-0.06, 0.7, 0); g.add(seat);
    var tail = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.12, 0.2), paint); tail.position.set(-0.5, 0.72, 0); tail.rotation.z = -0.18; g.add(tail);
    var fender = new THREE.Mesh(new THREE.TorusGeometry(0.33, 0.03, 6, 16, Math.PI * 0.8), paint); fender.position.set(0.74, 0.34, 0); fender.rotation.z = Math.PI * 0.1; g.add(fender);
    [-0.06, 0.06].forEach(function (z) { rod([0.74, 0.34, z], [0.52, 1.0, z], 0.026, chrome); rod([0.52, 1.0, z], [0.37, 1.15, z * 2], 0.02, chrome); });
    var bar = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.58, 8), chrome); bar.rotation.x = Math.PI / 2; bar.position.set(0.36, 1.16, 0); g.add(bar);
    [-1, 1].forEach(function (sd) { var gr = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.026, 0.12, 8), dark); gr.rotation.x = Math.PI / 2; gr.position.set(0.36, 1.16, sd * 0.24); g.add(gr); rod([0.46, 0.34, sd * 0.12], [0.46, 0.34, sd * 0.27], 0.02, chrome); });
    var lamp = new THREE.Mesh(new THREE.SphereGeometry(0.09, 12, 8), new THREE.MeshStandardMaterial({ color: 0xfff6da, emissive: 0xfff2c8, emissiveIntensity: 0.6 })); lamp.position.set(0.64, 0.98, 0); g.add(lamp);
    var ex = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.8, 8), chrome); ex.rotation.z = Math.PI / 2 - 0.12; ex.position.set(-0.35, 0.38, 0.18); g.add(ex);
    g.userData.L = 2.0; g.userData.W = 0.8; g.userData.r = 0.34; g.userData.moto = true;
    g.traverse(function (o) { if (o.isMesh) { o.castShadow = true; } });
    return g;
  }

  /* jet bridge: a tunnel with a window band that follows pts [[x, z, y], ...] (y = floor height) */
  function jetBridge(pts, parent) {
    var grp = new THREE.Group(), wallM = new THREE.MeshStandardMaterial({ color: 0xc9ced3, roughness: 0.45, metalness: 0.35 }), floorM = new THREE.MeshStandardMaterial({ color: 0x3a3f46, roughness: 0.8 }), winM = new THREE.MeshStandardMaterial({ color: 0x9fc2d6, roughness: 0.05, metalness: 0.5, transparent: true, opacity: 0.32, depthWrite: false }), darkM = new THREE.MeshStandardMaterial({ color: 0x2b2f36, roughness: 0.6 });
    for (var i = 1; i < pts.length; i++) {
      var a = pts[i - 1], b = pts[i], dx = b[0] - a[0], dz = b[1] - a[1], dy = b[2] - a[2], hl = Math.hypot(dx, dz), L = Math.hypot(hl, dy) + 0.3;
      var seg = new THREE.Group(); seg.position.set((a[0] + b[0]) / 2, (a[2] + b[2]) / 2, (a[1] + b[1]) / 2); seg.rotation.order = "YZX"; seg.rotation.y = -Math.atan2(dz, dx); seg.rotation.z = Math.atan2(dy, hl);
      [[L, 0.16, 2.9, floorM, 0, -0.08, 0], [L, 0.2, 2.9, wallM, 0, 2.55, 0], [L, 0.95, 0.1, wallM, 0, 0.47, 1.4], [L, 0.95, 0.1, wallM, 0, 0.47, -1.4], [L, 0.95, 0.06, winM, 0, 1.42, 1.4], [L, 0.95, 0.06, winM, 0, 1.42, -1.4], [L, 0.6, 0.1, wallM, 0, 2.2, 1.4], [L, 0.6, 0.1, wallM, 0, 2.2, -1.4]].forEach(function (q) { var m = new THREE.Mesh(new THREE.BoxGeometry(q[0], q[1], q[2]), q[3]); m.position.set(q[4], q[5], q[6]); m.castShadow = q[3] !== winM; seg.add(m); });
      grp.add(seg);
      if (b[2] > 0.8) { var col = new THREE.Mesh(new THREE.BoxGeometry(0.5, b[2], 0.5), darkM); col.position.set(b[0], b[2] / 2, b[1]); grp.add(col); var wh = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.5, 0.9), darkM); wh.position.set(b[0], 0.25, b[1]); grp.add(wh); }
    }
    (parent || scene).add(grp); return grp;
  }
  var jet = airliner();
  var JET_HOME = { x: AX2 + 22 + 18.5, z: 12, yaw: Math.PI };
  function placeJet(x, y, z, yaw, pitch) { jet.position.set(x, 3.75 + y, z); jet.rotation.set(0, yaw, pitch || 0); }
  placeJet(JET_HOME.x, 0, JET_HOME.z, JET_HOME.yaw);

  /* ================= Airside: a real-looking airport (pier, stands, taxiway, runway, tower, hangar) ================= */
  var AIRSIDE = new THREE.Group(); AIRSIDE.name = "airside"; var HELI = null;
  function buildAirside() {
    var n0 = scene.children.length;
    var RWZ = 95, RW_W = 45, RWX1 = 200, RWX2 = 1040, TWZ = 48;
    var concTex = canvasTex(256, 256, function (g, w, h) { g.fillStyle = "#9a9c98"; g.fillRect(0, 0, w, h); for (var i = 0; i < 2600; i++) { var v = 140 + Math.random() * 40 | 0; g.fillStyle = "rgba(" + v + "," + v + "," + (v - 4) + ",0.25)"; g.fillRect(Math.random() * w, Math.random() * h, 2, 2); } g.strokeStyle = "rgba(60,62,60,0.45)"; g.lineWidth = 2; g.strokeRect(1, 1, w - 2, h - 2); for (var k = 0; k < 6; k++) { g.fillStyle = "rgba(40,40,40,0.06)"; g.beginPath(); g.ellipse(Math.random() * w, Math.random() * h, 20 + Math.random() * 30, 10 + Math.random() * 20, Math.random() * 3, 0, 7); g.fill(); } }, true);
    var asphTex = canvasTex(256, 256, function (g, w, h) { g.fillStyle = "#2c2e32"; g.fillRect(0, 0, w, h); for (var i = 0; i < 5000; i++) { var v = 30 + Math.random() * 35 | 0; g.fillStyle = "rgba(" + v + "," + v + "," + (v + 3) + ",0.5)"; g.fillRect(Math.random() * w, Math.random() * h, 1.5, 1.5); } g.fillStyle = "rgba(10,10,10,0.25)"; for (var k = 0; k < 30; k++) g.fillRect(Math.random() * w, Math.random() * h, 40 + Math.random() * 80, 1); }, true);
    var grassTex = canvasTex(256, 256, function (g, w, h) { g.fillStyle = "#5b7a3e"; g.fillRect(0, 0, w, h); for (var i = 0; i < 7000; i++) { var gg = 90 + Math.random() * 60 | 0; g.fillStyle = "rgba(" + (gg * 0.6 | 0) + "," + gg + "," + (gg * 0.4 | 0) + ",0.35)"; g.fillRect(Math.random() * w, Math.random() * h, 1, 3); } }, true);
    function tiled(tex, rx, ry) { var t = tex.clone(); t.needsUpdate = true; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry); return t; }
    var white = new THREE.MeshBasicMaterial({ color: 0xf2f2ee }), yellow = new THREE.MeshBasicMaterial({ color: 0xf2c418 }), red = new THREE.MeshBasicMaterial({ color: 0xc8382c });
    function flat(w, d, mat, x, z, y) { var m = plane(w, d, mat, x, y || 0.04, z); m.receiveShadow = true; return m; }
    function text(str, w, h, x, z, rot, col) { var t = canvasTex(512, 256, function (g, W, H) { g.clearRect(0, 0, W, H); g.fillStyle = col || "#f2f2ee"; g.font = "900 200px Arial Black, Arial, sans-serif"; g.textAlign = "center"; g.textBaseline = "middle"; g.fillText(str, W / 2, H / 2 + 8); }); var m = plane(w, h, new THREE.MeshBasicMaterial({ map: t, transparent: true, depthWrite: false }), x, 0.075, z); m.rotation.z = rot || 0; return m; }

    /* ground: grass airfield, concrete apron, asphalt taxiway and runway */
    flat(1500, 640, new THREE.MeshStandardMaterial({ map: tiled(grassTex, 120, 52), roughness: 1 }), AX2 + 700, 10, 0.012);
    var AP = { x1: AX2, x2: 450, z1: -100, z2: 38 };
    flat(AP.x2 - AP.x1, AP.z2 - AP.z1, new THREE.MeshStandardMaterial({ map: tiled(concTex, (AP.x2 - AP.x1) / 7.5, (AP.z2 - AP.z1) / 7.5), roughness: 0.92 }), (AP.x1 + AP.x2) / 2, (AP.z1 + AP.z2) / 2, 0.03);
    var asph = function (rx, ry) { return new THREE.MeshStandardMaterial({ map: tiled(asphTex, rx, ry), roughness: 0.95 }); };
    flat(RWX2 - 170, 23, asph((RWX2 - 170) / 12, 2), (170 + RWX2) / 2, TWZ, 0.035);
    flat(40, RWZ - TWZ, asph(3, 4), 262, (TWZ + RWZ) / 2, 0.036); flat(40, RWZ - TWZ, asph(3, 4), RWX2 - 40, (TWZ + RWZ) / 2, 0.036);
    flat(60, TWZ - AP.z2 + 4, asph(5, 2), 262, (TWZ + AP.z2) / 2, 0.034);
    flat(RWX2 - RWX1 + 60, RW_W + 6, asph((RWX2 - RWX1) / 12, 4), (RWX1 + RWX2) / 2, RWZ, 0.04);

    /* runway markings: edges, centreline, thresholds, numbers, touchdown zone, aiming points */
    flat(RWX2 - RWX1, 0.9, white, (RWX1 + RWX2) / 2, RWZ - RW_W / 2 + 0.6, 0.06); flat(RWX2 - RWX1, 0.9, white, (RWX1 + RWX2) / 2, RWZ + RW_W / 2 - 0.6, 0.06);
    for (var cx = RWX1 + 70; cx < RWX2 - 70; cx += 50) flat(30, 0.9, white, cx, RWZ, 0.062);
    [[RWX1, 1, "09"], [RWX2, -1, "27"]].forEach(function (e) {
      var x0 = e[0], s = e[1];
      for (var k = 0; k < 8; k++) { var off = 3.2 + k * 2.6; flat(30, 1.8, white, x0 + s * 18, RWZ - off, 0.062); flat(30, 1.8, white, x0 + s * 18, RWZ + off, 0.062); }
      text(e[2], 24, 12, x0 + s * 55, RWZ, s > 0 ? -Math.PI / 2 : Math.PI / 2);
      flat(45, 9, white, x0 + s * 320, RWZ - 9, 0.062); flat(45, 9, white, x0 + s * 320, RWZ + 9, 0.062);
      [150, 450, 600].forEach(function (d) { for (var b = 0; b < 3; b++) { flat(22, 1.8, white, x0 + s * d, RWZ - 6 - b * 3, 0.062); flat(22, 1.8, white, x0 + s * d, RWZ + 6 + b * 3, 0.062); } });
      flat(1.2, RW_W - 2, white, x0 + s * 2, RWZ, 0.062);
    });
    /* taxiway markings and holding point */
    flat(RWX2 - 180, 0.45, yellow, (180 + RWX2) / 2, TWZ, 0.06);
    flat(0.45, RWZ - TWZ, yellow, 262, (TWZ + RWZ) / 2, 0.061); flat(0.45, RWZ - TWZ, yellow, RWX2 - 40, (TWZ + RWZ) / 2, 0.061);
    flat(0.45, TWZ - 20, yellow, 252, (TWZ + 20) / 2, 0.061);
    for (var hb = 0; hb < 4; hb++) flat(22, 0.35, yellow, 262, RWZ - RW_W / 2 - 8 - hb * 0.8, 0.063);
    text("B", 7, 4, 262, TWZ + 8, Math.PI, "#f2c418");

    /* lights: runway edge (white), thresholds (green/red), taxiway edge (blue) */
    function lights(pts, color, size) { var g = new THREE.SphereGeometry(size || 0.35, 6, 4), m = new THREE.MeshBasicMaterial({ color: color }), im = new THREE.InstancedMesh(g, m, pts.length), o = new THREE.Object3D(); pts.forEach(function (p, i) { o.position.set(p[0], 0.35, p[1]); o.updateMatrix(); im.setMatrixAt(i, o.matrix); }); scene.add(im); return im; }
    var rl = [], tl = [], gl = [], rd = [];
    for (var lx = RWX1; lx <= RWX2; lx += 30) { rl.push([lx, RWZ - RW_W / 2 - 1.5]); rl.push([lx, RWZ + RW_W / 2 + 1.5]); }
    for (var lz = -RW_W / 2; lz <= RW_W / 2; lz += 3) { gl.push([RWX1 - 2, RWZ + lz]); rd.push([RWX2 + 2, RWZ + lz]); }
    for (var tx = 180; tx <= RWX2; tx += 25) { tl.push([tx, TWZ - 12.5]); tl.push([tx, TWZ + 12.5]); }
    lights(rl, 0xfffbe8); lights(gl, 0x2bff6a); lights(rd, 0xff3030); lights(tl, 0x2f6bff, 0.28);

    /* finger pier with gates (Concourse B) */
    var glassM = new THREE.MeshStandardMaterial({ color: 0x8fb4c9, roughness: 0.08, metalness: 0.6, transparent: true, opacity: 0.55 }), metal = new THREE.MeshStandardMaterial({ color: 0xdfe3e6, roughness: 0.35, metalness: 0.5 }), darkM = new THREE.MeshStandardMaterial({ color: 0x2b2f36, roughness: 0.6 }), jbM = new THREE.MeshStandardMaterial({ color: 0xc9ced3, roughness: 0.45, metalness: 0.35 });
    var PZ1 = -44, PZ2 = -30, PX2 = 430, PH = 9;
    box(PX2 - AX2, PH - 1.2, PZ2 - PZ1, glassM, (AX2 + PX2) / 2, 0.6 + (PH - 1.2) / 2, (PZ1 + PZ2) / 2, { shadow: false });
    box(PX2 - AX2, 1.2, PZ2 - PZ1, darkM, (AX2 + PX2) / 2, 0.6, (PZ1 + PZ2) / 2);
    box(PX2 - AX2 + 4, 0.7, PZ2 - PZ1 + 5, metal, (AX2 + PX2) / 2 + 2, PH + 0.35, (PZ1 + PZ2) / 2);
    for (var fx = AX2 + 4; fx < PX2; fx += 8) { box(0.3, PH, 0.3, metal, fx, PH / 2, PZ1); box(0.3, PH, 0.3, metal, fx, PH / 2, PZ2); }
    solid(AX2, PX2, PZ1, PZ2, "bld"); MAPB.push({ x1: AX2, x2: PX2, z1: PZ1, z2: PZ2, k: "glass" });
    sign("CONCOURSE B", 16, 1.8, PX2 + 0.4, PH - 2.2, (PZ1 + PZ2) / 2, Math.PI / 2, { size: 90, w: 1024, h: 116 });

    /* parked airliners at the pier, with jet bridges, stand markings and service vehicles */
    function lite(j) { var rm = []; j.traverse(function (o) { if (o.isMesh && o.geometry && o.geometry.type === "BoxGeometry" && o.geometry.parameters && o.geometry.parameters.width === 0.02) rm.push(o); }); rm.forEach(function (o) { o.parent.remove(o); }); return j; }
    var STANDS = [[205, -1, "B21"], [262, -1, "B23"], [320, -1, "B25"], [378, -1, "B27"], [330, 1, "B24"], [392, 1, "B26"]];
    STANDS.forEach(function (st, i) {
      var sx = st[0], side = st[1], cz = side < 0 ? PZ1 - 2.5 - 19.8 : PZ2 + 2.5 + 19.8;
      var j = lite(jet.clone()); j.position.set(sx, 3.75, cz); j.rotation.set(0, side < 0 ? -Math.PI / 2 : Math.PI / 2, 0); scene.add(j);
      var bz = side < 0 ? PZ1 - 4.5 : PZ2 + 4.5;
      if (side < 0) jetBridge([[sx + 9, PZ1 + 0.4, 2.75], [sx + 9, PZ1 - 5, 2.75], [sx + 3.7, cz + 13.2, 2.75]]); else jetBridge([[sx - 9, PZ2 - 0.4, 2.75], [sx - 9, PZ2 + 5, 2.75], [sx - 3.7, cz - 13.2, 2.75]]);
      flat(0.45, 46, yellow, sx, side < 0 ? PZ1 - 26 : PZ2 + 26, 0.061);
      flat(6, 0.45, yellow, sx, side < 0 ? PZ1 - 6 : PZ2 + 6, 0.062);
      text(st[2], 9, 4.5, sx + 7, side < 0 ? PZ1 - 48 : PZ2 + 48, side < 0 ? 0 : Math.PI, "#f2c418");
      flat(52, 0.35, red, sx, side < 0 ? PZ1 - 52 : PZ2 + 52, 0.061);
      solid(sx - 2.6, sx + 2.6, cz - 21, cz + 21, "car"); solid(sx - 19, sx + 19, cz - 6, cz + 6, "car");
      if (i % 2 === 0) { var tug = carMesh(0xf2f0ea, "truck", false); tug.position.set(sx + 12, 0.02, cz + 6); tug.rotation.y = Math.PI / 2; scene.add(tug); }
      for (var c2 = 0; c2 < 3; c2++) { box(2.2, 1.4, 1.5, darkM, sx - 12 - c2 * 2.8, 0.9, cz - 4 * side); box(2.2, 0.08, 1.5, new THREE.MeshStandardMaterial({ color: 0x3a6fd8 }), sx - 12 - c2 * 2.8, 1.62, cz - 4 * side); }
    });
    /* stand and lead-in line for the player's departure gate B12 */
    flat(60, 0.45, yellow, AX2 + 30, 12, 0.061); flat(0.45, 26, yellow, 252, 25, 0.061);
    text("B12", 9, 4.5, AX2 + 52, 22, -Math.PI / 2, "#f2c418");
    flat(0.35, 70, red, AX2 + 6, -1, 0.061);
    var ft = carMesh(0xe8e6df, "truck", false); ft.position.set(AX2 + 46, 0.02, 26); ft.rotation.y = 0; scene.add(ft); solid(AX2 + 42, AX2 + 50, 24.5, 27.5, "car");

    /* control tower */
    (function () {
      var x = 480, z = -128, H = 52;
      var conc = new THREE.MeshStandardMaterial({ color: 0xd9d6cf, roughness: 0.8 });
      var shaft = new THREE.Mesh(new THREE.CylinderGeometry(3.4, 4.6, H, 24), conc); shaft.position.set(x, H / 2, z); shaft.castShadow = true; scene.add(shaft);
      var flare = new THREE.Mesh(new THREE.CylinderGeometry(7.5, 3.4, 5, 8), conc); flare.position.set(x, H + 2.5, z); scene.add(flare);
      var cab = new THREE.Mesh(new THREE.CylinderGeometry(7.8, 7.2, 5, 8, 1, true), new THREE.MeshStandardMaterial({ color: 0x3a6b80, roughness: 0.05, metalness: 0.8, transparent: true, opacity: 0.75, side: THREE.DoubleSide })); cab.position.set(x, H + 7.5, z); scene.add(cab);
      var top = new THREE.Mesh(new THREE.CylinderGeometry(6.5, 8.4, 1.4, 8), metal); top.position.set(x, H + 10.7, z); scene.add(top);
      var ant = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 9, 6), darkM); ant.position.set(x + 2, H + 15.5, z); scene.add(ant);
      var bc = new THREE.Mesh(new THREE.SphereGeometry(0.5, 8, 6), new THREE.MeshBasicMaterial({ color: 0xff3030 })); bc.position.set(x + 2, H + 20, z); scene.add(bc);
      box(18, 8, 14, conc, x, 4, z + 6); solid(x - 9, x + 9, z - 5, z + 13, "bld"); MAPB.push({ x1: x - 9, x2: x + 9, z1: z - 5, z2: z + 13, k: "stone" });
    })();
    /* maintenance hangar */
    (function () {
      var x = 600, z = -120, W = 90, D = 60, H = 22;
      var wallM = new THREE.MeshStandardMaterial({ color: 0xb7bcc2, roughness: 0.6, metalness: 0.4 });
      box(W, H, D, wallM, x, H / 2, z);
      var roof = new THREE.Mesh(new THREE.CylinderGeometry(D * 0.75, D * 0.75, W, 32, 1, true, -0.73, 1.46), metal); roof.geometry.rotateX(-Math.PI / 2); roof.geometry.rotateY(Math.PI / 2); roof.position.set(x, H - D * 0.75 + 7.5, z); scene.add(roof);
      box(W * 0.8, H * 0.82, 0.4, new THREE.MeshStandardMaterial({ color: 0x5d6670, roughness: 0.5, metalness: 0.5 }), x, H * 0.41, z + D / 2 + 0.2);
      sign("EARTHPASS AIR  ·  MAINTENANCE", 40, 3, x, H + 4.5, z + D / 2 + 0.6, 0, { size: 80, w: 1500, h: 116 });
      solid(x - W / 2, x + W / 2, z - D / 2, z + D / 2, "bld"); MAPB.push({ x1: x - W / 2, x2: x + W / 2, z1: z - D / 2, z2: z + D / 2, k: "factory" });
      flat(W, 40, new THREE.MeshStandardMaterial({ map: tiled(concTex, 12, 5), roughness: 0.92 }), x, z + D / 2 + 20, 0.03);
    })();
    /* general aviation: private jets in front of the hangar, helicopter on its pad */
    [[585, -76, Math.PI / 2 + 0.25, 0xff3d8b], [628, -70, Math.PI / 2 - 0.2, 0xc8382c]].forEach(function (b) { var j = bizjet(b[3]); j.position.set(b[0], 1.72, b[1]); j.rotation.y = b[2]; scene.add(j); solid(b[0] - 3, b[0] + 3, b[1] - 9, b[1] + 9, "car"); });
    (function () { var x = 520, z = -64; var pad = plane(20, 20, new THREE.MeshStandardMaterial({ map: canvasTex(256, 256, function (g, w, h) { g.fillStyle = "#2c2e32"; g.fillRect(0, 0, w, h); g.strokeStyle = "#f2c418"; g.lineWidth = 10; g.beginPath(); g.arc(w / 2, h / 2, w * 0.4, 0, 7); g.stroke(); g.fillStyle = "#f2f2ee"; g.font = "900 140px Arial Black, Arial"; g.textAlign = "center"; g.textBaseline = "middle"; g.fillText("H", w / 2, h / 2 + 6); }), roughness: 0.9 }), x, 0.05, z); var hc = helicopter(); hc.position.set(x, 0.05, z); hc.rotation.y = 0.6; scene.add(hc); HELI = hc; solid(x - 3, x + 3, z - 3, z + 3, "car"); })();
    /* airport fire station */
    (function () { var x = 520, z = 14; box(34, 9, 16, new THREE.MeshStandardMaterial({ color: 0xb83a2c, roughness: 0.7 }), x, 4.5, z); for (var d = 0; d < 4; d++) box(6, 6, 0.3, new THREE.MeshStandardMaterial({ color: 0xe9e6df, roughness: 0.5 }), x - 12 + d * 8, 3, z + 8.1); sign("AIRPORT FIRE & RESCUE", 20, 1.6, x, 7.6, z + 8.2, 0, { bg: "#ffffff", fg: "#b83a2c", size: 80, w: 1024, h: 96 }); solid(x - 17, x + 17, z - 8, z + 8, "bld"); MAPB.push({ x1: x - 17, x2: x + 17, z1: z - 8, z2: z + 8, k: "brick" }); })();
    /* apron flood-light masts */
    [[215, -95], [300, -95], [390, -95], [300, 30], [400, 30], [440, -30]].forEach(function (p) { var m = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.55, 26, 8), metal); m.position.set(p[0], 13, p[1]); scene.add(m); var hd = box(4, 1.2, 1.2, new THREE.MeshStandardMaterial({ color: 0x2b2f36, emissive: 0xfff3d0, emissiveIntensity: 0.4 }), p[0], 26, p[1]); nightMats.push(hd.material); solid(p[0] - 0.6, p[0] + 0.6, p[1] - 0.6, p[1] + 0.6); });
    /* perimeter fence */
    var fenceM = new THREE.MeshStandardMaterial({ color: 0x8a9096, roughness: 0.6, metalness: 0.5, transparent: true, opacity: 0.55 });
    box(1300, 2.6, 0.1, fenceM, AX2 + 690, 1.3, -168, { shadow: false }); box(1300, 2.6, 0.1, fenceM, AX2 + 690, 1.3, 168, { shadow: false });

    for (var k = scene.children.length - 1; k >= n0; k--) { var o = scene.children[k]; if (o === jet) continue; AIRSIDE.add(o); }
    scene.add(AIRSIDE);
  }

  /* terminal: modern curved roof and an airside name sign */
  (function () {
    var R = 90, len = AX2 - AX1 + 24, th = Math.asin(40 / R);
    var g = new THREE.CylinderGeometry(R, R, len, 72, 1, true, -th, th * 2); g.rotateX(-Math.PI / 2); g.rotateY(Math.PI / 2);
    var roofM = new THREE.MeshStandardMaterial({ color: 0xe8ebee, roughness: 0.32, metalness: 0.55, side: THREE.DoubleSide });
    var m = new THREE.Mesh(g, roofM); m.position.set((AX1 + AX2) / 2 - 4, AH + 5.2 - R, 0); m.castShadow = true; scene.add(m);
    var ribs = []; for (var rx = AX1 - 14; rx <= AX2 + 8; rx += 9) { var rb = new THREE.Mesh(new THREE.TorusGeometry(R + 0.05, 0.18, 4, 40, th * 2), new THREE.MeshStandardMaterial({ color: 0x9aa3ab, roughness: 0.4, metalness: 0.6 })); rb.rotation.set(0, Math.PI / 2, Math.PI / 2 - th); rb.position.set(rx, AH + 5.2 - R, 0); scene.add(rb); ribs.push(rb); }
    ROOMS.forEach(function (rm) { if (rm.x1 === AX1 && rm.x2 === AX2) { rm.meshes.push(m); ribs.forEach(function (r) { rm.meshes.push(r); }); } });
    sign(function () { return here().name.toUpperCase(); }, 30, 3.2, AX2 + 0.35, AH - 2.6, -14, Math.PI / 2, { bg: "#0b0d0b", fg: "#ffffff", size: 78, w: 1500, h: 160, bar: "#ff3d8b" });
  })();
  setInterval(function () { AIRSIDE.visible = P.x > -500; }, 1000);
  /* gate B12 bridge: terminal door -> rotunda -> side door of our plane */
  var B12_PATH = [[AX2 - 4, 12, 0.06], [AX2 + 1.2, 12, 0.06], [AX2 + 12, 12, 1.0], [JET_HOME.x - 13.2, JET_HOME.z + 5.0, 2.65], [JET_HOME.x - 13.2, JET_HOME.z + 2.9, 2.75], [JET_HOME.x - 13.2, JET_HOME.z + 1.2, 2.75]];
  jetBridge([[AX2 + 0.2, 12, 0.06], [AX2 + 12, 12, 1.0], [JET_HOME.x - 13.2, JET_HOME.z + 5.0, 2.65], [JET_HOME.x - 13.2, JET_HOME.z + 2.6, 2.75]]);
  solid(AX2 + 0.2, AX2 + 12, 10.4, 13.6, "bld");
  scene.add(jet);

  /* ================= Cars ================= */
  var CAR_TYPES = {
    sedan: { L: 4.7, W: 1.86, belt: 0.98, roof: 1.45, hx: 0.85, wsT: 0.15, rfE: -1.15, rx: -1.75, r: 0.35, cl: 0.28 },
    suv: { L: 4.85, W: 1.96, belt: 1.12, roof: 1.78, hx: 1.05, wsT: 0.45, rfE: -1.95, rx: -2.2, r: 0.41, cl: 0.36 },
    hatch: { L: 4.05, W: 1.8, belt: 0.98, roof: 1.5, hx: 0.75, wsT: 0.1, rfE: -1.65, rx: -1.85, r: 0.34, cl: 0.27 },
    van: { L: 5.3, W: 2.0, belt: 1.15, roof: 2.15, hx: 1.85, wsT: 1.35, rfE: -2.5, rx: -2.6, r: 0.4, cl: 0.32 },
    coupe: { L: 4.5, W: 1.9, belt: 0.86, roof: 1.24, hx: 0.55, wsT: -0.4, rfE: -1.25, rx: -1.9, r: 0.36, cl: 0.2 },
    pickup: { L: 5.6, W: 2.0, belt: 1.15, roof: 1.88, hx: 1.25, wsT: 0.75, rfE: -0.45, rx: -0.7, r: 0.45, cl: 0.44, bed: true },
    bus: { L: 11.4, W: 2.55, belt: 1.3, roof: 3.05, hx: 5.3, wsT: 5.2, rfE: -5.45, rx: -5.6, r: 0.5, cl: 0.42, bus: true },
    sport: { L: 4.55, W: 2.0, belt: 0.78, roof: 1.13, hx: 0.42, wsT: -0.6, rfE: -1.35, rx: -1.95, r: 0.36, cl: 0.14 },
    truck: { L: 7.2, W: 2.3, belt: 1.35, roof: 2.45, hx: 3.25, wsT: 2.95, rfE: 2.0, rx: 1.8, r: 0.5, cl: 0.46, box: 2.6 }
  };
  buildAirside();
  var boxSideTex = canvasTex(1024, 384, function (c, w, h) { c.fillStyle = "#f4f4f0"; c.fillRect(0, 0, w, h); c.fillStyle = "#1f6b35"; c.fillRect(0, h - 60, w, 60); c.fillStyle = "#1f6b35"; c.font = "800 120px Unbounded, 'Arial Black', sans-serif"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("FRESH MART", w / 2, h / 2 - 30); c.font = "600 44px 'JetBrains Mono', monospace"; c.fillStyle = "#333"; c.fillText("GROCERY DELIVERY", w / 2, h / 2 + 60); });
  var boxSideM = new THREE.MeshStandardMaterial({ map: boxSideTex, roughness: 0.6 }), boxWhiteM = new THREE.MeshStandardMaterial({ color: 0xf4f4f0, roughness: 0.6 });
  var busStripeM = new THREE.MeshStandardMaterial({ color: 0xff3d8b, emissive: 0xff3d8b, emissiveIntensity: 0.15, roughness: 0.5 });
  var busSignM = new THREE.MeshStandardMaterial({ map: signTex("CITY LOOP  \u00b7  AIRPORT", { w: 1024, h: 128, bg: "#0b0d0b", fg: "#ffb02e", size: 70 }), emissive: 0xffb02e, emissiveIntensity: 0.5 });
  var polRedM = new THREE.MeshStandardMaterial({ color: 0x500000, emissive: 0xff1a1a, emissiveIntensity: 1, roughness: 0.3 }), polBlueM = new THREE.MeshStandardMaterial({ color: 0x000a50, emissive: 0x2a5bff, emissiveIntensity: 1, roughness: 0.3 });
  var polTextM = new THREE.MeshStandardMaterial({ map: signTex("POLICE", { w: 512, h: 96, bg: "#f4f4f2", fg: "#13306b", size: 70 }), roughness: 0.5 });
  var carGlass = new THREE.MeshPhysicalMaterial({ color: 0x0b1118, metalness: 0.2, roughness: 0.05, clearcoat: 1, clearcoatRoughness: 0.03, envMapIntensity: 1.4 });
  var carBlack = new THREE.MeshStandardMaterial({ color: 0x0d0e10, roughness: 0.55 });
  var carChrome = new THREE.MeshStandardMaterial({ color: 0xd9dde2, roughness: 0.15, metalness: 1 });
  var tireM = new THREE.MeshStandardMaterial({ color: 0x121212, roughness: 0.92 });
  var rimM = new THREE.MeshStandardMaterial({ color: 0xb7bcc2, metalness: 0.9, roughness: 0.25 });
  var headM = new THREE.MeshStandardMaterial({ color: 0xf6f8ff, emissive: 0xfff1c8, emissiveIntensity: 0.3, roughness: 0.1, metalness: 0.4 });
  var tailM = new THREE.MeshStandardMaterial({ color: 0x5c0707, emissive: 0xff1a1a, emissiveIntensity: 0.4, roughness: 0.3 });
  var plateM = new THREE.MeshStandardMaterial({ map: canvasTex(256, 128, function (g, w, h) { g.fillStyle = "#f4f4ee"; g.fillRect(0, 0, w, h); g.strokeStyle = "#1a3a7a"; g.lineWidth = 8; g.strokeRect(4, 4, w - 8, h - 8); g.fillStyle = "#1a3a7a"; g.font = "800 58px 'JetBrains Mono', monospace"; g.textAlign = "center"; g.fillText("PW-2026", w / 2, 86); g.font = "600 20px sans-serif"; g.fillText("NEW YORK", w / 2, 30); }), roughness: 0.5 });
  var taxiSignM = new THREE.MeshStandardMaterial({ map: signTex("TAXI", { w: 256, h: 96, bg: "#ffffff", fg: "#111111", size: 64 }), emissive: 0xfff3b0, emissiveIntensity: 0.3, roughness: 0.4 });
  var carLightMats = [headM, tailM, taxiSignM];
  function pillar(g, mat, x1, y1, x2, y2, z, th) {
    var l = Math.hypot(x2 - x1, y2 - y1), m = new THREE.Mesh(new THREE.BoxGeometry(l, th, th), mat);
    m.position.set((x1 + x2) / 2, (y1 + y2) / 2, z); m.rotation.z = Math.atan2(y2 - y1, x2 - x1); g.add(m);
  }
  /* merge each car's parts by material so 60+ draw calls become ~15 */
  function mergeInto(parent, meshes) {
    var by = new Map();
    meshes.forEach(function (o) { o.updateMatrix(); var geo = o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone(); geo.applyMatrix4(o.matrix); if (!geo.attributes.uv) return; if (!by.has(o.material)) by.set(o.material, []); by.get(o.material).push(geo); parent.remove(o); });
    by.forEach(function (geos, mat) {
      var n = 0; geos.forEach(function (q) { n += q.attributes.position.count; });
      var pos = new Float32Array(n * 3), nor = new Float32Array(n * 3), uv = new Float32Array(n * 2), off = 0;
      geos.forEach(function (q) { pos.set(q.attributes.position.array, off * 3); nor.set(q.attributes.normal.array, off * 3); uv.set(q.attributes.uv.array, off * 2); off += q.attributes.position.count; q.dispose(); });
      var bg = new THREE.BufferGeometry(); bg.setAttribute("position", new THREE.BufferAttribute(pos, 3)); bg.setAttribute("normal", new THREE.BufferAttribute(nor, 3)); bg.setAttribute("uv", new THREE.BufferAttribute(uv, 2));
      var m = new THREE.Mesh(bg, mat); m.castShadow = true; parent.add(m);
    });
  }
  function bakeCar(g) {
    mergeInto(g, g.children.filter(function (o) { return o.isMesh; }));
    g.userData.wheels.forEach(function (w) { mergeInto(w, w.children.filter(function (o) { return o.isMesh; })); });
  }
  var STK_SEQ = 0;
  /* car cabin: door trim texture and a merged, vertex-coloured interior (seats, dash, wheel) built the first time a door opens */
  var DOOR_TRIM_T = null, DOOR_TRIM_M = null, CABIN_MAT = null, carGlassD = null;
  function doorTrimMat() {
    if (DOOR_TRIM_M) return DOOR_TRIM_M;
    if (!DOOR_TRIM_T) DOOR_TRIM_T = canvasTex(256, 128, function (c, w, h) {
      c.fillStyle = "#6a645c"; c.fillRect(0, 0, w, h);
      c.fillStyle = "#4c4b51"; c.fillRect(0, 0, w, 20);
      c.fillStyle = "#7d766d"; c.fillRect(0, 20, w, 30);
      c.fillStyle = "#6e675f"; c.fillRect(20, 54, w - 50, 14); c.fillStyle = "#cfd3d8"; c.fillRect(150, 57, 38, 7);
      c.fillStyle = "#5d5852"; c.fillRect(14, 86, w - 70, 30);
      c.fillStyle = "#3b3b40"; c.beginPath(); c.arc(w - 40, 98, 20, 0, Math.PI * 2); c.fill(); c.fillStyle = "#2a2a2e"; for (var i = 0; i < 5; i++) c.fillRect(w - 52, 88 + i * 5, 24, 2);
    });
    DOOR_TRIM_M = new THREE.MeshStandardMaterial({ map: DOOR_TRIM_T, roughness: 0.85 }); return DOOR_TRIM_M;
  }
  function cabinMesh(T, W, dxB, dxF, nb, top) {
    if (!CABIN_MAT) CABIN_MAT = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.8 });
    var pos = [], nor = [], col = [], cc = new THREE.Color(), mm = new THREE.Matrix4(), qq = new THREE.Quaternion(), ee = new THREE.Euler();
    function add(geo, hex, x, y, z, rx, ry, rz) {
      var gg = geo.index ? geo.toNonIndexed() : geo; ee.set(rx || 0, ry || 0, rz || 0); qq.setFromEuler(ee); mm.compose(new THREE.Vector3(x, y, z), qq, new THREE.Vector3(1, 1, 1)); gg.applyMatrix4(mm);
      var pa = gg.attributes.position, na = gg.attributes.normal; cc.setHex(hex);
      for (var i = 0; i < pa.count; i++) { pos.push(pa.getX(i), pa.getY(i), pa.getZ(i)); nor.push(na.getX(i), na.getY(i), na.getZ(i)); col.push(cc.r, cc.g, cc.b); }
    }
    /* the body and glass outlines are bevelled, so their inner walls sit ~5 cm inside the opening: build just in front of them */
    var dl = dxF - dxB, mx = (dxB + dxF) / 2, iw = W - 0.3, seat = 0x5b5049, seatD = 0x3f3833, nf = nb + 0.07, bw = dxB + 0.07, fw = dxF - 0.07;
    add(new THREE.BoxGeometry(dl, 0.03, iw), 0x222226, mx, nf - 0.015, 0);                                       /* carpet */
    add(new THREE.BoxGeometry(dl + 0.2, 0.03, iw), 0x9d978d, mx, top - 0.06, 0);                                  /* headliner */
    add(new THREE.BoxGeometry(0.04, top - nf, iw), 0x4f4b46, bw + 0.02, (top + nf) / 2, 0);                        /* B-pillar wall behind the seats */
    add(new THREE.BoxGeometry(0.04, Math.max(0.1, T.belt - 0.3 - nf), iw), 0x2a2a2e, fw - 0.02, nf + Math.max(0.1, T.belt - 0.3 - nf) / 2, 0); /* footwell */
    var ch = Math.max(0.16, Math.min(0.3, (T.belt - nf) * 0.55)), cu = nf + ch, bh = Math.max(0.32, Math.min(0.62, top - cu - 0.14)), sx = bw + 0.3;
    [-0.36, 0.36].forEach(function (z) {
      add(new THREE.BoxGeometry(0.48, ch, 0.48), seatD, sx + 0.04, nf + ch / 2, z);                                 /* seat base */
      add(new THREE.BoxGeometry(0.5, 0.06, 0.48), seat, sx + 0.04, cu + 0.01, z);                                   /* cushion */
      add(new THREE.BoxGeometry(0.13, bh, 0.48), seat, bw + 0.12, cu + bh / 2, z, 0, 0, 0.14);                     /* backrest */
      add(new THREE.BoxGeometry(0.1, 0.16, 0.26), seatD, bw + 0.08, cu + bh + 0.07, z, 0, 0, 0.14);                /* headrest */
    });
    var cl = Math.max(0.3, Math.min(0.7, fw - sx)); add(new THREE.BoxGeometry(cl, Math.min(0.26, ch + 0.02), 0.22), 0x26262b, sx + cl / 2, nf + Math.min(0.26, ch + 0.02) / 2, 0); /* console */
    var wx = Math.max(sx + 0.3, Math.min(fw - 0.12, sx + 0.5)), wy = T.belt - 0.04;
    add(new THREE.BoxGeometry(0.5, 0.32, iw), 0x2b2b30, fw + 0.22, T.belt - 0.13, 0);                             /* dashboard */
    add(new THREE.BoxGeometry(0.46, 0.03, iw), 0x26262a, fw + 0.24, T.belt + 0.04, 0);                            /* dash top */
    add(new THREE.BoxGeometry(0.04, 0.11, 0.34), 0x1d2a33, fw - 0.04, T.belt - 0.02, -0.36);                      /* gauges */
    add(new THREE.BoxGeometry(Math.max(0.05, fw - wx), 0.04, 0.04), 0x2a2a2e, (wx + fw) / 2, wy - 0.05, -0.36, 0, 0, 0.35); /* column */
    var tor = new THREE.TorusGeometry(0.17, 0.024, 8, 22); tor.rotateY(Math.PI / 2); tor.rotateZ(0.42); add(tor, 0x1c1c20, wx, wy, -0.36);
    add(new THREE.CylinderGeometry(0.05, 0.05, 0.04, 12), 0x55555c, wx + 0.01, wy, -0.36, 0, 0, Math.PI / 2 + 0.42);
    var g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute("normal", new THREE.Float32BufferAttribute(nor, 3)); g.setAttribute("color", new THREE.Float32BufferAttribute(col, 3));
    var m = new THREE.Mesh(g, CABIN_MAT); m.receiveShadow = true; return m;
  }
  function carMesh(color, kind, taxiOn) {
    var T = CAR_TYPES[kind] || CAR_TYPES.sedan, L = T.L, W = T.W, r = T.r, h2 = L / 2, g = new THREE.Group();
    var paint = new THREE.MeshPhysicalMaterial({ color: color, metalness: 0.55, roughness: 0.3, clearcoat: 1, clearcoatRoughness: 0.06 });
    var wb = L * 0.3 + 0.1, wf = wb + 0.05, wr = -wb + 0.05, R = r + 0.08, y0 = T.cl;
    /* front door opening: from the B-pillar to the A-pillar, sill to roof rail. Only where it clears both wheel arches. */
    var dxF = T.hx - 0.09, dxB = (T.wsT + T.rfE) / 2 + 0.15, nb = y0 + 0.12, gb0 = T.belt - 0.01, gtop = T.roof - 0.09;
    var hasD = !T.bus && dxF < wf - R - 0.06 && dxB > wr + R + 0.06 && dxF - dxB > 0.6;
    function xA(y) { return T.hx + (T.wsT - T.hx) * (y - gb0) / (T.roof - gb0) - 0.09; }
    var s = new THREE.Shape();
    s.moveTo(-h2 + 0.05, y0);
    s.lineTo(wr - R, y0); s.absarc(wr, r, R, Math.PI, 0, true);
    s.lineTo(wf - R, y0); s.absarc(wf, r, R, Math.PI, 0, true);
    s.lineTo(h2 - 0.08, y0); s.quadraticCurveTo(h2 + 0.04, y0 + 0.05, h2, 0.62);
    s.quadraticCurveTo(h2 - 0.02, T.belt - 0.12, h2 - 0.35, T.belt - 0.06);
    s.lineTo(T.hx, T.belt);
    if (hasD) { s.lineTo(dxF, T.belt); s.lineTo(dxF, nb); s.lineTo(dxB, nb); s.lineTo(dxB, T.belt); }
    s.lineTo(T.rx, T.belt);
    s.quadraticCurveTo(-h2 + 0.1, T.belt - 0.02, -h2 + 0.02, T.belt - 0.2);
    s.lineTo(-h2, 0.55); s.quadraticCurveTo(-h2, y0, -h2 + 0.05, y0);
    var bg = new THREE.ExtrudeGeometry(s, { depth: W - 0.12, bevelEnabled: true, bevelThickness: 0.06, bevelSize: 0.05, bevelSegments: 3, curveSegments: 10 });
    bg.translate(0, 0, -(W - 0.12) / 2);
    g.add(new THREE.Mesh(bg, paint));
    var gs = new THREE.Shape();
    gs.moveTo(T.hx, T.belt - 0.01); gs.lineTo(T.wsT, T.roof); gs.lineTo(T.rfE, T.roof); gs.lineTo(T.rx, T.belt - 0.01);
    if (hasD) { gs.lineTo(dxB, gb0); gs.lineTo(dxB, gtop); gs.lineTo(xA(gtop), gtop); gs.lineTo(xA(gb0), gb0); }
    gs.lineTo(T.hx, T.belt - 0.01);
    var gg = new THREE.ExtrudeGeometry(gs, { depth: W - 0.3, bevelEnabled: true, bevelThickness: 0.03, bevelSize: 0.03, bevelSegments: 2 });
    gg.translate(0, 0, -(W - 0.3) / 2);
    g.add(new THREE.Mesh(gg, carGlass));
    var roof = new THREE.Mesh(new THREE.BoxGeometry(T.wsT - T.rfE + 0.06, 0.07, W - 0.26), paint); roof.position.set((T.wsT + T.rfE) / 2, T.roof + 0.03, 0); g.add(roof);
    [-1, 1].forEach(function (sd) {
      var z = sd * (W / 2 - 0.14);
      pillar(g, paint, T.hx, T.belt, T.wsT, T.roof + 0.02, z, 0.08);
      pillar(g, paint, T.rx, T.belt, T.rfE, T.roof + 0.02, z, 0.09);
      var bx = (T.wsT + T.rfE) / 2 + 0.15; pillar(g, carBlack, bx, T.belt, bx, T.roof, z * 1.01, 0.09);
      if (kind === "suv" || kind === "van") { var cx2 = T.rfE + 0.55; pillar(g, carBlack, cx2, T.belt, cx2, T.roof, z * 1.01, 0.09); }
      var mir = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.13, 0.17), paint); mir.position.set(T.hx - 0.12, T.belt + 0.13, sd * (W / 2 + 0.1)); g.add(mir);
      var mg = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.1, 0.14), carGlass); mg.position.set(T.hx - 0.23, T.belt + 0.13, sd * (W / 2 + 0.1)); g.add(mg);
      var arm = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.04, 0.14), carBlack); arm.position.set(T.hx - 0.1, T.belt + 0.08, sd * (W / 2 + 0.0)); g.add(arm);
      var seam = new THREE.Mesh(new THREE.BoxGeometry(0.015, T.belt - y0 - 0.15, 0.01), carBlack); seam.position.set(bx, (T.belt + y0) / 2, sd * (W / 2 - 0.0)); g.add(seam);
      var seam2 = seam.clone(); seam2.position.x = T.hx - 0.05; g.add(seam2);
      var handle = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.035, 0.02), carChrome); handle.position.set(bx + 0.35, T.belt - 0.12, sd * (W / 2 + 0.01));
      if (!(hasD && sd < 0)) g.add(handle);
      var handle2 = handle.clone(); handle2.position.x = bx - 0.55; g.add(handle2);
      if (hasD && sd < 0) { [[T.hx, dxF], [dxB, T.rx]].forEach(function (seg) { if (seg[0] - seg[1] < 0.05) return; var tp = new THREE.Mesh(new THREE.BoxGeometry(seg[0] - seg[1], 0.03, 0.02), carChrome); tp.position.set((seg[0] + seg[1]) / 2, T.belt + 0.005, sd * (W / 2 - 0.08)); g.add(tp); }); }
      else { var trim = new THREE.Mesh(new THREE.BoxGeometry(T.hx - T.rx, 0.03, 0.02), carChrome); trim.position.set((T.hx + T.rx) / 2, T.belt + 0.005, sd * (W / 2 - 0.08)); g.add(trim); }
      var sill = new THREE.Mesh(new THREE.BoxGeometry(wf - wr - 2 * R - 0.05, 0.12, 0.04), carBlack); sill.position.set((wf + wr) / 2, y0 + 0.06, sd * (W / 2 - 0.02)); g.add(sill);
    });
    if (hasD) {
      /* driver door (left, -z) hinged at its front edge; a fixed passenger door and window close the other side of the cabin */
      var dl = dxF - dxB, dh = T.belt - nb, DT = 0.12, trimM = doorTrimMat();
      if (!carGlassD) carGlassD = new THREE.MeshPhysicalMaterial({ color: 0x0b1118, metalness: 0.1, roughness: 0.05, clearcoat: 1, transparent: true, opacity: 0.42, depthWrite: false, side: THREE.DoubleSide });
      var winShape = function (ox) { var ws = new THREE.Shape(); ws.moveTo(dxB - 0.03 - ox, gb0 - 0.03); ws.lineTo(xA(gb0) + 0.03 - ox, gb0 - 0.03); ws.lineTo(xA(gtop) + 0.03 - ox, gtop + 0.03); ws.lineTo(dxB - 0.03 - ox, gtop + 0.03); ws.lineTo(dxB - 0.03 - ox, gb0 - 0.03); return new THREE.ShapeGeometry(ws); };
      var piv = new THREE.Group(); piv.position.set(dxF, 0, -W / 2);
      var pnl = new THREE.Mesh(new THREE.BoxGeometry(dl + 0.02, dh + 0.04, DT), paint); pnl.position.set(-dl / 2, nb - 0.02 + (dh + 0.04) / 2, DT / 2 - 0.004); pnl.castShadow = true; piv.add(pnl);
      var inr = new THREE.Mesh(new THREE.PlaneGeometry(dl - 0.04, dh - 0.03), trimM); inr.position.set(-dl / 2, nb + dh / 2, DT - 0.002); piv.add(inr);
      var dgl = new THREE.Mesh(winShape(dxF), carGlassD); dgl.position.z = 0.12; piv.add(dgl);
      var dhd = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.035, 0.03), carChrome); dhd.position.set(-dl + 0.32, T.belt - 0.12, -0.016); piv.add(dhd);
      var dsl = new THREE.Mesh(new THREE.BoxGeometry(dl, 0.02, 0.02), carChrome); dsl.position.set(-dl / 2, T.belt + 0.005, 0.03); piv.add(dsl);
      g.add(piv);
      var pp = new THREE.Mesh(new THREE.BoxGeometry(dl + 0.02, dh + 0.04, DT), paint); pp.position.set((dxB + dxF) / 2, nb - 0.02 + (dh + 0.04) / 2, W / 2 - DT / 2 + 0.004); g.add(pp);
      var pin = new THREE.Mesh(new THREE.PlaneGeometry(dl - 0.04, dh - 0.03), trimM); pin.rotation.y = Math.PI; pin.position.set((dxB + dxF) / 2, nb + dh / 2, W / 2 - DT + 0.002); g.add(pin);
      var pgl = new THREE.Mesh(winShape(0), carGlass); pgl.position.z = W / 2 - 0.12; g.add(pgl);
      g.userData.door = { piv: piv, stand: [dxF - dl / 2 - 0.1, -(W / 2 + 0.62)], seat: [dxB + 0.36, -0.36], cab: null, mk: function () { return cabinMesh(T, W, dxB, dxF, nb, gtop); } };
    }
    var srng = rng((color | 0) % 100003 + String(kind || "").length * 977 + (taxiOn ? 31 : 0) + (++STK_SEQ) * 7);
    if (srng() < 0.8) { var sxs = Math.max(wr + R + 0.25, ((T.wsT + T.rfE) / 2 + 0.15) - 0.5), sys = Math.min(T.belt - 0.3, (y0 + T.belt) / 2 + 0.08), ssz = Math.min(0.5, (T.belt - y0) * 0.62), sk1 = Math.floor(srng() * STK_N);
      stick(g, sk1, ssz, sxs, sys, W / 2 + 0.035, 1); stick(g, sk1 + (srng() < 0.5 ? 0 : 5), ssz, sxs, sys, -W / 2 - 0.035, -1);
      if (srng() < 0.45) { stick(g, Math.floor(srng() * STK_N), ssz * 0.75, h2 - 0.25, 0.55, W / 2 - 0.05, 1); } }
    var grille = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.2, W * 0.5), carBlack); grille.position.set(h2 + 0.02, 0.55, 0); g.add(grille);
    var bumperF = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.14, W - 0.1), carBlack); bumperF.position.set(h2 + 0.02, y0 + 0.1, 0); g.add(bumperF);
    var bumperR = bumperF.clone(); bumperR.position.x = -h2 - 0.02; g.add(bumperR);
    [-1, 1].forEach(function (sd) {
      var hl = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.1, 0.42), headM); hl.position.set(h2 - 0.02, 0.74, sd * (W / 2 - 0.32)); g.add(hl);
      var tl = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.12, 0.46), tailM); tl.position.set(-h2 + 0.01, T.belt - 0.22, sd * (W / 2 - 0.3)); g.add(tl);
    });
    var pf = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.15, 0.5), plateM); pf.position.set(h2 + 0.09, y0 + 0.2, 0); pf.rotation.y = Math.PI / 2; pf.geometry = new THREE.PlaneGeometry(0.5, 0.15); g.add(pf);
    var pr = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.15), plateM); pr.position.set(-h2 - 0.09, y0 + 0.32, 0); pr.rotation.y = -Math.PI / 2; g.add(pr);
    var under = new THREE.Mesh(new THREE.BoxGeometry(L - 0.4, 0.12, W - 0.3), carBlack); under.position.set(0, y0 + 0.02, 0); g.add(under);
    g.userData.wheels = [];
    [[wf, 1], [wf, -1], [wr, 1], [wr, -1]].forEach(function (p) {
      var w = new THREE.Group();
      var tr = new THREE.Mesh(new THREE.CylinderGeometry(r, r, 0.24, 24), tireM); tr.rotation.x = Math.PI / 2; w.add(tr);
      var rm = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.62, r * 0.62, 0.25, 20), rimM); rm.rotation.x = Math.PI / 2; w.add(rm);
      for (var k = 0; k < 5; k++) { var sp = new THREE.Mesh(new THREE.BoxGeometry(r * 1.1, 0.05, 0.02), carChrome); sp.rotation.z = k * Math.PI / 5; sp.position.z = p[1] * 0.13; w.add(sp); }
      var hub = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.27, 10), carBlack); hub.rotation.x = Math.PI / 2; w.add(hub);
      w.position.set(p[0], r, p[1] * (W / 2 - 0.16)); w.userData.front = p[0] === wf; g.add(w); g.userData.wheels.push(w);
    });
    if (taxiOn === true) {
      var sg = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.22, 0.28), taxiSignM); sg.position.set((T.wsT + T.rfE) / 2, T.roof + 0.18, 0); g.add(sg);
      var chk = canvasTex(256, 32, function (c, w, h) { for (var i = 0; i < 16; i++) for (var j = 0; j < 2; j++) { c.fillStyle = (i + j) % 2 ? "#111" : "#f2c230"; c.fillRect(i * 16, j * 16, 16, 16); } });
      var chkM = new THREE.MeshStandardMaterial({ map: chk, roughness: 0.5 }), DD = g.userData.door;
      [-1, 1].forEach(function (sd) {
        var segs = DD && sd < 0 ? [[T.hx, dxF], [dxB, T.rx]] : [[T.hx, T.rx]];
        segs.forEach(function (sg2) { if (sg2[0] - sg2[1] < 0.04) return; var st = new THREE.Mesh(new THREE.PlaneGeometry(sg2[0] - sg2[1], 0.1), chkM); st.position.set((sg2[0] + sg2[1]) / 2, T.belt - 0.3, sd * (W / 2 + 0.012)); if (sd < 0) st.rotation.y = Math.PI; g.add(st); });
        if (DD && sd < 0) { var sdr = new THREE.Mesh(new THREE.PlaneGeometry(dxF - dxB, 0.1), chkM); sdr.rotation.y = Math.PI; sdr.position.set(-(dxF - dxB) / 2, T.belt - 0.3, -0.012); DD.piv.add(sdr); }
      });
    }
    if (T.bed) { var bed = new THREE.Mesh(new THREE.BoxGeometry(T.rx + h2 - 0.4, 0.5, W - 0.34), carBlack); bed.position.set((T.rx - h2) / 2 + 0.05, T.belt - 0.2, 0); g.add(bed); }
    if (T.box) {
      var bl = T.rx + h2 - 0.1, cb = new THREE.Mesh(new THREE.BoxGeometry(bl, T.box, W + 0.08), boxWhiteM); cb.position.set((T.rx - h2) / 2 - 0.02, T.belt + T.box / 2 - 0.25, 0); g.add(cb);
      [-1, 1].forEach(function (sd) { var sp = new THREE.Mesh(new THREE.PlaneGeometry(bl - 0.2, T.box - 0.2), boxSideM); sp.position.set(cb.position.x, cb.position.y, sd * (W / 2 + 0.05)); if (sd < 0) sp.rotation.y = Math.PI; g.add(sp); });
    }
    if (T.bus) {
      for (var bp = T.rfE + 1.4; bp < T.wsT - 0.6; bp += 1.45) [-1, 1].forEach(function (sd) { pillar(g, carBlack, bp, T.belt, bp, T.roof, sd * (W / 2 - 0.13), 0.1); });
      [-1, 1].forEach(function (sd) { var bs = new THREE.Mesh(new THREE.BoxGeometry(L - 0.6, 0.16, 0.02), busStripeM); bs.position.set(0, T.belt - 0.25, sd * (W / 2 + 0.01)); g.add(bs); });
      var ds = new THREE.Mesh(new THREE.PlaneGeometry(W - 0.5, 0.3), busSignM); ds.position.set(h2 - 0.12, T.roof - 0.22, 0); ds.rotation.y = Math.PI / 2; g.add(ds);
    }
    if (taxiOn === "police") {
      var lb = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.12, W * 0.38), polRedM); lb.position.set((T.wsT + T.rfE) / 2, T.roof + 0.12, W * 0.2); g.add(lb);
      var lb2 = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.12, W * 0.38), polBlueM); lb2.position.set((T.wsT + T.rfE) / 2, T.roof + 0.12, -W * 0.2); g.add(lb2);
      [-1, 1].forEach(function (sd) { var pt = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 0.24), polTextM); pt.position.set((T.hx + T.rx) / 2 - 0.2, T.belt - 0.3, sd * (W / 2 + 0.006)); if (sd < 0) pt.rotation.y = Math.PI; g.add(pt); });
      var hood = new THREE.Mesh(new THREE.BoxGeometry(h2 - T.hx - 0.1, 0.02, W - 0.2), carBlack); hood.position.set((h2 + T.hx) / 2 - 0.1, T.belt + 0.01, 0); g.add(hood);
    }
    bakeCar(g);
    g.traverse(function (o) { if (o.isMesh) o.castShadow = true; });
    g.userData.L = L; g.userData.W = W; g.userData.r = r;
    return g;
  }
  var CAR_COLORS = [0x15181c, 0xf4f4f2, 0x8a1c1c, 0x1d3f7a, 0x9aa1a8, 0x2f5d3a, 0xcaa36a, 0x3b3f45, 0x5a6b7a, 0x6b1f3a, 0xe8e4d8, 0x24324a];
  var KINDS = ["sedan", "suv", "hatch", "coupe", "pickup", "van", "sedan", "suv"];
  var TRAFFIC = [], CARS = [], POLICE = [];
  var LANE_PLAN = ["sedan", "taxi", "suv", "bus", "coupe", "hatch", "pickup", "police", "sedan", "truck", "suv", "taxi", "van", "coupe", "hatch", "sedan"];
  [-1, 1].forEach(function (dir, li) {
    var span = CITY_X2 + 1 - (CITY_X1 - 20), n = LANE_PLAN.length, step = span / n;
    LANE_PLAN.forEach(function (k, i) {
      var kk = LANE_PLAN[(i + li * 5) % n], isTaxi = kk === "taxi", isPol = kk === "police", kind = isTaxi || isPol ? "sedan" : kk;
      var col = isTaxi ? 0xf2c230 : isPol ? 0xf4f4f2 : kind === "bus" ? 0x1d3f7a : CAR_COLORS[(i * 5 + li * 3) % CAR_COLORS.length];
      var mesh = carMesh(col, kind, isTaxi ? true : isPol ? "police" : false); scene.add(mesh);
      var vm = kind === "bus" || kind === "truck" ? 7.5 : 8.5 + ((i * 7) % 5) * 0.9;
      var tc = { m: mesh, dir: dir, x: CITY_X1 - 20 + step * (i + 0.5), z: dir > 0 ? 3.6 : -3.6, v: vm, vmax: vm };
      TRAFFIC.push(tc); CARS.push(tc); if (isPol) POLICE.push(mesh);
    });
  });
  (function () {
    var r = rng(55);
    [-1, 1].forEach(function (sd) {
      for (var x = CITY_X1 + 8; x < CITY_X2 - 6; x += 9 + Math.floor(r() * 8)) {
        if (Math.abs(x + 25) < 6 || Math.abs(x - 20) < 6 || (sd > 0 && x > -78 && x < -48) || (sd > 0 && x > -14 && x < 14) || (sd < 0 && x > 40 && x < 56)) continue;
        if (r() < 0.35) continue;
        var kind = KINDS[Math.floor(r() * KINDS.length)], m = carMesh(CAR_COLORS[Math.floor(r() * CAR_COLORS.length)], kind, false);
        var z = sd * 5.9; m.position.set(x, 0, z); m.rotation.y = sd > 0 ? 0 : Math.PI; scene.add(m);
        var L = m.userData.L, W = m.userData.W;
        solid(x - L / 2, x + L / 2, z - W / 2, z + W / 2, "car");
      }
    });
    [44, 52].forEach(function (x) { var m = carMesh(0xf4f4f2, "sedan", "police"); m.position.set(x, 0, -5.9); m.rotation.y = Math.PI; scene.add(m); POLICE.push(m); solid(x - m.userData.L / 2, x + m.userData.L / 2, -5.9 - m.userData.W / 2, -5.9 + m.userData.W / 2, "car"); });
    [[-63, 115], [-49, 115]].forEach(function (p) { var m = carMesh(0xf4f4f0, "truck", false); m.position.set(p[0], 0.02, p[1]); m.rotation.y = Math.PI / 2; scene.add(m); solid(p[0] - m.userData.W / 2, p[0] + m.userData.W / 2, p[1] - m.userData.L / 2, p[1] + m.userData.L / 2, "car"); });
    (function () { var m = carMesh(0x8a1c1c, "pickup", false); m.position.set(-38, 0.02, 80); m.rotation.y = 0.3; scene.add(m); solid(-40.8, -35.2, 79, 81, "car"); })();
    [[-76, 21], [-70.8, 21], [-55, 21], [-49.8, 21], [-60, 21]].forEach(function (p, i) {
      var m = carMesh(CAR_COLORS[(i * 3) % CAR_COLORS.length], KINDS[(i + 1) % KINDS.length], false);
      m.position.set(p[0], 0.02, p[1] + 1); m.rotation.y = Math.PI / 2; scene.add(m);
      solid(p[0] - m.userData.W / 2, p[0] + m.userData.W / 2, p[1] + 1 - m.userData.L / 2, p[1] + 1 + m.userData.L / 2, "car");
    });
  })();
  var taxi = { m: carMesh(0xf2c230, "sedan", true), x: -65.5, z: 18, yaw: Math.PI / 2, v: 0, steer: 0 };
  scene.add(taxi.m);
  CARS.push(taxi);
  function carPush(p, rad) {
    for (var i = 0; i < CARS.length; i++) {
      var c = CARS[i]; if (c.skip) continue; var yaw = c.yaw !== undefined ? c.yaw : (c.dir > 0 ? 0 : Math.PI), L = c.m.userData.L / 2 + rad, W = c.m.userData.W / 2 + rad;
      var dx = p.x - c.x, dz = p.z - c.z, cs = Math.cos(yaw), sn = Math.sin(yaw);
      var lx = dx * cs - dz * sn, lz = dx * sn + dz * cs;
      if (Math.abs(lx) < L && Math.abs(lz) < W) {
        var px = L - Math.abs(lx), pz = W - Math.abs(lz);
        if (px < pz) lx = Math.sign(lx || 1) * L; else lz = Math.sign(lz || 1) * W;
        p.x = c.x + lx * cs + lz * sn; p.z = c.z - lx * sn + lz * cs;
      }
    }
  }
  var taxiZone = { id: "taxi", x: -65.5, z: 18, r: 3.4 }; ZONES.push(taxiZone);
  ZONES.push({ id: "cityhall", x: -100, z: -9.8, r: 2.6 });
  ZONES.push({ id: "tunnel", x: 63, z: 9, r: 2.6 });
  ZONES.push({ id: "toCity", x: AX1 - 8, z: 9, r: 2.6 });
  /* ================= Landmark at the west end of the avenue ================= */
  var ANIMS = [], MAPR = [];
  function mapRect(x1, x2, z1, z2, col, line) { MAPR.push({ x1: Math.min(x1, x2), x2: Math.max(x1, x2), z1: Math.min(z1, z2), z2: Math.max(z1, z2), c: col, l: line || "" }); }
  function mesh(geo, mat, x, y, z, noShadow) { var m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); if (!noShadow) { m.castShadow = true; m.receiveShadow = true; } scene.add(m); return m; }
  var LMX = -216, LMZ = 0;
  (false) && (function () {
    plane(56, 60, M.walk, LMX + 4, 0.03, 0);
    mapRect(LMX - 24, LMX + 32, -30, 30, "#3b403a");
    var r = rng(CS.seed), x = LMX, z = LMZ;
    var stone = new THREE.MeshStandardMaterial({ color: 0xd9d0bf, roughness: 0.8 }), sand = new THREE.MeshStandardMaterial({ color: 0xd3b47a, roughness: 0.95, flatShading: true });
    var gold = new THREE.MeshStandardMaterial({ color: 0xd8a93b, metalness: 0.9, roughness: 0.3 }), red = new THREE.MeshStandardMaterial({ color: 0xc2352b, roughness: 0.55 });
    var glassT = facade("glass", CS.seed % 97), stoneT = facade("stone", CS.seed % 89), whiteM = new THREE.MeshStandardMaterial({ color: 0xf4f2ec, roughness: 0.35 });
    var bronze = new THREE.MeshStandardMaterial({ color: 0x5b4a3a, roughness: 0.6, metalness: 0.5, wireframe: true });
    var foot = 10;
    function cone4(rad, h, mat, y) { var c = mesh(new THREE.ConeGeometry(rad, h, 4), mat, x, y + h / 2, z); c.rotation.y = Math.PI / 4; return c; }
    function tower(w, h, mat, y, d) { return mesh(new THREE.BoxGeometry(w, h, d || w), mat, x, y + h / 2, z); }
    switch (CS.lm) {
      case "spire": tower(18, 46, stoneT, 0); tower(13, 22, stoneT, 46); tower(8.5, 16, stoneT, 68); tower(5, 10, stoneT, 84); mesh(new THREE.ConeGeometry(0.7, 22, 8), M.metal, x, 105, z); foot = 9; break;
      case "clock":
        tower(9, 52, stoneT, 0); tower(10.5, 10, stone, 52);
        var face = canvasTex(256, 256, function (g, w) { g.fillStyle = "#e9e1c8"; g.beginPath(); g.arc(128, 128, 120, 0, 7); g.fill(); g.strokeStyle = "#1a1a1a"; g.lineWidth = 8; g.stroke(); for (var i = 0; i < 12; i++) { var a = i / 12 * Math.PI * 2; g.fillStyle = "#1a1a1a"; g.fillRect(128 + Math.sin(a) * 96 - 4, 128 - Math.cos(a) * 96 - 10, 8, 20); } g.lineWidth = 10; g.beginPath(); g.moveTo(128, 128); g.lineTo(128, 52); g.moveTo(128, 128); g.lineTo(178, 150); g.stroke(); });
        var fm = new THREE.MeshStandardMaterial({ map: face, emissive: 0xfff2c8, emissiveMap: face, emissiveIntensity: 0.2 }); nightMats.push(fm);
        [0, 1, 2, 3].forEach(function (i) { var p = mesh(new THREE.PlaneGeometry(8, 8), fm, x + Math.sin(i * Math.PI / 2) * 5.3, 57, z + Math.cos(i * Math.PI / 2) * 5.3, true); p.rotation.y = i * Math.PI / 2; });
        cone4(8, 16, M.dark, 62); mesh(new THREE.ConeGeometry(0.4, 8, 6), gold, x, 82, z); foot = 6; break;
      case "lattice":
        var lm = CS.lmName === "Red Tower" ? new THREE.MeshStandardMaterial({ color: 0xd4402a, roughness: 0.6, wireframe: true }) : bronze;
        var lat = mesh(new THREE.CylinderGeometry(0.6, 15, 86, 4, 18, true), lm, x, 43, z); lat.rotation.y = Math.PI / 4;
        [[18, 13], [42, 7], [64, 3.6]].forEach(function (p) { var b = mesh(new THREE.BoxGeometry(p[1] * 1.45, 1.2, p[1] * 1.45), new THREE.MeshStandardMaterial({ color: lm.color.getHex(), roughness: 0.6 }), x, p[0], z); b.rotation.y = 0; });
        mesh(new THREE.CylinderGeometry(0.15, 0.3, 14, 6), M.metal, x, 93, z); foot = 12; break;
      case "needle":
        mesh(new THREE.CylinderGeometry(1.6, 3.2, 64, 16), whiteM, x, 32, z); mesh(new THREE.CylinderGeometry(9, 6, 5, 24), glassT, x, 62, z); mesh(new THREE.CylinderGeometry(10, 9, 1, 24), whiteM, x, 65, z);
        mesh(new THREE.CylinderGeometry(0.2, 0.6, 24, 8), M.metal, x, 77, z); [0, 1, 2].forEach(function (i) { var l = mesh(new THREE.CylinderGeometry(0.5, 1, 30, 8), whiteM, x + Math.sin(i * 2.1) * 5, 14, z + Math.cos(i * 2.1) * 5); l.rotation.set(Math.cos(i * 2.1) * 0.18, 0, -Math.sin(i * 2.1) * 0.18); }); foot = 7; break;
      case "dome":
        mesh(new THREE.CylinderGeometry(13, 14, 12, 32), stone, x, 6, z); mesh(new THREE.CylinderGeometry(10.5, 10.5, 6, 32), stoneT, x, 15, z);
        mesh(new THREE.SphereGeometry(10.5, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), CS.lmName === "Hilltop Observatory" ? new THREE.MeshStandardMaterial({ color: 0x8c9aa3, metalness: 0.8, roughness: 0.3 }) : new THREE.MeshStandardMaterial({ color: 0x6f8f9a, roughness: 0.5 }), x, 18, z);
        mesh(new THREE.CylinderGeometry(1.4, 1.4, 4, 12), stone, x, 30, z); mesh(new THREE.ConeGeometry(1.6, 3, 12), gold, x, 33.5, z);
        if (CS.lmName === "Grand Dome") [[-16, -16], [16, -16], [-16, 16], [16, 16]].forEach(function (p) { mesh(new THREE.CylinderGeometry(0.9, 1.1, 42, 12), stone, x + p[0], 21, z + p[1]); mesh(new THREE.ConeGeometry(1.1, 6, 12), M.metal, x + p[0], 45, z + p[1]); });
        foot = 14; break;
      case "gate":
        [-11, 11].forEach(function (oz) { mesh(new THREE.BoxGeometry(4, 64, 4), red, x, 32, z + oz); [18, 40, 60].forEach(function (y) { mesh(new THREE.BoxGeometry(3, 3, 22), red, x, y, z); }); });
        for (var ci = 0; ci < 9; ci++) { var cl = mesh(new THREE.BoxGeometry(0.2, 0.2, 30), M.dark, x + 3 - ci * 0.01, 64 - ci * 6, z); cl.visible = ci === 0; }
        [-1, 1].forEach(function (s) { var cab = mesh(new THREE.BoxGeometry(0.3, 0.3, 70), red, x, 34, z + s * 30); cab.rotation.x = s * 0.88; }); foot = 13; break;
      case "lighthouse":
        var stripe = canvasTex(64, 256, function (g, w, h) { for (var i = 0; i < 8; i++) { g.fillStyle = i % 2 ? "#c62e2e" : "#f4f1ea"; g.fillRect(0, i * h / 8, w, h / 8); } });
        mesh(new THREE.CylinderGeometry(2.4, 4, 34, 24), new THREE.MeshStandardMaterial({ map: stripe, roughness: 0.6 }), x, 17, z); mesh(new THREE.CylinderGeometry(3.2, 3.2, 1, 24), M.dark, x, 34.5, z);
        var lamp = mesh(new THREE.CylinderGeometry(2, 2, 3.5, 16), new THREE.MeshStandardMaterial({ color: 0xfff6d0, emissive: 0xfff0b0, emissiveIntensity: 0.6, transparent: true, opacity: 0.85 }), x, 36.8, z);
        nightMats.push(lamp.material); mesh(new THREE.ConeGeometry(2.6, 3, 16), M.dark, x, 40, z); foot = 5; break;
      case "column":
        tower(14, 4, stone, 0); tower(8, 6, stoneT, 4); mesh(new THREE.CylinderGeometry(1.6, 1.9, 34, 20), stone, x, 27, z);
        mesh(new THREE.CylinderGeometry(2.4, 2.4, 1.2, 20), stone, x, 44.6, z); mesh(new THREE.ConeGeometry(1.2, 4, 10), gold, x, 47.2, z); mesh(new THREE.SphereGeometry(0.8, 12, 10), gold, x, 50, z);
        [-1, 1].forEach(function (s) { var wg = mesh(new THREE.BoxGeometry(0.2, 2.2, 3.4), gold, x, 48.6, z + s * 1.4); wg.rotation.x = s * 0.5; }); foot = 7; break;
      case "arch":
        var sh = new THREE.Shape(); sh.moveTo(-13, 0); sh.lineTo(13, 0); sh.lineTo(13, 34); sh.lineTo(-13, 34); sh.lineTo(-13, 0);
        var hole = new THREE.Path(); hole.moveTo(-5.5, 0); hole.lineTo(-5.5, 18); hole.absarc(0, 18, 5.5, Math.PI, 0, true); hole.lineTo(5.5, 0); hole.lineTo(-5.5, 0); sh.holes.push(hole);
        var ag = new THREE.ExtrudeGeometry(sh, { depth: 7, bevelEnabled: false }); ag.translate(0, 0, -3.5);
        var ar = mesh(ag, CS.lmName === "Martyrs Arch" ? whiteM : stone, x, 0, z); ar.rotation.y = Math.PI / 2;
        tower(8, 3, stone, 34, 28); foot = 4; break;
      case "arena":
        var arc = canvasTex(512, 128, function (g, w, h) { g.fillStyle = "#c9b48e"; g.fillRect(0, 0, w, h); g.fillStyle = "#3a2f24"; for (var i = 0; i < 16; i++) { g.beginPath(); g.moveTo(i * 32 + 6, h - 8); g.lineTo(i * 32 + 6, 56); g.arc(i * 32 + 16, 56, 10, Math.PI, 0); g.lineTo(i * 32 + 26, h - 8); g.fill(); } g.fillRect(0, 0, w, 6); }, true);
        arc.repeat.set(4, 3);
        mesh(new THREE.CylinderGeometry(24, 25, 22, 48, 1, true), new THREE.MeshStandardMaterial({ map: arc, roughness: 0.9, side: THREE.DoubleSide }), x, 11, z);
        mesh(new THREE.CylinderGeometry(17, 17, 12, 48, 1, true), new THREE.MeshStandardMaterial({ color: 0xa48e6a, side: THREE.DoubleSide, roughness: 0.9 }), x, 6, z); foot = 25; break;
      case "pyramid": cone4(46, 56, sand, 0); foot = 30; break;
      case "supertall":
        [[22, 50], [16, 42], [11, 36], [7, 26], [4, 16]].reduce(function (y, p) { mesh(new THREE.CylinderGeometry(p[0] * 0.48, p[0] * 0.55, p[1], 6), glassT, x, y + p[1] / 2, z); return y + p[1]; }, 0);
        mesh(new THREE.CylinderGeometry(0.3, 1.2, 46, 8), M.metal, x, 193, z); foot = 12; break;
      case "pagoda":
        var roofM = CS.lmName === "Golden Pagoda" ? gold : new THREE.MeshStandardMaterial({ color: 0x1f5a4a, roughness: 0.5 });
        for (var pi = 0, py = 0; pi < 5; pi++) { var pw = 16 - pi * 2.6, ph = 6.5 - pi * 0.6; tower(pw, ph, pi % 2 ? red : new THREE.MeshStandardMaterial({ color: 0xb8352a, roughness: 0.6 }), py); var rf = mesh(new THREE.ConeGeometry(pw * 0.95, 3.4, 4), roofM, x, py + ph + 1.4, z); rf.rotation.y = Math.PI / 4; py += ph + 2.4; }
        mesh(new THREE.CylinderGeometry(0.3, 0.6, 9, 8), gold, x, py + 4, z); foot = 9; break;
      case "trio":
        [-14, 0, 14].forEach(function (oz) { mesh(new THREE.BoxGeometry(10, 62, 9), glassT, x, 31, z + oz); });
        var deck = mesh(new THREE.BoxGeometry(14, 3, 44), new THREE.MeshStandardMaterial({ color: 0x6f7c84, metalness: 0.7, roughness: 0.3 }), x - 1, 63.5, z); foot = 8; break;
      case "twin":
        [-10, 10].forEach(function (oz) { mesh(new THREE.CylinderGeometry(6, 7.5, 90, 8), glassT, x, 45, z + oz); mesh(new THREE.CylinderGeometry(0.4, 2, 18, 8), M.metal, x, 99, z + oz); });
        mesh(new THREE.BoxGeometry(3, 3, 14), M.metal, x, 42, z); foot = 9; break;
      case "sails":
        tower(40, 6, stone, 0, 30);
        [[-10, 22, 1], [2, 18, 0.85], [12, 14, 0.7]].forEach(function (p) { var s = mesh(new THREE.SphereGeometry(p[1], 24, 12, 0, Math.PI, 0, Math.PI / 2), whiteM, x + p[0], 6, z); s.scale.set(0.9, 1.3 * p[2] + 0.2, 0.55); s.rotation.y = Math.PI / 2; });
        foot = 18; break;
    }
    solid(x - foot, x + foot, z - foot, z + foot, "bld");
    MAPB.push({ x1: x - foot, x2: x + foot, z1: z - foot, z2: z + foot, k: "landmark" });
    box(6, 1.4, 0.3, M.dark, x + foot + 4, 0.7, z + 0, {});
    sign(CS.lmName.toUpperCase(), 5.6, 0.9, x + foot + 4.16, 0.85, z, Math.PI / 2, { bg: "#111411", fg: "#ff3d8b", size: 70, w: 1024, h: 150 });
    solid(x + foot + 3.85, x + foot + 4.15, z - 3, z + 3);
  })();

  /* ================= Fronts on Main Street: signs, canopies, doors ================= */
  function front(x, side, title, sub, col) {
    return;
    var z = side < 0 ? -11.2 : 11.2, dz = side < 0 ? 0.06 : -0.06, ry = side < 0 ? 0 : Math.PI;
    box(5, 3.2, 0.12, new THREE.MeshStandardMaterial({ color: 0x111518, roughness: 0.15, metalness: 0.6 }), x, 1.75, z + dz * 2, { shadow: false });
    box(7, 0.25, 2.2, M.dark, x, 3.7, z - side * 1.05);
    sign(title, 9, 1.3, x, 4.75, z + dz * 3, ry, { bg: col || "#111411", fg: "#ffffff", size: 82, w: 1024, h: 148, sub: sub, subfg: "#ff3d8b" });
  }

  /* ================= Workplaces ================= */
  var WORK = [
    { id: "office", t: "Summit Tower", x: -29, z: -9.6, jobs: ["Company Owner", "Real Estate Agent", "Lawyer"], gig: "Office Assistant" },
    { id: "bank", t: "City Bank", x: 19, z: -9.8, jobs: ["Bank Owner", "Banker"], gig: "Bank Teller" },
    { id: "hotel", t: "Grand Hotel", x: -134, z: -9.8, jobs: ["Hotel Owner", "Hotel Receptionist", "Security Guard"], gig: "Bellhop" },
    { id: "diner", t: "Sunny Diner", x: -2, z: -9.8, jobs: ["Restaurant Owner", "Chef"], gig: "Waiter" },
    { id: "mart", t: "Fresh Mart stockroom", x: -76, z: -25, jobs: ["Grocery Store Owner", "Shop Assistant"], gig: "Shelf Stacker" },
    { id: "hospital", t: "City Hospital", x: -135, z: 9.8, jobs: ["Doctor", "Nurse"], gig: "Hospital Porter" },
    { id: "school", t: "Central School", x: -100, z: 9.8, jobs: ["Teacher"], gig: "Tutor" },
    { id: "cafe", t: "Corner Cafe", x: -33, z: 9.8, jobs: ["Barista"], gig: "Cafe Helper" },
    { id: "tech", t: "Tech Hub", x: 25, z: 9.8, jobs: ["Tech Founder", "Software Engineer"], gig: "IT Helper" },
    { id: "site", t: "Construction Site", x: 52, z: 9.9, jobs: ["Construction Worker"], gig: "Site Helper" },
    { id: "farm", t: "Green Acres Farm", x: -16.4, z: 69, jobs: ["Farm Owner", "Farmer"], gig: "Farm Hand" },
    { id: "oil", t: "Oil Field", x: 6.4, z: 70, jobs: ["Oil Field Owner", "Oil Rig Worker"], gig: "Rig Helper" },
    { id: "mine", t: "Gold Mine", x: -112, z: 108.6, jobs: ["Gold Mine Owner", "Miner"], gig: "Mine Helper" },
    { id: "factory", t: "Factory", x: 30, z: 110.4, jobs: ["Factory Owner", "Factory Worker"], gig: "Line Worker" },
    { id: "depot", t: "Truck Depot and Garage", x: -55, z: 104.4, jobs: ["Truck Driver", "Delivery Driver", "Mechanic"], gig: "Loader" },
    { id: "crew", t: "Airport Crew Room", x: 100, z: 27.6, jobs: ["Airline Pilot"], gig: "Baggage Handler" }
  ];
  var GOV = [["Police Officer", "Police HQ"], ["Detective", "Police HQ"], ["City Hall Clerk", "City Hall"], ["Land Registrar", "City Hall"], ["Immigration Officer", "Airport"], ["Customs Officer", "Airport"], ["Air Traffic Controller", "Airport"]];
  function workFor(job) { for (var i = 0; i < WORK.length; i++) if (WORK[i].jobs.indexOf(job) >= 0) return WORK[i]; return null; }
  WORK.forEach(function (w) { ZONES.push({ id: "job:" + w.id, x: w.x, z: w.z, r: 1.9, w: w }); });
  front(-134, -1, "GRAND HOTEL", "ROOMS  \u00b7  JOBS INSIDE", "#2a1f14");
  front(-2, -1, "SUNNY DINER", "BURGERS  \u00b7  COFFEE  \u00b7  24H", "#5a1414");
  front(19, -1, "CITY BANK", "SAVINGS  \u00b7  LOANS", "#0f2a4a");
  front(48, -1, "POLICE HQ", "GOVERNMENT  \u00b7  CITY POLICE", "#0d1b3a");
  front(-135, 1, "CITY HOSPITAL", "EMERGENCY  \u00b7  24 HOURS", "#7a1a1a");
  front(-100, 1, "CENTRAL SCHOOL", "EDUCATION  \u00b7  SINCE 1901", "#2a3a1a");
  front(-33, 1, "CORNER CAFE", "ESPRESSO  \u00b7  PASTRY", "#3a2a1a");
  front(25, 1, "TECH HUB", "STARTUPS  \u00b7  SOFTWARE", "#111411");
  ZONES.push({ id: "diner", x: -7.5, z: -9.8, r: 1.7 });
  ZONES.push({ id: "police", x: 48, z: -9.8, r: 1.9 });
  ZONES.push({ id: "busOut", x: 9, z: 9.4, r: 2 });
  /* bus stop shelter on Main Street */
  (function () {
    box(4.2, 0.12, 1.6, M.dark, 9, 2.6, 10.3); box(0.1, 2.5, 1.6, M.glass, 7, 1.3, 10.3, { shadow: false }); box(0.1, 2.5, 1.6, M.glass, 11, 1.3, 10.3, { shadow: false }); box(4, 0.1, 0.4, M.wood, 9, 0.65, 10.8);
    sign("BUS  \u00b7  OUTSKIRTS", 3.6, 0.5, 9, 2.95, 9.48, Math.PI, { bg: "#ff3d8b", fg: "#0b0d0b", size: 80, w: 1024, h: 140 });
  })();

  /* ================= Construction site (replaces a block) ================= */
  (function () {
    var x1 = 42, x2 = 62, z1 = 12, z2 = 28;
    plane(x2 - x1, z2 - z1, new THREE.MeshStandardMaterial({ color: 0x8a7457, roughness: 1 }), (x1 + x2) / 2, 0.02, (z1 + z2) / 2);
    mapRect(x1, x2, z1, z2, "#5a4a36", "rgba(242,194,48,0.8)");
    var fenceM = new THREE.MeshStandardMaterial({ color: 0xf2c230, roughness: 0.6 });
    box(x2 - x1, 2, 0.1, fenceM, (x1 + x2) / 2, 1, z1 + 0.05); solid(x1, (x1 + x2) / 2 - 2, z1 - 0.1, z1 + 0.2); solid((x1 + x2) / 2 + 2, x2, z1 - 0.1, z1 + 0.2);
    box(0.1, 2, z2 - z1, fenceM, x1, 1, (z1 + z2) / 2); box(0.1, 2, z2 - z1, fenceM, x2, 1, (z1 + z2) / 2); solid(x1 - 0.1, x1 + 0.1, z1, z2); solid(x2 - 0.1, x2 + 0.1, z1, z2); solid(x1, x2, z2 - 0.1, z2 + 0.1);
    sign("CONSTRUCTION SITE  \u00b7  HARD HATS", 7, 0.9, (x1 + x2) / 2, 2.6, z1 - 0.05, Math.PI, { bg: "#f2c230", fg: "#111", size: 70, w: 1024, h: 130 });
    var steel = new THREE.MeshStandardMaterial({ color: 0x7c8590, roughness: 0.5, metalness: 0.6 });
    for (var i = 0; i < 4; i++) for (var j = 0; j < 3; j++) { box(0.4, 8, 0.4, steel, 46 + i * 4, 4, 18 + j * 4); solid(45.8 + i * 4, 46.2 + i * 4, 17.8 + j * 4, 18.2 + j * 4); }
    [4, 8].forEach(function (y) { box(13, 0.35, 0.35, steel, 52, y, 18); box(13, 0.35, 0.35, steel, 52, y, 26); for (var i = 0; i < 4; i++) box(0.35, 0.35, 8.4, steel, 46 + i * 4, y, 22); });
    box(13, 0.3, 9, new THREE.MeshStandardMaterial({ color: 0x9a9a94, roughness: 0.9 }), 52, 4, 22);
    var crane = new THREE.MeshStandardMaterial({ color: 0xf2c230, roughness: 0.5, wireframe: true });
    mesh(new THREE.BoxGeometry(1.6, 34, 1.6, 1, 14, 1), crane, 59, 17, 26.5); mesh(new THREE.BoxGeometry(26, 1.4, 1.4, 16, 1, 1), crane, 52, 34, 26.5);
    box(2.4, 1.6, 1.6, fenceM, 59, 35.6, 26.5); box(0.06, 12, 0.06, M.dark, 44, 28, 26.5); box(1.6, 0.8, 1.6, new THREE.MeshStandardMaterial({ color: 0x8a6040 }), 44, 21.6, 26.5);
    for (var k = 0; k < 6; k++) box(2.6, 0.3, 0.3, steel, 47 + (k % 2) * 0.2, 0.2 + k * 0.32, 13.6);
  })();

  /* ================= South road to the outskirts ================= */
  var ROADX = -5;
  (function () {
    plane(10, 154, M.asphalt, ROADX, 0.015, 11.2 + 77);
    plane(240, 8, M.asphalt, -35, 0.016, 95);
    var dash = canvasTex(64, 256, function (g, w, h) { g.clearRect(0, 0, w, h); g.fillStyle = "#e9e9e3"; g.fillRect(28, 0, 8, h * 0.5); }, true); dash.repeat.set(1, 30);
    var dl = plane(0.25, 150, new THREE.MeshStandardMaterial({ map: dash, transparent: true }), ROADX, 0.02, 12 + 75);
    mapRect(ROADX - 5, ROADX + 5, 11.2, 165, "#25292a"); mapRect(-155, 85, 91, 99, "#25292a");
    for (var z = 40; z < 165; z += 30) { tree(ROADX - 8, z, 1.1); tree(ROADX + 8, z + 14, 1); }
    sign("OUTSKIRTS  \u00b7  FARM  \u00b7  OIL  \u00b7  MINE  \u00b7  FACTORY", 9, 0.9, ROADX + 6.5, 3.6, 38, -Math.PI / 2, { bg: "#0f4d2a", fg: "#ffffff", size: 56, w: 1024, h: 100 });
    box(0.2, 3.2, 0.2, M.dark, ROADX + 6.5, 1.6, 34); box(0.2, 3.2, 0.2, M.dark, ROADX + 6.5, 1.6, 42);
  })();

  /* ================= Farm ================= */
  (function () {
    var soil = new THREE.MeshStandardMaterial({ color: 0x5a4126, roughness: 1 }), crop = new THREE.MeshStandardMaterial({ color: 0x6f9a35, roughness: 0.9, flatShading: true }), wheat = new THREE.MeshStandardMaterial({ color: 0xc9a74a, roughness: 0.9, flatShading: true });
    crop.userData.soft = wheat.userData.soft = true; /* crops: cars may drive through a field */
    plane(62, 42, soil, -69, 0.02, 66.5); mapRect(-100, -38, 45.5, 87.5, "#4a3a22");
    for (var i = 0; i < 14; i++) { var row = mesh(new THREE.BoxGeometry(58, 0.7, 1.1, 20, 1, 1), i < 7 ? crop : wheat, -69, 0.35, 48.5 + i * 2.8); row.receiveShadow = true; mapRect(-98, -40, 48 + i * 2.8, 49 + i * 2.8, i < 7 ? "#5d7f2c" : "#a8893c"); }
    var barnM = new THREE.MeshStandardMaterial({ color: 0x9c2a22, roughness: 0.8 }), trimM = M.white;
    box(16, 9, 14, barnM, -26, 4.5, 69); solid(-34, -18, 62, 76, "bld"); MAPB.push({ x1: -34, x2: -18, z1: 62, z2: 76, k: "barn" });
    var rs = new THREE.Shape(); rs.moveTo(-8.6, 0); rs.lineTo(0, 5.5); rs.lineTo(8.6, 0); rs.lineTo(-8.6, 0);
    var rg = new THREE.ExtrudeGeometry(rs, { depth: 14.6, bevelEnabled: false }); rg.translate(0, 0, -7.3);
    var roof = mesh(rg, new THREE.MeshStandardMaterial({ color: 0x3b3b3b, roughness: 0.7 }), -26, 9, 69); roof.rotation.y = Math.PI / 2;
    box(0.2, 6, 5, new THREE.MeshStandardMaterial({ color: 0x6b1d18 }), -17.9, 3, 69); box(0.25, 0.3, 5.4, trimM, -17.8, 6.1, 69); box(0.25, 6, 0.3, trimM, -17.8, 3, 66.4); box(0.25, 6, 0.3, trimM, -17.8, 3, 71.6);
    sign("GREEN ACRES FARM", 7, 0.9, -17.75, 7.6, 69, Math.PI / 2, { bg: "#f4f1ea", fg: "#6b1d18", size: 82, w: 1024, h: 130 });
    mesh(new THREE.CylinderGeometry(3, 3, 14, 20), M.metal, -28, 7, 54); mesh(new THREE.SphereGeometry(3, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2), M.metal, -28, 14, 54); solid(-31, -25, 51, 57, "bld"); MAPB.push({ x1: -31, x2: -25, z1: 51, z2: 57, k: "silo" });
    var tg = new THREE.Group(), tmat = new THREE.MeshStandardMaterial({ color: 0x2f7a2f, roughness: 0.5 });
    var tb = new THREE.Mesh(new THREE.BoxGeometry(3.2, 1.2, 1.6), tmat); tb.position.y = 1.3; tg.add(tb);
    var cab = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.4, 1.4), carGlass); cab.position.set(-0.6, 2.6, 0); tg.add(cab);
    [[1, 0.6], [-1, 0.95]].forEach(function (p) { [-1, 1].forEach(function (s) { var wh = new THREE.Mesh(new THREE.CylinderGeometry(p[1], p[1], 0.5, 18), tireM); wh.rotation.x = Math.PI / 2; wh.position.set(p[0], p[1], s * 1.05); tg.add(wh); }); });
    tg.position.set(-48, 0, 89.2); tg.traverse(function (o) { if (o.isMesh) o.castShadow = true; }); scene.add(tg); solid(-50, -46, 88, 90.4);
    var fenceW = new THREE.MeshStandardMaterial({ color: 0xd8ccb4, roughness: 0.8 });
    box(62, 0.12, 0.12, fenceW, -69, 0.9, 44.8); box(62, 0.12, 0.12, fenceW, -69, 0.5, 44.8); for (var f = -100; f <= -38; f += 3) box(0.14, 1.1, 0.14, fenceW, f, 0.55, 44.8);
    solid(-100, -38, 44.7, 44.9);
  })();

  /* ================= Oil field ================= */
  (function () {
    var dirt = new THREE.MeshStandardMaterial({ color: 0x6b5b45, roughness: 1 });
    plane(70, 42, dirt, 46, 0.02, 66.5); mapRect(11, 81, 45.5, 87.5, "#4a4032");
    var pj = new THREE.MeshStandardMaterial({ color: 0x2a2d31, roughness: 0.5, metalness: 0.5 }), head = new THREE.MeshStandardMaterial({ color: 0xd6a72a, roughness: 0.5 });
    [[26, 55], [48, 58], [68, 54], [38, 77], [60, 76]].forEach(function (p, i) {
      var x = p[0], z = p[1];
      box(7, 0.4, 2.4, M.curb, x, 0.2, z);
      var a1 = mesh(new THREE.BoxGeometry(0.3, 4.6, 0.3), pj, x, 2.3, z - 0.7); a1.rotation.x = 0.15; var a2 = mesh(new THREE.BoxGeometry(0.3, 4.6, 0.3), pj, x, 2.3, z + 0.7); a2.rotation.x = -0.15;
      var piv = new THREE.Group(); piv.position.set(x, 4.6, z); scene.add(piv);
      var beam = new THREE.Mesh(new THREE.BoxGeometry(7, 0.5, 0.5), pj); beam.castShadow = true; piv.add(beam);
      var hd = new THREE.Mesh(new THREE.BoxGeometry(0.9, 2.2, 0.8), head); hd.position.set(3.6, -0.4, 0); hd.castShadow = true; piv.add(hd);
      var cw = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 0.5, 16), head); cw.rotation.x = Math.PI / 2; cw.position.set(-2.6, -2.4, 0); scene.add(cw); cw.position.add(new THREE.Vector3(x, 4.6, z));
      mesh(new THREE.CylinderGeometry(0.14, 0.14, 3, 8), M.metal, x + 3.6, 1.5, z);
      ANIMS.push(function (t) { piv.rotation.z = Math.sin(t * 1.6 + i) * 0.32; cw.position.y = 2.2 + Math.sin(t * 1.6 + i + 1.6) * 0.5; });
      solid(x - 3.5, x + 3.5, z - 1.2, z + 1.2); MAPB.push({ x1: x - 3.5, x2: x + 3.5, z1: z - 1.2, z2: z + 1.2, k: "rig" });
    });
    [[72, 82], [64, 84]].forEach(function (p) { mesh(new THREE.CylinderGeometry(3.4, 3.4, 6, 24), M.white, p[0], 3, p[1]); solid(p[0] - 3.4, p[0] + 3.4, p[1] - 3.4, p[1] + 3.4, "bld"); MAPB.push({ x1: p[0] - 3.4, x2: p[0] + 3.4, z1: p[1] - 3.4, z2: p[1] + 3.4, k: "tank" }); });
    box(8, 3.6, 8, new THREE.MeshStandardMaterial({ color: 0xd8d2c4, roughness: 0.8 }), 12, 1.8, 70); solid(8, 16, 66, 74, "bld"); MAPB.push({ x1: 8, x2: 16, z1: 66, z2: 74, k: "concrete" });
    box(0.1, 2.4, 1.4, M.dark, 7.95, 1.2, 70, { shadow: false });
    sign("OIL FIELD  \u00b7  CONTROL", 6, 0.8, 7.9, 3.1, 70, -Math.PI / 2, { bg: "#111411", fg: "#d6a72a", size: 80, w: 1024, h: 130 });
  })();

  /* ================= Gold mine ================= */
  (function () {
    var rock = new THREE.MeshStandardMaterial({ color: 0x7a6650, roughness: 1, flatShading: true });
    var hill = mesh(new THREE.DodecahedronGeometry(30, 1), rock, -120, -6, 142); hill.scale.set(1, 0.75, 0.95);
    var hill2 = mesh(new THREE.DodecahedronGeometry(18, 1), rock, -142, -2, 120); hill2.scale.set(1, 0.9, 1);
    solid(-150, -92, 116, 170, "bld"); solid(-158, -128, 104, 134, "bld");
    MAPB.push({ x1: -158, x2: -92, z1: 104, z2: 170, k: "hill" });
    var timber = new THREE.MeshStandardMaterial({ color: 0x6a4a2a, roughness: 0.9 });
    box(1, 6, 1, timber, -116, 3, 113.6); box(1, 6, 1, timber, -108, 3, 113.6); box(9.2, 1, 1.2, timber, -112, 6.3, 113.6);
    box(7, 5.4, 3, new THREE.MeshBasicMaterial({ color: 0x050403 }), -112, 2.7, 115.4, { shadow: false });
    sign("GOLD MINE  \u00b7  SHAFT 3", 6, 0.9, -112, 7.4, 112.95, Math.PI, { bg: "#2a1d10", fg: "#e8b84a", size: 80, w: 1024, h: 130 });
    for (var z = 99; z < 114; z += 1.2) box(2.4, 0.12, 0.25, timber, -112, 0.06, z, { shadow: false });
    box(0.1, 0.1, 15, M.metal, -112.7, 0.16, 106.5, { shadow: false }); box(0.1, 0.1, 15, M.metal, -111.3, 0.16, 106.5, { shadow: false });
    var cart = box(2, 1.1, 2.4, new THREE.MeshStandardMaterial({ color: 0x3a3a3a, metalness: 0.6, roughness: 0.5 }), -112, 0.8, 104);
    box(1.8, 0.4, 2.2, new THREE.MeshStandardMaterial({ color: 0xe8b84a, metalness: 0.9, roughness: 0.3, emissive: 0x3a2a00 }), -112, 1.4, 104); solid(-113, -111, 102.8, 105.2);
    ANIMS.push(function (t) { var k = (Math.sin(t * 0.25) + 1) / 2; cart.position.z = 101 + k * 10; });
  })();

  /* ================= Factory + truck depot ================= */
  (function () {
    var wallM = new THREE.MeshStandardMaterial({ color: 0x8e959b, roughness: 0.7, metalness: 0.2 }), roofM = new THREE.MeshStandardMaterial({ color: 0x4a5058, roughness: 0.6, metalness: 0.4 });
    plane(70, 50, M.asphalt, 45, 0.02, 128); mapRect(10, 80, 103, 153, "#2a2e2c");
    box(50, 12, 28, wallM, 45, 6, 126); solid(20, 70, 112, 140, "bld"); MAPB.push({ x1: 20, x2: 70, z1: 112, z2: 140, k: "factory" });
    for (var i = 0; i < 5; i++) { var tri = new THREE.Shape(); tri.moveTo(0, 0); tri.lineTo(10, 0); tri.lineTo(10, 4); tri.lineTo(0, 0); var tg = new THREE.ExtrudeGeometry(tri, { depth: 28, bevelEnabled: false }); var t = mesh(tg, roofM, 20 + i * 10, 12, 112); }
    [[62, 136], [66, 136]].forEach(function (p) { mesh(new THREE.CylinderGeometry(1.2, 1.6, 30, 16), new THREE.MeshStandardMaterial({ color: 0x9a4a3a, roughness: 0.8 }), p[0], 15, p[1]); });
    box(5, 4.4, 0.15, M.dark, 30, 2.2, 111.9, { shadow: false });
    sign("FACTORY  \u00b7  ASSEMBLY LINE", 12, 1.3, 45, 9.4, 111.9, Math.PI, { bg: "#111411", fg: "#ff3d8b", size: 80, w: 1024, h: 120 });
    var smoke = []; for (var s = 0; s < 8; s++) { var sm = mesh(new THREE.SphereGeometry(1.6, 10, 8), new THREE.MeshStandardMaterial({ color: 0xd9d9d9, transparent: true, opacity: 0.35, depthWrite: false }), 62, 31, 136, true); smoke.push(sm); }
    ANIMS.push(function (t) { smoke.forEach(function (m, i) { var k = ((t * 0.12 + i / smoke.length) % 1); m.position.set(62 + k * 8 + (i % 2) * 4, 31 + k * 18, 136 - k * 3); m.scale.setScalar(0.6 + k * 2.2); m.material.opacity = 0.4 * (1 - k); }); });
    var shedM = new THREE.MeshStandardMaterial({ color: 0x3d4a55, roughness: 0.6, metalness: 0.4 });
    box(30, 0.5, 18, shedM, -55, 7, 115); [[-69.5, 106.5], [-40.5, 106.5], [-69.5, 123.5], [-40.5, 123.5]].forEach(function (p) { box(0.5, 7, 0.5, M.dark, p[0], 3.5, p[1]); solid(p[0] - 0.3, p[0] + 0.3, p[1] - 0.3, p[1] + 0.3); });
    box(30, 7, 0.3, shedM, -55, 3.5, 124); solid(-70, -40, 123.8, 124.2);
    plane(30, 18, new THREE.MeshStandardMaterial({ color: 0x55585c, roughness: 0.9 }), -55, 0.025, 115); mapRect(-70, -40, 106, 124, "#33372f", "rgba(255,61,139,0.6)");
    sign("TRUCK DEPOT  \u00b7  GARAGE", 10, 1.2, -55, 6.2, 105.9, Math.PI, { bg: "#ff3d8b", fg: "#0b0d0b", size: 80, w: 1024, h: 120 });
  })();
  ZONES.push({ id: "busIn", x: 2.5, z: 101, r: 2 });
  [["man", -20, 72, Math.PI / 2, 0x6b4f2f], ["man", 10, 66, -Math.PI / 2, 0x8a6a2a], ["man", -109, 107.6, Math.PI, 0x4a4a52], ["woman", 34, 110, Math.PI, 0x2f6b4f],
   ["man", -58, 108, Math.PI, 0x1d3f7a], ["man", 50, 15.4, Math.PI, 0xf2a030], ["woman", 56, 20, 0, 0xf2a030], ["man", -131, -10.3, 0, 0x2a1f14],
   ["woman", -138, 10.3, Math.PI, 0xe8e4d8], ["woman", -30, 10.3, Math.PI, 0x6b3a2a], ["officer", 22, -10.3, 0, 0], ["officer", 51, -10.3, 0, 0],
   ["woman", LMX + 32, 6, -Math.PI / 2, 0x7a1d3f], ["man", LMX + 33, -5, -Math.PI / 2, 0x3b5998], ["man", 103, 27.4, Math.PI, 0x13244a]].forEach(function (n) { NPCS.push({ kind: n[0], x: n[1], z: n[2], yaw: n[3], tint: n[4] || undefined, anim: "Idle" }); });
  (function () {
    box(4.2, 0.12, 1.6, M.dark, 2.5, 2.6, 102.3); box(4, 0.1, 0.4, M.wood, 2.5, 0.65, 102.8);
    sign("BUS  \u00b7  CITY CENTRE", 3.6, 0.5, 2.5, 2.95, 101.48, Math.PI, { bg: "#ff3d8b", fg: "#0b0d0b", size: 80, w: 1024, h: 140 });
  })();

  /* ================= Characters (CC0 Quaternius base characters + UAL animations) ================= */
  var player = null, ACTORS = [], npcSeed = 1000;
  var OFFICER = { sex: "M", skin: 2, hair: "Hair_Buzzed", hairColor: "#1c1512", beard: false, top: "suit", bottom: "slacks", c1: "#13244a", c2: "#0b1630", c3: "#13244a", shoes: "#111111", eye: "#4a2f1f" };
  function makeActor(kind, tint) {
    var tr;
    if (kind && typeof kind === "object") tr = kind;
    else if (kind === "officer") { npcSeed++; tr = Object.assign({}, OFFICER, { skin: npcSeed % 6, sex: npcSeed % 3 ? "M" : "F", hair: npcSeed % 3 ? "Hair_Buzzed" : "Hair_Buns" }); }
    else tr = People.traitsFor(npcSeed++, kind === "woman" ? "F" : kind === "man" ? "M" : null);
    var a = People.create(tr); scene.add(a.g); a.kind = kind; ACTORS.push(a); return a;
  }
  function removeActor(a) { scene.remove(a.g); var i = ACTORS.indexOf(a); if (i >= 0) ACTORS.splice(i, 1); }
  var ANIM_MAP = {};
  function blendTo(a, target, dt, speedRatio) { a.play(ANIM_MAP[target] || target, { speed: speedRatio || 1 }); }
  function lookFor(pp) { if (!pp.look) { pp.look = People.traitsFor(pp.id || 1, pp.sex, pp.job && pp.job[1]); save(); } return pp.look; }

  /* ================= Input ================= */
  var keys = {}, joy = { x: 0, y: 0, active: false }, run = false;
  window.addEventListener("keydown", function (e) { keys[e.key.toLowerCase()] = true; if (e.key === "Shift") run = true; if ((e.key === "e" || e.key === "Enter") && !$("prompt").hidden && !$("pB").disabled) $("pB").click(); });
  window.addEventListener("keyup", function (e) { keys[e.key.toLowerCase()] = false; if (e.key === "Shift") run = $("bRun").getAttribute("aria-pressed") === "true"; });
  try { if (matchMedia("(pointer: coarse)").matches || !matchMedia("(hover: hover)").matches) document.body.classList.add("has-joy"); } catch (e) {}
  var joyEl = $("joy"), knob = $("knob"), joyId = null;
  function joyMove(e) {
    var r = joyEl.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2, R = r.width / 2 - 14;
    var dx = e.clientX - cx, dy = e.clientY - cy, l = Math.hypot(dx, dy);
    if (l > R) { dx *= R / l; dy *= R / l; }
    knob.style.transform = "translate(" + dx + "px," + dy + "px)";
    joy.x = dx / R; joy.y = dy / R;
  }
  joyEl.addEventListener("pointerdown", function (e) { joyId = e.pointerId; joyEl.setPointerCapture(e.pointerId); joy.active = true; joyMove(e); e.preventDefault(); });
  joyEl.addEventListener("pointermove", function (e) { if (e.pointerId === joyId) joyMove(e); });
  function joyEnd(e) { if (e.pointerId !== joyId) return; joyId = null; joy.active = false; joy.x = joy.y = 0; knob.style.transform = ""; }
  joyEl.addEventListener("pointerup", joyEnd); joyEl.addEventListener("pointercancel", joyEnd);
  /* RUN: tap = run on/off, press and hold = run while held. Uses pointer events so it works while the other thumb is on the joystick. */
  (function () {
    var b = $("bRun"), t0 = 0, was = false;
    function setRun(v) { run = v; b.setAttribute("aria-pressed", v ? "true" : "false"); }
    b.addEventListener("pointerdown", function (e) {
      e.preventDefault(); e.stopPropagation(); try { b.setPointerCapture(e.pointerId); } catch (x) {}
      if (P.mode === "car") { leaveVehicle(); setRun(false); return; }
      was = run; t0 = performance.now(); setRun(true);
    });
    function up() { if (P.mode === "car" || !t0) return; var held = performance.now() - t0; t0 = 0; if (held > 350) setRun(false); else setRun(!was); }
    b.addEventListener("pointerup", up); b.addEventListener("pointercancel", up);
    b.addEventListener("contextmenu", function (e) { e.preventDefault(); });
    b.addEventListener("click", function (e) { e.preventDefault(); });
  })();
  window.addEventListener("keydown", function (e) {
    var k = e.key.toLowerCase();
    if (k === "f" && !e.repeat) { if (P.mode === "car") fireCannon(); else { firing = true; fireWeapon(); } }
    if (k === "q" && !e.repeat && P.mode !== "car") nextWeapon();
    if (k === "h" && P.mode === "car") sfx("horn");
    if ((k === "n" || e.key === "Shift") && P.mode === "car" && !e.repeat) useNitro();
  });
  window.addEventListener("keyup", function (e) { if (e.key === "f" || e.key === "F") firing = false; });
  $("bHit").addEventListener("pointerdown", function (e) { e.preventDefault(); e.stopPropagation(); firing = true; fireWeapon(); });
  ["pointerup", "pointercancel", "pointerleave"].forEach(function (ev) { $("bHit").addEventListener(ev, function () { firing = false; }); });
  $("dN").addEventListener("pointerdown", function (e) { e.preventDefault(); e.stopPropagation(); useNitro(); });
  $("dF").addEventListener("pointerdown", function (e) { e.preventDefault(); e.stopPropagation(); fireCannon(); });
  window.addEventListener("keydown", function (e) { if ((e.key === "r" || e.key === "R") && P.mode !== "car" && !e.repeat) { run = !run; $("bRun").setAttribute("aria-pressed", run ? "true" : "false"); toast(run ? "Running" : "Walking"); } });
  /* phones: play full screen in landscape */
  function goLandscape() {
    var el = document.documentElement, rq = el.requestFullscreen || el.webkitRequestFullscreen;
    try { var pr = rq ? rq.call(el) : null; Promise.resolve(pr).then(function () { if (screen.orientation && screen.orientation.lock) return screen.orientation.lock("landscape"); }).catch(function () {}); } catch (e) {}
  }
  $("rotateGo").addEventListener("click", goLandscape);
  setTimeout(function () { $("keys").classList.add("off"); }, 45000); window.addEventListener("keydown", function (e) { if (e.key === "h" || e.key === "H") $("keys").classList.toggle("off"); });
  $("rotateSkip").addEventListener("click", function () { document.body.classList.add("portraitOK"); });
  window.addEventListener("touchend", function once() { window.removeEventListener("touchend", once); if (matchMedia("(pointer: coarse)").matches && !document.fullscreenElement) goLandscape(); }, { passive: true });

  var cam = { yaw: Math.PI * 0.85, pitch: 0.32, dist: 6.2, tdist: 6.2 }, drags = {};
  canvas.addEventListener("pointerdown", function (e) { drags[e.pointerId] = { x: e.clientX, y: e.clientY }; canvas.setPointerCapture(e.pointerId); });
  canvas.addEventListener("pointermove", function (e) {
    var d = drags[e.pointerId]; if (!d) return;
    var ids = Object.keys(drags);
    if (ids.length >= 2) {
      var a = drags[ids[0]], b = drags[ids[1]], before = Math.hypot(a.x - b.x, a.y - b.y);
      d.x = e.clientX; d.y = e.clientY;
      var after = Math.hypot(drags[ids[0]].x - drags[ids[1]].x, drags[ids[0]].y - drags[ids[1]].y);
      cam.tdist = clamp(cam.tdist * before / Math.max(1, after), 2.4, 16);
      return;
    }
    camDragT = performance.now(); cam.yaw -= (e.clientX - d.x) * 0.006; cam.pitch = clamp(cam.pitch + (e.clientY - d.y) * 0.004, -0.05, 1.2);
    d.x = e.clientX; d.y = e.clientY;
  });
  function dragEnd(e) { delete drags[e.pointerId]; }
  var camDragT = 0, moveHungryT = 0;
  canvas.addEventListener("pointerup", dragEnd); canvas.addEventListener("pointercancel", dragEnd);
  canvas.addEventListener("wheel", function (e) { cam.tdist = clamp(cam.tdist * (1 + e.deltaY * 0.001), 2.4, 16); e.preventDefault(); }, { passive: false });

  /* ================= UI helpers ================= */
  var toastT = 0;
  function toast(msg) { $("toast").textContent = msg; $("toast").hidden = false; toastT = Date.now() + 3200; }
  function modal(html) { $("sheet").innerHTML = html; $("modal").hidden = false; var c = $("mClose"); if (c) c.addEventListener("click", closeModal); }
  function closeModal() { $("modal").hidden = true; $("sheet").innerHTML = ""; }
  $("modal").addEventListener("click", function (e) { if (e.target === $("modal")) closeModal(); });
  function tok(n) { return Math.round(n).toLocaleString("en-US") + " TOKEN"; }
  /* ===== skills: grow as you play, like GTA San Andreas ===== */
  var SKILLS = [["drive", "Driving"], ["shoot", "Shooting"], ["stamina", "Stamina"], ["strength", "Strength"], ["swim", "Swimming"], ["fly", "Flying"]];
  if (!G.skills) G.skills = { drive: 5, shoot: 0, stamina: 10, strength: 5, swim: 5, fly: 0 };
  var skillSaveT = 0;
  function sk(k) { return (G.skills && G.skills[k]) || 0; }
  function skillAdd(k, d) {
    var v = sk(k), nv = Math.min(100, v + d); if (nv === v) return; G.skills[k] = nv;
    if (Math.floor(nv / 5) > Math.floor(v / 5)) { var nm = SKILLS.filter(function (q) { return q[0] === k; })[0][1]; toast(nm + " skill increased \u00b7 " + Math.floor(nv) + "%"); save(); }
    else if (Date.now() - skillSaveT > 15000) { skillSaveT = Date.now(); save(); }
  }
  function skillsHTML() { return "<div class='eyebrow'>Skills \u00b7 they grow as you play</div><dl class='skills'>" + SKILLS.map(function (q) { var v = Math.floor(sk(q[0])); return "<dt>" + q[1] + "</dt><dd><i style='width:" + v + "%'></i></dd><em>" + v + "%</em>"; }).join("") + "</dl>"; }

  /* ================= Passport book ================= */
  function photoSVG(p) {
    var hairShape = ["M30 46 C30 22 70 22 70 46 C70 36 62 30 50 30 C38 30 30 36 30 46Z", "M28 50 C26 20 74 20 72 50 C70 40 64 34 50 33 C36 34 30 40 28 50Z M28 50 C26 64 30 74 32 78 L34 52Z M72 50 C74 64 70 74 68 78 L66 52Z", "M31 44 C33 26 67 26 69 44 L69 40 C64 34 58 36 50 34 C42 36 36 34 31 40Z"][p.style];
    return "<svg viewBox='0 0 100 133' xmlns='http://www.w3.org/2000/svg'><rect width='100' height='133' fill='#d9e7f2'/><path d='M14 133 C16 104 32 96 50 96 C68 96 84 104 86 133Z' fill='" + p.suit + "'/><path d='M42 96 L50 112 L58 96Z' fill='#f4f4f4'/><path d='M48 100 L50 118 L52 100Z' fill='#7a1f2b'/><rect x='43' y='76' width='14' height='22' rx='6' fill='" + p.skin + "'/><ellipse cx='50' cy='56' rx='19' ry='23' fill='" + p.skin + "'/><ellipse cx='31' cy='58' rx='3.5' ry='6' fill='" + p.skin + "'/><ellipse cx='69' cy='58' rx='3.5' ry='6' fill='" + p.skin + "'/><path d='" + hairShape + "' fill='" + p.hair + "'/><ellipse cx='43' cy='57' rx='2.2' ry='2.4' fill='#1d1d24'/><ellipse cx='57' cy='57' rx='2.2' ry='2.4' fill='#1d1d24'/><path d='M39 51 L46 50 M54 50 L61 51' stroke='" + p.hair + "' stroke-width='2' stroke-linecap='round'/><path d='M50 58 L48 66 L52 66' stroke='rgba(0,0,0,0.25)' stroke-width='1.4' fill='none' stroke-linecap='round'/><path d='M44 71 Q50 74 56 71' stroke='#7a3b3b' stroke-width='1.6' fill='none' stroke-linecap='round'/></svg>";
  }
  function check(s) { var w = [7, 3, 1], t = 0; for (var i = 0; i < s.length; i++) { var c = s[i], v = c === "<" ? 0 : /[0-9]/.test(c) ? +c : c.charCodeAt(0) - 55; t += v * w[i % 3]; } return String(t % 10); }
  function mrz(p) {
    var l1 = ("P<USA" + p.last.toUpperCase() + "<<" + p.first.toUpperCase() + "<".repeat(44)).slice(0, 44);
    var dob = String(p.dob[0]).slice(2) + String(p.dob[1]).padStart(2, "0") + String(p.dob[2]).padStart(2, "0"), exp = "361121", no = p.no.padEnd(9, "<").slice(0, 9), opt = "<".repeat(14);
    var l2 = no + check(no) + "USA" + dob + check(dob) + p.sex + exp + check(exp) + opt + check(opt);
    l2 = (l2 + check(no + check(no) + dob + check(dob) + exp + check(exp) + opt + check(opt))).padEnd(44, "<").slice(0, 44);
    return l1 + "<br>" + l2;
  }
  var MON = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"], STC = ["#a3243b", "#1f5aa6", "#2f7a4a", "#7a3fa6", "#a65f1f"];
  function stamps(from, to) {
    var s = "";
    G.stamps.slice(from, to).forEach(function (st, i) {
      var r = rng(hash(st.code + st.t)), col = STC[Math.floor(r() * 5)];
      s += "<div class='stamp" + (r() < 0.4 ? " sq" : "") + "' style='left:" + (6 + (i % 2) * 50 + r() * 6) + "%;top:" + (4 + Math.floor(i / 2) * 58 + r() * 6) + "px;color:" + col + ";transform:rotate(" + ((r() - 0.5) * 30).toFixed(0) + "deg)'>" + (st.kind === "in" ? "ENTRY" : "EXIT") + "<br>" + st.code + "<br>" + st.date + "</div>";
    });
    return s || "<div class='empty'>No stamps yet.<br>Travel abroad to fill this page.</div>";
  }
  var page = 0;
  function openPassport() {
    var p = G.passport, dob = String(p.dob[2]).padStart(2, "0") + " " + MON[p.dob[1] - 1] + " " + p.dob[0];
    modal("<div><div class='eyebrow'>Passport NFT \u00b7 #" + String(p.id).padStart(4, "0") + " of 3,333</div><h2>" + p.first + " " + p.last + "</h2></div>" +
      "<div class='book-wrap'><div class='book closed' id='book'></div></div><div class='pager'><button class='btn ghost' id='pgP' type='button'>Previous</button><button class='btn ghost' id='pgN' type='button'>Open</button></div>" +
      skillsHTML() + "<dl class='kv'><dt>Job (random at mint)</dt><dd>" + p.job[0] + "</dd><dt>Rarity</dt><dd>" + p.job[1] + "</dd><dt>Pay per shift</dt><dd>" + tok(p.job[4]) + "</dd><dt>Citizenship</dt><dd>United States</dd><dt>Now in</dt><dd>" + here().city + "</dd></dl>" +
      "<div class='row'><button class='btn ghost' id='reroll' type='button'>Sample another passport</button><button class='btn' id='mClose' type='button'>Close</button></div>");
    var leaves = [
      ["<div class='face cover'><div class='t1'>UNITED STATES OF AMERICA</div><svg viewBox='0 0 100 100' fill='none' stroke='currentColor' stroke-width='2.2'><circle cx='50' cy='50' r='38'/><ellipse cx='50' cy='50' rx='16' ry='38'/><path d='M12 50h76M18 30h64M18 70h64'/></svg><div><div class='t2'>PASSPORT</div><div class='t1' style='margin-top:6px'>EARTHPASS</div></div></div>",
       "<div class='face back inside'><div>This passport is your key to the world.<br><br>Work, travel, trade<br>and own land in every country.<br><br>TOKEN #" + String(p.id).padStart(4, "0") + " / 3333</div></div>"],
      ["<div class='face pg'><div class='ttl'><span>PASSPORT</span><span>USA</span></div><div class='data'><div class='photo'>" + photoSVG(p) + "</div><div class='fld'><span>SURNAME</span><b>" + p.last.toUpperCase() + "</b><span>GIVEN NAMES</span><b>" + p.first.toUpperCase() + "</b><span>NATIONALITY</span><b>UNITED STATES</b><span>DATE OF BIRTH</span><b>" + dob + "</b><span>PASSPORT NO.</span><b>" + p.no + "</b></div></div><div class='mrz'>" + mrz(p) + "</div></div>",
       "<div class='face back pg'><div class='ttl'><span>WORK PERMIT</span><span>#" + String(p.id).padStart(4, "0") + "</span></div><span class='rarity' style='background:" + p.job[3] + "'>" + p.job[1].toUpperCase() + "</span><div class='prof'>" + p.job[0] + "</div><div class='fld' style='margin-top:auto'><span>PAY PER SHIFT</span><b>" + p.job[4] + " TOKEN</b><span>PAID WHEN</span><b>WORKING</b></div></div>"],
      ["<div class='face pg'><div class='ttl'><span>VISAS</span><span>1</span></div><div class='stamps'>" + stamps(0, 4) + "</div></div>", "<div class='face back pg'><div class='ttl'><span>VISAS</span><span>2</span></div><div class='stamps'>" + stamps(4, 8) + "</div></div>"]
    ];
    var b = $("book");
    leaves.forEach(function (lf, i) { var el = document.createElement("div"); el.className = "leaf"; el.style.zIndex = 10 - i; el.innerHTML = lf[0] + lf[1]; b.appendChild(el); });
    page = 0;
    function setPage(n) {
      page = clamp(n, 0, 3);
      for (var i = 0; i < b.children.length; i++) { b.children[i].classList.toggle("flipped", i < page); b.children[i].style.zIndex = i < page ? 10 + i : 10 - i; }
      b.classList.toggle("closed", page === 0); $("pgP").disabled = page === 0; $("pgN").disabled = page >= 3; $("pgN").textContent = page === 0 ? "Open" : "Next page";
    }
    setPage(0);
    $("pgN").addEventListener("click", function () { setPage(page + 1); });
    $("pgP").addEventListener("click", function () { setPage(page - 1); });
    $("reroll").addEventListener("click", function () { G.passport = makePassport(1 + Math.floor(Math.random() * 3333)); save(); openPassport(); });
  }
  $("bPass").addEventListener("click", openPassport);

  /* ================= Travel ================= */
  function fees(a, b) { var km = distKm(a, b), intl = a.country !== b.country, t = Math.round(40 + km * 0.09); return { ticket: t, visa: intl ? 60 + (hash(b.country) % 5) * 20 : 0, tax: Math.round(t * (intl ? 0.08 : 0.04)), intl: intl }; }
  function slots() { var t = now(), first = Math.ceil((t + 20 * 60000) / (30 * 60000)) * 30 * 60000, s = []; for (var k = 0; k < 4; k++) s.push(first + k * 90 * 60000); return s; }
  function passHTML(tr) {
    var A = AIR[tr.from], B = AIR[tr.to];
    return "<div class='pass'><div class='main'><div class='brandline'><span>BOARDING PASS</span><em>" + tr.no + "</em></div><div class='route'>" + A.code + " <i>&#9992;</i> " + B.code + "</div><div style='font-size:11px;color:#6b6455'>" + A.city + " to " + B.city + "</div>" +
      "<div class='grid'><div>NAME<b>" + G.passport.last.toUpperCase() + "</b></div><div>GATE<b>B12</b></div><div>SEAT<b>" + tr.seat + "</b></div><div>DEPART<b>" + fmtT(tr.dep, A.tz) + "</b></div><div>CLASS<b>" + (tr.cls || "Economy").toUpperCase() + "</b></div><div>GROUP<b>" + (tr.cls === "First" ? "1" : tr.cls === "Business" ? "2" : "4") + "</b></div></div></div><div class='stub'><div>" + tr.no + "<br>" + tr.seat + "</div><div class='barcode'></div></div></div>";
  }
  function openAgency() {
    var a = here(), pick = G.pick && G.pick !== a.code ? G.pick : (a.us ? "LHR" : "JFK");
    var dests = AP.filter(function (x) { return x !== a; }).sort(function (x, y) { return (x.us === y.us ? 0 : x.us ? -1 : 1) || x.city.localeCompare(y.city); });
    var b = AIR[pick], f = fees(a, b), ss = slots();
    if (G.trip) { modal("<div><div class='eyebrow'>Global Travel</div><h2>You already have a ticket</h2></div>" + passHTML(G.trip) + "<div class='row'><button class='btn ghost' id='cancelT' type='button'>Cancel ticket</button><button class='btn' id='mClose' type='button'>Close</button></div>"); $("cancelT").addEventListener("click", function () { G.trip = null; G.flags = {}; save(); applyBlocks(); refreshSigns(); closeModal(); toast("Ticket cancelled"); }); return; }
    modal("<div><div class='eyebrow'>Global Travel \u00b7 " + a.city + "</div><h2>Where are you flying?</h2></div>" +
      "<label class='f'>Destination<select id='dest'>" + dests.map(function (x) { return "<option value='" + x.code + "'" + (x.code === pick ? " selected" : "") + ">" + x.city + ", " + x.country + " (" + x.code + ")</option>"; }).join("") + "</select></label>" +
      "<label class='f'>Departure, " + a.city + " time<select id='slot'>" + ss.map(function (x) { return "<option value='" + x + "'>" + fmtD(x, a.tz) + "  " + fmtT(x, a.tz) + "</option>"; }).join("") + "</select></label>" +
      "<div class='row' style='gap:10px'><label class='f' style='flex:1'>Class<select id='cls'><option value='Economy'>Economy</option><option value='Business'>Business · x2.4</option><option value='First'>First class · x4</option></select></label><label class='f' style='flex:1'>Seat<select id='seatp'><option value='A'>Window</option><option value='C'>Aisle</option><option value='B'>Middle</option></select></label></div>" +
      "<dl class='kv'><dt>Distance</dt><dd>" + Math.round(distKm(a, b)).toLocaleString("en-US") + " km</dd><dt>Flight time</dt><dd>" + dur(flightMs(a, b)) + "</dd><dt>Ticket</dt><dd id='tkP'>" + tok(f.ticket) + "</dd><dt>Visa</dt><dd>" + (f.intl ? tok(f.visa) : "Not needed") + "</dd><dt>Travel tax</dt><dd>" + tok(f.tax) + "</dd><dt class='tot'>Total</dt><dd class='tot' id='tkT'>" + tok(f.ticket + f.visa + f.tax) + "</dd></dl>" +
      "<div class='row'><button class='btn ghost' id='mClose' type='button'>Not now</button><button class='btn' id='pay' type='button'" + (G.balance < f.ticket + f.visa + f.tax ? " disabled" : "") + ">Pay and book</button></div>" +
      "<p class='note'>" + (G.balance < f.ticket + f.visa + f.tax ? "Not enough TOKEN. Work a shift at Summit Tower first." : "TOKEN is a placeholder name. Prices are samples.") + "</p>");
    $("dest").addEventListener("change", function (e) { G.pick = e.target.value; openAgency(); });
    var CLM = { Economy: 1, Business: 2.4, First: 4 };
    function priceNow() { var m = CLM[$("cls").value] || 1, t = Math.round(f.ticket * m), tx = Math.round(t * (f.intl ? 0.08 : 0.04)); return { t: t, total: t + f.visa + tx, tax: tx }; }
    $("cls").addEventListener("change", function () { var q = priceNow(); $("tkP").textContent = tok(q.t); $("tkT").textContent = tok(q.total); $("pay").disabled = G.balance < q.total; });
    $("pay").addEventListener("click", function () {
      var B = AIR[$("dest").value], dep = +$("slot").value, f2 = fees(a, B), h = hash(a.code + B.code + dep), q = priceNow(), total = q.total, cls = $("cls").value, sp = $("seatp").value;
      var rowN = cls === "First" ? 1 + h % 2 : cls === "Business" ? 3 + h % 4 : 10 + h % 28, letter = sp === "A" ? (h % 2 ? "A" : "F") : sp === "C" ? (h % 2 ? "C" : "D") : (h % 2 ? "B" : "E");
      if (G.balance < total) { toast("Not enough TOKEN"); return; }
      G.trip = { from: a.code, to: B.code, dep: dep, dur: flightMs(a, B), no: "PW " + (100 + h % 899), seat: rowN + letter, cls: cls, intl: f2.intl, stage: "booked" };
      spend(total, "Flight " + G.trip.no + " to " + B.city); missionEvent("booked");
      G.flags = {}; G.pick = null; save(); applyBlocks(); refreshSigns();
      modal("<div><div class='eyebrow'>Booked</div><h2>See you at the airport</h2></div>" + passHTML(G.trip) + "<p class='note'>Walk east along Main Street through the tunnel to the airport. Check in, pass security" + (G.trip.intl ? " and passport control" : "") + ", then scan your boarding pass at Gate B12. Boarding opens 30 minutes before departure. Everyone passes the entrance security at the terminal doors first.</p><button class='btn' id='mClose' type='button'>Got it</button>");
    });
  }
  $("bTicket").addEventListener("click", function () {
    if (!G.trip) { modal("<div><div class='eyebrow'>Ticket</div><h2>No ticket yet</h2></div><p class='note'>Book a flight at Global Travel, next to the airport.</p><button class='btn' id='mClose' type='button'>Close</button>"); return; }
    var tr = G.trip, A = AIR[tr.from];
    modal("<div><div class='eyebrow'>Your ticket</div><h2>" + A.city + " to " + AIR[tr.to].city + "</h2></div>" + passHTML(tr) + "<dl class='kv'><dt>Departs in</dt><dd>" + dur(tr.dep - now()) + "</dd><dt>Checked in</dt><dd>" + (G.flags.checkin ? "Yes" : "Not yet") + "</dd></dl><button class='btn' id='mClose' type='button'>Close</button>");
  });
  $("bSet").addEventListener("click", function () {
    modal("<div><div class='eyebrow'>Settings</div><h2>Test speed</h2></div><p class='note'>The live game runs in real time. Speed up the clock only to test flights and waiting.</p>" +
      "<select id='spd'><option value='1'>Real time</option><option value='60'>60\u00d7 faster</option><option value='600'>600\u00d7 faster</option></select>" +
      "<h2 style='margin-top:14px'>Sound</h2><label class='check'><input type='checkbox' id='sOn'> Sound on</label>" +
      "<label style='display:block;margin-top:10px'>Volume <input type='range' id='sVol' min='0' max='1' step='0.05' style='width:100%'></label>" +
      "<label style='display:block;margin-top:6px'>Music and radio <input type='range' id='sMus' min='0' max='1' step='0.05' style='width:100%'></label>" +
      "<button class='btn' id='mClose' type='button'>Done</button>");
    $("spd").value = String(clk.speed); $("spd").addEventListener("change", function (e) { setSpeed(+e.target.value); });
    if (SND) { var SP = SND.pref; $("sOn").checked = SP.on; $("sVol").value = SP.vol; $("sMus").value = SP.music;
      $("sOn").addEventListener("change", function (e) { SP.on = e.target.checked; SND.savePref(); SND.applyVol(); });
      $("sVol").addEventListener("input", function (e) { SP.vol = +e.target.value; SND.savePref(); SND.applyVol(); });
      $("sMus").addEventListener("input", function (e) { SP.music = +e.target.value; SND.savePref(); SND.applyVol(); }); }
  });

  function applyBlocks() {
    var tr = G.trip, arr = G.arrival;
    var secOpen = arr || !!G.flags.security;
    var immOpen = arr ? !!G.flags.entry || (G.arrivalDomestic) : (!!G.flags.immigration || (tr && !tr.intl && G.flags.security));
    blockSec.on = !secOpen; blockSec.mesh.visible = !secOpen;
    blockImm.on = !immOpen; blockImm.mesh.visible = !immOpen;
    if (blockEntry) { blockEntry.on = !entryOk; blockEntry.mesh.visible = !entryOk; }
  }

  /* ================= Gestures ================= */
  var gesture = null, passportProp = null;
  function doGesture(sec, done, anim, opts) { gesture = Object.assign({ t0: performance.now(), dur: sec * 1000, done: done, anim: anim }, opts || {}); }

  /* ================= Zones ================= */
  function zoneInfo(z) {
    var tzi = towerZoneInfo(z.id); if (tzi) return tzi;
    var tr = G.trip, t = now(), a = here();
    if (z.w) {
      if (working) return { t: "On shift \u00b7 " + working.title, d: "Stay here until the shift ends", b: "Working\u2026", off: true };
      var own = z.w.jobs.indexOf(G.passport.job[0]) >= 0;
      return own ? { t: z.w.t, d: "Your job: " + G.passport.job[0] + ". Work a shift for " + G.passport.job[4] + " TOKEN.", b: "Start shift" } : { t: z.w.t, d: "Part-time " + z.w.gig + ". Shift pays " + GIG + " TOKEN.", b: "Work part-time" };
    }
    if (z.id.indexOf("door:") === 0) { var pid = z.id.slice(5), pl0 = pid === "home" ? HOME : cityPlaces[pid]; if (!pl0) return null; return { t: pid === "home" ? "Your " + HOME.name.toLowerCase() : pl0.name, d: pid === "home" ? "Your home in " + CITY_NAME : pl0.fn, b: "Go inside" }; }
    if (z.id.indexOf("exit:") === 0) return { t: "Exit", d: "Back to the street", b: "Leave" };
    if (z.id.indexOf("tr:") === 0) return TRANSIT ? rideInfo(z) : null;
    switch (z.id) {
      case "jack": if (!jackZone.car) return null; return { t: jackZone.car.m.userData.moto ? "Motorbike" : "Car", d: "Pull the driver out and drive away", b: jackZone.car.m.userData.moto ? "Steal motorbike" : "Steal car" };
      case "vaultDoor": return G.mis && G.mis.id === "bigScore" && MIS.bigScore.steps[G.mis.step].ev === "vault" ? { t: "Bank vault", d: "Crack the lock. The alarm will go off.", b: "Crack the vault" } : { t: "Bank vault", d: "Staff only", b: "Locked", off: true };
      case "homeSofa": return { t: "Sofa", d: P.seat ? "Relaxing at home" : "Sit down and relax", b: P.seat ? "Stand up" : "Sit down" };
      case "homeBed": return { t: "Bed", d: "Take a nap.", b: "Rest" };
      case "homeFridge": return G.food >= 98 ? { t: "Kitchen", d: "You are not hungry.", b: "Eat", off: true } : { t: "Kitchen", d: "Cook a meal at home.", b: "Eat for 6 TOKEN", off: G.balance < 6 };
      case "grocery": return G.food >= 98 ? { t: "Fresh Mart", d: "You are not hungry right now.", b: "Buy food", off: true } : { t: "Fresh Mart", d: "Meal and drink, refills your food bar.", b: "Buy for 15 TOKEN", off: G.balance < 15 };
      case "agency": return { t: "Global Travel", d: G.trip ? "View or cancel your ticket" : "Book flights and visas", b: "Talk to agent" };
      case "diner": return G.food >= 98 ? { t: "Restaurant", d: "You are not hungry right now.", b: "Eat", off: true } : { t: "Restaurant table", d: "Sit down for a full meal.", b: "Eat for 25 TOKEN", off: G.balance < 25 };
      case "police": return { t: "Police HQ", d: "Government jobs are run by the EarthPass team.", b: "Team only", off: true };
      case "busOut": return { t: "Bus stop", d: "Ride to the outskirts: farm, oil field, gold mine, factory", b: "Take the bus \u00b7 3 TOKEN", off: G.balance < 3 };
      case "busIn": return { t: "Bus stop", d: "Ride back to the city centre", b: "Take the bus \u00b7 3 TOKEN", off: G.balance < 3 };
      case "sit": return P.seat ? null : { t: "Seat", d: "Sit down and rest for a while", b: "Sit" };
      case "entrySec": if (entryOk) return null; return { t: "Entrance security", d: (G.weapons && Object.keys(G.weapons).some(function (k) { return G.weapons[k] > 0; })) ? "Weapons are not allowed inside. They go in a locker." : "Bag scan and body scan before you enter the terminal", b: "Go through security" };
      case "ticketDesk": return { t: "Airline tickets", d: G.trip ? "View or change your ticket" : "Buy a flight here, same as Global Travel", b: G.trip ? "My ticket" : "Buy a ticket" };
      case "airCafe": return { t: "Sky Cafe", d: G.food >= 98 ? "You are not hungry" : "Coffee and a sandwich · 9 TOKEN", b: "Order", off: G.food >= 98 || G.balance < 9 };
      case "foodCourt": return { t: "Food court", d: G.food >= 98 ? "You are not hungry" : "Burger, noodles or coffee · 12 TOKEN", b: "Order food", off: G.food >= 98 || G.balance < 12 };
      case "dutyFree": return { t: "Duty free", d: "Perfume, chocolate, sunglasses and souvenirs", b: "Shop" };
      case "armsShop": return { t: "Arms & Auto", d: "Guns, armor, nitro and fast rides", b: "Shop" };
      case "tank": return TANK && TANK.home ? { t: "Battle tank", d: "Stealing it brings four wanted stars", b: "Steal the tank" } : null;
      case "taxi": if (taxi.m.userData.air) return { t: taxi.m.userData.air === "heli" ? "Helicopter" : "Plane", d: taxi.m.userData.air === "heli" ? "UP to lift off \u00b7 FWD to fly" : "Throttle up on the runway, then pull UP", b: "Get in and fly" }; if (taxi.m.userData.tank) return { t: "Tank", d: "Climb back in", b: "Get in" }; if (taxi.m.userData.boat) return { t: "Speedboat", d: "Drive it on the river", b: "Get in" }; return { t: "Taxi", d: G.passport.job[0] === "Taxi Driver" ? "You are a taxi driver. Earn per kilometre." : "Drive around the city", b: "Get in and drive" };
      case "cityhall": return { t: "City Hall \u00b7 Land Office", d: "Land ownership opens in the next phase. You will need your passport and TOKEN.", b: "Coming soon", off: true };
      case "tunnel": return { t: "Airport", d: "Walk through the tunnel to the terminal", b: "Go to the airport" };
      case "toCity": return { t: a.city + " city centre", d: "Back to Main Street", b: "Walk to the city" };
      case "checkin":
        if (G.arrival) return null;
        if (!tr) return { t: "Check-in", d: "You need a ticket. Book at Global Travel next to the airport.", b: "No ticket", off: true };
        if (G.flags.checkin) return { t: "Checked in", d: "Go to security", b: "Done", off: true };
        if (tr.dep - t < 0) return { t: "Check-in closed", d: "Your flight has left. Book a new one.", b: "Missed", off: true };
        return { t: "Check-in desk", d: "Hand over your passport to get your boarding pass", b: "Check in" };
      case "security":
        if (G.arrival) return null;
        if (!G.flags.checkin) return { t: "Security", d: "Check in first to get a boarding pass", b: "Closed", off: true };
        if (G.flags.security) return null;
        return { t: "Security check", d: "Scan your passport and walk through the scanner", b: "Scan passport" };
      case "immigration":
        if (G.arrival) { if (G.arrivalDomestic || G.flags.entry) return null; return { t: "Passport control", d: "Show your passport to enter " + a.country, b: "Show passport" }; }
        if (!tr || !tr.intl || !G.flags.security || G.flags.immigration) return null;
        return { t: "Passport control", d: "Exit stamp for " + a.country, b: "Show passport" };
      case "gate":
        if (G.arrival || !tr || !G.flags.security) return null;
        if (tr.intl && !G.flags.immigration) return null;
        var left = tr.dep - t;
        if (left < 0) return { t: "Gate closed", d: "Flight " + tr.no + " has departed.", b: "Book again", miss: true };
        if (left > 30 * 60000) return { t: "Gate B12 \u00b7 " + tr.no, d: "Boarding opens at " + fmtT(tr.dep - 30 * 60000, a.tz) + " (in " + dur(left - 30 * 60000) + ")", b: "Wait", off: true };
        return { t: "Gate B12 \u00b7 Boarding", d: AIR[tr.to].city + " \u00b7 seat " + tr.seat, b: "Board the plane" };
      case "exit": if (!G.arrival) return null; return { t: "Exit", d: "Leave the airport into " + a.city, b: "Exit to " + a.city, off: !(G.arrivalDomestic || G.flags.entry) };
    }
    return null;
  }
  var working = null, GIG = 12;
  function act(z) {
    if (towerAct(z.id)) return;
    var tr = G.trip, a = here();
    if (z.w) {
      var own = z.w.jobs.indexOf(G.passport.job[0]) >= 0;
      working = { until: now() + 60000 * clk.speed, start: now(), z: z, pay: own ? G.passport.job[4] : GIG, title: own ? G.passport.job[0] : z.w.gig, place: z.w.id, face: z.face };
      if (z.seat) { sitAt(z.seat); working.seated = true; }
      toast("Shift started as " + working.title + ". Stay for 1 minute."); missionEvent("shiftStart:" + z.w.id); return;
    }
    missionEvent(z.id);
    if (z.id.indexOf("door:") === 0) { enterPlace(z.id.slice(5)); return; }
    if (z.id.indexOf("exit:") === 0) { leavePlace(); return; }
    if (z.id.indexOf("tr:") === 0) { rideAct(z); return; }
    switch (z.id) {
      case "jack": carjack(jackZone.car); break;
      case "vaultDoor": toast("Cracking the vault…"); doGesture(9, function () { missionEvent("vault"); setWanted(3, "ALARM! The police are on their way · ★★★"); }, "Fix", { passport: false }); break;
      case "homeSofa": if (P.seat) standUp(); else sitAt(z.seat); break;
      case "homeBed": fadeTo(function () { G.food = Math.max(0, G.food - 5); toast("You feel rested"); }); break;
      case "homeFridge": spend(6, "Groceries at home"); P.yaw = z.face || 0; doGesture(4, function () { G.food = Math.min(100, G.food + 45); save(); toast("Home-cooked meal \u00b7 \u22126 TOKEN"); missionEvent("ate"); }, "Eat", { passport: false }); break;
      case "diner": sitAt(z.seat); spend(25, "Restaurant meal"); setTimeout(function () { player.play("Eat"); }, 1000); setTimeout(function () { G.food = 100; save(); standUp(); toast("Great meal \u00b7 \u221225 TOKEN"); missionEvent("ate"); }, 7000); break;
      case "busOut": spend(3, "Bus fare"); teleport(2.5, 103, Math.PI); break;
      case "busIn": spend(3, "Bus fare"); (function () { var r = CITY && CITY.nearestRoad(CITY_OX, CITY_OZ, 400); if (r) teleport(r.x + (-r.dz) * (r.road.w / 2 + 2), r.z + r.dx * (r.road.w / 2 + 2), 0); else teleport(-240, 8.4, 0); })(); break;
      case "grocery": doGesture(1.6, function () { spend(15, "Fresh Mart groceries"); G.food = Math.min(100, G.food + 55); save(); toast("Ate a meal \u00b7 \u221215 TOKEN"); missionEvent("ate"); }); break;
      case "agency": openAgency(); break;
      case "taxi": boardVehicle(); break;
      case "armsShop": openShop(); break;
      case "sit": sitAt(z.seat); break;
      case "entrySec": entranceCheck(); break;
      case "ticketDesk": openAgency(); break;
      case "airCafe": case "foodCourt": var price = z.id === "airCafe" ? 9 : 12; spend(price, z.id === "airCafe" ? "Sky Cafe" : "Food court"); var near = null, nd2 = 9; ZONES.forEach(function (q) { if (q.id === "sit" && q.seat) { var dd = Math.hypot(q.x - P.x, q.z - P.z); if (dd < nd2) { nd2 = dd; near = q; } } }); if (near) { sitAt({ x: near.seat.x, z: near.seat.z, yaw: near.seat.yaw, anim: "Eat" }); setTimeout(function () { player.play("Eat"); }, 1000); } else doGesture(2.5, null, "Eat", { passport: false }); setTimeout(function () { G.food = 100; save(); toast("That hit the spot · food full"); }, 3500); missionEvent("ate"); break;
      case "dutyFree": dutyFree(); break;
      case "tank": stealTank(); break;
      case "tunnel": teleport(AX1 - 6, 8, -Math.PI / 2); break;
      case "toCity": teleport(58, 9, -Math.PI / 2); break;
      case "checkin": checkinSequence(function () { G.flags.checkin = true; save(); applyBlocks(); modal("<div><div class='eyebrow'>Check-in complete</div><h2>Your boarding pass</h2></div>" + passHTML(tr) + "<button class='btn' id='mClose' type='button'>Go to security</button>"); }); break;
      case "security": bodyScan(function () { G.flags.security = true; save(); applyBlocks(); toast("Cleared security"); }); break;
      case "immigration": immigrationSequence(a, G.arrival); break;
      case "gate": var info = zoneInfo(z); if (info && info.miss) { G.trip = null; G.flags = {}; save(); applyBlocks(); refreshSigns(); toast("Ticket expired. Book again at Global Travel."); } else boardingScan(board); break;
      case "exit": G.arrival = false; G.flags = {}; G.arrivalDomestic = false; save(); applyBlocks(); teleport(AX1 - 6, 8, -Math.PI / 2); toast("Welcome to " + a.city); break;
    }
  }

  /* ================= Player ================= */
  var P = { x: -70, z: 9, yaw: Math.PI, v: 0, mode: "walk" };
  if (G.arrival) { P.x = 154; P.z = 12; P.yaw = -Math.PI / 2; }
  function teleport(x, z, yaw) {
    $("fade").classList.add("on");
    setTimeout(function () { if (P.fall) endFall(); P.lv = null; P.x = x; P.z = z; P.yaw = yaw; cam.yaw = yaw + Math.PI; $("fade").classList.remove("on"); }, 600);
  }

  /* taxi */
  var meter = 0;
  var drive = { gas: 0, brake: 0, left: 0, right: 0 };
  function driveUI(on) {
    document.body.classList.toggle("driving", on); $("drive").hidden = !on; $("speedo").hidden = !on;
    if (!$("speedo")._horn) { $("speedo")._horn = 1; $("speedo").addEventListener("pointerdown", function () { sfx("horn"); }); }
    drive.gas = drive.brake = drive.left = drive.right = 0;
    ["dL", "dR", "dB", "dG"].forEach(function (id) { $(id).classList.remove("on"); });
  }
  function enterTaxi() {
    P.mode = "car"; P.swim = false; player.g.visible = false; taxi.skip = true; taxi.v = 0; taxi.steer = 0; meter = 0;
    cam.tdist = 11; cam.pitch = 0.34; cam.yaw = taxi.yaw - Math.PI / 2;
    $("bRun").textContent = "EXIT"; $("bRun").setAttribute("aria-pressed", "false");
    $("prompt").hidden = true; curZone = null; driveUI(true);
    var AU = taxi.m.userData; flyUI(!!AU.air);
    if (AU.air) { P.lv = null; cam.tdist = AU.air === "heli" ? 15 : AU.L > 14 ? (AU.armed ? 24 : 30) : 17; cam.pitch = 0.26; taxi.alt = taxi.alt || 0; taxi.vy = 0; if (AU.air === "plane") taxi.thr = 0; }
  }
  function exitTaxi() {
    if (taxi.m.userData.air) {
      var AU = taxi.m.userData, afl = topAt(taxi.x, taxi.z);
      if (taxi.alt - afl > 2.5) { bailOut(); return; }
      if (Math.abs(taxi.v) > 3) { toast("Slow down to stop first"); return; }
      taxi.v = 0; driveUI(false); flyUI(false); P.mode = "walk"; player.g.visible = true; cam.tdist = 6.2; cam.pitch = 0.32; $("bRun").textContent = "RUN";
      var side = AU.air === "heli" ? 2.6 : AU.L > 14 ? 3.4 : 2.4, fwd = AU.air === "plane" ? AU.L * 0.22 : 0, cy0 = Math.cos(taxi.yaw), sy0 = Math.sin(taxi.yaw);
      P.x = taxi.x + cy0 * fwd + sy0 * side; P.z = taxi.z - sy0 * fwd + cy0 * side; P.yaw = Math.atan2(sy0, cy0);
      P.lv = taxi.alt > 1.2 ? surfaceAt(P.x, P.z, taxi.alt) || surfaceAt(taxi.x, taxi.z, taxi.alt) : null;
      if (P.lv && !P.lv.inside(P.x, P.z)) { P.x = taxi.x; P.z = taxi.z; }
      if (!P.lv) { var aq = { x: P.x, z: P.z }; collide(aq, 0.32); if (CITY) CITY.collide(aq, 0.34); P.x = aq.x; P.z = aq.z; }
      if (P.lv && TOWER && P.lv.id !== "roof") TOWER.spawn();
      taxi.skip = false; missionEvent("exitTaxi"); return;
    }
    if (Math.abs(taxi.v) > 1.5) { toast("Slow down to stop first"); return; }
    taxi.v = 0; driveUI(false);
    P.mode = "walk"; player.g.visible = true; cam.tdist = 6.2; cam.pitch = 0.32; $("bRun").textContent = "RUN";
    var s = Math.sin(taxi.yaw), c = Math.cos(taxi.yaw);
    P.x = taxi.x + s * 1.9; P.z = taxi.z + c * 1.9; if (onBridge(taxi.x, taxi.z)) P.z = clamp(P.z, -6.8, 6.8); var pq = { x: P.x, z: P.z }; collide(pq, 0.32); P.x = pq.x; P.z = pq.z;
    if (taxi.m.userData.boat) { var land = null; for (var rr = 2; rr <= 7 && !land; rr += 1) for (var aa = 0; aa < 6.28 && !land; aa += 0.5) { var lx = taxi.x + Math.cos(aa) * rr, lz = taxi.z + Math.sin(aa) * rr; if (deckAt(lx, lz) || (!isWater(lx, lz) && freeAt(lx, lz))) land = [lx, lz]; } if (land) { P.x = land[0]; P.z = land[1]; P.swim = false; } else { P.x = taxi.x + s * 2.4; P.z = taxi.z + c * 2.4; P.swim = true; toast("You jumped into the water"); } }
    taxi.skip = false;
    if (meter > 0 && G.passport.job[0] === "Taxi Driver") { var fare = Math.floor(meter / 100) * 2; if (fare > 0) { earn(fare, "Taxi fares"); toast("Fares earned \u00b7 +" + fare + " TOKEN"); } }
    missionEvent("exitTaxi");
  }

  [["dL", "left"], ["dR", "right"], ["dB", "brake"], ["dG", "gas"]].forEach(function (pr) {
    var el = $(pr[0]), k = pr[1];
    function dn(e) { e.preventDefault(); try { el.setPointerCapture(e.pointerId); } catch (x) {} drive[k] = 1; el.classList.add("on"); }
    function upf() { drive[k] = 0; el.classList.remove("on"); }
    el.addEventListener("pointerdown", dn); el.addEventListener("pointerup", upf); el.addEventListener("pointercancel", upf); el.addEventListener("lostpointercapture", upf);
    el.addEventListener("contextmenu", function (e) { e.preventDefault(); });
  });
  /* driving into the river: the car sinks and you swim out */
  var SINK = null, SWIM_Y = 0;
  function sinkCar() {
    sfx("splash");
    var m = taxi.m, yaw = taxi.yaw, sp = taxi.v;
    SINK = { m: m, t: 0, x: taxi.x, z: taxi.z, yaw: yaw, v: clamp(sp, -4, 8) };
    var ring = new THREE.Mesh(new THREE.RingGeometry(1.7, 2.1, 40), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.6, depthWrite: false, side: THREE.DoubleSide })); ring.rotation.x = -Math.PI / 2; ring.position.set(taxi.x, 0.12, taxi.z); ring.renderOrder = 5; scene.add(ring); SINK.ring = ring;
    taxi.v = 0; driveUI(false); flyUI(false); P.mode = "walk"; P.swim = true; P.v = 0; P.lv = null; player.g.visible = true; cam.tdist = 6.2; cam.pitch = 0.3; $("bRun").textContent = "RUN"; meter = 0; taxi.alt = 0;
    P.x = taxi.x + Math.sin(yaw) * 2.2; P.z = taxi.z + Math.cos(yaw) * 2.2; P.yaw = yaw;
    var nm = carMesh(0xf2c230, "sedan", true); scene.add(nm); taxi.m = nm; taxi.x = -65.5; taxi.z = 18; taxi.yaw = Math.PI / 2; taxi.skip = false;
    toast("Splash! Your car sank in the river · swim to the shore"); missionEvent("exitTaxi");
  }
  function sinkTick(dt) {
    if (!SINK) return; SINK.t += dt; var k = Math.min(1, SINK.t / 4.5);
    SINK.v *= Math.max(0, 1 - dt * 1.4); SINK.x += Math.cos(SINK.yaw) * SINK.v * dt; SINK.z -= Math.sin(SINK.yaw) * SINK.v * dt;
    SINK.m.position.set(SINK.x, -0.4 - 2.6 * k * k, SINK.z); SINK.m.rotation.set(0.1 * k, SINK.yaw, -0.32 * k);
    var rk = Math.min(1, SINK.t / 2.5); SINK.ring.scale.setScalar(1 + rk * 2.2); SINK.ring.material.opacity = 0.6 * (1 - rk); SINK.ring.position.set(SINK.x, 0.12, SINK.z);
    if (SINK.t > 6) { scene.remove(SINK.m); scene.remove(SINK.ring); SINK = null; }
  }
  /* ===== car-only colliders made from the real 3D objects: anything standing at car height blocks vehicles (people still walk as before) ===== */
  var VCOL = [], VGRID = {}, VCELL = 8, vcolIv = null;
  function vAdd(c) { VCOL.push(c); var r = c.r; for (var i = Math.floor((c.x - r) / VCELL); i <= Math.floor((c.x + r) / VCELL); i++) for (var j = Math.floor((c.z - r) / VCELL); j <= Math.floor((c.z + r) / VCELL); j++) (VGRID[i + "," + j] || (VGRID[i + "," + j] = [])).push(c); }
  function vHit(px, pz) {
    var a = VGRID[Math.floor(px / VCELL) + "," + Math.floor(pz / VCELL)]; if (!a) return 0;
    for (var i = 0; i < a.length; i++) {
      var c = a[i], dx = px - c.x, dz = pz - c.z; if (dx * dx + dz * dz > c.r * c.r) continue;
      if (c.o) { var e = c.o.matrixWorld.elements; if (!c.o.visible || Math.abs(e[12] - c.t0[0]) + Math.abs(e[13] - c.t0[1]) + Math.abs(e[14] - c.t0[2]) > 0.05) continue; }
      if (c.circ) { var dd = Math.hypot(dx, dz); if (dd < c.hx) return 0.05 + c.hx - dd; continue; }
      var lx = Math.abs(dx * c.cs - dz * c.sn), lz = Math.abs(dx * c.sn + dz * c.cs); if (lx < c.hx && lz < c.hz) return 0.05 + Math.min(c.hx - lx, c.hz - lz);
    }
    return 0;
  }
  function buildVCOL() {
    VCOL = []; VGRID = {};
    var skip = new Set(), top = function (o) { while (o.parent && o.parent !== scene) o = o.parent; return o; };
    scene.traverse(function (o) { if (o.isSkinnedMesh) skip.add(top(o)); });
    CARS.forEach(function (c) { if (c.m) skip.add(top(c.m)); });
    [taxi.m, player.g, sky, rainMesh].forEach(function (o) { if (o) skip.add(top(o)); });
    if (CITY) Object.keys(CITY.tiles).forEach(function (k) { if (CITY.tiles[k].g) skip.add(top(CITY.tiles[k].g)); });
    if (TRANSIT && TRANSIT.rail) TRANSIT.rail.trains.forEach(function (t) { skip.add(top(t.m)); });
    var bb = new THREE.Box3(), lb = new THREE.Box3(), mw = new THREE.Matrix4(), mi = new THREE.Matrix4(), pos = new THREE.Vector3(), q = new THREE.Quaternion(), sc = new THREE.Vector3(), up = new THREE.Vector3(), ax = new THREE.Vector3(), cen = new THREE.Vector3();
    function vPut(c, o) { var e = o.matrixWorld.elements; c.o = o; c.t0 = [e[12], e[13], e[14]]; c.hx = Math.max(c.hx, 0.22); if (!c.circ) c.hz = Math.max(c.hz, 0.22); c.r = Math.max(c.r, Math.hypot(c.hx, c.hz || c.hx) + 0.1); vAdd(c); }
    function addFrom(geo, M, o) {
      if (!geo.boundingBox) geo.computeBoundingBox(); lb.copy(geo.boundingBox);
      bb.copy(lb).applyMatrix4(M); if (bb.min.y > 1.5 || bb.max.y < 0.35) return;
      M.decompose(pos, q, sc); up.set(0, 1, 0).applyQuaternion(q); lb.getCenter(cen).applyMatrix4(M);
      var t = geo.type || "", round = /Cylinder|Sphere|Dodecahedron|Icosahedron|Octahedron|Lathe|Cone|Torus/.test(t);
      if (Math.abs(up.y) > 0.97) {
        ax.set(1, 0, 0).applyQuaternion(q);
        var yaw = Math.atan2(-ax.z, ax.x), hx = (lb.max.x - lb.min.x) / 2 * Math.abs(sc.x), hz = (lb.max.z - lb.min.z) / 2 * Math.abs(sc.z);
        if ((hx < 0.03 && hz < 0.03) || hx > 60 || hz > 60 || hx * hz > 900) return;
        if (round && Math.abs(hx - hz) < Math.max(hx, hz) * 0.25) {
          var rr = Math.min(hx, hz);
          if (/Dodeca|Icosa|Sphere|Octa/.test(t)) { var ry = (bb.max.y - bb.min.y) / 2, cy = (bb.max.y + bb.min.y) / 2, yb = Math.min(1.5, Math.max(0.35, cy)), f = 1 - Math.pow((yb - cy) / (ry || 1), 2); rr *= Math.sqrt(Math.max(0, f)); }
          vPut({ x: cen.x, z: cen.z, hx: rr, r: rr, circ: true }, o); return;
        }
        vPut({ x: cen.x, z: cen.z, hx: hx, hz: hz, cs: Math.cos(yaw), sn: Math.sin(yaw), r: Math.hypot(hx, hz) + 0.1 }, o);
      } else {
        var sx = (bb.max.x - bb.min.x) / 2, sz = (bb.max.z - bb.min.z) / 2; if (sx > 15 || sz > 15) return;
        vPut({ x: (bb.min.x + bb.max.x) / 2, z: (bb.min.z + bb.max.z) / 2, hx: sx, hz: sz, cs: 1, sn: 0, r: Math.hypot(sx, sz) + 0.1 }, o);
      }
    }
    scene.updateMatrixWorld(true);
    scene.traverse(function (o) {
      if (!o.isMesh || o.isSkinnedMesh || skip.has(top(o))) return;
      for (var v = o; v; v = v.parent) if (!v.visible) return;
      var mt = Array.isArray(o.material) ? o.material[0] : o.material;
      if (!mt || mt.userData.soft || o.userData.soft || mt.colorWrite === false || mt.blending === THREE.AdditiveBlending || mt.opacity < 0.12 || (mt.transparent && mt.type === "MeshBasicMaterial")) return;
      if (o.isInstancedMesh) { for (var i = 0; i < o.count; i++) { o.getMatrixAt(i, mi); mw.multiplyMatrices(o.matrixWorld, mi); addFrom(o.geometry, mw, o); } return; }
      addFrom(o.geometry, o.matrixWorld, o);
    });
    return VCOL.length;
  }
  /* a free spot for a vehicle near (x, z): no wall, pillar, building or other car under its outline */
  function carFreeAt(m, x, z, yaw) { var keep = taxi.m; taxi.m = m; var n = carHits(x, z, yaw); taxi.m = keep; return n === 0; }
  function findCarSpot(m, x, z, yaw) {
    if (carFreeAt(m, x, z, yaw)) return [x, z, yaw];
    for (var rr = 1.5; rr <= 30; rr += 1.5) for (var a = 0; a < 6.28; a += 0.4) { var tx = x + Math.cos(a) * rr, tz = z + Math.sin(a) * rr; if (isWater(tx, tz) && !m.userData.boat) continue; if (carFreeAt(m, tx, tz, yaw)) return [tx, tz, yaw]; if (carFreeAt(m, tx, tz, yaw + Math.PI / 2)) return [tx, tz, yaw + Math.PI / 2]; }
    return [x, z, yaw];
  }
  /* car body collision: sample points around the taxi's outline */
  function carHits(x, z, yaw) {
    var U = taxi.m.userData, L = U.L / 2 - 0.05, W = U.W / 2 - 0.05, cs = Math.cos(yaw), sn = Math.sin(yaw), n = 0;
    /* outline points every ~0.45 m so a thin pole or post can't slip between them */
    if (!U.hitPts || U.hitPts.L !== L || U.hitPts.W !== W) {
      var hp = [], nW = Math.max(2, Math.ceil(2 * W / 0.45)), nL = Math.max(2, Math.ceil(2 * L / 0.45));
      for (var a = 0; a <= nW; a++) { var zz = -W + 2 * W * a / nW; hp.push([L, zz], [-L, zz]); }
      for (var b = 1; b < nL; b++) { var xx = -L + 2 * L * b / nL; hp.push([xx, W], [xx, -W]); }
      hp.L = L; hp.W = W; U.hitPts = hp;
    }
    var pts = U.hitPts;
    for (var i = 0; i < pts.length; i++) {
      var px = x + pts[i][0] * cs + pts[i][1] * sn, pz = z - pts[i][0] * sn + pts[i][1] * cs;
      for (var j = 0; j < COL.length; j++) { var c = COL[j]; if (c.on && px > c.x1 && px < c.x2 && pz > c.z1 && pz < c.z2) { n += 0.05 + Math.min(px - c.x1, c.x2 - px, pz - c.z1, c.z2 - pz); break; } }
      if (!onBridge(px, pz)) { var vh = vHit(px, pz); if (vh > 0) n += vh; }
      if (CITY && !onBridge(px, pz) && CITY.hit(px, pz, 0)) { var tp = { x: px, z: pz }; CITY.collide(tp, 0.01); n += 0.05 + Math.hypot(tp.x - px, tp.z - pz); }
      for (var k = 0; k < CARS.length; k++) {
        var o = CARS[k]; if (o.skip || o === taxi || o.m === taxi.m) continue;
        var oy = o.yaw !== undefined ? o.yaw : (o.dir > 0 ? 0 : Math.PI), oc = Math.cos(oy), os = Math.sin(oy), dx = px - o.x, dz = pz - o.z, lx = Math.abs(dx * oc - dz * os), lz = Math.abs(dx * os + dz * oc), hl = o.m.userData.L / 2 + 0.1, hw = o.m.userData.W / 2 + 0.1;
        if (lx < hl && lz < hw) { if (taxi.m.userData.tank && !o.boat) { if (!o.burnt) explodeCar(o, false, true); break; } n += 0.05 + Math.min(hl - lx, hw - lz); break; }
      }
    }
    return n;
  }

  /* boarding cutscene + flight */
  var cine = null, scanFlash = 0;
  function board() {
    G.trip.stage = "boarded"; skillAdd("fly", 2); save();
    cine = { t0: performance.now(), phase: "walk" };
    $("prompt").hidden = true;
  }
  var JET_PATH = [
    [0, JET_HOME.x, 0, 12, Math.PI, 0],
    [6, JET_HOME.x + 30, 0, 12, Math.PI, 0],
    [10, JET_HOME.x + 52, 0, 40, Math.PI * 0.5 + 0.0, 0],
    [15, JET_HOME.x + 62, 0, 95, 0, 0],
    [17, JET_HOME.x + 75, 0, 95, 0, 0],
    [25, JET_HOME.x + 380, 0, 95, 0, 0],
    [28, JET_HOME.x + 560, 6, 95, 0, 0.12],
    [32, JET_HOME.x + 860, 80, 95, 0, 0.16]
  ];
  function jetAt(t) {
    for (var i = 0; i < JET_PATH.length - 1; i++) {
      var a = JET_PATH[i], b = JET_PATH[i + 1];
      if (t <= b[0]) {
        var k = (t - a[0]) / (b[0] - a[0]), e = i === 4 ? k * k : smooth(k);
        var yawA = a[4], yawB = b[4], dy = ((yawB - yawA + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
        return [lerp(a[1], b[1], e), lerp(a[2], b[2], e), lerp(a[3], b[3], e), yawA + dy * e, lerp(a[5], b[5], e)];
      }
    }
    var l = JET_PATH[JET_PATH.length - 1]; return [l[1], l[2], l[3], l[4], l[5]];
  }
  function showFlight() {
    var tr = G.trip; if (!tr) return;
    tr.stage = "inflight"; save();
    $("flight").hidden = false;
    $("fE").textContent = tr.no + " \u00b7 " + tr.from + " to " + tr.to;
    $("fSeat").textContent = tr.seat;
    $("fArr").textContent = fmtT(tr.dep + tr.dur, AIR[tr.to].tz);
  }
  $("fBtn").addEventListener("click", function () {
    var tr = G.trip, B = AIR[tr.to];
    G.city = B.code; G.arrival = true; G.arrivalDomestic = !tr.intl; G.flags = {}; G.trip = null; G.wp = null; G.mis = null; save();
    msg("EarthPass", "Welcome to " + B.city + ", " + B.country + ". " + (tr.intl ? "Go to passport control for your entry stamp." : "Exit the terminal into the city."));
    $("loading").hidden = false; $("lmsg").textContent = "ARRIVING IN " + B.city.toUpperCase(); $("lbar").style.width = "100%";
    setTimeout(function () { location.reload(); }, 400); return;
    $("flight").hidden = true; refreshSigns(); applyBlocks();
    placeJet(JET_HOME.x, 0, JET_HOME.z, JET_HOME.yaw);
    P.x = 154; P.z = 12; P.yaw = -Math.PI / 2; cam.yaw = Math.PI / 2; P.mode = "walk"; player.g.visible = true;
    toast("Welcome to " + B.city + (tr.intl ? " \u00b7 go to passport control" : ""));
  });

  /* in-flight: window or live map, and cabin meal service */
  var flightView = "win";
  $("fvWin").addEventListener("click", function () { flightView = "win"; $("fvWin").setAttribute("aria-pressed", "true"); $("fvMap").setAttribute("aria-pressed", "false"); });
  $("fvMap").addEventListener("click", function () { flightView = "map"; $("fvMap").setAttribute("aria-pressed", "true"); $("fvWin").setAttribute("aria-pressed", "false"); });
  function drawFlightMap(p, t) {
    var tr = G.trip, c = $("win"), g = c.getContext("2d"), W = c.width, H = c.height, A = AIR[tr.from], B = AIR[tr.to], k = clamp(p, 0, 1);
    var pts = []; for (var i = 0; i <= 80; i++) { var q = gcPoint(A, B, i / 80); pts.push(q); }
    for (var u = 1; u < pts.length; u++) { while (pts[u].lon - pts[u - 1].lon > 180) pts[u].lon -= 360; while (pts[u].lon - pts[u - 1].lon < -180) pts[u].lon += 360; }
    var x1 = 1e9, x2 = -1e9, y1 = 1e9, y2 = -1e9; pts.forEach(function (q) { x1 = Math.min(x1, q.lon); x2 = Math.max(x2, q.lon); y1 = Math.min(y1, q.lat); y2 = Math.max(y2, q.lat); });
    var cx = (x1 + x2) / 2, cy = (y1 + y2) / 2, sc = Math.min(W * 0.78 / Math.max(8, x2 - x1), H * 0.66 / Math.max(6, y2 - y1)), sx = function (lon) { return W / 2 + (lon - cx) * sc; }, sy = function (lat) { return H / 2 - (lat - cy) * sc + 10; };
    g.setTransform(1, 0, 0, 1, 0, 0); g.fillStyle = "#071016"; g.fillRect(0, 0, W, H);
    g.strokeStyle = "rgba(255,61,139,0.07)"; g.lineWidth = 1; for (var gl = -180; gl <= 540; gl += 10) { g.beginPath(); g.moveTo(sx(gl), 0); g.lineTo(sx(gl), H); g.stroke(); } for (var gt = -80; gt <= 80; gt += 10) { g.beginPath(); g.moveTo(0, sy(gt)); g.lineTo(W, sy(gt)); g.stroke(); }
    if (WPATH) { [-360, 0, 360].forEach(function (o) { g.save(); g.setTransform(sc, 0, 0, sc, W / 2 - (cx - o) * sc, H / 2 + cy * sc + 10); g.fillStyle = "#16261a"; g.fill(WPATH); g.lineWidth = 1 / sc; g.strokeStyle = "rgba(255,61,139,0.3)"; g.stroke(WPATH); g.restore(); }); }
    var n = Math.round(k * 80);
    g.setLineDash([8, 8]); g.strokeStyle = "rgba(233,236,230,0.55)"; g.lineWidth = 2.5; g.beginPath(); pts.forEach(function (q, i) { if (i) g.lineTo(sx(q.lon), sy(q.lat)); else g.moveTo(sx(q.lon), sy(q.lat)); }); g.stroke(); g.setLineDash([]);
    g.strokeStyle = "#ff3d8b"; g.lineWidth = 4; g.beginPath(); for (var j = 0; j <= n; j++) { var q2 = pts[j]; if (j) g.lineTo(sx(q2.lon), sy(q2.lat)); else g.moveTo(sx(q2.lon), sy(q2.lat)); } var pq = gcPoint(A, B, k); var pl = pts[Math.min(80, n)].lon + ((pq.lon - pts[Math.min(80, n)].lon + 540) % 360 - 180); g.lineTo(sx(pl), sy(pq.lat)); g.stroke();
    [[A, pts[0]], [B, pts[80]]].forEach(function (e, i) { var X = sx(e[1].lon), Y = sy(e[1].lat); g.fillStyle = i ? "#ffffff" : "#ff3d8b"; g.beginPath(); g.arc(X, Y, 7, 0, 7); g.fill(); g.font = "700 20px 'JetBrains Mono', monospace"; g.textAlign = "center"; g.fillStyle = "#e9ece6"; g.fillText(e[0].code + " · " + e[0].city.toUpperCase(), X, Y - 16); });
    var nq = gcPoint(A, B, Math.min(1, k + 0.01)), nl = pl + ((nq.lon - pl + 540) % 360 - 180), PX = sx(pl), PY = sy(pq.lat), ang = Math.atan2(sy(nq.lat) - PY, sx(nl) - PX);
    g.save(); g.translate(PX, PY); g.rotate(ang); g.fillStyle = "#ff3d8b"; g.shadowColor = "rgba(255,61,139,0.8)"; g.shadowBlur = 16;
    g.beginPath(); g.moveTo(18, 0); g.lineTo(4, -3); g.lineTo(-4, -16); g.lineTo(-8, -16); g.lineTo(-3, -3); g.lineTo(-12, -3); g.lineTo(-16, -8); g.lineTo(-18, -8); g.lineTo(-15, 0); g.lineTo(-18, 8); g.lineTo(-16, 8); g.lineTo(-12, 3); g.lineTo(-3, 3); g.lineTo(-8, 16); g.lineTo(-4, 16); g.lineTo(4, 3); g.closePath(); g.fill(); g.restore();
    var km = distKm(A, B), left = Math.max(0, km * (1 - k)), climb = Math.min(1, Math.min(k, 1 - k) / 0.05), alt = p < 0 ? 0 : Math.round(climb * 11280 / 10) * 10, spd = p < 0 ? 0 : Math.round(260 + climb * 645);
    var info = [["ALTITUDE", alt.toLocaleString("en-US") + " m"], ["GROUND SPEED", spd + " km/h"], ["TO " + B.code, Math.round(left).toLocaleString("en-US") + " km"], ["LOCAL TIME " + B.code, fmtT(t, B.tz)]];
    g.fillStyle = "rgba(5,6,5,0.78)"; g.fillRect(0, H - 74, W, 74);
    info.forEach(function (it, i) { var X = 24 + i * (W - 48) / 4; g.textAlign = "left"; g.fillStyle = "#9aa392"; g.font = "600 14px 'JetBrains Mono', monospace"; g.fillText(it[0], X, H - 46); g.fillStyle = "#ffffff"; g.font = "800 24px Unbounded, 'Arial Black', sans-serif"; g.fillText(it[1], X, H - 18); });
  }
  var MEALS = [["Chicken with rice", "Pasta primavera", "Vegetarian curry"], ["Fruit and yoghurt", "Sandwich", "Cookies and tea"]];
  function mealTick(tr, p) {
    if (!tr || p < 0 || p >= 1) { if (!$("meal").hidden && (!tr || p >= 1)) $("meal").hidden = true; return; }
    tr.meals = tr.meals || 0;
    var long = tr.dur > 2.5 * 3600000, plan = long ? [0.12, 0.78] : [0.35], due = tr.meals < plan.length && p >= plan[tr.meals];
    if (!due || !$("meal").hidden) return;
    var main = tr.meals === 0, list = main ? MEALS[0] : MEALS[1];
    $("mealT").textContent = "Cabin service · " + (main ? (localHour(now(), AIR[tr.from].tz) < 11 ? "Breakfast" : "Meal") : "Snack");
    $("mealH").textContent = main ? "Your meal is served" : "Something before landing?";
    $("mealD").textContent = "The crew is coming down the aisle. Pick one.";
    var b = $("mealB"); b.innerHTML = "";
    list.concat(["No, thanks"]).forEach(function (name, i) {
      var bt = document.createElement("button"); bt.type = "button"; bt.textContent = name;
      bt.addEventListener("click", function () { tr.meals++; if (i < list.length) { G.food = Math.min(100, G.food + (main ? 100 : 40)); toast("Enjoy your " + name.toLowerCase()); } save(); $("meal").hidden = true; });
      b.appendChild(bt);
    });
    $("meal").hidden = false;
  }

  /* window view */
  var clouds = []; (function () { var r = rng(99); for (var i = 0; i < 28; i++) clouds.push({ x: r(), y: r(), s: 0.4 + r() * 1.2, l: Math.floor(r() * 3) }); })();
  function drawWindow(p, dayK, t) {
    var c = $("win"), g = c.getContext("2d"), W = c.width, H = c.height;
    var alt = p < 0 ? 0 : Math.min(1, Math.min(p, 1 - p) / 0.04);
    function mixc(a, b, k) { return "rgb(" + a.map(function (v, i) { return Math.round(v + (b[i] - v) * k); }).join(",") + ")"; }
    g.fillStyle = "#cfd3d6"; g.fillRect(0, 0, W, H);
    var gr0 = g.createLinearGradient(0, 0, W, H); gr0.addColorStop(0, "#e9ebec"); gr0.addColorStop(1, "#b9bec2"); g.fillStyle = gr0; g.fillRect(0, 0, W, H);
    g.save(); g.beginPath(); var rx = W * 0.3, ry = H * 0.4; g.ellipse(W / 2, H / 2, rx, ry, 0, 0, 6.2832); g.clip();
    var sky2 = g.createLinearGradient(0, 0, 0, H);
    sky2.addColorStop(0, mixc([6, 10, 26], [56, 124, 214], dayK)); sky2.addColorStop(0.6, mixc([18, 22, 46], [150, 196, 238], dayK)); sky2.addColorStop(1, mixc([28, 26, 44], [236, 214, 190], dayK * 0.9));
    g.fillStyle = sky2; g.fillRect(0, 0, W, H);
    if (dayK < 0.5) { var sr = rng(5); g.fillStyle = "rgba(255,255,255," + (0.8 * (1 - dayK * 2)) + ")"; for (var i = 0; i < 70; i++) g.fillRect(sr() * W, sr() * H * 0.6, 1.8, 1.8); }
    var hz = H * (0.64 + (1 - alt) * 0.2);
    var gg = g.createLinearGradient(0, hz, 0, H); gg.addColorStop(0, mixc([10, 14, 24], [96, 120, 84], dayK)); gg.addColorStop(1, mixc([6, 8, 14], [58, 78, 50], dayK)); g.fillStyle = gg; g.fillRect(0, hz, W, H - hz);
    clouds.forEach(function (cl) {
      var x = ((cl.x - t / 1000 * 0.02 * (cl.l + 1)) % 1 + 1) % 1, y = alt > 0.6 ? hz + (cl.y * 0.9 - 0.05) * (H - hz) : cl.y * hz, s = cl.s * W * 0.07 * (cl.l + 1);
      g.fillStyle = "rgba(" + (dayK > 0.3 ? "255,255,255," : "150,160,190,") + (0.35 + cl.l * 0.15) + ")"; g.beginPath(); g.ellipse(x * W * 1.3 - W * 0.15, y, s * 1.6, s * 0.45, 0, 0, 6.2832); g.fill();
    });
    g.fillStyle = mixc([24, 26, 32], [232, 234, 236], dayK * 0.85); g.beginPath(); g.moveTo(W * 0.12, H * 0.98); g.lineTo(W * 0.6, H * 0.74); g.lineTo(W * 0.64, H * 0.77); g.lineTo(W * 0.2, H * 1.04); g.fill();
    g.fillStyle = "#ff3d8b"; g.beginPath(); g.moveTo(W * 0.6, H * 0.74); g.lineTo(W * 0.64, H * 0.77); g.lineTo(W * 0.66, H * 0.7); g.lineTo(W * 0.63, H * 0.69); g.fill();
    if (Math.floor(t / 900) % 2 === 0) { g.fillStyle = "#ff3b3b"; g.beginPath(); g.arc(W * 0.64, H * 0.7, 5, 0, 6.2832); g.fill(); }
    g.restore();
    g.strokeStyle = "#8f969c"; g.lineWidth = 16; g.beginPath(); g.ellipse(W / 2, H / 2, rx + 8, ry + 8, 0, 0, 6.2832); g.stroke();
    var shade = g.createLinearGradient(0, H / 2 - ry - 10, 0, H / 2 - ry + 30); shade.addColorStop(0, "rgba(0,0,0,0.25)"); shade.addColorStop(1, "rgba(0,0,0,0)"); g.fillStyle = shade; g.fillRect(W / 2 - rx, H / 2 - ry - 10, rx * 2, 40);
  }

  /* ================= Day / night ================= */
  /* ===================== Real sky: sun and moon from the real date and place, stars, clouds, wind, rain, storms ===================== */
  var RAD = Math.PI / 180;
  function astro(ms, lat, lon) {
    var d = ms / 86400000 - 10957.5, e = RAD * 23.4397;
    function eq(l, b) { return { ra: Math.atan2(Math.sin(l) * Math.cos(e) - Math.tan(b) * Math.sin(e), Math.cos(l)), dec: Math.asin(Math.sin(b) * Math.cos(e) + Math.cos(b) * Math.sin(e) * Math.sin(l)) }; }
    var M = RAD * (357.5291 + 0.98560028 * d), C = RAD * (1.9148 * Math.sin(M) + 0.02 * Math.sin(2 * M) + 0.0003 * Math.sin(3 * M)), sEq = eq(M + C + RAD * 102.9372 + Math.PI, 0);
    var L = RAD * (218.316 + 13.176396 * d), Mm = RAD * (134.963 + 13.064993 * d), F = RAD * (93.272 + 13.22935 * d), mEq = eq(L + RAD * 6.289 * Math.sin(Mm), RAD * 5.128 * Math.sin(F));
    var phi = RAD * lat, th = RAD * (280.16 + 360.9856235 * d) + RAD * lon;
    function dir(q) { var H = th - q.ra, alt = Math.asin(Math.sin(phi) * Math.sin(q.dec) + Math.cos(phi) * Math.cos(q.dec) * Math.cos(H)), az = Math.atan2(Math.sin(H), Math.cos(H) * Math.sin(phi) - Math.tan(q.dec) * Math.cos(phi)); return { alt: alt, v: new THREE.Vector3(-Math.sin(az) * Math.cos(alt), Math.sin(alt), Math.cos(az) * Math.cos(alt)) }; }
    var el = Math.acos(clamp(Math.sin(sEq.dec) * Math.sin(mEq.dec) + Math.cos(sEq.dec) * Math.cos(mEq.dec) * Math.cos(sEq.ra - mEq.ra), -1, 1)), inc = Math.atan2(149598000 * Math.sin(el), 385001 - 149598000 * Math.cos(el));
    var waxing = Math.sin(mEq.ra - sEq.ra) > 0;
    return { sun: dir(sEq), moon: dir(mEq), illum: (1 + Math.cos(inc)) / 2, waxing: waxing, lst: th };
  }
  /* weather: live from Open-Meteo for the real city, or a simulated cycle when offline, or a preset chosen in the phone */
  var WXP = { clear: ["Clear", 0.08, 0, 0, 2.5], fair: ["Few clouds", 0.32, 0, 0, 4], cloudy: ["Cloudy", 0.72, 0, 0, 6], overcast: ["Overcast", 0.92, 0, 0, 7], rain: ["Rain", 0.9, 0.55, 0, 8], storm: ["Thunderstorm", 1, 1, 1, 15], snow: ["Snow", 0.88, 0.5, 0, 4], fog: ["Fog", 0.75, 0, 0, 1.5] };
  var WX = { mode: G.wxMode || "live", live: null, liveCode: "", liveAt: 0, cur: { cover: 0.3, rain: 0, storm: 0, wind: 3, snow: 0, fog: 0 }, wdir: new THREE.Vector2(0.8, 0.6), label: "", temp: null, src: "", off: new THREE.Vector2(), flashT: 0, nextBolt: 8, wet: 0 };
  function wxFetch() {
    var a = here(); if (!a || a.lat == null || typeof fetch !== "function") return;
    WX.liveCode = a.code; WX.liveAt = Date.now();
    fetch("https://api.open-meteo.com/v1/forecast?latitude=" + a.lat.toFixed(3) + "&longitude=" + a.lon.toFixed(3) + "&current=temperature_2m,weather_code,cloud_cover,precipitation,wind_speed_10m,wind_direction_10m&timezone=auto")
      .then(function (r) { return r.json(); }).then(function (j) { if (j && j.current) { WX.live = j.current; WX.live.code = a.code; } }).catch(function () {});
  }
  function wxTarget() {
    var a = here(), m = WX.mode;
    if (m !== "live" && WXP[m]) { var p = WXP[m]; return { label: p[0], cover: p[1], rain: m === "snow" ? 0 : p[2], snow: m === "snow" ? p[2] : 0, storm: p[3], wind: p[4], fog: m === "fog" ? 1 : 0, temp: null, src: "Chosen in Weather app", dir: 0.9 }; }
    if (WX.live && WX.live.code === a.code) {
      var c = WX.live, k = c.weather_code | 0, pr = c.precipitation || 0, sn = (k >= 71 && k <= 77) || k === 85 || k === 86, rn = (k >= 51 && k <= 67) || (k >= 80 && k <= 82), st = k >= 95;
      var lbl = k === 0 ? "Clear" : k <= 2 ? "Few clouds" : k === 3 ? "Overcast" : k === 45 || k === 48 ? "Fog" : k <= 57 ? "Drizzle" : k <= 67 ? "Rain" : sn ? "Snow" : k <= 82 ? "Showers" : "Thunderstorm";
      var amt = clamp(0.2 + pr / 4, 0.2, 1);
      return { label: lbl, cover: clamp((c.cloud_cover || 0) / 100, st ? 0.95 : rn || sn ? 0.8 : 0, 1), rain: rn || st ? (st ? Math.max(0.8, amt) : amt) : 0, snow: sn ? amt : 0, storm: st ? 1 : 0, wind: (c.wind_speed_10m || 0) / 3.6, fog: k === 45 || k === 48 ? 1 : 0, temp: c.temperature_2m, src: "Live weather in " + a.city, dir: ((c.wind_direction_10m || 0) + 180) * RAD };
    }
    /* offline: a new sky every 40 minutes, the same for everyone in the same city */
    var blk = Math.floor(Date.now() / 2400000), hsh = hash(a.code + ":" + blk) % 100, key = hsh < 34 ? "clear" : hsh < 58 ? "fair" : hsh < 74 ? "cloudy" : hsh < 82 ? "overcast" : hsh < 92 ? "rain" : "storm";
    var q = WXP[key]; return { label: q[0], cover: q[1], rain: q[2], snow: 0, storm: q[3], wind: q[4] * (0.7 + (hsh % 7) / 10), fog: 0, temp: null, src: "Simulated weather", dir: (hsh % 36) * 10 * RAD };
  }
  var RAIN_N = 2600, rainPos = new Float32Array(RAIN_N * 6), rainSeed = new Float32Array(RAIN_N * 3);
  for (var ri = 0; ri < RAIN_N; ri++) { rainSeed[ri * 3] = Math.random(); rainSeed[ri * 3 + 1] = Math.random(); rainSeed[ri * 3 + 2] = Math.random(); }
  var rainGeo = new THREE.BufferGeometry(); rainGeo.setAttribute("position", new THREE.BufferAttribute(rainPos, 3));
  var rainM = new THREE.LineBasicMaterial({ color: 0xb8c8dc, transparent: true, opacity: 0.45, depthWrite: false, fog: false });
  var rainMesh = new THREE.LineSegments(rainGeo, rainM); rainMesh.frustumCulled = false; rainMesh.visible = false; scene.add(rainMesh);
  var bolt = new THREE.Line(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ color: 0xeef2ff, fog: false })); bolt.visible = false; bolt.frustumCulled = false; scene.add(bolt);
  /* wind: tree crowns sway (shader) */
  var windU = { value: new THREE.Vector3(0.8, 0.6, 3) }, timeU = skyU.uTime;
  function windify(mat) {
    if (!mat || mat.userData.windy) return; mat.userData.windy = true;
    mat.onBeforeCompile = function (sh) {
      sh.uniforms.uWind = windU; sh.uniforms.uWT = timeU;
      sh.vertexShader = "uniform vec3 uWind; uniform float uWT;\n" + sh.vertexShader.replace("#include <begin_vertex>", "#include <begin_vertex>\n#ifdef USE_INSTANCING\n vec4 wp0 = instanceMatrix * vec4(0.,0.,0.,1.);\n#else\n vec4 wp0 = modelMatrix * vec4(0.,0.,0.,1.);\n#endif\n float swy = (sin(uWT * (1.1 + uWind.z * 0.12) + wp0.x * 0.13 + wp0.z * 0.11) * 0.6 + 0.4) * min(uWind.z, 22.) * 0.012 * max(0., transformed.y - 1.2);\n transformed.x += swy * uWind.x; transformed.z += swy * uWind.y;");
    };
    mat.needsUpdate = true;
  }
  windify(M.leaf);
  /* weather sound: rain hiss, wind and thunder, made in code (starts after the first tap) */
  var WXA = null;
  function wxAudio() {
    if (WXA || G.wxSound === false) return;
    try {
      var AC = window.AudioContext || window.webkitAudioContext; if (!AC) return; var ac = new AC(), buf = ac.createBuffer(1, ac.sampleRate * 2, ac.sampleRate), dd = buf.getChannelData(0); for (var i = 0; i < dd.length; i++) dd[i] = Math.random() * 2 - 1;
      function loop(type, f, q) { var s = ac.createBufferSource(); s.buffer = buf; s.loop = true; var fl = ac.createBiquadFilter(); fl.type = type; fl.frequency.value = f; fl.Q.value = q; var gn = ac.createGain(); gn.gain.value = 0; s.connect(fl); fl.connect(gn); gn.connect(ac.destination); s.start(); return gn; }
      WXA = { ac: ac, buf: buf, rain: loop("bandpass", 2600, 0.6), wind: loop("lowpass", 380, 0.8) };
    } catch (e) { WXA = null; }
  }
  function thunder(delay, power) {
    if (!WXA) return; var ac = WXA.ac, t = ac.currentTime + delay, s = ac.createBufferSource(), fl = ac.createBiquadFilter(), gn = ac.createGain();
    s.buffer = WXA.buf; fl.type = "lowpass"; fl.frequency.setValueAtTime(900, t); fl.frequency.exponentialRampToValueAtTime(90, t + 2.2);
    gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(0.5 * power, t + 0.06); gn.gain.exponentialRampToValueAtTime(0.0001, t + 2.6);
    s.connect(fl); fl.connect(gn); gn.connect(ac.destination); s.start(t); s.stop(t + 2.8);
  }
  ["pointerdown", "keydown"].forEach(function (ev) { window.addEventListener(ev, function () { wxAudio(); if (WXA && WXA.ac.state === "suspended") WXA.ac.resume(); }, { passive: true }); });
  function strike() {
    var a = Math.random() * Math.PI * 2, dist = 220 + Math.random() * 600, x = camera.position.x + Math.cos(a) * dist, z = camera.position.z + Math.sin(a) * dist, pts = [], y = 520;
    var px = x, pz = z; while (y > 0) { pts.push(new THREE.Vector3(px, y, pz)); y -= 25 + Math.random() * 40; px += (Math.random() - 0.5) * 30; pz += (Math.random() - 0.5) * 30; } pts.push(new THREE.Vector3(px, 0, pz));
    bolt.geometry.dispose(); bolt.geometry = new THREE.BufferGeometry().setFromPoints(pts); bolt.visible = true; WX.flashT = 0.32; WX.boltT = 0.22;
    thunder(Math.min(3.5, dist / 340), dist < 400 ? 1 : 0.6);
  }
  var lastAstro = null;
  function wxTick(dt, tsec) {
    if (!WX.liveAt || Date.now() - WX.liveAt > 900000 || WX.liveCode !== here().code) wxFetch();
    var T = wxTarget(), C = WX.cur, k = 1 - Math.exp(-dt / (WX.fast > 0 ? 3 : 45)); if (WX.fast > 0) WX.fast -= dt;
    ["cover", "rain", "storm", "wind", "snow", "fog"].forEach(function (n) { C[n] += ((T[n] || 0) - C[n]) * k; });
    WX.label = T.label; WX.temp = T.temp; WX.src = T.src;
    var tdx = Math.cos(T.dir || 0), tdz = Math.sin(T.dir || 0); WX.wdir.x += (Math.sin(T.dir || 0) - WX.wdir.x) * k; WX.wdir.y += (-Math.cos(T.dir || 0) - WX.wdir.y) * k;
    var gust = 1 + 0.35 * Math.sin(tsec * 0.7) * Math.sin(tsec * 0.23 + 1.3), ws = C.wind * gust;
    windU.value.set(WX.wdir.x, WX.wdir.y, ws);
    WX.off.x += WX.wdir.x * (0.0012 + ws * 0.00035) * dt; WX.off.y += WX.wdir.y * (0.0012 + ws * 0.00035) * dt; skyU.wind.value.copy(WX.off);
    skyU.cover.value = C.cover; timeU.value = tsec % 3600;
    /* lightning */
    if (C.storm > 0.5) { WX.nextBolt -= dt; if (WX.nextBolt <= 0) { WX.nextBolt = 5 + Math.random() * 11; strike(); } }
    if (WX.flashT > 0) { WX.flashT -= dt; skyU.flash.value = Math.max(0, WX.flashT / 0.32) * (Math.random() < 0.7 ? 1 : 0.3); } else skyU.flash.value = 0;
    if (WX.hemiBase != null) hemi.intensity = WX.hemiBase + skyU.flash.value * 1.6;
    if (WX.boltT > 0) { WX.boltT -= dt; if (WX.boltT <= 0) bolt.visible = false; }
    /* rain or snow around the camera */
    var amt = Math.max(C.rain, C.snow), sheltered = INSIDE || (P.lv && P.lv.camBox) || camera.position.x > 4000;
    rainMesh.visible = amt > 0.03 && !sheltered;
    if (rainMesh.visible) {
      var snow = C.snow > C.rain, n = Math.floor(RAIN_N * Math.min(1, amt * 1.1)), cx = camera.position.x, cy = camera.position.y, cz = camera.position.z, BX = 46, BY = 30, sp = snow ? 1.6 : 24, len = snow ? 0.07 : 0.75, wx = WX.wdir.x * ws * (snow ? 0.5 : 0.25), wz = WX.wdir.y * ws * (snow ? 0.5 : 0.25);
      for (var i = 0; i < n; i++) {
        var s = rainSeed, fy = ((s[i * 3 + 2] * BY - tsec * sp * (0.85 + s[i * 3] * 0.3)) % BY + BY) % BY, x = cx + ((s[i * 3] * BX + wx * fy / sp * 0) % BX) - BX / 2, z = cz + (s[i * 3 + 1] * BX) - BX / 2, y = cy - BY / 2 + fy;
        x += wx * (fy / BY) * 1.5 + (snow ? Math.sin(tsec * 1.3 + i) * 0.4 : 0); z += wz * (fy / BY) * 1.5;
        var o = i * 6; rainPos[o] = x; rainPos[o + 1] = y; rainPos[o + 2] = z; rainPos[o + 3] = x - wx * len / sp * 4; rainPos[o + 4] = y + len; rainPos[o + 5] = z - wz * len / sp * 4;
      }
      rainGeo.attributes.position.needsUpdate = true; rainGeo.setDrawRange(0, n * 2);
      rainM.color.set(snow ? 0xffffff : 0xa9bdd6); rainM.opacity = snow ? 0.85 : 0.32 + amt * 0.25;
    }
    WX.wet = clamp(WX.wet + (C.rain > 0.1 ? dt / 60 : -dt / 300), 0, 1); M.asphalt.roughness = 0.9 - WX.wet * 0.45; M.asphalt.metalness = WX.wet * 0.25;
    if (WXA) { var tg = WXA.ac.currentTime; WXA.rain.gain.setTargetAtTime(sheltered ? C.rain * 0.02 : C.rain * 0.09, tg, 0.5); WXA.wind.gain.setTargetAtTime(clamp(ws / 20, 0, 1) * (playerY() > 60 ? 0.12 : 0.05), tg, 0.5); }
  }
  var envDay = 1;
  function updateSky(t) {
    var a = here(), A = astro(t, a.lat, a.lon); lastAstro = A;
    var el = Math.sin(A.sun.alt), day = smooth((el + 0.12) / 0.4), dusk = Math.max(0, 1 - Math.abs(el) / 0.28) * (el > -0.22 ? 1 : 0), C = WX.cur, cov = C.cover, storm = C.storm;
    envDay = day;
    var grey = new THREE.Color(0.5, 0.53, 0.58).multiplyScalar(0.25 + day * 0.75 - storm * 0.18);
    var top = new THREE.Color(0x070b1c).lerp(new THREE.Color(0x2f72c9), day).lerp(grey, cov * 0.75);
    var mid = new THREE.Color(0x141a32).lerp(new THREE.Color(0x9cc4e8), day).lerp(new THREE.Color(0xff9a5c), dusk * 0.6 * (1 - cov * 0.6)).lerp(grey, cov * 0.7 + C.fog * 0.3);
    var bot = new THREE.Color(0x0a0d14).lerp(new THREE.Color(0xd5dde3), day).lerp(grey, cov * 0.5);
    skyU.top.value.copy(top); skyU.mid.value.copy(mid); skyU.bot.value.copy(bot);
    skyU.sunDir.value.copy(A.sun.v); skyU.sunVis.value = smooth((el + 0.04) / 0.08);
    skyU.sunCol.value.set(0xfff1dc).lerp(new THREE.Color(0xff7a3c), dusk * 0.8);
    skyU.moonDir.value.copy(A.moon.v); skyU.moonVis.value = smooth((Math.sin(A.moon.alt) + 0.02) / 0.06);
    skyU.stars.value = (1 - smooth((el + 0.2) / 0.22)) * (1 - C.fog);
    var cr = A.lst, cs = Math.cos(cr), sn = Math.sin(cr); skyU.starRot.value.set(cs, 0, -sn, 0, 1, 0, sn, 0, cs);
    var lit = new THREE.Color(1, 1, 1).lerp(new THREE.Color(0xffb08a), dusk * 0.75).multiplyScalar(0.12 + 0.88 * Math.max(day, dusk * 0.8)).multiplyScalar(1 - storm * 0.55);
    skyU.cloudLit.value.copy(lit); skyU.cloudShade.value.copy(lit).multiplyScalar(0.55 - storm * 0.15).lerp(new THREE.Color(0.08, 0.09, 0.13), 1 - day);
    scene.fog.color.copy(mid);
    hemi.intensity = (0.35 + 0.32 * day) * (1 - storm * 0.3); hemi.color.set(0x8fa3d8).lerp(new THREE.Color(0xdfeeff), day);
    var moonUp = Math.sin(A.moon.alt) > 0.02;
    if (el > -0.03 || !moonUp) {
      sun.intensity = (0.18 + 1.6 * day) * (1 - cov * 0.62) * (1 - storm * 0.3);
      sun.color.set(0x9fb2ff).lerp(new THREE.Color(0xfff1dc), day).lerp(new THREE.Color(0xffb27a), dusk * 0.5);
      var sv = A.sun.v.clone(); if (el < 0) sv.set(sv.x, 0.3, sv.z); sv.y = Math.max(0.26, sv.y); sun.userData.dir = sv.normalize();
    } else {
      sun.intensity = (0.1 + 0.32 * A.illum) * (1 - cov * 0.7); sun.color.set(0x9fb6ff);
      var mv = A.moon.v.clone(); mv.y = Math.max(0.3, mv.y); sun.userData.dir = mv.normalize();
    }
    var night = 1 - day;
    nightMats.forEach(function (m) { m.emissiveIntensity = m.map && m.emissiveMap === m.map ? 0.25 + night * 0.9 : night * 1.15; });
    if (CITY) { CITY.setNight(night); if (CITY.M && CITY.M.leaf) windify(CITY.M.leaf); }
    M.bulb.emissiveIntensity = Math.max(night, storm * 0.7) * 2.2; headM.emissiveIntensity = 0.3 + Math.max(night, storm * 0.6) * 2.5; tailM.emissiveIntensity = 0.4 + night * 1.6; taxiSignM.emissiveIntensity = 0.3 + night * 1.2; poolMat.opacity = night * 0.9;
    renderer.toneMappingExposure = (0.62 + 0.1 * day) * (1 - storm * 0.12); WX.hemiBase = hemi.intensity;
  }
  function fmtClock(ms, tz) { try { return new Intl.DateTimeFormat("en-GB", { hour: "2-digit", minute: "2-digit", hourCycle: "h23", timeZone: tz }).format(ms); } catch (e) { return "--:--"; } }
  /* sunrise / sunset / moonrise today, found by stepping through the day */
  function skyTimes(t) {
    var a = here(), out = {}, prevS = null, prevM = null, d0 = t - 12 * 3600000;
    for (var k = 0; k <= 24 * 12; k++) { var tt = d0 + k * 300000, A = astro(tt, a.lat, a.lon), s = A.sun.alt > -0.0145, m = A.moon.alt > 0.002;
      if (prevS !== null && s !== prevS) { if (s && !out.rise && tt > t - 12 * 3600000) out.rise = tt; if (!s && !out.set && tt > t - 3 * 3600000) out.set = tt; }
      if (prevM !== null && m && !prevM && !out.mrise) out.mrise = tt;
      prevS = s; prevM = m; }
    return out;
  }

  /* ================= Departures board ================= */
  var boardCanvas = document.createElement("canvas"); boardCanvas.width = 1024; boardCanvas.height = 576;
  var boardTex = new THREE.CanvasTexture(boardCanvas); boardTex.encoding = THREE.sRGBEncoding;
  function drawBoard(t) {
    var g = boardCanvas.getContext("2d"), a = here();
    g.fillStyle = "#050605"; g.fillRect(0, 0, 1024, 576);
    g.fillStyle = "#ff3d8b"; g.font = "800 40px Unbounded, sans-serif"; g.fillText("DEPARTURES", 36, 64);
    g.fillStyle = "#ffffff"; g.font = "600 34px 'JetBrains Mono', monospace"; g.textAlign = "right"; g.fillText(fmtT(t, a.tz), 988, 64); g.textAlign = "left";
    var list = AP.filter(function (x) { return x !== a; }).map(function (x, i) { var h = hash(a.code + x.code); var period = (5 + h % 6) * 3600000, off = (h % 300) * 60000; var d = Math.ceil((t - off) / period) * period + off; return { x: x, d: d, no: "PW " + (100 + h % 899) }; });
    if (G.trip && G.trip.from === a.code) list.push({ x: AIR[G.trip.to], d: G.trip.dep, no: G.trip.no, mine: true });
    list.sort(function (p, q) { return p.d - q.d; });
    g.font = "500 30px 'JetBrains Mono', monospace";
    list.slice(0, 8).forEach(function (r, i) {
      var y = 130 + i * 56, left = r.d - t;
      g.fillStyle = i % 2 ? "#0b0d0b" : "#101310"; g.fillRect(24, y - 38, 976, 52);
      g.fillStyle = r.mine ? "#ff3d8b" : "#ffcf5a"; g.fillText(fmtT(r.d, a.tz), 40, y);
      g.fillStyle = "#ffffff"; g.fillText(r.no, 170, y); g.fillText(r.x.city.toUpperCase().slice(0, 16), 360, y);
      g.fillStyle = left < 30 * 60000 ? "#ff3d8b" : "#8f998a"; g.fillText(left < 30 * 60000 ? "BOARDING" : "ON TIME", 760, y);
    });
    boardTex.needsUpdate = true;
  }

  /* ================= Pedestrians ================= */
  var walkers = [];
  function spawnWalkers() {
    var r = rng(11);
    var PAL = [0x3b5998, 0x9c2f2f, 0x2f6b4f, 0x6b4f2f, 0x4a4a52, 0x8a6a2a, 0x2a2a2a, 0x5b3b7a, 0xc9a74a, 0x1f6b6b, 0x7a1d3f, 0xe8e4d8, 0x24324a, 0x9a4a3a, 0x556b2f, 0x6a5acd];
    for (var i = 0; i < 6; i++) {
      var kind = i % 2 ? "woman" : "man";
      var a = makeActor(kind, PAL[i % PAL.length]);
      var side = r() < 0.5 ? -1 : 1, z = side * (8.4 + r() * 1.4), x = CITY_X1 + 10 + r() * (CITY_X2 - CITY_X1 - 20);
      walkers.push({ a: a, x: x, z: z, dir: r() < 0.5 ? 1 : -1, sp: 1.25 + r() * 0.35, pause: 0 });
    }
    var r2 = rng(23);
    for (var j = 0; j < 6; j++) {
      var b = makeActor(j % 2 ? "man" : "woman", [0x1d3f7a, 0x7a1d3f, 0x3f7a1d, 0x555555, 0x2b2b2b, 0x7a5a1d][j]);
      walkers.push({ a: b, x: 86 + r2() * 20, z: -6 + r2() * 20, dir: r2() < 0.5 ? 1 : -1, sp: 1.2 + r2() * 0.3, pause: 0, airport: true, x1: 84, x2: 108 });
    }
    for (var k = 0; k < 4; k++) {
      var c = makeActor(k % 2 ? "woman" : "man", PAL[(k * 5 + 3) % PAL.length]);
      walkers.push({ a: c, x: ROADX + (k % 2 ? 6.2 : -6.2), z: 20 + k * 30, dir: k % 2 ? 1 : -1, sp: 1.2 + k * 0.08, pause: 0, axis: "z", x1: 16, x2: 150 });
    }
  }
  function updateWalkers(dt) {
    walkers.forEach(function (w) {
      var x1 = w.x1 !== undefined ? w.x1 : CITY_X1 + 6, x2 = w.x2 !== undefined ? w.x2 : CITY_X2 - 6, zx = w.axis === "z";
      var far = Math.abs(P.x - w.x) + Math.abs(P.z - w.z) > 110;
      if (w.pause > 0) { w.pause -= dt; if (!far) blendTo(w.a, "Idle", dt); }
      else {
        if (zx) w.z += w.dir * w.sp * dt; else w.x += w.dir * w.sp * dt;
        var cur = zx ? w.z : w.x;
        if (cur > x2 || cur < x1) { w.dir *= -1; w.pause = 1 + Math.random() * 3; if (zx) w.z = clamp(w.z, x1, x2); else w.x = clamp(w.x, x1, x2); }
        var dpx = P.x - w.x, dpz = P.z - w.z, ahead = zx ? dpz : dpx, side = zx ? dpx : dpz;
        if (ahead * w.dir > 0 && ahead * w.dir < 1.6 && Math.abs(side) < 0.8) { w.pause = 0.8; }
        if (!far) blendTo(w.a, "Walk", dt, w.sp / 1.35);
      }
      w.a.g.position.set(w.x, w.airport ? 0.05 : zx ? 0.02 : 0.16, w.z);
      w.a.g.rotation.y = zx ? (w.dir > 0 ? 0 : Math.PI) : (w.dir > 0 ? Math.PI / 2 : -Math.PI / 2);
    });
  }

  /* ================= Load ================= */
  var staticNpcs = [];
  People.load("assets/people/", function (k) { $("lbar").style.width = (k * 100).toFixed(0) + "%"; }).then(function () {
    $("lmsg").textContent = "BUILDING THE CITY";
    player = makeActor(lookFor(G.passport));
    passportProp = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.012, 0.14), new THREE.MeshStandardMaterial({ color: 0x13244a, roughness: 0.5 }));
    passportProp.visible = false;
    phoneProp = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.15, 0.012), [M.dark, M.dark, M.dark, M.dark, new THREE.MeshStandardMaterial({ color: 0x0b1000, emissive: 0xff3d8b, emissiveIntensity: 0.5 }), M.dark]);
    phoneProp.visible = false;
    var hand = player.bones.hand_r, hs = hand ? 1 / Math.max(0.0001, hand.getWorldScale(new THREE.Vector3()).x) : 1;
    if (hand) { hand.add(phoneProp); phoneProp.position.set(0.02 * (1 / hs), 0.09 * (1 / hs), 0.03 * (1 / hs)); phoneProp.scale.setScalar(hs); hand.add(passportProp); passportProp.position.copy(phoneProp.position); passportProp.scale.setScalar(hs); }
    NPCS = NPCS.filter(function (n) { return !(n.x > -160 && n.x < 62 && Math.abs(n.z) < 12) && n.x > -250; });
    NPCS.forEach(function (n) { var a = makeActor(n.kind, n.tint); a.g.position.set(n.x, n.y != null ? n.y : n.kind === "officer" ? 0.05 : 0.16, n.z); a.g.rotation.y = n.yaw; a.play(n.anim || "Idle"); staticNpcs.push(a); });
    spawnWalkers();
    depBoard.material = new THREE.MeshBasicMaterial({ map: boardTex, toneMapped: false }); depBoard2.material = depBoard.material;
    applyBlocks();
    var go = function () {
      refreshSigns();
      $("loading").hidden = true;
      if (G.trip && (G.trip.stage === "boarded" || G.trip.stage === "inflight")) showFlight();
      else toast(G.arrival ? "Arrived in " + here().city + " \u00b7 follow signs to passport control" : "Welcome, " + G.passport.first + ". You are a " + G.passport.job[0] + ".");
    };
    startCity().then(function () { if (document.fonts && document.fonts.load) Promise.all([document.fonts.load("800 40px Unbounded"), document.fonts.load("600 20px 'JetBrains Mono'")]).then(go, go); else go(); });
    last = performance.now();
    requestAnimationFrame(loop);
  }).catch(function (e) { $("lmsg").textContent = "COULD NOT LOAD THE 3D MODELS. REFRESH TO TRY AGAIN."; console.error(e); });
  var WORK_ANIM = { farm: ["Harvest", "Plant", "Water"], mine: ["Chop"], oil: ["Fix"], factory: ["PickUp", "Push"], depot: ["PickUp"], site: ["Push", "PickUp"], crew: ["Talk"], mart: ["PickUp", "Interact"], diner: ["Interact"], cafe: ["Interact"], hospital: ["Talk", "Interact"], school: ["Talk"], bank: ["Talk", "Interact"], hotel: ["Talk"], office: ["SitTalk"], tech: ["Sit"], home: ["Sit"] };

  /* ================= Loop ================= */
  function resize() { var w = window.innerWidth, h = window.innerHeight; renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); }
  window.addEventListener("resize", resize); resize();
  var last = 0, uiT = 0, curZone = null, camPos = new THREE.Vector3(), camLook = new THREE.Vector3();
  function loop(tm) {
    if (window.__pause) { requestAnimationFrame(loop); return; }
    var dt = Math.min(window.__dtMax || 0.05, (tm - last) / 1000); last = tm;
    var t = now();
    var sim = (t - (G.foodT || t)) / 60000;
    if (sim > 0) { G.food = Math.max(0, G.food - sim * 0.25); G.foodT = t; }

    var ix = 0, iz = 0;
    if (keys.w || keys.arrowup) iz -= 1; if (keys.s || keys.arrowdown) iz += 1; if (keys.a || keys.arrowleft) ix -= 1; if (keys.d || keys.arrowright) ix += 1;
    if (joy.active) { ix = joy.x; iz = joy.y; }
    var mag = Math.min(1, Math.hypot(ix, iz));
    var busy = gesture || cine || CUT || RIDE || SCANNING || VSEQ || !$("shop").hidden || !$("modal").hidden || !$("flight").hidden || !$("mapov").hidden || !$("phone").hidden;

    if (P.mode === "car" && taxi.m.userData.air) { airTick(dt, busy); }
    else if (P.mode === "car") {
      var gas = drive.gas || keys.w || keys.arrowup ? 1 : 0, brk = drive.brake || keys.s || keys.arrowdown ? 1 : 0;
      var st = (drive.left || keys.a || keys.arrowleft ? 1 : 0) - (drive.right || keys.d || keys.arrowright ? 1 : 0);
      /* menus and door animations hold the car still (braking at a standstill used to engage reverse and block getting out) */
      if (busy) { gas = 0; brk = 0; st = 0; if (Math.abs(taxi.v) > 0.4) taxi.v -= Math.sign(taxi.v) * 16 * dt; else taxi.v = 0; }
      var VM = (taxi.m.userData.vmax || 22) * (NITRO.t > 0 ? 1.45 : 1);
      if (gas) taxi.v += (taxi.v < 0 ? 14 : (taxi.m.userData.acc || 8.5) * Math.max(0, 1 - taxi.v / VM)) * dt;
      if (NITRO.t > 0 && !busy) taxi.v += 16 * dt;
      if (brk) { if (taxi.v > 0.3) taxi.v -= 16 * dt; else taxi.v = Math.max(-6, taxi.v - 4.5 * dt); }
      if (!gas && !brk) { taxi.v *= (1 - dt * 0.6); if (Math.abs(taxi.v) < 0.15) taxi.v = 0; }
      taxi.v = clamp(taxi.v, -6, VM - 0.5);
      taxi.steer = lerp(taxi.steer, st, Math.min(1, dt * 7));
      if (Math.abs(taxi.steer) > 0.75 && Math.abs(taxi.v) > 13 && !taxi.m.userData.boat) sfx("tires");
      var turn = taxi.steer * dt * 1.7 * (1 + sk("drive") / 400) * clamp(taxi.v / 3, -1, 1) / (1 + Math.abs(taxi.v) / 30);
      var ny = taxi.yaw + turn, nx = taxi.x + Math.cos(ny) * taxi.v * dt, nz = taxi.z - Math.sin(ny) * taxi.v * dt;
      var h0 = carHits(taxi.x, taxi.z, taxi.yaw), h1 = carHits(nx, nz, ny);
      /* fast cars check their path in short steps, so they can't jump through a thin wall between frames */
      var nst = Math.ceil(Math.hypot(nx - taxi.x, nz - taxi.z) / 0.3);
      if (h1 === 0 && nst > 1 && !taxi.m.userData.boat) for (var ks = 1; ks < nst; ks++) { var fk = ks / nst, hs = carHits(taxi.x + (nx - taxi.x) * fk, taxi.z + (nz - taxi.z) * fk, taxi.yaw + (ny - taxi.yaw) * fk); if (hs > h0 + 0.001) { h1 = hs; break; } }
      if (taxi.m.userData.boat) { var bL = taxi.m.userData.L / 2, cY = Math.cos(ny), sY = Math.sin(ny); if (!isWater(nx + cY * bL, nz - sY * bL) || !isWater(nx - cY * bL, nz + sY * bL) || deckAt(nx + cY * bL, nz - sY * bL)) h1 += 5; }
      if (h1 === 0 || h1 < h0 - 0.001) { meter += Math.hypot(nx - taxi.x, nz - taxi.z); if (!taxi.m.userData.boat) skillAdd("drive", Math.hypot(nx - taxi.x, nz - taxi.z) * 0.008); taxi.x = nx; taxi.z = nz; taxi.yaw = ny; }
      else {
        if (carHits(taxi.x, taxi.z, ny) <= h0) taxi.yaw = ny;
        if (Math.abs(taxi.v) > 4) { toast("Bump!"); sfx("crash", Math.abs(taxi.v)); }
        taxi.v = -taxi.v * 0.2;
      }
      P.x = taxi.x; P.z = taxi.z;
      taxi.m.userData.wheels.forEach(function (w) { if (w.userData.front) w.rotation.y = taxi.steer * 0.45; });
      if (!taxi.m.userData.boat && !INSIDE && deepWater(taxi.x + Math.cos(taxi.yaw) * 1.2, taxi.z - Math.sin(taxi.yaw) * 1.2) && deepWater(taxi.x, taxi.z)) sinkCar();
    } else if (P.fall) { fallTick(dt, busy ? 0 : ix, busy ? 0 : iz, busy ? 0 : mag); }
    else if (P.seat && !working) { if (mag > 0.3 && !busy) standUp(); }
    else if (!busy && !working) {
      if (mag > 0.08) {
        var cy = Math.cos(cam.yaw), sy = Math.sin(cam.yaw);
        var wx = ix * cy + iz * sy, wz = -ix * sy + iz * cy;
        var targetYaw = Math.atan2(wx, wz);
        var dy = ((targetYaw - P.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
        /* turn fast and smooth; turn almost on the spot when changing direction a lot */
        P.yaw += dy * (1 - Math.exp(-dt * (Math.abs(dy) > 2 ? 22 : 14)));
        var hungry = G.food <= 5, sprint = run && !P.swim, gait = sprint ? "sprint" : (joy.active ? (mag > 0.55 ? "jog" : "walk") : (keys.alt || keys.control ? "walk" : "jog"));
        var running = sprint;
        var spd = P.swim ? (sprint ? 2.3 : 1.35 * Math.max(0.5, mag)) * (1 + sk("swim") / 300) : gait === "sprint" ? (hungry ? 3.6 : 5.6) * (1 + sk("stamina") / 500) : gait === "jog" ? 3.3 * (hungry ? 0.85 : 1) : 1.5 * Math.max(0.55, mag / 0.55);
        if (Math.abs(dy) > 2.2 && P.v > 2) spd *= 0.5;
        P.v = lerp(P.v, spd, 1 - Math.exp(-dt * (spd > P.v ? 7 : 11)));
        if (hungry && sprint && !moveHungryT) { moveHungryT = 1; toast("You are hungry \u00b7 eat something to sprint at full speed"); }
        var dl = Math.hypot(wx, wz) || 1;
        var pp = { x: P.x + (wx / dl) * P.v * dt, z: P.z + (wz / dl) * P.v * dt };
        if (P.lv) { if (P.lv.link) { var nlv = P.lv.link(pp.x, pp.z); if (nlv) P.lv = nlv; } collideList(P.lv.col, pp, 0.32); if (P.lv.clamp) P.lv.clamp(pp); } else { var wasIn = CITY && !INSIDE && CITY.hit(P.x, P.z, 0); collide(pp, 0.32); if (CITY && !wasIn) CITY.collide(pp, 0.34); carPush(pp, 0.32); }
        var want = P.v * dt, got = Math.hypot(pp.x - P.x, pp.z - P.z);
        if (!INSIDE && want > 0.005 && got < want * 0.25) stuckT += dt; else stuckT = Math.max(0, stuckT - dt * 2);
        P.x = pp.x; P.z = pp.z;
        if (P.lv) { stuckT = 0; if (P.lv.yAt) P.lv.y = P.lv.yAt(P.x, P.z); if (!P.lv.inside(P.x, P.z)) startFall(P.lv.y, (wx / dl) * Math.max(2.5, P.v), (wz / dl) * Math.max(2.5, P.v)); }
        if (P.swim) skillAdd("swim", got * 0.03); else if (running) skillAdd("stamina", got * 0.02);
        if (stuckT > 1.2 && !P.lv && !P.fall && (stuckT > 4 || trapped())) { stuckT = 0; unstick(true); }
        P.swim = !P.lv && !P.fall && !INSIDE && (deepWater(P.x, P.z) || (P.swim && isWater(P.x, P.z) && !deckAt(P.x, P.z) && !(CITY && CITY.onRoad(P.x, P.z))));
        if (P.swim) blendTo(player, "Swim", dt, running ? 1.4 : 1);
        else if (P.v > 4.4) player.play("Run", { speed: clamp(P.v / 5.4, 0.8, 1.3), fade: 0.18 });
        else if (P.v > 2.1) player.play("Jog", { speed: clamp(P.v / 3.2, 0.75, 1.25), fade: 0.18 });
        else player.play("Walk", { speed: clamp(P.v / 1.35, 0.6, 1.3), fade: 0.2 });
        /* the camera slowly swings back behind you while you move (unless you are looking around) */
        if (performance.now() - camDragT > 1400 && !(P.aimT > performance.now()) && P.v > 1) { var behind = P.yaw + Math.PI, dc = ((behind - cam.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI; cam.yaw += dc * Math.min(1, dt * 0.9 * Math.min(1, P.v / 3)); }
      } else { P.v = lerp(P.v, 0, 1 - Math.exp(-dt * 12)); P.swim = !P.lv && !INSIDE && (deepWater(P.x, P.z) || (P.swim && isWater(P.x, P.z) && !deckAt(P.x, P.z))); blendTo(player, P.swim ? "SwimIdle" : "Idle", dt); }
    } else if (!working && !gesture && !phoneOpen && !P.seat && !cine && !CUT && !VSEQ) { blendTo(player, P.swim ? "SwimIdle" : "Idle", dt); }

    if (working) {
      var tl = working.until - t;
      if (tl <= 0) { var pay = working.pay, wp = working.place; earn(pay, "Shift \u00b7 " + working.title); if (working.seated) standUp(); working = null; toast("Shift done \u00b7 +" + pay + " TOKEN"); missionEvent("shift:" + wp); }
      else if (Math.hypot(P.x - working.z.x, P.z - working.z.z) > 3) { working = null; toast("You left your shift early. No pay."); }
    }

    /* cutscene */
    if (cine) {
      var ct = (tm - cine.t0) / 1000;
      if (cine.phase === "walk") {
        /* walk through the jet bridge to the plane's side door, filmed in three shots */
        if (!cine.path) {
          var pth = [[P.x, P.z, 0.06]].concat(B12_PATH), L0 = 0; cine.path = pth; cine.cum = [0];
          for (var pi = 1; pi < pth.length; pi++) { L0 += Math.hypot(pth[pi][0] - pth[pi - 1][0], pth[pi][1] - pth[pi - 1][1], pth[pi][2] - pth[pi - 1][2]); cine.cum.push(L0); }
          cine.len = L0; cine.s = 0; document.body.classList.add("cinema");
          if (jet.userData.setDoor) jet.userData.setDoor(1); sfx("board");
          cine.crew = makeActor("woman", 0x0f3a6b); cine.crew.g.position.set(JET_HOME.x - 13.2 + 0.75, 2.75, JET_HOME.z + 1.7); cine.crew.g.rotation.y = 0.35; cine.crew.play("Talk"); scene.add(cine.crew.g);
        }
        cine.s = Math.min(cine.len, cine.s + 1.55 * dt);
        var seg = 1; while (seg < cine.cum.length - 1 && cine.cum[seg] < cine.s) seg++;
        var A0 = cine.path[seg - 1], B0 = cine.path[seg], k0 = (cine.s - cine.cum[seg - 1]) / Math.max(0.001, cine.cum[seg] - cine.cum[seg - 1]);
        P.x = lerp(A0[0], B0[0], k0); P.z = lerp(A0[1], B0[1], k0); cine.py = lerp(A0[2], B0[2], k0);
        var wy = Math.atan2(B0[0] - A0[0], B0[1] - A0[1]), dyw = ((wy - P.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI; P.yaw += dyw * Math.min(1, dt * 6);
        blendTo(player, "Walk", dt, 1.1);
        var fr = cine.s / cine.len, hx = Math.sin(P.yaw), hz = Math.cos(P.yaw);
        if (fr < 0.28) camOverride = { pos: new THREE.Vector3(AX2 - 9, 2.4, 9.2), look: new THREE.Vector3(P.x + hx * 2, cine.py + 1.2, P.z + hz * 2), exact: true };
        else if (fr < 0.82) camOverride = { pos: new THREE.Vector3(AX2 + 13, 4.6, JET_HOME.z + 13), look: new THREE.Vector3(P.x, cine.py + 1.2, P.z), exact: true };
        else camOverride = { pos: new THREE.Vector3(JET_HOME.x - 9.2, 4.9, JET_HOME.z + 6.6), look: new THREE.Vector3(JET_HOME.x - 13.2, 3.8, JET_HOME.z + 2.2), exact: true };
        $("cine").hidden = false; $("cine").textContent = (G.trip ? G.trip.no + " \u00b7 " : "") + (fr < 0.82 ? "Boarding through gate B12" : "Welcome aboard");
        if (P.z < JET_HOME.z + 1.95) player.g.visible = false;
        if (cine.s >= cine.len - 0.01) { if (cine.crew) { scene.remove(cine.crew.g); removeActor(cine.crew); cine.crew = null; } cine.phase = "close"; cine.t3 = tm; sfx("boardDoor"); $("cine").textContent = (G.trip ? G.trip.no + " \u00b7 " : "") + "Doors closing"; }
      } else if (cine.phase === "close") {
        var kc = Math.min(1, (tm - cine.t3) / 1100); if (jet.userData.setDoor) jet.userData.setDoor(1 - kc * kc * (3 - 2 * kc));
        if (kc >= 1 && !cine.fadeOn) { cine.fadeOn = true; cine.t4 = tm; }
        if (cine.fadeOn && tm - cine.t4 > 450) { $("fade").classList.add("on"); cine.phase = "fade"; cine.t1 = tm; }
      } else if (cine.phase === "fade" && tm - cine.t1 > 700) {
        player.g.visible = false; cine.phase = "taxi"; cine.t2 = tm; cine.py = undefined; camOverride = null; document.body.classList.remove("cinema"); $("fade").classList.remove("on");
        $("cine").hidden = false; $("cine").textContent = G.trip.no + " \u00b7 pushback";
      } else if (cine.phase === "taxi") {
        var jt = (tm - cine.t2) / 1000, j = jetAt(jt);
        placeJet(j[0], j[1], j[2], j[3], j[4]);
        $("cine").textContent = G.trip.no + (jt < 6 ? " \u00b7 pushback" : jt < 16 ? " \u00b7 taxiing to runway" : jt < 24 ? " \u00b7 take-off roll" : " \u00b7 lift-off");
        if (jt > 31) { cine = null; $("cine").hidden = true; showFlight(); }
      }
    }

    /* traffic */
    TRAFFIC.forEach(function (c) {
      var ahead = c.vmax;
      TRAFFIC.forEach(function (o) { if (o !== c && o.dir === c.dir) { var gap = (o.x - c.x) * c.dir, need = (o.m.userData.L + c.m.userData.L) / 2 + 2.2; if (gap > 0 && gap < need + 12) ahead = Math.min(ahead, Math.max(0, (gap - need) * 1.5)); } });
      var pg = (P.x - c.x) * c.dir; if (pg > -1 && pg < 12 && Math.abs(P.z - c.z) < 2.4) ahead = Math.min(ahead, (pg - c.m.userData.L / 2 - 1.6) * 2);
      var tg = (taxi.x - c.x) * c.dir; if ((taxi.alt || 0) < 2 && tg > 0 && tg < 14 && Math.abs(taxi.z - c.z) < 2.6) ahead = Math.min(ahead, (tg - c.m.userData.L / 2 - taxi.m.userData.L / 2 - 1.2) * 2);
      c.v = lerp(c.v, clamp(ahead, 0, c.vmax), Math.min(1, dt * 2));
      c.x += c.dir * c.v * dt;
      if (c.dir > 0 && c.x > CITY_X2 + 1) c.x = CITY_X1 - 20;
      if (c.dir < 0 && c.x < CITY_X1 - 20) c.x = CITY_X2 + 1;
      c.m.position.set(c.x, 0, c.z); c.m.rotation.y = c.dir > 0 ? 0 : Math.PI;
      c.m.userData.wheels.forEach(function (w) { w.rotation.z -= c.v * dt / c.m.userData.r; });
    });
    var isBoat = !!taxi.m.userData.boat, tgy = isBoat ? 0 : groundY(taxi.x, taxi.z), tsl = tgy > 0 ? (bridgeY(taxi.x + 0.5) - bridgeY(taxi.x - 0.5)) : 0;
    if (isBoat) { taxi.ph = taxi.ph || 0; placeBoat({ m: taxi.m, x: taxi.x, z: taxi.z, yaw: taxi.yaw, ph: 0 }, tm / 1000, taxi.v); }
    else if (taxi.m.userData.air) { if (P.mode !== "car") { taxi.rpm = Math.max(0, (taxi.rpm || 0) - dt * 0.35); taxi.thr = 0; taxi.v = 0; } placeAir(dt); }
    else { taxi.m.position.set(taxi.x, tgy, taxi.z); taxi.m.rotation.set(0, taxi.yaw, Math.atan(tsl * Math.cos(taxi.yaw))); }
    sinkTick(dt); transitTick(dt, tm / 1000); combatTick(dt, tm / 1000); wreckTick(dt); liftTick(dt); TOWER.tick(dt, tm / 1000); vseqTick(dt); if (SND) SND.tick(dt); wxTick(dt, tm / 1000);
    taxi.m.userData.wheels.forEach(function (w) { w.rotation.z -= taxi.v * dt / taxi.m.userData.r; });

    /* actors */
    updateWalkers(dt);
    var onBoat = P.mode === "car" && taxi.m && taxi.m.userData.boat, onBike = P.mode === "car" && taxi.m && (taxi.m.userData.moto || onBoat); if (onBike) { player.g.visible = true; P.yaw = Math.atan2(Math.cos(taxi.yaw), -Math.sin(taxi.yaw)); player.play("Drive"); }
    player.g.position.set(onBike ? taxi.x + Math.cos(taxi.yaw) * (onBoat ? (taxi.m.userData.seatX !== undefined ? taxi.m.userData.seatX : -0.45) : 0.35) : P.x, RIDE && RIDE.py !== undefined ? RIDE.py : onBike ? (onBoat ? taxi.m.position.y + (taxi.m.userData.seatY || 0.62) : 0.31 + tgy) : P.swim && P.mode !== "car" ? (SWIM_Y = lerp(SWIM_Y, P.v > 0.4 ? 0.1 : -0.06, Math.min(1, dt * 3))) : P.mode !== "car" && deckAt(P.x, P.z) ? deckAt(P.x, P.z).y + 0.04 : P.mode !== "car" && onBridge(P.x, P.z) ? 0.1 + bridgeY(P.x) : cine && cine.py !== undefined ? cine.py + 0.03 : P.x < -240 ? 0.105 : P.x > 5000 ? 0.035 : P.x > AX1 && P.x < AX2 && Math.abs(P.z) < AZ ? 0.06 : (Math.abs(P.z) > 7 && Math.abs(P.z) < 11.2 ? 0.17 : (P.z < -11 && P.x > -81 && P.x < -41 ? 0.18 : 0.035)), onBike ? taxi.z - Math.sin(taxi.yaw) * (onBoat ? (taxi.m.userData.seatX !== undefined ? taxi.m.userData.seatX : -0.45) : 0.35) : P.z);
    player.g.rotation.y = P.yaw;
    if (P.fall) { player.g.rotation.x = 0; player.g.position.set(P.x, P.fall.y + (P.fall.chute ? 0 : 0.5), P.z); CHUTE.position.set(P.x, P.fall.y + 1.05, P.z); CHUTE.rotation.y = P.yaw; }
    else { if (player.g.rotation.x) player.g.rotation.x = 0; if (P.lv && P.mode !== "car") player.g.position.y = P.lv.y + 0.03; if (VSEQ && VSEQ.sink) player.g.position.y -= VSEQ.sink; }
    if (working && !gesture) { var wa = WORK_ANIM[working.place] || ["Interact"], wi = Math.floor((now() - working.start) / (9000 * clk.speed)) % wa.length; player.play(wa[wi]); if (working.face !== undefined) P.yaw = working.face; }
    else if (phoneOpen && !gesture && P.mode !== "car") player.play("Phone");
    if (gesture) {
      var gk = (tm - gesture.t0) / gesture.dur;
      player.play(gesture.anim || "Interact", { speed: gesture.speed || 1.2 });
      passportProp.visible = gesture.passport !== false && gk > 0.15 && gk < 0.85;
      if (gk >= 1) { var dn = gesture.done; gesture = null; passportProp.visible = false; player.play("Idle"); if (dn) dn(); }
    }
    ACTORS.forEach(function (a) {
      var d = a === player ? 0 : Math.abs(a.g.position.x - P.x) + Math.abs(a.g.position.z - P.z);
      if (a !== player) a.g.visible = d < 110;
      if (d < 110) { a.skip = (a.skip || 0) + dt; if (d < 40 || a.skip > 0.1) { a.update(a.skip); a.skip = 0; } }
    });
    if (armsUp > 0) poseArmsUp(player, armsUp);
    tickScan(tm);
    if (scanLight) { var sf = (tm - scanFlash) / 1000; scanLight.material.emissiveIntensity = sf < 1.2 ? 2 + Math.sin(sf * 30) : 0.6; scanLight.position.y = sf < 1.2 ? 0.3 + (sf / 1.2) * 2 : 2.3; }

    /* rooms fade */
    ROOMS.forEach(function (r) {
      var inside = P.x > r.x1 && P.x < r.x2 && P.z > r.z1 && P.z < r.z2;
      if (inside !== r.inside) { r.inside = inside; r.meshes.forEach(function (m) { fadeMesh(m, inside ? 0.18 : 1); }); }
    });

    /* zones */
    if (!busy && P.mode === "walk") {
      var best = null, bd = 1e9;
      var pzY = P.lv ? P.lv.y : 0;
      ZONES.forEach(function (z) { if (Math.abs((z.y || 0) - pzY) > 2.5) return; var d = Math.hypot(P.x - z.x, P.z - z.z); if (d < z.r && d < bd) { var inf = zoneInfo(z); if (inf) { bd = d; best = { z: z, i: inf }; } } });
      if (best) {
        var key = best.z.id + best.i.t + best.i.d + best.i.b + !!best.i.off;
        if (!curZone || curZone.key !== key) {
          curZone = { key: key, z: best.z };
          $("pT").textContent = best.i.t; $("pD").textContent = best.i.d; $("pB").textContent = best.i.b; $("pB").disabled = !!best.i.off;
          $("prompt").hidden = false;
        }
      } else if (curZone) { curZone = null; $("prompt").hidden = true; }
    } else if (curZone && P.mode !== "car") { curZone = null; $("prompt").hidden = true; }
    if (P.mode === "car") {
      if (!$("prompt").hidden) $("prompt").hidden = true; curZone = null;
      $("spd").textContent = Math.round(Math.abs(taxi.v) * 3.6); $("gear").textContent = taxi.m.userData.air ? (taxi.m.userData.air === "heli" ? "H" : "\u2708") : taxi.v < -0.2 ? "R" : Math.abs(taxi.v) < 0.2 ? "P" : "D";
      $("meterT").textContent = taxi.m.userData.air ? "ALT " + Math.round(taxi.alt || 0) + " M" + (taxi.m.userData.air === "plane" ? " \u00b7 THR " + Math.round((taxi.thr || 0) * 100) + "%" : "") : G.passport.job[0] === "Taxi Driver" ? "FARE " + (meter / 1000).toFixed(2) + " KM" : "";
    }

    if (HELI && AIRSIDE.visible) { HELI.userData.rotor.rotation.y += dt * 3.2; HELI.userData.tail.rotation.z += dt * 14; }
    /* camera */
    cam.dist = lerp(cam.dist, cam.tdist, Math.min(1, dt * 6));
    var inAir = P.x > AX1 && P.x < AX2 && Math.abs(P.z) < AZ;
    var dist = cam.dist * (inAir ? 1.15 : 1), pitch = cam.pitch;
    var tgt = new THREE.Vector3(P.x, P.mode === "car" ? 1.2 + (taxi.m.userData.boat ? 0 : groundY(P.x, P.z)) : P.swim ? 0.5 : 1.5 + standY(P.x, P.z), P.z);
    if (P.mode === "car" && taxi.m.userData.air) tgt.y = (taxi.alt || 0) + (taxi.m.userData.gy || 0) + 1.6; else if (P.fall) tgt.y = P.fall.y + (P.fall.chute ? 2.4 : 1.0); else if (P.lv) tgt.y = P.lv.y + 1.5;
    if (P.mode === "car" && Object.keys(drags).length === 0) { var want = taxi.yaw - Math.PI / 2; var dyc = ((want - cam.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI; cam.yaw += dyc * Math.min(1, dt * (Math.abs(taxi.v) > 0.5 ? 3 : 1)); }
    tickCut(tm);
    if (camOverride && camOverride.exact) { camera.position.copy(camOverride.pos); camLook.copy(camOverride.look); camera.lookAt(camLook); }
    else if (camOverride) { if (camera.position.distanceTo(camOverride.pos) > 25) { camera.position.copy(camOverride.pos); camLook.copy(camOverride.look); } camera.position.lerp(camOverride.pos, Math.min(1, dt * 4)); camLook.lerp(camOverride.look, Math.min(1, dt * 5)); camera.lookAt(camLook); }
    else if (cine && cine.phase === "taxi") {
      var jp = jet.position;
      var jtt = (tm - cine.t2) / 1000;
      camPos.set(jp.x - (jtt < 16 ? 14 : 26), jp.y + 5 + Math.min(14, jp.y * 0.25), jp.z + (jtt < 16 ? 30 : 34));
      camera.position.lerp(camPos, jtt < 0.1 ? 1 : 0.12); camera.lookAt(jp.x + 8, jp.y + 1, jp.z);
    } else {
      var dxc = Math.sin(cam.yaw) * Math.cos(pitch), dzc = Math.cos(cam.yaw) * Math.cos(pitch), safe = dist;
      for (var st = 1; st <= 16; st++) {
        var f = dist * st / 16, qx = tgt.x + dxc * f, qz = tgt.z + dzc * f, hit = false;
        var qy0 = tgt.y + Math.sin(pitch) * f + 0.4;
        if (!(P.lv && P.lv.camBox)) for (var ci2 = 0; ci2 < COL.length; ci2++) { var cc = COL[ci2]; if (cc.on && (cc.tag === "bld" || (INSIDE && cc.tag === "wall")) && qx > cc.x1 - 0.45 && qx < cc.x2 + 0.45 && qz > cc.z1 - 0.45 && qz < cc.z2 + 0.45) { if (cc.tag === "bld" && qy0 > (cc.hf ? cc.hf(qx, qz) : (cc.h || 12)) + 1.2) continue; hit = true; break; } }
        if (!hit && CITY && !INSIDE && CITY.hit(qx, qz, 0.6)) {
          var hb = CITY.buildingAt(qx, qz), qy = tgt.y + Math.sin(pitch) * f + 0.4; hit = hb ? !(hb.h && qy > hb.h + 1.5) : qy < 2.0;
        }
        if (hit) { safe = Math.max(1.6, f - dist / 16 - 0.35); break; }
      }
      /* a wall behind the player: lift the camera over the head instead of pushing it into the wall */
      var pc = safe < dist * 0.8 ? Math.min(0.72, pitch + (1 - safe / dist) * 0.45) : pitch, hz = Math.cos(pc) / Math.max(0.2, Math.cos(pitch));
      camPos.set(tgt.x + dxc * safe * hz, tgt.y + Math.sin(pc) * safe + 0.4, tgt.z + dzc * safe * hz);
      if (P.lv && P.lv.camBox) P.lv.camBox(camPos);
      camera.position.lerp(camPos, Math.min(1, dt * 10)); camLook.lerp(tgt, Math.min(1, dt * 12)); camera.lookAt(camLook);
    }

    var sd = sun.userData.dir || new THREE.Vector3(0.4, 0.8, 0.3);
    sun.position.set(P.x + sd.x * 120, sd.y * 120, P.z + sd.z * 120); sun.target.position.set(P.x, 0, P.z); sun.target.updateMatrixWorld();
    sky.position.copy(camera.position);
    var chh = Math.max(0, camera.position.y), fogK = 1 - WX.cur.rain * 0.4 - WX.cur.storm * 0.2 - WX.cur.fog * 0.65 - WX.cur.snow * 0.35; scene.fog.near = (140 + chh * 1.6) * fogK; scene.fog.far = Math.min(2100, 700 + chh * 3.2) * Math.max(0.3, fogK);
    renderer.render(scene, camera);

    if (tm - uiT > 400) {
      uiT = tm;
      if (cityReady && CITY && CITY.inBounds(P.x, P.z) && P.mode !== "car" && !cine && !P.lv && !P.fall) { G.pos = [Math.round(P.x * 10) / 10, Math.round(P.z * 10) / 10]; if (Math.random() < 0.05) save(); }
      updateSky(t);
      var a = here();
      $("hCity").textContent = (INSIDE ? (INSIDE.id === "home" ? "Home" : cityPlaces[INSIDE.id].name) : P.x > AX1 - 10 ? a.city + " \u00b7 " + a.code : false ? (INSIDE.id === "home" ? "Home" : cityPlaces[INSIDE.id].name) : CITY && CITY.inBounds(P.x, P.z) ? CITY_NAME + (CITY_PREVIEW ? " \u00b7 preview map" : "") : a.city + " \u00b7 Airport Expressway");
      $("hTime").textContent = fmtD(t, a.tz) + " \u00b7 " + fmtT(t, a.tz) + (clk.speed > 1 ? " \u00b7 TEST " + clk.speed + "\u00d7" : "") + (working ? " \u00b7 SHIFT " + Math.ceil((working.until - t) / 1000 / clk.speed) + "s" : "") + (WX.label ? " \u00b7 " + WX.label + (WX.temp != null ? " " + Math.round(WX.temp) + "\u00b0C" : "") : "");
      $("hBal").textContent = Math.round(G.balance).toLocaleString("en-US");
      $("hFood").style.width = G.food.toFixed(0) + "%"; $("hFoodBar").classList.toggle("low", G.food < 25);
      $("arcHp").style.strokeDasharray = (221 * clamp(G.hp, 0, 100) / 100).toFixed(1) + " 584"; $("arcHp").classList.toggle("low", G.hp < 30);
      $("arcAr").style.strokeDasharray = (221 * clamp(G.armor || 0, 0, 100) / 100).toFixed(1) + " 584";
      $("arcFd").style.strokeDasharray = (45 * clamp(G.food, 0, 100) / 100).toFixed(1) + " 584"; $("arcFd").classList.toggle("low", G.food < 25);
      if (toastT && Date.now() > toastT) { $("toast").hidden = true; toastT = 0; }
      if (Math.abs(P.x - 120) < 50) drawBoard(t);
      if (tm % 4000 < 420) save();
      if (!$("flight").hidden && G.trip) {
        var tr = G.trip, p = (t - tr.dep) / tr.dur, B = AIR[tr.to];
        $("fH").textContent = p < 0 ? "Seated \u00b7 doors closing" : p < 0.03 ? "Climbing" : p > 0.96 ? "Descending into " + B.city : "Cruising to " + B.city;
        $("fLeftL").textContent = p < 0 ? "Departs in" : "Time left";
        $("fLeft").textContent = dur(p < 0 ? tr.dep - t : (1 - p) * tr.dur);
        $("fP").style.width = clamp(p * 100, 0, 100).toFixed(1) + "%";
        $("fBtn").hidden = p < 1;
        if (p >= 1) $("fH").textContent = "Landed in " + B.city;
      }
    }
    if (!$("flight").hidden && G.trip) {
      var tr2 = G.trip, pp2 = (t - tr2.dep) / tr2.dur;
      var A2 = AIR[tr2.from], B2 = AIR[tr2.to], k2 = clamp(pp2, 0, 1);
      var lonM = A2.lon + (B2.lon - A2.lon) * k2, hUTC = (t / 3600000) % 24, solar = (hUTC + lonM / 15 + 48) % 24;
      if (flightView === "map") drawFlightMap(pp2, t); else drawWindow(pp2, smooth((Math.sin((solar - 6) / 12 * Math.PI) + 0.15) / 0.45), tm);
      mealTick(tr2, pp2);
    }
    if (typeof mapTick === "function") mapTick(tm);
    requestAnimationFrame(loop);
  }

  /* ================= Map + minimap + waypoint ================= */
  var PLACES = [
    { id: "landmark", t: CS.lmName, d: "Famous landmark", b: "LM", c: "#ff3d8b", x: LMX + 26, z: 0 },
    { id: "hotel", t: "Grand Hotel", d: "Hotel jobs", b: "HT", c: "#d8b46a", x: -134, z: -9.8, lp: "u" },
    { id: "cityhall", t: "City Hall", d: "Land office", b: "CH", c: "#f2efe6", x: -100, z: -9.8, lp: "u" },
    { id: "grocery", t: "Fresh Mart", d: "Food", b: "FM", c: "#7bd88f", x: -70, z: -11.6, lp: "u" },
    { id: "agency", t: "Global Travel", d: "Visas and flights", b: "GT", c: "#5ab0ff", x: -49, z: -11.6 },
    { id: "work", t: "Summit Tower", d: "Office jobs", b: "ST", c: "#c9a7ff", x: -29, z: -9.6, lp: "u" },
    { id: "diner", t: "Sunny Diner", d: "Food and jobs", b: "SD", c: "#ff7a59", x: -5, z: -9.8, lp: "u" },
    { id: "bank", t: "City Bank", d: "Bank jobs", b: "BK", c: "#6fa8ff", x: 19, z: -9.8, lp: "u" },
    { id: "police", t: "Police HQ", d: "Government", b: "PD", c: "#4d7cff", x: 48, z: -9.8, lp: "u" },
    { id: "hospital", t: "City Hospital", d: "Doctors and nurses", b: "HS", c: "#ff5a5a", x: -135, z: 9.8, lp: "d" },
    { id: "school", t: "Central School", d: "Teachers", b: "SC", c: "#b5d86a", x: -100, z: 9.8, lp: "d" },
    { id: "taxi", t: "Taxi Rank", d: "Drive and earn", b: "TX", c: "#f2c230", x: -63.4, z: 18 },
    { id: "cafe", t: "Corner Cafe", d: "Barista jobs", b: "CF", c: "#c08a5a", x: -33, z: 9.8, lp: "d" },
    { id: "bus", t: "Bus Stop", d: "To the outskirts", b: "BS", c: "#ff3d8b", x: 9, z: 9.4, lp: "d" },
    { id: "tech", t: "Tech Hub", d: "Software jobs", b: "TH", c: "#5ad8d8", x: 25, z: 9.8, lp: "d" },
    { id: "site", t: "Construction Site", d: "Builders", b: "CS", c: "#f2a030", x: 52, z: 9.9 },
    { id: "tunnel", t: "Airport Tunnel", d: "Walk to the terminal", b: "TN", c: "#9aa39a", x: 63, z: 9, lp: "d" },
    { id: "exit", t: "Airport Terminal", d: "Entrance and arrivals", b: "AP", c: "#ff3d8b", x: 83, z: 0 },
    { id: "checkin", t: "Check-in", d: "Boarding pass", b: "CK", c: "#ff3d8b", x: 98, z: -13.8, lp: "u" },
    { id: "crew", t: "Crew Room", d: "Pilots and baggage", b: "CR", c: "#9fb3ff", x: 100, z: 27.6, lp: "u" },
    { id: "security", t: "Security", d: "Scan and screening", b: "SE", c: "#ff8a5c", x: 110, z: 0 },
    { id: "immigration", t: "Immigration", d: "Passport control", b: "IM", c: "#ff8a5c", x: 125.8, z: 0, lp: "d" },
    { id: "gate", t: "Gate B12", d: "Boarding", b: "GB", c: "#ff3d8b", x: 156, z: 12 },
    { id: "farm", t: "Green Acres Farm", d: "Farm jobs", b: "FA", c: "#8fd85a", x: -16.4, z: 69 },
    { id: "oil", t: "Oil Field", d: "Oil jobs", b: "OL", c: "#d6a72a", x: 6.4, z: 70 },
    { id: "mine", t: "Gold Mine", d: "Mining jobs", b: "GM", c: "#e8b84a", x: -112, z: 108.6 },
    { id: "depot", t: "Truck Depot", d: "Drivers and mechanics", b: "DP", c: "#ff3d8b", x: -55, z: 104.4, lp: "d" },
    { id: "factory", t: "Factory", d: "Factory jobs", b: "FC", c: "#a0a8b0", x: 30, z: 110.4, lp: "d" }
  ];
  var MX1 = -250, MX2 = 620, MZ1 = -160, MZ2 = 175, MS = 3;
  var mapBase = document.createElement("canvas");
  mapBase.width = (MX2 - MX1) * MS; mapBase.height = (MZ2 - MZ1) * MS;
  (function () {
    var c = mapBase.getContext("2d");
    c.setTransform(MS, 0, 0, MS, -MX1 * MS, -MZ1 * MS);
    function R(x1, x2, z1, z2, col) { c.fillStyle = col; c.fillRect(Math.min(x1, x2), Math.min(z1, z2), Math.abs(x2 - x1), Math.abs(z2 - z1)); }
    R(MX1, MX2, MZ1, MZ2, "#211538");
    for (var i = 0; i < 260; i++) { var rx = MX1 + ((i * 977) % (MX2 - MX1)), rz = MZ1 + ((i * 613) % (MZ2 - MZ1)); c.fillStyle = "rgba(36,74,47,0.55)"; c.beginPath(); c.arc(rx, rz, 3 + (i % 5), 0, 7); c.fill(); }
    R(AX2, MX2, -160, 175, "#1f3220");
    R(AX2, 450, -100, 38, "#55585a");
    R(170, MX2, 36.5, 59.5, "#35383c"); R(242, 282, 38, 95, "#35383c");
    R(200, MX2, 72.5, 117.5, "#2a2c30");
    c.fillStyle = "#e9ece6"; for (var rx2 = 270; rx2 < MX2; rx2 += 50) c.fillRect(rx2, 94.5, 30, 1);
    R(200, MX2, 73.5, 74.3, "#e9ece6"); R(200, MX2, 115.7, 116.5, "#e9ece6");
    for (var pk2 = 0; pk2 < 8; pk2++) { R(203, 233, 91.5 - pk2 * 2.6, 92.6 - pk2 * 2.6, "#e9ece6"); R(203, 233, 97.4 + pk2 * 2.6, 98.5 + pk2 * 2.6, "#e9ece6"); }
    R(170, MX2, 47.7, 48.3, "#d8b12a"); R(261.7, 262.3, 38, 95, "#d8b12a");
    R(AX2, 262, 11.7, 12.3, "#d8b12a");
    [[205, -66.3], [262, -66.3], [320, -66.3], [378, -66.3], [330, -7.7], [392, -7.7]].forEach(function (pl) { R(pl[0] - 2.1, pl[0] + 2.1, pl[1] - 20, pl[1] + 20, "#e6e9ec"); R(pl[0] - 19, pl[0] + 19, pl[1] - 2, pl[1] + 4, "#c9ced3"); });
    R(AX2 + 21, AX2 + 60, 9.9, 14.1, "#e6e9ec"); R(AX2 + 36, AX2 + 42, -7, 31, "#c9ced3");
    R(CITY_X1 - 42, CITY_X2 + 18, -11.2, 11.2, "#2c3230");
    R(CITY_X1 - 42, CITY_X2 + 18, -7.7, 7.7, "#120a24"); R(CITY_X1 - 42, CITY_X2 + 18, -6.8, 6.8, "#ff9a3c");
    c.fillStyle = "rgba(0,0,0,0.28)"; c.fillRect(CITY_X1 - 42, -0.3, CITY_X2 - CITY_X1 + 60, 0.6);
    R(64, 80, -30, 30, "#3b403a");
    R(-79, -47, 11.2, 29.2, "#2a2e2c");
    c.fillStyle = "rgba(240,240,235,0.55)"; for (var pk = 0; pk < 6; pk++) c.fillRect(-76 + pk * 5.2 - 0.1, 14.1, 0.2, 5);
    R(66, 68, -17, 17, "#5d5a52");
    R(AX1, AX2, -AZ, AZ, "#1b2433");
    c.strokeStyle = "#ff3d8b"; c.lineWidth = 0.7; c.strokeRect(AX1, -AZ, AX2 - AX1, AZ * 2);
    c.fillStyle = "#26324a"; c.fillRect(AX1, -27.5, AX2 - AX1, 7);
    R(AX2, AX2 + 22, 10.5, 13.5, "#4a5160");
    MAPR.forEach(function (q) { R(q.x1, q.x2, q.z1, q.z2, q.c); if (q.l) { c.strokeStyle = q.l; c.lineWidth = 0.5; c.strokeRect(q.x1, q.z1, q.x2 - q.x1, q.z2 - q.z1); } });
    MAPB.forEach(function (b) {
      var col = { glass: "#26333b", brick: "#3a2b26", stone: "#3a3832", shop: "#33402a", landmark: "#2c3a1a", barn: "#5a1f1a", silo: "#5d6166", rig: "#2a2d31", tank: "#6d7075", factory: "#3d444b", hill: "#5a4a38" }[b.k] || "#30332f";
      R(b.x1, b.x2, b.z1, b.z2, col);
      c.strokeStyle = b.k === "shop" || b.k === "landmark" ? "rgba(255,61,139,0.75)" : "rgba(255,255,255,0.16)"; c.lineWidth = 0.5; c.strokeRect(b.x1, b.z1, b.x2 - b.x1, b.z2 - b.z1);
      c.fillStyle = "rgba(0,0,0,0.35)"; c.fillRect(b.x1 + 1, b.z2, b.x2 - b.x1, 0.9);
    });
    c.fillStyle = "rgba(20,16,8,0.85)"; c.font = "800 3.2px Manrope, sans-serif"; c.textAlign = "center"; c.textBaseline = "middle";
    c.fillText(CS.street, -130, 0.1); c.fillText(CS.street, -60, 0.1); c.fillStyle = "rgba(255,255,255,0.55)"; c.font = "700 3px Manrope, sans-serif"; c.fillText("OUTSKIRTS RD", ROADX, 60); c.fillText("RUNWAY 09 / 27", AX2 + 240, 108); c.fillText("TAXIWAY B", AX2 + 240, 54); c.fillText("CONCOURSE B", 300, -37); c.fillText("TERMINAL", 120, 24);
  })();

  var wpMesh = (function () {
    var g = new THREE.Group();
    var col = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.7, 70, 20, 1, true), new THREE.MeshBasicMaterial({ color: 0xff3d8b, transparent: true, opacity: 0.28, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
    col.position.y = 35; g.add(col);
    var ring = new THREE.Mesh(new THREE.RingGeometry(1.1, 1.6, 40), new THREE.MeshBasicMaterial({ color: 0xff3d8b, transparent: true, opacity: 0.9, depthWrite: false, side: THREE.DoubleSide }));
    ring.rotation.x = -Math.PI / 2; ring.position.y = 0.08; g.add(ring);
    g.userData.ring = ring; g.visible = false; scene.add(g); return g;
  })();
  function setWaypoint(x, z, label) {
    G.wp = { x: x, z: z, t: label || "Waypoint" }; save();
    wpMesh.position.set(x, 0, z); wpMesh.visible = true; toast("Waypoint set \u00b7 " + G.wp.t);
  }
  function clearWaypoint() { G.wp = null; save(); wpMesh.visible = false; $("wpChip").hidden = true; $("nav").hidden = true; ROUTE = null; }
  if (G.wp) { wpMesh.position.set(G.wp.x, 0, G.wp.z); wpMesh.visible = true; }
  $("wpClear").addEventListener("click", clearWaypoint); $("navX").addEventListener("click", clearWaypoint);

  function headingVec() { return P.mode === "car" ? { x: Math.cos(taxi.yaw), z: -Math.sin(taxi.yaw) } : { x: Math.sin(P.yaw), z: Math.cos(P.yaw) }; }
  function arrow(c, x, y, ang, s) {
    c.save(); c.translate(x, y); c.rotate(ang);
    c.beginPath(); c.moveTo(0, -s); c.lineTo(s * 0.72, s * 0.8); c.lineTo(0, s * 0.38); c.lineTo(-s * 0.72, s * 0.8); c.closePath();
    c.fillStyle = "#ff3d8b"; c.strokeStyle = "#0b0d0b"; c.lineWidth = 2; c.fill(); c.stroke(); c.restore();
  }
  function badge(c, x, y, p, r) {
    c.beginPath(); c.arc(x, y, r, 0, 7); c.fillStyle = p.c; c.fill(); c.lineWidth = 2; c.strokeStyle = "#0b0d0b"; c.stroke();
    c.fillStyle = "#0b0d0b"; c.font = "800 " + Math.round(r * 0.82) + "px Unbounded, sans-serif"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(p.b, x, y + 0.5);
  }
  function wpPin(c, x, y, r) {
    c.beginPath(); c.arc(x, y, r, 0, 7); c.fillStyle = "rgba(255,61,139,0.25)"; c.fill();
    c.beginPath(); c.arc(x, y, r * 0.5, 0, 7); c.fillStyle = "#ff3d8b"; c.fill(); c.lineWidth = 2; c.strokeStyle = "#0b0d0b"; c.stroke();
  }

  /* Minimap: rotates with the camera so "up" is the way you are looking */
  var mini = $("mini"), mctx = mini.getContext("2d"), miniT = 0;
  /* ---------- GPS: shortest route along the real road graph to the waypoint ---------- */
  var ROUTE = null, routeT = -1e9, routeLen = 0, routeTurn = null;
  function heapPush(h, it) { h.push(it); var i = h.length - 1; while (i > 0) { var p = (i - 1) >> 1; if (h[p][0] <= h[i][0]) break; var t = h[p]; h[p] = h[i]; h[i] = t; i = p; } }
  function heapPop(h) { var top = h[0], last = h.pop(); if (h.length) { h[0] = last; var i = 0; for (;;) { var l = i * 2 + 1, r = l + 1, m = i; if (l < h.length && h[l][0] < h[m][0]) m = l; if (r < h.length && h[r][0] < h[m][0]) m = r; if (m === i) break; var t = h[m]; h[m] = h[i]; h[i] = t; i = m; } } return top; }
  function roadPts(r, s0, s1) { var out = [], step = 6, dir = s1 >= s0 ? 1 : -1, n = Math.max(1, Math.ceil(Math.abs(s1 - s0) / step)); for (var i = 0; i <= n; i++) { var q = CITY.pointAt(r, s0 + (s1 - s0) * i / n); out.push([q.x, q.z]); } return out; }
  /* routing graph built from road geometry: every shared point (a real junction) links the roads together */
  var RG = null;
  /* ===== Water: rivers and lakes from the real map. Cars sink, people swim. ===== */
  var WATER = null;
  function buildWater(ov) {
    var C = 60, grid = {}, n = 0;
    function add(o) { for (var i = Math.floor(o.x1 / C); i <= Math.floor(o.x2 / C); i++) for (var j = Math.floor(o.z1 / C); j <= Math.floor(o.z2 / C); j++) (grid[i + "," + j] || (grid[i + "," + j] = [])).push(o); n++; }
    (ov.w || []).forEach(function (w) {
      var p = w.p.map(function (v, i) { return v + (i % 2 ? CITY_OZ : CITY_OX); }), x1 = 1e9, x2 = -1e9, z1 = 1e9, z2 = -1e9, r = w.line ? w.line / 2 : 0;
      for (var i = 0; i < p.length; i += 2) { x1 = Math.min(x1, p[i]); x2 = Math.max(x2, p[i]); z1 = Math.min(z1, p[i + 1]); z2 = Math.max(z2, p[i + 1]); }
      add({ p: p, line: r, x1: x1 - r, x2: x2 + r, z1: z1 - r, z2: z2 + r });
    });
    WATER = { grid: grid, C: C, n: n };
  }
  function polyIn(p, x, z) { var c = false; for (var i = 0, j = p.length - 2; i < p.length; j = i, i += 2) { var xi = p[i], zi = p[i + 1], xj = p[j], zj = p[j + 1]; if (((zi > z) !== (zj > z)) && (x < (xj - xi) * (z - zi) / (zj - zi) + xi)) c = !c; } return c; }
  function isWater(x, z) {
    if (!WATER || !WATER.n) return false;
    if (CITY && CITY.onPier(x, z)) return false;
    var a = WATER.grid[Math.floor(x / WATER.C) + "," + Math.floor(z / WATER.C)]; if (!a) return false;
    for (var i = 0; i < a.length; i++) { var o = a[i]; if (x < o.x1 || x > o.x2 || z < o.z1 || z > o.z2) continue;
      if (!o.line) { if (polyIn(o.p, x, z)) return true; }
      else for (var j = 2; j < o.p.length; j += 2) { var p = o.p, ex = p[j] - p[j - 2], ez = p[j + 1] - p[j - 1], l2 = ex * ex + ez * ez || 1, t = Math.max(0, Math.min(1, ((x - p[j - 2]) * ex + (z - p[j - 1]) * ez) / l2)), dx = x - p[j - 2] - ex * t, dz = z - p[j - 1] - ez * t; if (dx * dx + dz * dz < o.line * o.line) return true; } }
    return false;
  }
  /* deep water where you sink or swim: not on a mapped road (real bridges) and not on our bridge */
  function deepWater(x, z) { return isWater(x, z) && !onBridge(x, z) && !deckAt(x, z) && !(CITY && CITY.onRoad(x, z)); }

  /* ===== East River bridge: links the city to Queens and the airport ===== */
  var BRIDGE = null, BR_H = 9, BR_RAMP = 85;
  function onBridge(x, z) { return !!(BRIDGE && !BRIDGE.land && x > BRIDGE.xa - 1 && x < BRIDGE.xb + 1 && Math.abs(z) < 8.2); }
  function bridgeY(x) { if (!BRIDGE || BRIDGE.land) return 0; var d = Math.min(x - BRIDGE.xa, BRIDGE.xb - x); if (d <= 0) return 0; var k = Math.min(1, d / BR_RAMP); return BR_H * k * k * (3 - 2 * k); }
  function groundY(x, z) { return onBridge(x, z) ? bridgeY(x) : 0; }
  function buildBridge() {
    if (BRIDGE || !cityOV || !WATER) return;
    if (!isWater(-257, 0) && !isWater(-280, 0)) {
      /* no river between the city and the expressway here: the streets just meet */
      BRIDGE = { land: true, pts: [[-262, 0], [-250, 0]] }; RG = null; return;
    }
    var x = -257, run = 0, shore = null;
    for (; x > -1600; x -= 2) { if (!isWater(x, 0)) { if (++run >= 4) { shore = x + 6; break; } } else run = 0; }
    if (shore === null) return;
    var xa = shore - 10, xb = -246, L = xb - xa, mx = (xa + xb) / 2;
    BRIDGE = { xa: xa, xb: xb, pts: [[xa, 0], [xb, 0]] }; RG = null;
    var g = new THREE.Group(), steel = new THREE.MeshStandardMaterial({ color: 0x6f8796, roughness: 0.4, metalness: 0.55 }), conc = new THREE.MeshStandardMaterial({ color: 0xa5a29a, roughness: 0.9 }), lineM = new THREE.MeshBasicMaterial({ color: 0xf3c63a }), whiteM = new THREE.MeshBasicMaterial({ color: 0xeeeeee });
    /* deck: a strip that follows the rise of the bridge */
    function strip(z1, z2, yTop, yBot, mat, step) {
      var pos = [], idx = [], N = Math.ceil(L / step);
      for (var i = 0; i <= N; i++) { var px = xa + L * i / N, y = bridgeY(px); pos.push(px, y + yTop, z1, px, y + yTop, z2, px, y + yBot, z1, px, y + yBot, z2); }
      for (var i2 = 0; i2 < N; i2++) { var a = i2 * 4, b = a + 4; idx.push(a, a + 1, b, b, a + 1, b + 1); if (yBot !== yTop) { idx.push(a + 2, b + 2, a + 3, a + 3, b + 2, b + 3); idx.push(a, b, a + 2, a + 2, b, b + 2); idx.push(a + 1, a + 3, b + 1, b + 1, a + 3, b + 3); } }
      var geo = new THREE.BufferGeometry(); geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3)); geo.setIndex(idx); geo.computeVertexNormals();
      var m = new THREE.Mesh(geo, mat); m.receiveShadow = true; m.castShadow = yBot !== yTop; g.add(m); return m;
    }
    strip(-7.5, 7.5, 0.06, 0.06, M.asphalt, 3);
    strip(-8.2, 8.2, 0.02, -1.6, conc, 3);
    strip(-0.12, 0.12, 0.075, 0.075, lineM, 3);
    [-1, 1].forEach(function (sd) {
      strip(sd * 3.75 - 0.08, sd * 3.75 + 0.08, 0.075, 0.075, whiteM, 3);
      strip(sd * 7.55 - 0.3, sd * 7.55 + 0.3, 1.0, 0.0, conc, 3);       /* parapet */
      strip(sd * 8.05 - 0.2, sd * 8.05 + 0.2, 7.6, 7.2, steel, 4);      /* top chord */
      solid(xa, xb, sd * 7.55 - 0.3, sd * 7.55 + 0.3);
    });
    /* truss: posts, diagonals and cross beams */
    for (var k = 0, sg = 1; k <= L; k += 8, sg = -sg) {
      var px = xa + k, y0 = bridgeY(px);
      [-1, 1].forEach(function (sd) {
        var post = new THREE.Mesh(new THREE.BoxGeometry(0.42, 7.4, 0.42), steel); post.position.set(px, y0 + 3.7, sd * 8.05); post.castShadow = true; g.add(post);
        if (k + 8 <= L) { var x2 = px + 8, y2 = bridgeY(x2), dx = 8, dy = (y2 + 7.2) - y0, len = Math.hypot(dx, dy), dg = new THREE.Mesh(new THREE.BoxGeometry(len, 0.28, 0.28), steel);
          if (sg > 0) { dg.position.set(px + 4, (y0 + y2 + 7.2) / 2, sd * 8.05); dg.rotation.z = Math.atan2(dy, dx); }
          else { var dy2 = y2 - (y0 + 7.2); dg.position.set(px + 4, (y0 + 7.2 + y2) / 2, sd * 8.05); dg.rotation.z = Math.atan2(dy2, dx); dg.scale.x = Math.hypot(dx, dy2) / len; }
          g.add(dg); }
      });
      var beam = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, 16.5), steel); beam.position.set(px, y0 + 7.4, 0); g.add(beam);
      if (k % 32 === 0) { var lamp = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.18, 1.2), new THREE.MeshBasicMaterial({ color: 0xfff2c0 })); lamp.position.set(px, y0 + 7.1, 0); g.add(lamp); }
    }
    /* piers standing in the river */
    for (var k2 = 24; k2 < L - 10; k2 += 36) { var qx = xa + k2; if (!isWater(qx, 0)) continue; var yb = bridgeY(qx) - 1.6, pier = new THREE.Mesh(new THREE.BoxGeometry(3.2, yb + 8, 13), conc); pier.position.set(qx, (yb - 8) / 2, 0); pier.castShadow = true; g.add(pier); BRIDGE.piers = (BRIDGE.piers || []).concat([qx]); }
    scene.add(g); BRIDGE.g = g;
    sign("QUEENS · JFK AIRPORT  →", 11, 1.0, xa + 30, bridgeY(xa + 30) + 6.2, 0, -Math.PI / 2, { bg: "#0f5d36", fg: "#ffffff", size: 64, w: 1024, h: 96 });
    sign("←  MANHATTAN", 9, 1.0, xb - 30, bridgeY(xb - 30) + 6.2, 0, Math.PI / 2, { bg: "#0f5d36", fg: "#ffffff", size: 64, w: 1024, h: 96 });
    /* ramp down onto the shore street */
    var rd = null, rdd = 150; (cityOV.r || []).forEach(function (r) { if (r.c > 5) return; for (var i = 0; i < r.p.length; i += 2) { var qx = r.p[i] + CITY_OX, qz = r.p[i + 1] + CITY_OZ, d = Math.hypot(qx - xa, qz); if (d < rdd && qx <= xa + 2) { rdd = d; rd = { x: qx, z: qz }; } } });
    if (rd && Math.hypot(rd.x - xa, rd.z) > 6) { var ax = rd.x, az = rd.z, dl = Math.hypot(xa - ax, az), ap = new THREE.Mesh(new THREE.PlaneGeometry(dl + 6, 12), M.asphalt); ap.rotation.x = -Math.PI / 2; ap.rotation.z = Math.atan2(az, xa - ax); ap.position.set((xa + ax) / 2, 0.02, az / 2); scene.add(ap); BRIDGE.pts[0] = [ax, az]; BRIDGE.ramp = [ax, az]; }
  }
  function drawBridge(ctx) { if (!BRIDGE || BRIDGE.land) return; ctx.save(); ctx.lineCap = "butt"; ctx.strokeStyle = "#5c636b"; ctx.lineWidth = 17 * MS; ctx.beginPath(); ctx.moveTo((BRIDGE.xa - MX1) * MS, (0 - MZ1) * MS); ctx.lineTo((BRIDGE.xb - MX1) * MS, (0 - MZ1) * MS); ctx.stroke(); ctx.strokeStyle = "#e8c35a"; ctx.lineWidth = 13 * MS; ctx.stroke(); if (BRIDGE.ramp) { ctx.beginPath(); ctx.moveTo((BRIDGE.ramp[0] - MX1) * MS, (BRIDGE.ramp[1] - MZ1) * MS); ctx.lineTo((BRIDGE.xa - MX1) * MS, (0 - MZ1) * MS); ctx.stroke(); } ctx.restore(); }
  /* ===================== Elevated airport rail, river boats and ferries ===================== */
  var TRANSIT = null, RIDE = null, BOATS = [], DECKS = [], BAND_PIERS = [], FERRY = null;
  var RAIL_Z = 13.5, RAIL_Y = 10, TRK = [12.3, 14.7];
  function wrapA(a) { return ((a + Math.PI * 3) % (Math.PI * 2)) - Math.PI; }
  function deckAt(x, z) { for (var i = 0; i < DECKS.length; i++) { var d = DECKS[i]; if (x > d.x1 && x < d.x2 && z > d.z1 && z < d.z2) return d; } return null; }
  function nearDeck(x, z, c) { for (var i = 0; i < DECKS.length; i++) { var d = DECKS[i]; if (x > d.x1 - c && x < d.x2 + c && z > d.z1 - c && z < d.z2 + c) return true; } return false; }
  /* height of whatever the walking player stands on */
  function standY(x, z) { if (P.lv && Math.abs(x - P.x) < 0.01 && Math.abs(z - P.z) < 0.01) return P.lv.y; var d = deckAt(x, z); if (d) return d.y; return onBridge(x, z) ? bridgeY(x) : 0; }
  function tmat(c, r, m, o) { var p = { color: c, roughness: r === undefined ? 0.6 : r, metalness: m || 0 }; if (o) for (var k in o) p[k] = o[k]; return new THREE.MeshStandardMaterial(p); }
  function gbox(g, w, h, d, m, x, y, z, noSh) { var o = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m); o.position.set(x, y, z); if (!noSh) { o.castShadow = true; o.receiveShadow = true; } g.add(o); return o; }
  function gsign(g, text, w, h, x, y, z, ry, opt) { var mt = new THREE.MeshStandardMaterial({ map: signTex(text, opt), roughness: 0.5, emissive: new THREE.Color(0xffffff), emissiveIntensity: 0.22 }); mt.emissiveMap = mt.map; var m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mt); m.position.set(x, y, z); m.rotation.y = ry || 0; g.add(m); return m; }
  var GLASS_T = tmat(0x1d2a33, 0.15, 0.6), WHITE_T = tmat(0xf3f3ee, 0.5), DARK_T = tmat(0x202326, 0.6);

  /* ---------- boats ---------- */
  function hullGeo(L, W, H, bow) {
    var s = new THREE.Shape(), hl = L / 2, hw = W / 2, b = hl - L * (bow || 0.28);
    s.moveTo(-hl, -hw * 0.92); s.lineTo(b, -hw); s.quadraticCurveTo(hl * 0.95, -hw * 0.8, hl, 0); s.quadraticCurveTo(hl * 0.95, hw * 0.8, b, hw); s.lineTo(-hl, hw * 0.92); s.lineTo(-hl, -hw * 0.92);
    var g = new THREE.ExtrudeGeometry(s, { depth: H, bevelEnabled: false, curveSegments: 6 }); g.rotateX(-Math.PI / 2); return g;
  }
  var WAKE_TEX = null;
  function wakeMesh(L, W) {
    if (!WAKE_TEX) WAKE_TEX = canvasTex(128, 256, function (g, w, h) { g.clearRect(0, 0, w, h); for (var i = 0; i < 60; i++) { var t = i / 60, y = t * h, half = 8 + t * (w / 2 - 10), a = 0.55 * (1 - t); g.fillStyle = "rgba(255,255,255," + a.toFixed(3) + ")"; g.fillRect(w / 2 - half, y, 5, h / 60 + 1); g.fillRect(w / 2 + half - 5, y, 5, h / 60 + 1); g.fillStyle = "rgba(255,255,255," + (a * 0.45).toFixed(3) + ")"; g.fillRect(w / 2 - W * 2, y, W * 4, h / 60 + 1); } }, true);
    var m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: WAKE_TEX, transparent: true, depthWrite: false, opacity: 0 }));
    m.rotation.x = -Math.PI / 2; m.rotation.z = Math.PI / 2; m.renderOrder = 4; m.userData = { L: L, W: W }; return m;
  }
  function finishBoat(g, L, W, tall, deckY) { var wk = wakeMesh(L, W); g.add(wk); g.userData = { L: L, W: W, tall: tall, boat: true, wheels: [], r: 1, deckY: deckY, wake: wk, vmax: L < 8 ? 19 : 12, acc: L < 8 ? 7 : 3 }; return g; }
  function speedboat(col) {
    var g = new THREE.Group(), L = 7, W = 2.5;
    var h = new THREE.Mesh(hullGeo(L, W, 1.1, 0.36), WHITE_T); h.position.y = -0.45; h.castShadow = true; g.add(h);
    var st = new THREE.Mesh(hullGeo(L * 1.004, W * 1.02, 0.2, 0.36), tmat(col, 0.35)); st.position.y = 0.3; g.add(st);
    gbox(g, 4.6, 0.06, W - 0.4, tmat(0xcbb999, 0.85), -0.9, 0.62, 0);
    var ws = gbox(g, 0.06, 0.55, W - 0.6, tmat(0x9fc3d6, 0.05, 0.3, { transparent: true, opacity: 0.55 }), 0.95, 0.95, 0, true); ws.rotation.z = 0.55;
    gbox(g, 0.7, 0.42, 0.75, WHITE_T, -0.2, 0.86, -0.55); gbox(g, 0.7, 0.42, 0.75, WHITE_T, -0.2, 0.86, 0.55);
    gbox(g, 0.75, 0.45, W - 0.5, WHITE_T, -2.5, 0.86, 0); gbox(g, 0.2, 0.55, W - 0.5, tmat(col, 0.4), -2.95, 1.0, 0);
    gbox(g, 0.42, 0.95, 0.48, DARK_T, -3.62, 0.62, 0); gbox(g, 0.5, 0.18, 0.12, DARK_T, 0.35, 0.95, -0.55);
    stick(g, 10, 0.75, -1.4, 0.05, W / 2 + 0.04, 1); stick(g, 3, 0.75, -1.4, 0.05, -W / 2 - 0.04, -1);
    return finishBoat(g, L, W, false, 0.62);
  }
  function waterTaxi() {
    var g = new THREE.Group(), L = 11, W = 3.8, yel = tmat(0xf2c230, 0.4);
    var h = new THREE.Mesh(hullGeo(L, W, 1.4, 0.3), yel); h.position.y = -0.7; h.castShadow = true; g.add(h);
    gbox(g, 6, 1.7, W - 0.5, WHITE_T, -1, 1.55, 0); gbox(g, 5.6, 0.7, W - 0.42, GLASS_T, -1, 1.75, 0, true); gbox(g, 6.4, 0.16, W - 0.2, yel, -1, 2.45, 0);
    for (var i = 0; i < 6; i++) gbox(g, 0.5, 0.12, 0.06, i % 2 ? DARK_T : yel, -3.5 + i, 0.85, W / 2 - 0.25, true);
    gsign(g, "WATER TAXI", 3.2, 0.5, -1, 2.0, W / 2 - 0.21, 0, { w: 512, h: 80, bg: "#f2c230", fg: "#111", size: 56 });
    gsign(g, "WATER TAXI", 3.2, 0.5, -1, 2.0, -W / 2 + 0.21, Math.PI, { w: 512, h: 80, bg: "#f2c230", fg: "#111", size: 56 });
    return finishBoat(g, L, W, false, 0.7);
  }
  function ferryBoat() {
    var g = new THREE.Group(), L = 26, W = 8, blue = tmat(0x1f4f8f, 0.45);
    var h = new THREE.Mesh(hullGeo(L, W, 2.2, 0.24), WHITE_T); h.position.y = -1.2; h.castShadow = true; g.add(h);
    var band = new THREE.Mesh(hullGeo(L * 1.003, W * 1.01, 0.4, 0.24), blue); band.position.y = 0.45; g.add(band);
    gbox(g, L * 0.82, 0.08, W - 0.6, tmat(0x9aa4a8, 0.8), -0.5, 1.0, 0);
    gbox(g, 15, 2.4, W - 1.2, WHITE_T, -2.5, 2.2, 0); gbox(g, 14.6, 1.1, W - 1.1, GLASS_T, -2.5, 2.4, 0, true);
    gbox(g, 10, 2.0, W - 2, WHITE_T, -3.5, 4.4, 0); gbox(g, 9.6, 0.9, W - 1.9, GLASS_T, -3.5, 4.55, 0, true);
    gbox(g, 3.2, 1.5, 4, WHITE_T, 0.2, 6.15, 0); gbox(g, 3.25, 0.6, 4.05, GLASS_T, 0.2, 6.3, 0, true); gbox(g, 15.4, 0.16, W - 0.9, blue, -2.5, 3.45, 0);
    for (var i = 0; i < 7; i++) gbox(g, 0.06, 0.9, 0.06, WHITE_T, 6.2 + i * 0.9, 1.5, W / 2 - 0.55, true), gbox(g, 0.06, 0.9, 0.06, WHITE_T, 6.2 + i * 0.9, 1.5, -W / 2 + 0.55, true);
    gbox(g, 6.4, 0.06, 0.06, WHITE_T, 9, 1.95, W / 2 - 0.55, true); gbox(g, 6.4, 0.06, 0.06, WHITE_T, 9, 1.95, -W / 2 + 0.55, true);
    gsign(g, "RIVER FERRY", 6, 0.7, -2.5, 3.45, W / 2 - 0.57, 0, { w: 768, h: 90, bg: "#1f4f8f", fg: "#fff", size: 64 });
    gsign(g, "RIVER FERRY", 6, 0.7, -2.5, 3.45, -W / 2 + 0.57, Math.PI, { w: 768, h: 90, bg: "#1f4f8f", fg: "#fff", size: 64 });
    return finishBoat(g, L, W, false, 1.04);
  }
  function tugBoat() {
    var g = new THREE.Group(), L = 12, W = 4.6, red = tmat(0xb3261e, 0.5);
    var h = new THREE.Mesh(hullGeo(L, W, 1.9, 0.3), red); h.position.y = -1.1; h.castShadow = true; g.add(h);
    gbox(g, L * 0.9, 0.35, W + 0.2, DARK_T, 0, 0.65, 0);
    gbox(g, 5, 1.8, W - 1.2, WHITE_T, -0.6, 1.7, 0); gbox(g, 3, 1.4, W - 1.6, WHITE_T, 0, 3.3, 0); gbox(g, 3.05, 0.6, W - 1.55, GLASS_T, 0, 3.4, 0, true);
    var st = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.5, 2.2, 12), DARK_T); st.position.set(-2.4, 3.6, 0); g.add(st); gbox(g, 1, 0.4, 1, red, -2.4, 4.5, 0);
    return finishBoat(g, L, W, false, 0.9);
  }
  function cargoShip() {
    var g = new THREE.Group(), L = 64, W = 11, cols = [0xb3261e, 0x1f5fa8, 0x2e7d4f, 0xe08a1e, 0x6b6b6b, 0x7a3d8c, 0xd9c23a];
    var h = new THREE.Mesh(hullGeo(L, W, 5, 0.18), tmat(0x23324a, 0.6)); h.position.y = -2.8; h.castShadow = true; g.add(h);
    var bt = new THREE.Mesh(hullGeo(L * 1.002, W * 1.005, 0.6, 0.18), tmat(0x8a2a22, 0.6)); bt.position.y = -0.4; g.add(bt);
    gbox(g, L * 0.78, 0.2, W - 1, tmat(0x6a6f72, 0.8), -1, 2.2, 0);
    for (var r = 0; r < 6; r++) for (var c = 0; c < 3; c++) for (var t = 0; t < 2 + ((r + c) % 2); t++) gbox(g, 6.1, 2.5, 2.45, tmat(cols[(r * 3 + c * 5 + t * 2) % cols.length], 0.7), 14 - r * 6.4, 3.55 + t * 2.55, (c - 1) * 2.6);
    gbox(g, 7, 8, W - 1.5, WHITE_T, -26, 6.2, 0); gbox(g, 7.1, 1, W - 1.4, GLASS_T, -26, 9.3, 0, true); gbox(g, 2, 3, 2.4, tmat(0xb3261e, 0.5), -28.5, 11.5, 0);
    return finishBoat(g, L, W, true, 2.3);
  }
  function sailBoat() {
    var g = new THREE.Group(), L = 9, W = 3;
    var h = new THREE.Mesh(hullGeo(L, W, 1.2, 0.34), WHITE_T); h.position.y = -0.7; h.castShadow = true; g.add(h);
    gbox(g, 3, 0.6, 1.8, tmat(0xcbb999, 0.8), -0.5, 0.75, 0);
    var mast = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 11, 8), tmat(0xdddddd, 0.4, 0.5)); mast.position.set(0.8, 5.9, 0); g.add(mast);
    var sh = new THREE.Shape(); sh.moveTo(0, 0); sh.lineTo(-3.6, 0); sh.lineTo(0, 9.6); sh.lineTo(0, 0);
    var sail = new THREE.Mesh(new THREE.ShapeGeometry(sh), new THREE.MeshStandardMaterial({ color: 0xfafaf5, side: THREE.DoubleSide, roughness: 0.8 })); sail.position.set(0.75, 1.1, 0); g.add(sail);
    var sh2 = new THREE.Shape(); sh2.moveTo(0, 0); sh2.lineTo(3.4, 0); sh2.lineTo(0, 8.4); sh2.lineTo(0, 0);
    var jib = new THREE.Mesh(new THREE.ShapeGeometry(sh2), new THREE.MeshStandardMaterial({ color: 0xe8eef2, side: THREE.DoubleSide, roughness: 0.8 })); jib.position.set(0.95, 1.1, 0.02); g.add(jib);
    return finishBoat(g, L, W, true, 0.6);
  }
  function yacht() {
    var g = new THREE.Group(), L = 16, W = 4.6;
    var h = new THREE.Mesh(hullGeo(L, W, 1.8, 0.32), WHITE_T); h.position.y = -0.9; h.castShadow = true; g.add(h);
    gbox(g, 8, 1.3, W - 0.9, WHITE_T, -1.5, 1.55, 0); gbox(g, 7.6, 0.6, W - 0.85, GLASS_T, -1.5, 1.6, 0, true);
    gbox(g, 5, 1, W - 1.6, WHITE_T, -2.2, 2.7, 0); gbox(g, 4.6, 0.45, W - 1.55, GLASS_T, -2.2, 2.75, 0, true); gbox(g, 4, 0.1, 0.4, tmat(0x1f4f8f, 0.4), -1.5, 1.05, W / 2 + 0.01, true);
    return finishBoat(g, L, W, false, 0.9);
  }

  /* ---------- water paths ---------- */
  function inBand(x, z) { return !!(BRIDGE && !BRIDGE.land && z > -11.5 && z < 19.5 && x > BRIDGE.xa - 30 && x < -240); }
  function pathClear(ax, az, bx2, bz2, clr, tall, decksOk) {
    var dx = bx2 - ax, dz = bz2 - az, L = Math.hypot(dx, dz) || 1, nx = -dz / L, nz = dx / L;
    for (var s = 0; s <= L + 0.1; s += 4) {
      var x = ax + dx * s / L, z = az + dz * s / L;
      if (!isWater(x, z) || !isWater(x + nx * clr, z + nz * clr) || !isWater(x - nx * clr, z - nz * clr)) return false;
      if (!decksOk && nearDeck(x, z, clr + 2)) return false;
      if (inBand(x, z)) { if (tall) return false; for (var i = 0; i < BAND_PIERS.length; i++) if (Math.abs(x - BAND_PIERS[i]) < clr + 3) return false; }
    }
    return true;
  }
  function pickTarget(b) {
    for (var k = 0; k < 16; k++) {
      var ang = k < 9 ? b.yaw + (Math.random() - 0.5) * 1.6 : Math.random() * 6.283, d = 80 + Math.random() * 240;
      var tx = b.x + Math.cos(ang) * d, tz = b.z - Math.sin(ang) * d;
      if (Math.hypot(tx - b.hx, tz - b.hz) > b.range) continue;
      if (pathClear(b.x, b.z, tx, tz, b.m.userData.W / 2 + 3, b.m.userData.tall)) { b.tgt = [tx, tz]; return; }
    }
    b.tgt = null; b.spin = 2.5;
  }
  function bob(o, t, k) { return Math.sin(t * 1.3 + o.ph) * 0.05 * k; }
  function placeBoat(b, t, sp) {
    var m = b.m, big = m.userData.L > 30 ? 0.25 : 1;
    m.position.set(b.x, bob(b, t, big), b.z);
    m.rotation.set(Math.sin(t * 0.9 + b.ph) * 0.025 * big, b.yaw, Math.min(0.08, Math.abs(sp) * 0.006) * (m.userData.L < 12 ? 1 : 0.3) + Math.sin(t * 1.1 + b.ph) * 0.012 * big);
    var wk = m.userData.wake; if (wk) { var k = Math.min(1, Math.abs(sp) / 8), len = m.userData.L * (0.8 + k * 1.6); wk.scale.set(m.userData.W * 2.6, len, 1); wk.position.set(-m.userData.L / 2 - len / 2 + 0.6, 0.07 - m.position.y, 0); wk.material.opacity = k * 0.85; }
  }
  function boatTick(b, dt, t) {
    if (b.ride) return;
    if (b.spin > 0) { b.spin -= dt; b.yaw += dt * 0.5; b.v = lerp(b.v, 0, dt); if (b.spin <= 0) pickTarget(b); placeBoat(b, t, b.v); return; }
    if (!b.tgt || Math.hypot(b.tgt[0] - b.x, b.tgt[1] - b.z) < 14) pickTarget(b);
    if (!b.tgt) { placeBoat(b, t, 0); return; }
    var want = Math.atan2(-(b.tgt[1] - b.z), b.tgt[0] - b.x), dy = wrapA(want - b.yaw);
    b.yaw += clamp(dy, -b.turn * dt, b.turn * dt);
    var px = P.mode === "car" ? taxi.x : P.x, pz = P.mode === "car" ? taxi.z : P.z, ahead = (px - b.x) * Math.cos(b.yaw) - (pz - b.z) * Math.sin(b.yaw), side = Math.abs((px - b.x) * Math.sin(b.yaw) + (pz - b.z) * Math.cos(b.yaw));
    var blocked = ahead > 0 && ahead < b.m.userData.L / 2 + 10 && side < b.m.userData.W / 2 + 3;
    b.v = lerp(b.v, blocked ? 0 : b.vmax * (Math.abs(dy) > 0.9 ? 0.35 : 1), Math.min(1, dt * 0.6));
    var nx = b.x + Math.cos(b.yaw) * b.v * dt, nz = b.z - Math.sin(b.yaw) * b.v * dt;
    if (isWater(nx + Math.cos(b.yaw) * b.m.userData.L / 2, nz - Math.sin(b.yaw) * b.m.userData.L / 2)) { b.x = nx; b.z = nz; } else { b.v = 0; b.tgt = null; b.spin = 1.5; }
    placeBoat(b, t, b.v);
    b.m.visible = Math.hypot(b.x - camera.position.x, b.z - camera.position.z) < 1300;
  }
  function spawnBoats(hx, hz) {
    var kinds = [[speedboat, 0xc0392b, 13], [speedboat, 0x1f5fa8, 13], [speedboat, 0x111111, 14], [waterTaxi, 0, 8], [tugBoat, 0, 5], [cargoShip, 0, 4.5], [sailBoat, 0, 4], [sailBoat, 0, 4], [yacht, 0, 7], [ferryBoat, 0, 7]];
    kinds.forEach(function (k, i) {
      var m = k[0](k[1]), cl = m.userData.W / 2 + 4;
      for (var tries = 0; tries < 80; tries++) {
        var x = hx + (Math.random() - 0.5) * 1200, z = hz + (Math.random() - 0.5) * 1700;
        if (!isWater(x, z) || !isWater(x + cl, z) || !isWater(x - cl, z) || !isWater(x, z + cl) || !isWater(x, z - cl) || inBand(x, z) || nearDeck(x, z, 20)) continue;
        var b = { m: m, x: x, z: z, yaw: Math.random() * 6.28, v: 0, vmax: k[2], turn: m.userData.L > 30 ? 0.08 : m.userData.L > 15 ? 0.18 : 0.6, hx: hx, hz: hz, range: 1150, ph: Math.random() * 6, boat: true, spin: 0 };
        scene.add(m); BOATS.push(b); CARS.push(b); placeBoat(b, 0, 0); break;
      }
    });
  }

  /* ---------- the elevated airport rail line ---------- */
  function trainMesh() {
    var g = new THREE.Group(), body = tmat(0xd7dde2, 0.35, 0.5), stripe = tmat(0x1f5fa8, 0.4), win = tmat(0x16222c, 0.12, 0.5, { emissive: new THREE.Color(0x3a4a55), emissiveIntensity: 0.35 });
    for (var c = 0; c < 3; c++) {
      var cx = (c - 1) * 13.1;
      gbox(g, 12.6, 3.0, 2.9, body, cx, 1.95, 0); gbox(g, 12.65, 0.95, 2.95, win, cx, 2.35, 0, true); gbox(g, 12.65, 0.26, 2.95, stripe, cx, 1.45, 0, true);
      gbox(g, 10, 0.35, 1.8, tmat(0x9aa2a8, 0.5, 0.5), cx, 3.6, 0);
      [-1, 1].forEach(function (sd) { for (var d = -1; d <= 1; d += 2) gbox(g, 1.3, 2.3, 0.04, tmat(0xb9c1c7, 0.3, 0.6), cx + d * 3.2, 1.75, sd * 1.47, true); gbox(g, 2.4, 0.55, 2.2, DARK_T, cx + sd * 4.4, 0.32, 0); });
    }
    [-1, 1].forEach(function (sd) { var fx = sd * (13.1 + 6.32); gbox(g, 0.08, 1.2, 2.5, GLASS_T, fx, 2.45, 0, true); var hl = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.18, 0.4), new THREE.MeshBasicMaterial({ color: 0xfff6d0 })); hl.position.set(fx, 1.0, 0.95); g.add(hl); var h2 = hl.clone(); h2.position.z = -0.95; g.add(h2); });
    return g;
  }
  function buildRail(river, shore) {
    var isNY = G.city === "JFK", g = new THREE.Group();
    var X1 = river ? shore - 20 : -262, X2 = 79;
    var xs = river ? [shore + 6, -200, -62, 57] : [-236, -150, -62, 57];
    var names = isNY ? ["MANHATTAN · MIDTOWN", "QUEENS PLAZA", CS.street, "JFK AIRPORT"] : [here().city.toUpperCase() + " CENTRE", "EAST SIDE", CS.street, G.city + " AIRPORT"];
    var conc = tmat(0xb9b6ae, 0.85), steel = tmat(0x8e979e, 0.45, 0.6), green = tmat(0x1c5a3a, 0.5);
    var L = X2 - X1, mx = (X1 + X2) / 2;
    gbox(g, L, 1.2, 6.4, conc, mx, RAIL_Y - 0.6, RAIL_Z);
    [-1, 1].forEach(function (sd) { gbox(g, L, 0.9, 0.22, conc, mx, RAIL_Y + 0.45, RAIL_Z + sd * 3.1); });
    TRK.forEach(function (tz) { gbox(g, L, 0.06, 2.2, tmat(0x4a4541, 1), mx, RAIL_Y + 0.03, tz, true); [-0.72, 0.72].forEach(function (o) { gbox(g, L, 0.16, 0.1, steel, mx, RAIL_Y + 0.14, tz + o, true); }); });
    var st = xs.map(function (x, i) { return { x: x, name: names[i], tx: i === 0 && river ? shore - 13 : x + 18 }; });
    /* pillars, some standing in the river */
    for (var px = X1 + 6; px < X2 - 3; px += 24) {
      if ((px > -12 && px < 2) || (px > 4 && px < 14) || (px > 38 && px < 66)) continue;
      if (st.some(function (s) { return Math.abs(px - s.tx) < 3.5; })) continue;
      var wet = isWater(px, RAIL_Z), y0 = wet ? -4 : 0;
      gbox(g, 1.3, RAIL_Y - 1.2 - y0, 1.3, conc, px, (RAIL_Y - 1.2 + y0) / 2, RAIL_Z); gbox(g, 1.8, 0.8, 6.6, conc, px, RAIL_Y - 1.5, RAIL_Z);
      solid(px - 0.65, px + 0.65, RAIL_Z - 0.65, RAIL_Z + 0.65); if (wet) BAND_PIERS.push(px);
    }
    /* stations: side platforms, canopies, name boards and a stair tower down to the street */
    st.forEach(function (s, i) {
      [[8.5, 10.75], [16.25, i === 3 ? 17.6 : 18.4]].forEach(function (pz) {
        var w = pz[1] - pz[0], cz = (pz[0] + pz[1]) / 2;
        gbox(g, 44, 1.0, w, conc, s.x, RAIL_Y + 0.5, cz); gbox(g, 44, 0.04, 0.3, tmat(0xf2c230, 0.6), s.x, RAIL_Y + 1.02, pz[0] < 12 ? pz[1] - 0.2 : pz[0] + 0.2, true);
        gbox(g, 44, 0.18, w + 0.4, tmat(0xe9ecee, 0.4, 0.3), s.x, RAIL_Y + 4.4, cz);
        for (var k = -20; k <= 20; k += 8) { gbox(g, 0.22, 3.4, 0.22, steel, s.x + k, RAIL_Y + 2.7, pz[0] < 12 ? pz[0] + 0.3 : pz[1] - 0.3); if (!isWater(s.x + k, cz)) gbox(g, 0.9, RAIL_Y - 1.2, 0.9, conc, s.x + k, (RAIL_Y - 1.2) / 2, cz); else if (Math.abs(k) < 12) { gbox(g, 0.9, RAIL_Y + 2.8, 0.9, conc, s.x + k, (RAIL_Y - 4) / 2, cz); BAND_PIERS.push(s.x + k); } }
        gsign(g, s.name, 7, 0.8, s.x - 8, RAIL_Y + 3.6, pz[0] < 12 ? pz[0] + 0.45 : pz[1] - 0.45, pz[0] < 12 ? 0 : Math.PI, { w: 1024, h: 118, bg: "#111411", fg: "#ffffff", size: 66 });
        gsign(g, s.name, 7, 0.8, s.x + 10, RAIL_Y + 3.6, pz[0] < 12 ? pz[0] + 0.45 : pz[1] - 0.45, pz[0] < 12 ? 0 : Math.PI, { w: 1024, h: 118, bg: "#111411", fg: "#ffffff", size: 66 });
      });
      /* stair tower */
      var tz0 = i === 3 ? 17.6 : 18.4, tw = new THREE.Group();
      gbox(tw, 3.4, RAIL_Y + 3.4, 3.8, green, 0, (RAIL_Y + 3.4) / 2, 1.9); gbox(tw, 2.6, RAIL_Y + 2.4, 0.06, GLASS_T, 0, (RAIL_Y + 2.4) / 2 + 0.4, 3.82, true);
      gbox(tw, 1.8, 2.5, 0.08, DARK_T, 0, 1.25, 3.84, true);
      gsign(tw, "AIRPORT RAIL", 3.3, 0.55, 0, 3.0, 3.88, 0, { w: 768, h: 128, bg: "#1c5a3a", fg: "#fff", size: 70 });
      gsign(tw, s.name, 3.3, 0.42, 0, RAIL_Y + 2.7, 3.88, 0, { w: 1024, h: 130, bg: "#111411", fg: "#ff3d8b", size: 64 });
      [-1.2, 1.2].forEach(function (o) { var lp = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 8), new THREE.MeshBasicMaterial({ color: 0x5fe08a })); lp.position.set(o, 2.75, 4.0); tw.add(lp); });
      tw.position.set(s.tx, 0, tz0); g.add(tw);
      solid(s.tx - 1.7, s.tx + 1.7, tz0, tz0 + 3.8);
      s.ex = s.tx; s.ez = tz0 + 5.2;
      ZONES.push(s.zone = { id: "tr:rail:" + i, x: s.ex, z: s.ez, r: 2.2 });
      PLACES.push({ id: "rail" + i, t: s.name.replace("·", "-") + " station", d: "Airport rail", b: "RL", c: "#5fe08a", x: s.ex, z: s.ez });
    });
    scene.add(g);
    var trains = TRK.map(function (tz, k) { var m = trainMesh(); scene.add(m); var tr = { m: m, z: tz, x: k ? st[st.length - 1].x : st[0].x, v: 0, dir: k ? -1 : 1, at: k ? st.length - 1 : 0, next: k ? st.length - 2 : 1, dwell: 4 + k * 6 }; m.position.set(tr.x, RAIL_Y + 0.05, tz); return tr; });
    TRANSIT.rail = { x1: X1, x2: X2, st: st, trains: trains };
  }
  function trainTick(tr, dt) {
    var S = TRANSIT.rail.st;
    if (tr.dwell > 0) { tr.dwell -= dt; if (tr.dwell <= 0 && !(RIDE && RIDE.tr === tr)) { if (tr.next < 0 || tr.next >= S.length) { tr.dir = -tr.dir; tr.next = tr.at + tr.dir; } } return; }
    var tx = S[tr.next].x, dist = (tx - tr.x) * tr.dir, A = 1.1, VM = RIDE && RIDE.tr === tr ? 21 : 16;
    if (dist <= 0.05) { tr.x = tx; tr.v = 0; tr.at = tr.next; tr.next = tr.at + tr.dir; tr.dwell = 8; if (RIDE && RIDE.tr === tr && tr.at === RIDE.to) rideArrive(); }
    else { tr.v = dist <= tr.v * tr.v / (2 * A) + 0.3 ? Math.max(0.6, Math.sqrt(2 * A * dist)) : Math.min(VM, tr.v + A * dt); tr.x += tr.dir * Math.min(tr.v * dt, dist); }
    tr.m.position.set(tr.x, RAIL_Y + 0.05, tr.z);
  }

  /* ---------- ferry terminal, piers and stops ---------- */
  function shoreAt(z) { if (!isWater(-257, z)) return null; var run = 0; for (var x = -257; x > -1700; x -= 2) { if (!isWater(x, z)) { if (++run >= 4) return x + 6; } else run = 0; } return null; }
  function ferryPath(A, B) {
    var cands = []; for (var mx = -300; mx > -900; mx -= 9) cands.push(mx);
    for (var i = 0; i < cands.length; i++) { var x = cands[i], p = [A, [x, A[1]], [x, B[1]], B]; var ok = true; for (var k = 1; k < p.length && ok; k++) ok = pathClear(p[k - 1][0], p[k - 1][1], p[k][0], p[k][1], 5.5, false, true); if (ok) return p; }
    return null;
  }
  function buildFerry() {
    var g = new THREE.Group(), isNY = G.city === "JFK", wood = tmat(0x8a6a4a, 0.9), conc = tmat(0xb9b6ae, 0.85), steel = tmat(0x8e979e, 0.45, 0.6), blue = tmat(0x1f4f8f, 0.45);
    /* terminal building on the Queens shore */
    gbox(g, 18, 8, 22, tmat(0xe9ecee, 0.5), -231, 4, 47); gbox(g, 0.1, 6.4, 20, GLASS_T, -240.06, 3.6, 47, true);
    var roof = new THREE.Mesh(new THREE.CylinderGeometry(14, 14, 24, 24, 1, false, -0.5, 1.0), tmat(0xdfe3e6, 0.35, 0.4)); roof.rotation.x = Math.PI / 2; roof.rotation.y = Math.PI / 2; roof.position.set(-231, -4.2, 47); g.add(roof);
    gsign(g, isNY ? "QUEENS FERRY TERMINAL" : "FERRY TERMINAL", 14, 1.4, -240.2, 7.2, 47, -Math.PI / 2, { w: 1024, h: 104, bg: "#1f4f8f", fg: "#ffffff", size: 66 });
    solid(-240, -222, 36, 58, "bld");
    /* plaza, ticket kiosks, departures board */
    gbox(g, 10, 0.12, 22, tmat(0xcfcac0, 0.9), -245, 0.06, 47, true);
    gsign(g, "FERRIES  ·  TICKETS  4 TOKEN", 5.2, 1.0, -246.5, 2.7, 41.6, -Math.PI / 2, { w: 1024, h: 200, bg: "#0b0d0b", fg: "#ff3d8b", size: 64, sub: "SPEEDBOAT RENTAL ON THE PIER", subfg: "#ffffff" });
    gbox(g, 0.3, 3.4, 0.3, steel, -246.4, 1.7, 39.2); gbox(g, 0.3, 3.4, 0.3, steel, -246.4, 1.7, 44);
    /* the pier */
    var x1 = -292, x2 = -246, z1 = 41, z2 = 49;
    gbox(g, x2 - x1, 0.45, z2 - z1, wood, (x1 + x2) / 2, 0.22, (z1 + z2) / 2);
    for (var px = x1 + 2; px < x2; px += 6) [z1 + 0.4, z2 - 0.4].forEach(function (pz) { var pl = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 3.2, 8), DARK_T); pl.position.set(px, -1.2, pz); g.add(pl); });
    [[z1 + 0.1, [-284, -277]], [z2 - 0.1, [-267, -261]]].forEach(function (e) {
      var ez = e[0], gap = e[1];
      [[x1, gap[0]], [gap[1], -250]].forEach(function (seg) { gbox(g, seg[1] - seg[0], 0.06, 0.08, steel, (seg[0] + seg[1]) / 2, 1.45, ez, true); for (var rx = seg[0]; rx <= seg[1]; rx += 2) gbox(g, 0.07, 1.0, 0.07, steel, rx, 0.95, ez, true); solid(seg[0], seg[1], ez - 0.12, ez + 0.12); });
    });
    gbox(g, 0.08, 1.0, z2 - z1, steel, x1 + 0.1, 0.95, (z1 + z2) / 2, true); solid(x1 - 0.1, x1 + 0.2, z1, z2);
    for (var lx = x1 + 6; lx < -250; lx += 12) { gbox(g, 0.14, 4, 0.14, DARK_T, lx, 2.4, z2 - 0.6); var lb = new THREE.Mesh(new THREE.SphereGeometry(0.25, 10, 8), new THREE.MeshBasicMaterial({ color: 0xfff2c0 })); lb.position.set(lx, 4.45, z2 - 0.6); g.add(lb); }
    gbox(g, 16, 0.2, 7, blue, -258, 3.4, 45); [-265, -251].forEach(function (cx2) { gbox(g, 0.2, 3.2, 0.2, steel, cx2, 1.85, 42); gbox(g, 0.2, 3.2, 0.2, steel, cx2, 1.85, 48); });
    gsign(g, "FERRY", 3, 0.6, -280.5, 2.4, 41.06, Math.PI, { w: 512, h: 100, bg: "#1f4f8f", fg: "#fff", size: 70 });
    gsign(g, "SPEEDBOATS", 3.6, 0.6, -264, 2.4, 48.94, 0, { w: 640, h: 100, bg: "#c0392b", fg: "#fff", size: 66 });
    DECKS.push({ x1: x1, x2: x2 + 2, z1: z1, z2: z2, y: 0.45 });
    scene.add(g);
    ZONES.push({ id: "tr:ferry:0", x: -247.5, z: 45, r: 2.4 });
    ZONES.push({ id: "tr:rent", x: -264, z: 48.2, r: 1.9 });
    PLACES.push({ id: "ferry0", t: isNY ? "Queens Ferry Terminal" : "Ferry Terminal", d: "Ferries and speedboats", b: "FY", c: "#5ab0ff", x: -247.5, z: 45 });
    /* moored rental boats */
    [-270.5, -257].forEach(function (bx3) { var sb = speedboat(bx3 < -260 ? 0xc0392b : 0x1f5fa8); var o = { m: sb, x: bx3, z: 51.6, yaw: Math.PI, ph: Math.random() * 6, boat: true }; scene.add(sb); BOATS.push(o); CARS.push(o); o.moored = true; placeBoat(o, 0, 0); });
    /* our ferry waits at the pier */
    var fm = ferryBoat(); FERRY = { m: fm, x: -281, z: 35.4, yaw: Math.PI, ph: 1, boat: true, home: [-281, 35.4] }; scene.add(fm); CARS.push(FERRY); placeBoat(FERRY, 0, 0);
    /* stops on the far shore */
    var stops = [{ n: isNY ? "Kips Bay" : "South pier", z: 190 }, { n: isNY ? "Midtown East" : "Midtown pier", z: -270 }, { n: isNY ? "Turtle Bay" : "North pier", z: -1000 }, { n: isNY ? "Sutton Place" : "Far north pier", z: -1650 }];
    TRANSIT.stops = [{ n: isNY ? "Queens Ferry Terminal" : "Ferry Terminal", berth: [-281, 35.4], land: [-247.5, 45], yaw: Math.PI }];
    stops.forEach(function (s) {
      var sh = shoreAt(s.z); if (sh === null || sh > -300) return;
      var berth = [sh + 30, s.z]; if (!ferryPath(TRANSIT.stops[0].berth, berth)) return;
      var d = new THREE.Group(), dx1 = sh - 4, dx2 = sh + 15;
      gbox(d, dx2 - dx1, 0.4, 7, wood, (dx1 + dx2) / 2, 0.2, s.z); gbox(d, 6, 0.2, 5, blue, sh + 10, 3.1, s.z);
      [sh + 7.2, sh + 12.8].forEach(function (cx3) { gbox(d, 0.18, 2.9, 0.18, steel, cx3, 1.7, s.z - 2.2); gbox(d, 0.18, 2.9, 0.18, steel, cx3, 1.7, s.z + 2.2); });
      gsign(d, "FERRY · " + s.n.toUpperCase(), 5.4, 0.6, sh + 10, 3.5, s.z + 2.52, 0, { w: 1024, h: 110, bg: "#1f4f8f", fg: "#fff", size: 60 });
      gsign(d, "FERRY · " + s.n.toUpperCase(), 5.4, 0.6, sh + 10, 3.5, s.z - 2.52, Math.PI, { w: 1024, h: 110, bg: "#1f4f8f", fg: "#fff", size: 60 });
      scene.add(d); DECKS.push({ x1: dx1, x2: dx2, z1: s.z - 3.5, z2: s.z + 3.5, y: 0.4 });
      var k = TRANSIT.stops.length; TRANSIT.stops.push({ n: s.n, berth: berth, land: [sh + 6, s.z], yaw: Math.PI });
      ZONES.push({ id: "tr:ferry:" + k, x: sh + 6, z: s.z, r: 2.4 });
      PLACES.push({ id: "ferry" + k, t: "Ferry - " + s.n, d: "Ferry stop", b: "FY", c: "#5ab0ff", x: sh + 6, z: s.z });
    });
  }
  function buildTransit() {
    if (TRANSIT || !BRIDGE || !WATER) return;
    var river = !BRIDGE.land; TRANSIT = { river: river, stops: [] };
    if (river) buildFerry();
    buildRail(river, river ? BRIDGE.xa + 10 : -262);
    if (river) spawnBoats((BRIDGE.xa + BRIDGE.xb) / 2, -250);
    if (typeof drawBig === "function") try { drawBig(); } catch (e) {}
  }
  /* a station or pier exit that ended up inside a building is moved to the nearest open spot */
  function transitResolve() {
    if (!TRANSIT || !CITY || CITY.pending()) return;
    ZONES.forEach(function (z) { if (z.id.indexOf("tr:") !== 0 || z.ok) return; if (Math.hypot(z.x - P.x, z.z - P.z) > 300) return; if (freeAt(z.x, z.z) || deckAt(z.x, z.z)) { z.ok = true; return; } var f = freeSpot(z.x, z.z); if (f) { z.x = f.x; z.z = f.z; } z.ok = true; });
  }

  /* ---------- rides ---------- */
  function rideInfo(z) {
    var p = z.id.split(":");
    if (p[1] === "rail") { var s = TRANSIT.rail.st[+p[2]]; return { t: s.name.replace("·", "-") + " station", d: "Airport rail · 3 TOKEN a ride", b: "Take the train" }; }
    if (p[1] === "ferry") { var f = TRANSIT.stops[+p[2]]; return { t: "Ferry · " + f.n, d: TRANSIT.stops.length > 1 ? "River ferry · 4 TOKEN a ride" : "No ferry routes on this river", b: "Take the ferry", off: TRANSIT.stops.length < 2 }; }
    if (p[1] === "rent") return { t: "Speedboat rental", d: "Drive a fast boat on the river · 25 TOKEN", b: "Rent a speedboat", off: G.balance < 25 };
    return null;
  }
  function rideAct(z) {
    var p = z.id.split(":");
    if (p[1] === "rent") { rentBoat(); return; }
    var rail = p[1] === "rail", from = +p[2], list = rail ? TRANSIT.rail.st : TRANSIT.stops, price = rail ? 3 : 4;
    var html = "<div><div class='eyebrow'>" + (rail ? "Airport rail" : "River ferry") + "</div><h2>Where to?</h2></div><div class='row' style='flex-direction:column;gap:8px'>";
    list.forEach(function (s, i) { if (i !== from) html += "<button class='btn' type='button' data-go='" + i + "'>" + (rail ? s.name.replace("·", "-") : s.n) + "</button>"; });
    html += "<button class='btn ghost' id='mClose' type='button'>Not now</button></div><p class='note'>" + price + " TOKEN a ride. You have " + tok(G.balance) + ".</p>";
    modal(html);
    Array.prototype.forEach.call($("sheet").querySelectorAll("[data-go]"), function (b) { b.addEventListener("click", function () {
      if (G.balance < price) { toast("Not enough TOKEN"); return; }
      closeModal(); spend(price, rail ? "Train ticket" : "Ferry ticket"); startRide(rail ? "train" : "ferry", from, +b.getAttribute("data-go"));
    }); });
  }
  function startRide(kind, from, to) {
    fadeTo(function () {
      if (kind === "train") {
        var S = TRANSIT.rail.st, tr = TRANSIT.rail.trains[0];
        tr.x = S[from].x; tr.v = 0; tr.at = from; tr.dir = S[to].x > S[from].x ? 1 : -1; tr.next = to; tr.dwell = 1.2; tr.m.position.set(tr.x, RAIL_Y + 0.05, tr.z);
        RIDE = { kind: "train", tr: tr, to: to, name: S[to].name };
        player.g.visible = false;
      } else {
        var A = TRANSIT.stops[from], B = TRANSIT.stops[to], path = ferryPath(A.berth, B.berth) || [A.berth, B.berth];
        FERRY.x = A.berth[0]; FERRY.z = A.berth[1]; FERRY.yaw = Math.atan2(-(path[1][1] - path[0][1]), path[1][0] - path[0][0]); FERRY.v = 0;
        var cum = [0]; for (var i = 1; i < path.length; i++) cum.push(cum[i - 1] + Math.hypot(path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1]));
        RIDE = { kind: "ferry", path: path, cum: cum, len: cum[cum.length - 1], s: 0, v: 0, to: to, name: B.n };
      }
      P.swim = false; $("cine").hidden = false; $("rideSkip").hidden = false;
      $("cine").textContent = (kind === "train" ? "Airport rail · to " + RIDE.name.replace("·", "-") : "River ferry · to " + RIDE.name);
      missionEvent(kind === "train" ? "trainRide" : "ferryRide");
    });
  }
  function rideArrive() {
    if (!RIDE || RIDE.done) return; RIDE.done = true; var r = RIDE;
    fadeTo(function () {
      var x, z;
      if (r.kind === "train") { var s = TRANSIT.rail.st[r.to]; x = s.zone.x; z = s.zone.z; }
      else { var f = TRANSIT.stops[r.to]; x = f.land[0]; z = f.land[1]; FERRY.x = TRANSIT.stops[0].berth[0]; FERRY.z = TRANSIT.stops[0].berth[1]; FERRY.yaw = Math.PI; placeBoat(FERRY, 0, 0); }
      RIDE = null; camOverride = null; player.g.visible = true; $("cine").hidden = true; $("rideSkip").hidden = true;
      place(x, z, 0, Math.PI); cam.tdist = 6.2; cam.pitch = 0.32; P.swim = false;
      toast(r.kind === "train" ? "Arrived at " + r.name.replace("·", "-") : "Arrived at " + r.name);
    });
  }
  function rideTick(dt, t) {
    if (!RIDE || RIDE.done) return;
    if (RIDE.kind === "train") {
      var tr = RIDE.tr; P.x = tr.x; P.z = tr.z; P.yaw = tr.dir > 0 ? Math.PI / 2 : -Math.PI / 2;
      camOverride = { pos: new THREE.Vector3(tr.x - tr.dir * 26, RAIL_Y + 7, tr.z + 17), look: new THREE.Vector3(tr.x + tr.dir * 6, RAIL_Y + 2, tr.z) };
    } else {
      var R = RIDE, rem = R.len - R.s, A = 0.9; R.v = rem < R.v * R.v / (2 * A) + 1 ? Math.max(1, Math.sqrt(2 * A * rem)) : Math.min(13, R.v + A * dt); R.s = Math.min(R.len, R.s + R.v * dt);
      var i = 1; while (i < R.cum.length - 1 && R.cum[i] < R.s) i++;
      var a = R.path[i - 1], b = R.path[i], k = (R.s - R.cum[i - 1]) / Math.max(0.01, R.cum[i] - R.cum[i - 1]);
      FERRY.x = lerp(a[0], b[0], k); FERRY.z = lerp(a[1], b[1], k);
      var want = Math.atan2(-(b[1] - a[1]), b[0] - a[0]); FERRY.yaw += clamp(wrapA(want - FERRY.yaw), -0.5 * dt, 0.5 * dt);
      placeBoat(FERRY, t, R.v);
      var fx = Math.cos(FERRY.yaw), fz = -Math.sin(FERRY.yaw);
      P.x = FERRY.x + fx * 9.5; P.z = FERRY.z + fz * 9.5; P.yaw = Math.atan2(fx, fz); R.py = FERRY.m.position.y + FERRY.m.userData.deckY + 0.02;
      camOverride = { pos: new THREE.Vector3(FERRY.x - fx * 34 + fz * 12, 13, FERRY.z - fz * 34 - fx * 12), look: new THREE.Vector3(FERRY.x + fx * 4, 3, FERRY.z + fz * 4) };
      if (R.s >= R.len - 0.05) rideArrive();
    }
  }
  function skipRide() {
    if (!RIDE || RIDE.done) return;
    if (RIDE.kind === "train") { var tr = RIDE.tr; tr.x = TRANSIT.rail.st[RIDE.to].x; tr.dwell = 0; tr.next = RIDE.to; } else RIDE.s = RIDE.len;
    rideArrive();
  }
  function rentBoat() {
    if (spend(25, "Speedboat rental") < 25 && G.balance >= 0) { }
    var mo = BOATS.filter(function (b) { return b.moored; })[0];
    if (taxi.m && !taxi.m.userData.boat) CARS.push({ m: taxi.m, x: taxi.x, z: taxi.z, yaw: taxi.yaw, parked: true });
    else if (taxi.m && taxi.m.userData.boat) scene.remove(taxi.m);
    var sb;
    if (mo) { sb = mo.m; BOATS.splice(BOATS.indexOf(mo), 1); CARS.splice(CARS.indexOf(mo), 1); taxi.x = mo.x; taxi.z = mo.z; taxi.yaw = mo.yaw; }
    else { sb = speedboat(0xc0392b); scene.add(sb); taxi.x = -264; taxi.z = 52.2; taxi.yaw = Math.PI; }
    taxi.m = sb; taxi.v = 0; enterTaxi(); cam.tdist = 9; toast("Speedboat rented · have fun on the river"); missionEvent("boatRent");
  }
  function transitTick(dt, t) {
    if (!TRANSIT) return;
    if (TRANSIT.rail) TRANSIT.rail.trains.forEach(function (tr) { trainTick(tr, dt); });
    BOATS.forEach(function (b) { if (b.moored) placeBoat(b, t, 0); else boatTick(b, dt, t); });
    if (FERRY && !(RIDE && RIDE.kind === "ferry")) placeBoat(FERRY, t, 0);
    rideTick(dt, t);
  }
  function drawTransit(ctx) {
    if (!TRANSIT) return; ctx.save();
    if (TRANSIT.rail) { var r = TRANSIT.rail; ctx.fillStyle = "#59616a"; ctx.fillRect((r.x1 - MX1) * MS, (RAIL_Z - 3.2 - MZ1) * MS, (r.x2 - r.x1) * MS, 6.4 * MS); ctx.strokeStyle = "#e9ecee"; ctx.lineWidth = Math.max(1, 0.8 * MS); ctx.setLineDash([3 * MS, 2 * MS]); [TRK[0], TRK[1]].forEach(function (tz) { ctx.beginPath(); ctx.moveTo((r.x1 - MX1) * MS, (tz - MZ1) * MS); ctx.lineTo((r.x2 - MX1) * MS, (tz - MZ1) * MS); ctx.stroke(); }); ctx.setLineDash([]); ctx.fillStyle = "#5fe08a"; r.st.forEach(function (s) { ctx.fillRect((s.x - 22 - MX1) * MS, (8.5 - MZ1) * MS, 44 * MS, 10 * MS); }); }
    ctx.fillStyle = "#8a6a4a"; DECKS.forEach(function (d) { ctx.fillRect((d.x1 - MX1) * MS, (d.z1 - MZ1) * MS, (d.x2 - d.x1) * MS, (d.z2 - d.z1) * MS); });
    ctx.restore();
  }
  function routeGraph(car) {
    var key = Object.keys(CITY.tiles).sort().join("|") + (car ? "c" : "w") + (BRIDGE ? "b" : "");
    if (RG && RG.key === key) return RG;
    var V = {}, list = [];
    function vid(x, z) { var k = Math.round(x * 2) + "," + Math.round(z * 2), v = V[k]; if (!v) { v = V[k] = { x: x, z: z, e: [], i: list.length }; list.push(v); } return v; }
    Object.keys(CITY.tiles).forEach(function (k) { CITY.tiles[k].roads.forEach(function (r) {
      var p0 = CITY.pointAt(r, 0), ox = p0.x - r.p[0], oz = p0.z - r.p[1], prev = null;
      for (var i = 0; i < r.p.length; i += 2) {
        var v = vid(r.p[i] + ox, r.p[i + 1] + oz);
        if (prev && prev !== v) { var d = Math.hypot(v.x - prev.x, v.z - prev.z); prev.e.push([v, d, r.n]); if (!(car && r.o)) v.e.push([prev, d, r.n]); }
        prev = v;
      }
    }); });
    /* the bridge and the expressway join the city to Queens and the airport */
    if (BRIDGE && list.length) {
      var c0 = BRIDGE.pts[0], cand = list.map(function (v) { return [Math.hypot(v.x - c0[0], v.z - c0[1]), v]; }).filter(function (q) { return q[0] < 90; }).sort(function (a, b) { return a[0] - b[0]; }).slice(0, 8);
      var head = vid(c0[0], c0[1]); cand.forEach(function (q) { if (q[1] !== head) { q[1].e.push([head, q[0]]); head.e.push([q[1], q[0]]); } });
      var chain = [head]; (BRIDGE.land ? [[c0[0], c0[1]], [-250, 0]] : [[c0[0], c0[1]], [BRIDGE.xa, 0], [BRIDGE.xb, 0]]).concat([[-200, 2.5], [-120, 2.5], [-40, 2.5], [40, 2.5], [AX1 - 12, 2.5]]).forEach(function (p) { chain.push(vid(p[0], p[1])); });
      for (var c2 = 1; c2 < chain.length; c2++) { var A = chain[c2 - 1], B = chain[c2]; if (A === B) continue; var dd = Math.hypot(A.x - B.x, A.z - B.z); A.e.push([B, dd]); B.e.push([A, dd]); }
    }
    RG = { key: key, list: list }; return RG;
  }
  function findRoute(fx, fz, tx, tz, car) {
    var g = routeGraph(car), L = g.list; if (!L.length) return null;
    var S = null, sd = 1e9, Tg = null, td = 1e9;
    for (var i = 0; i < L.length; i++) { var v = L[i], a = Math.hypot(v.x - fx, v.z - fz), b = Math.hypot(v.x - tx, v.z - tz); if (a < sd) { sd = a; S = v; } if (b < td) { td = b; Tg = v; } }
    if (!S || sd > 150) return null;
    var gS = {}, prev = {}, pn = {}, h = [], closed = {}, best = S, bestH = 1e18, guard = 0;
    gS[S.i] = 0; heapPush(h, [Math.hypot(S.x - Tg.x, S.z - Tg.z), S.i, S]);
    while (h.length && guard++ < 80000) {
      var it = heapPop(h), u = it[2]; if (closed[u.i]) continue; closed[u.i] = 1;
      var hu = Math.hypot(u.x - Tg.x, u.z - Tg.z); if (hu < bestH) { bestH = hu; best = u; }
      if (u === Tg) break;
      for (var k = 0; k < u.e.length; k++) { var w = u.e[k][0], ng = gS[u.i] + u.e[k][1]; if (gS[w.i] === undefined || ng < gS[w.i]) { gS[w.i] = ng; prev[w.i] = u; pn[w.i] = u.e[k][2]; heapPush(h, [ng + Math.hypot(w.x - Tg.x, w.z - Tg.z), w.i, w]); } }
    }
    var pts = [], n = best, guard2 = 0; while (n && guard2++ < 20000) { pts.push([n.x, n.z, pn[n.i]]); n = prev[n.i]; }
    pts.reverse(); pts.push([tx, tz]);
    return pts;
  }
  function routeTick(tm) {
    if (!G.wp || !CITY || INSIDE || (!CITY.inBounds(P.x, P.z) && !(BRIDGE && P.x < AX1 && Math.abs(P.z) < 40))) { ROUTE = null; return; }
    var px = P.mode === "car" ? taxi.x : P.x, pz = P.mode === "car" ? taxi.z : P.z;
    if (tm - routeT > 1600 || !ROUTE) { routeT = tm; try { ROUTE = findRoute(px, pz, G.wp.x, G.wp.z, P.mode === "car"); } catch (e) { ROUTE = null; } }
    if (!ROUTE || ROUTE.length < 2) { routeLen = 0; routeTurn = null; return; }
    /* trim the part already driven, measure what is left, and find the next turn */
    var bi = 0, bd = 1e9; for (var i = 0; i < Math.min(ROUTE.length, 40); i++) { var d = Math.hypot(ROUTE[i][0] - px, ROUTE[i][1] - pz); if (d < bd) { bd = d; bi = i; } }
    if (bi > 0) ROUTE = ROUTE.slice(bi);
    var L = Math.hypot(ROUTE[0][0] - px, ROUTE[0][1] - pz), turn = null, acc = L;
    for (var j = 1; j < ROUTE.length; j++) {
      var a = ROUTE[j - 1], b = ROUTE[j], sl = Math.hypot(b[0] - a[0], b[1] - a[1]); L += sl;
      if (!turn && j < ROUTE.length - 1 && acc > 4) { var c = ROUTE[j + 1], h1 = Math.atan2(b[0] - a[0], b[1] - a[1]), h2 = Math.atan2(c[0] - b[0], c[1] - b[1]), dh = ((h2 - h1 + Math.PI * 3) % (Math.PI * 2)) - Math.PI; if (Math.abs(dh) > 0.6 && sl > 0.5) { var nn = null; for (var q = j + 1; q < Math.min(ROUTE.length, j + 6) && !nn; q++) nn = ROUTE[q][2]; turn = { d: acc + sl, dir: dh, n: nn && nn !== b[2] ? nn : nn }; } }
      acc += sl;
    }
    routeLen = L; routeTurn = turn;
  }
  function drawRoute(ctx, toS, w) {
    if (!ROUTE || ROUTE.length < 2) return;
    ctx.save(); ctx.lineJoin = "round"; ctx.lineCap = "round";
    [[w * 2.2, "rgba(10,6,20,0.65)"], [w, "#b56bff"]].forEach(function (st) { ctx.beginPath(); ROUTE.forEach(function (p, i) { var q = toS(p[0], p[1]); if (i) ctx.lineTo(q.x, q.y); else ctx.moveTo(q.x, q.y); }); ctx.lineWidth = st[0]; ctx.strokeStyle = st[1]; ctx.stroke(); });
    ctx.restore();
  }
  function rrPath(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function clampRect(s, cx, cy, hw, hh) { var dx = s.x - cx, dy = s.y - cy, k = Math.max(Math.abs(dx) / hw, Math.abs(dy) / hh); if (k > 1) { s.x = cx + dx / k; s.y = cy + dy / k; } return k > 1; }
  function drawMini() {
    var W = mini.width, H = mini.height, cx = W / 2, cy = H / 2, u = H / 264, sc = 2.2 * u * (P.mode === "car" ? clamp(1.25 - Math.abs(taxi.v) / 40, 0.7, 1.1) : 1) * (FLY ? 0.35 : 1), rot = cam.yaw;
    mctx.setTransform(1, 0, 0, 1, 0, 0); mctx.clearRect(0, 0, W, H);
    mctx.save(); mctx.beginPath(); mctx.arc(W / 2, H / 2, W / 2 - 1, 0, 7); mctx.clip();
    mctx.fillStyle = MSTY.land; mctx.fillRect(0, 0, W, H);
    mctx.translate(cx, cy); mctx.rotate(rot); mctx.scale(sc, sc); mctx.translate(-P.x, -P.z);
    var R = Math.hypot(W, H) / sc * 0.75;
    drawVec(mctx, P.x - R, P.z - R, P.x + R, P.z + R, sc);
    mctx.save(); mctx.translate(MX1, MZ1); mctx.scale(1 / MS, 1 / MS); mctx.drawImage(mapBase, 0, 0); mctx.restore();
    drawQueens(mctx, sc); drawExpressExt(mctx, sc);
    mctx.save(); mctx.translate(MX1, MZ1); mctx.scale(1 / MS, 1 / MS); drawBridge(mctx); drawTransit(mctx); mctx.restore();
    mctx.setTransform(1, 0, 0, 1, 0, 0);
    function toS(x, z) { var dx = (x - P.x) * sc, dz = (z - P.z) * sc, cr = Math.cos(rot), sr = Math.sin(rot); return { x: cx + dx * cr - dz * sr, y: cy + dx * sr + dz * cr }; }
    drawRouteNice(mctx, toS, 5 * u, false);
    var lim = W / 2 - 14 * u, mc = { x: W / 2, y: H / 2 };
    function clampC(s) { var dd = Math.hypot(s.x - mc.x, s.y - mc.y); if (dd > lim) { s.x = mc.x + (s.x - mc.x) / dd * lim; s.y = mc.y + (s.y - mc.y) / dd * lim; } }
    PLACES.forEach(function (p) { var s = toS(p.x, p.z); if (Math.hypot(s.x - mc.x, s.y - mc.y) < lim) badge(mctx, s.x, s.y, p, 11 * u); });
    if (WANTED > 0 && heatZone) { var hs2 = toS(heatZone.x, heatZone.z); mctx.beginPath(); mctx.arc(hs2.x, hs2.y, heatZone.r * sc, 0, 7); var fl = Math.floor(performance.now() / 400) % 2; mctx.fillStyle = fl ? "rgba(255,60,60,0.18)" : "rgba(60,120,255,0.18)"; mctx.fill(); mctx.lineWidth = 2; mctx.strokeStyle = fl ? "rgba(255,80,80,0.8)" : "rgba(80,140,255,0.8)"; mctx.stroke(); }
    if (G.wp) { var s = toS(G.wp.x, G.wp.z); clampC(s); flagPin(mctx, s.x, s.y, 12 * u); }
    var hv = headingVec(), hs = toS(P.x + hv.x, P.z + hv.z);
    arrow(mctx, cx, cy, Math.atan2(hs.x - cx, -(hs.y - cy)), 13 * u);
    mctx.restore();
    var nS = toS(P.x, P.z - 1000); clampC(nS);
    mctx.beginPath(); mctx.arc(nS.x, nS.y, 12 * u, 0, 7); mctx.fillStyle = "#120a24"; mctx.fill(); mctx.lineWidth = 2; mctx.strokeStyle = "#ff3d8b"; mctx.stroke();
    mctx.fillStyle = "#fff"; mctx.font = "800 " + Math.round(12 * u) + "px Unbounded, sans-serif"; mctx.textAlign = "center"; mctx.textBaseline = "middle"; mctx.fillText("N", nS.x, nS.y + 0.5);
  }
  /* the Queens streets/houses and the expressway west end, in world coordinates */
  function drawQueens(ctx, ppm) {
    var px = 1 / ppm; ctx.lineCap = "round";
    ctx.strokeStyle = MSTY.casing; ctx.lineWidth = 6 + 2.2 * px; QSTREETS.forEach(function (q) { ctx.beginPath(); ctx.moveTo(q[0], q[1]); ctx.lineTo(q[2], q[3]); ctx.stroke(); });
    ctx.strokeStyle = MSTY.road[4][0]; ctx.lineWidth = Math.max(6, 1.7 * px); QSTREETS.forEach(function (q) { ctx.beginPath(); ctx.moveTo(q[0], q[1]); ctx.lineTo(q[2], q[3]); ctx.stroke(); });
    ctx.fillStyle = "#3d2a55"; QUEENS.forEach(function (q) { ctx.fillRect(q[0], q[2], q[1] - q[0], q[3] - q[2]); });
    if (ppm > 1.2) { ctx.strokeStyle = "rgba(255,255,255,0.08)"; ctx.lineWidth = px; QUEENS.forEach(function (q) { ctx.strokeRect(q[0], q[2], q[1] - q[0], q[3] - q[2]); }); }
  }
  function drawExpressExt(ctx, ppm) { ctx.fillStyle = MSTY.casing; ctx.fillRect(-262, -7.7, 72, 15.4); ctx.fillStyle = "#ff9a3c"; ctx.fillRect(-262, -6.8, 72, 13.6); }
  /* Full-screen map */
  var big = $("bigmap"), bctx = big.getContext("2d"), MV = { x: 0, z: 0, s: 3 }, sel = null;
  function fitBig() { var r = big.getBoundingClientRect(), d = Math.min(2, window.devicePixelRatio || 1); big.width = Math.round(r.width * d); big.height = Math.round(r.height * d); }
  function b2w(px, py) { var d = big.width / big.getBoundingClientRect().width; return { x: MV.x + (px * d - big.width / 2) / (MV.s * d), z: MV.z + (py * d - big.height / 2) / (MV.s * d) }; }
  var bigCache = document.createElement("canvas"), bigKey = "";
  function drawBig() {
    var W = big.width, H = big.height, d = W / Math.max(1, big.getBoundingClientRect().width), s = MV.s * d;
    function toS(x, z) { return { x: W / 2 + (x - MV.x) * s, y: H / 2 + (z - MV.z) * s }; }
    var key = [W, H, MV.x.toFixed(2), MV.z.toFixed(2), s.toFixed(3), MV2.ver, BRIDGE ? 1 : 0, TRANSIT ? 1 : 0, DISTRICTS.length].join("|");
    if (key !== bigKey) {
      bigKey = key; bigCache.width = W; bigCache.height = H; var c = bigCache.getContext("2d");
      c.fillStyle = MSTY.land; c.fillRect(0, 0, W, H);
      c.save(); c.translate(W / 2, H / 2); c.scale(s, s); c.translate(-MV.x, -MV.z);
      var hw = W / 2 / s + 20, hh = H / 2 / s + 20;
      drawVec(c, MV.x - hw, MV.z - hh, MV.x + hw, MV.z + hh, s);
      c.save(); c.translate(MX1, MZ1); c.scale(1 / MS, 1 / MS); c.imageSmoothingEnabled = true; c.drawImage(mapBase, 0, 0); c.restore();
      drawQueens(c, s); drawExpressExt(c, s);
      c.save(); c.translate(MX1, MZ1); c.scale(1 / MS, 1 / MS); drawBridge(c); drawTransit(c); c.restore();
      c.restore();
      labelsOnBig(c, toS, s / d, d, W, H);
    }
    bctx.setTransform(1, 0, 0, 1, 0, 0); bctx.drawImage(bigCache, 0, 0);
    drawRouteNice(bctx, toS, Math.max(4, Math.min(10, 1.9 * s)), true);
    if (WANTED > 0 && heatZone) { var hq = toS(heatZone.x, heatZone.z); bctx.beginPath(); bctx.arc(hq.x, hq.y, heatZone.r * s, 0, 7); bctx.fillStyle = "rgba(255,70,70,0.16)"; bctx.fill(); bctx.lineWidth = 2 * d; bctx.strokeStyle = "rgba(255,90,90,0.8)"; bctx.stroke(); }
    bctx.textBaseline = "middle";
    PLACES.forEach(function (p) {
      var q = toS(p.x, p.z), r = 13 * d; if (q.x < -30 || q.y < -30 || q.x > W + 30 || q.y > H + 30) return;
      if (sel === p) { bctx.beginPath(); bctx.arc(q.x, q.y, r + 6 * d, 0, 7); bctx.fillStyle = "rgba(255,61,139,0.25)"; bctx.fill(); }
      badge(bctx, q.x, q.y, p, r);
      if (MV.s > 2.2 || sel === p) {
        bctx.font = "700 " + Math.round(12 * d) + "px Manrope, sans-serif"; bctx.textAlign = "left";
        var tw = bctx.measureText(p.t).width, lx = q.x + r + 5 * d, ly = q.y;
        if (p.lp === "u") { lx = q.x - (tw + 14 * d) / 2; ly = q.y - r - 14 * d; } else if (p.lp === "d") { lx = q.x - (tw + 14 * d) / 2; ly = q.y + r + 14 * d; }
        bctx.fillStyle = "rgba(7,9,7,0.86)"; roundRect(bctx, lx, ly - 11 * d, tw + 14 * d, 22 * d, 11 * d); bctx.fill();
        bctx.fillStyle = p.c; bctx.fillRect(lx + 4 * d, ly - 5 * d, 2 * d, 10 * d);
        bctx.fillStyle = "#f1f4ee"; bctx.fillText(p.t, lx + 9 * d, ly + 0.5);
      }
    });
    if (G.wp) { var w = toS(G.wp.x, G.wp.z); flagPin(bctx, w.x, w.y, 17 * d); }
    var hv = headingVec(), me = toS(P.x, P.z);
    bctx.beginPath(); bctx.arc(me.x, me.y, 22 * d, 0, 7); bctx.fillStyle = "rgba(255,61,139,0.16)"; bctx.fill();
    arrow(bctx, me.x, me.y, Math.atan2(hv.x, -hv.z), 14 * d);
    var meters = MV.s > 3 ? 50 : MV.s > 1 ? 100 : MV.s > 0.4 ? 250 : 500, bar = meters * s, bx = W - 16 * d - bar, by = H - 18 * d;
    bctx.fillStyle = "rgba(7,9,7,0.8)"; roundRect(bctx, bx - 12 * d, by - 24 * d, bar + 24 * d, 36 * d, 10 * d); bctx.fill();
    bctx.fillStyle = "#ff3d8b"; bctx.fillRect(bx, by, bar, 3 * d); bctx.fillRect(bx, by - 4 * d, 2 * d, 7 * d); bctx.fillRect(bx + bar - 2 * d, by - 4 * d, 2 * d, 7 * d);
    bctx.fillStyle = "rgba(241,244,238,0.9)"; bctx.font = "600 " + Math.round(11 * d) + "px JetBrains Mono, monospace"; bctx.textAlign = "center";
    bctx.fillText(meters + " m   ·   N ↑", bx + bar / 2, by - 11 * d);
  }
  function roundRect(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  /* ---------- world map ---------- */
  var mapMode = "city", WORLD = null, WPATH = null, WV = { lon: 0, lat: 20, s: 3 }, wsel = null;
  fetch("assets/world.json").then(function (r) { return r.json(); }).then(function (d) {
    WORLD = d; WPATH = new Path2D();
    d.forEach(function (c) { c.r.forEach(function (ring) {
      var mn = 999, mx = -999; for (var j = 0; j < ring.length; j += 2) { mn = Math.min(mn, ring[j]); mx = Math.max(mx, ring[j]); }
      [0, mx > 180 ? -360 : null, mn < -180 ? 360 : null].forEach(function (o) { if (o === null) return; WPATH.moveTo(ring[0] + o, -ring[1]); for (var i = 2; i < ring.length; i += 2) WPATH.lineTo(ring[i] + o, -ring[i + 1]); WPATH.closePath(); });
    }); });
    if (!$("mapov").hidden && mapMode === "world") drawBig();
  }).catch(function () {});
  function gcPoint(A, B, k) {
    var p1 = A.lat * D2R, l1 = A.lon * D2R, p2 = B.lat * D2R, l2 = B.lon * D2R;
    var x1 = Math.cos(p1) * Math.cos(l1), y1 = Math.cos(p1) * Math.sin(l1), z1 = Math.sin(p1), x2 = Math.cos(p2) * Math.cos(l2), y2 = Math.cos(p2) * Math.sin(l2), z2 = Math.sin(p2);
    var d = Math.acos(clamp(x1 * x2 + y1 * y2 + z1 * z2, -1, 1)); if (d < 1e-6) return { lat: A.lat, lon: A.lon };
    var a = Math.sin((1 - k) * d) / Math.sin(d), b = Math.sin(k * d) / Math.sin(d), x = a * x1 + b * x2, y = a * y1 + b * y2, z = a * z1 + b * z2;
    return { lat: Math.atan2(z, Math.hypot(x, y)) / D2R, lon: Math.atan2(y, x) / D2R };
  }
  function w2s(lon, lat, W, H, d) { return { x: W / 2 + (lon - WV.lon) * WV.s * d, y: H / 2 - (lat - WV.lat) * WV.s * d }; }
  function drawWorld() {
    var W = big.width, H = big.height, d = W / Math.max(1, big.getBoundingClientRect().width), s = WV.s * d, t = now();
    bctx.setTransform(1, 0, 0, 1, 0, 0); bctx.fillStyle = "#071016"; bctx.fillRect(0, 0, W, H);
    bctx.strokeStyle = "rgba(255,61,139,0.06)"; bctx.lineWidth = 1;
    for (var gl = -180; gl <= 180; gl += 30) { var a1 = w2s(gl, 85, W, H, d), a2 = w2s(gl, -85, W, H, d); bctx.beginPath(); bctx.moveTo(a1.x, a1.y); bctx.lineTo(a2.x, a2.y); bctx.stroke(); }
    for (var gt = -60; gt <= 60; gt += 30) { var b1 = w2s(-180, gt, W, H, d), b2 = w2s(180, gt, W, H, d); bctx.beginPath(); bctx.moveTo(b1.x, b1.y); bctx.lineTo(b2.x, b2.y); bctx.stroke(); }
    if (WPATH) {
      bctx.save(); bctx.setTransform(s, 0, 0, s, W / 2 - WV.lon * s, H / 2 + WV.lat * s);
      bctx.fillStyle = "#16261a"; bctx.fill(WPATH); bctx.lineWidth = 0.9 / s; bctx.strokeStyle = "rgba(255,61,139,0.35)"; bctx.stroke(WPATH);
      bctx.restore();
    } else { bctx.fillStyle = "#9aa392"; bctx.font = "600 " + Math.round(13 * d) + "px Manrope, sans-serif"; bctx.textAlign = "center"; bctx.fillText("Loading the world map\u2026", W / 2, H / 2); }
    var tr = G.trip;
    if (tr && AIR[tr.from] && AIR[tr.to]) {
      var A = AIR[tr.from], B = AIR[tr.to]; bctx.setLineDash([6 * d, 6 * d]); bctx.strokeStyle = "#ff3d8b"; bctx.lineWidth = 2 * d; bctx.beginPath();
      for (var i = 0; i <= 64; i++) { var q = gcPoint(A, B, i / 64), sp = w2s(q.lon, q.lat, W, H, d); if (i) bctx.lineTo(sp.x, sp.y); else bctx.moveTo(sp.x, sp.y); }
      bctx.stroke(); bctx.setLineDash([]);
      var pk = clamp((t - tr.dep) / tr.dur, 0, 1), pos = gcPoint(A, B, pk), nx = gcPoint(A, B, Math.min(1, pk + 0.01)), ps = w2s(pos.lon, pos.lat, W, H, d), ns = w2s(nx.lon, nx.lat, W, H, d);
      if (t > tr.dep) { bctx.save(); bctx.translate(ps.x, ps.y); bctx.rotate(Math.atan2(ns.y - ps.y, ns.x - ps.x)); bctx.fillStyle = "#ff3d8b"; bctx.beginPath(); bctx.moveTo(12 * d, 0); bctx.lineTo(-8 * d, -9 * d); bctx.lineTo(-4 * d, 0); bctx.lineTo(-8 * d, 9 * d); bctx.closePath(); bctx.fill(); bctx.restore(); }
    }
    bctx.textBaseline = "middle";
    AP.forEach(function (a) {
      var q = w2s(a.lon, a.lat, W, H, d), me = a.code === G.city, on = wsel === a;
      if (me) { bctx.beginPath(); bctx.arc(q.x, q.y, (12 + 4 * Math.sin(performance.now() / 300)) * d, 0, 7); bctx.fillStyle = "rgba(255,61,139,0.25)"; bctx.fill(); }
      bctx.beginPath(); bctx.arc(q.x, q.y, (me || on ? 6 : 4) * d, 0, 7); bctx.fillStyle = me ? "#ff3d8b" : on ? "#ffffff" : "#e9ece6"; bctx.fill(); bctx.lineWidth = 2 * d; bctx.strokeStyle = "#071016"; bctx.stroke();
      if (WV.s > 2.6 || me || on) {
        bctx.font = "700 " + Math.round(11 * d) + "px Manrope, sans-serif"; bctx.textAlign = "left";
        var lab = a.city + (WV.s > 5 ? " \u00b7 " + a.code : ""), tw = bctx.measureText(lab).width;
        bctx.fillStyle = "rgba(7,16,22,0.8)"; bctx.fillRect(q.x + 8 * d, q.y - 9 * d, tw + 10 * d, 18 * d);
        bctx.fillStyle = me ? "#ff3d8b" : "#f1f4ee"; bctx.fillText(lab, q.x + 13 * d, q.y + 0.5);
      }
    });
  }
  function worldCard(a) {
    var c = $("wcard"); if (!a) { c.hidden = true; return; }
    var h0 = here(), same = a.code === h0.code, km = Math.round(distKm(h0, a)), intl = a.country !== h0.country;
    c.innerHTML = "<b>" + a.city + " \u00b7 " + a.code + "</b><span>" + a.country + " \u00b7 " + a.name + "</span><span>Local time " + fmtT(now(), a.tz) + (same ? " \u00b7 You are here" : " \u00b7 " + km.toLocaleString("en-US") + " km \u00b7 about " + dur(flightMs(h0, a)) + " flight" + (intl ? " \u00b7 visa needed" : "")) + "</span>" +
      (same ? "" : "<div class='row2'><button class='btn' type='button' id='wcGo'>Book at Global Travel</button><button class='btn ghost' type='button' id='wcX'>Close</button></div>");
    c.hidden = false;
    if (!same) { $("wcGo").addEventListener("click", function () { closeMap(); setWaypoint(cityPlaces.agency ? cityPlaces.agency.x : 56, cityPlaces.agency ? cityPlaces.agency.z : -10.2, "Global Travel"); G.pick = a.code; save(); toast("Go to Global Travel to book " + a.city); }); $("wcX").addEventListener("click", function () { wsel = null; worldCard(null); drawBig(); }); }
  }
  function setMapMode(m) {
    mapMode = m; $("tCity").setAttribute("aria-pressed", m === "city" ? "true" : "false"); $("tWorld").setAttribute("aria-pressed", m === "world" ? "true" : "false");
    $("mapCity").textContent = m === "city" ? here().city.toUpperCase() + " \u00b7 CITY MAP" : "WORLD MAP";
    $("mapHint").textContent = m === "city" ? "Tap a place or anywhere on the map to set a waypoint" : "Tap an airport to see local time, distance and flight time";
    wsel = null; worldCard(null);
    if (m === "world") { var h0 = here(); WV.lon = h0.lon; WV.lat = h0.lat; WV.s = clamp(big.getBoundingClientRect().width / 140, 2, 6); if (G.trip && G.trip.stage === "inflight") { var A = AIR[G.trip.from], B = AIR[G.trip.to], q = gcPoint(A, B, clamp((now() - G.trip.dep) / G.trip.dur, 0, 1)); WV.lon = q.lon; WV.lat = q.lat; } }
    buildLegend(); drawBig();
  }
  $("tCity").addEventListener("click", function () { setMapMode("city"); });
  $("tWorld").addEventListener("click", function () { setMapMode("world"); });
  var drawCity = drawBig;
  drawBig = function () { if (mapMode === "world") drawWorld(); else drawCity(); };

  function buildLegend() {
    var L = $("legend"); L.innerHTML = "";
    if (mapMode === "world") {
      AP.forEach(function (a) {
        var b = document.createElement("button"); b.type = "button";
        b.innerHTML = "<em style='background:" + (a.code === G.city ? "#ff3d8b" : "#e9ece6") + "'>" + a.code.slice(0, 2) + "</em>" + a.city;
        b.setAttribute("aria-pressed", wsel === a ? "true" : "false");
        b.addEventListener("click", function () { wsel = a; WV.lon = a.lon; WV.lat = a.lat; WV.s = Math.max(WV.s, 4); worldCard(a); buildLegend(); drawBig(); });
        L.appendChild(b);
      });
      return;
    }
    PLACES.forEach(function (p) {
      var b = document.createElement("button"); b.type = "button";
      b.innerHTML = "<em style='background:" + p.c + "'>" + p.b + "</em>" + p.t;
      b.setAttribute("aria-pressed", sel === p ? "true" : "false");
      b.addEventListener("click", function () { sel = p; MV.x = p.x; MV.z = p.z; MV.s = Math.max(MV.s, 3.2); setWaypoint(p.x, p.z, p.t); buildLegend(); drawBig(); });
      L.appendChild(b);
    });
  }
  function openMap(mode) {
    $("mapov").hidden = false; fitBig(); MV.x = P.x; MV.z = P.z; MV.s = clamp(big.getBoundingClientRect().width / 110, 3.4, 5); sel = null;
    setMapMode(mode === "world" ? "world" : "city");
  }
  function closeMap() { $("mapov").hidden = true; worldCard(null); }
  $("bMap").addEventListener("click", function () { openMap("city"); });
  mini.addEventListener("click", function () { openMap("city"); });
  $("mapClose").addEventListener("click", closeMap);
  window.addEventListener("resize", function () { if (!$("mapov").hidden) { fitBig(); drawBig(); } });
  (function () {
    var pts = {}, moved = 0, pinch0 = 0, s0 = 0;
    function zoomBy(f) { if (mapMode === "world") WV.s = clamp(WV.s * f, 1.2, 40); else MV.s = clamp(MV.s * f, 0.22, 9); }
    big.addEventListener("pointerdown", function (e) { big.setPointerCapture(e.pointerId); pts[e.pointerId] = { x: e.clientX, y: e.clientY }; moved = 0; var k = Object.keys(pts); if (k.length === 2) { pinch0 = Math.hypot(pts[k[0]].x - pts[k[1]].x, pts[k[0]].y - pts[k[1]].y); s0 = mapMode === "world" ? WV.s : MV.s; } });
    big.addEventListener("pointermove", function (e) {
      var p = pts[e.pointerId]; if (!p) return;
      var k = Object.keys(pts);
      if (k.length === 1) {
        if (mapMode === "world") { WV.lon -= (e.clientX - p.x) / WV.s; WV.lat += (e.clientY - p.y) / WV.s; }
        else { MV.x -= (e.clientX - p.x) / MV.s; MV.z -= (e.clientY - p.y) / MV.s; }
        moved += Math.abs(e.clientX - p.x) + Math.abs(e.clientY - p.y);
      }
      p.x = e.clientX; p.y = e.clientY;
      if (k.length === 2) { var nd = Math.hypot(pts[k[0]].x - pts[k[1]].x, pts[k[0]].y - pts[k[1]].y), ns = s0 * nd / Math.max(1, pinch0); if (mapMode === "world") WV.s = clamp(ns, 1.2, 40); else MV.s = clamp(ns, 0.22, 9); moved = 99; }
      MV.x = clamp(MV.x, CITY_OX - cityHalf, MX2); MV.z = clamp(MV.z, MZ1, MZ2); WV.lon = clamp(WV.lon, -180, 180); WV.lat = clamp(WV.lat, -70, 80); drawBig();
    });
    function up(e) {
      if (!pts[e.pointerId]) return;
      var single = Object.keys(pts).length === 1; delete pts[e.pointerId];
      if (!single || moved > 8) return;
      var r = big.getBoundingClientRect();
      if (mapMode === "world") {
        var lon = WV.lon + (e.clientX - r.left - r.width / 2) / WV.s, lat = WV.lat - (e.clientY - r.top - r.height / 2) / WV.s, bestA = null, bdA = 16 / WV.s;
        AP.forEach(function (a) { var dd = Math.hypot(a.lon - lon, a.lat - lat); if (dd < bdA) { bdA = dd; bestA = a; } });
        wsel = bestA; worldCard(bestA); buildLegend(); drawBig(); return;
      }
      var w = b2w(e.clientX - r.left, e.clientY - r.top), best = null, bd = 18 / MV.s;
      PLACES.forEach(function (p) { var dd = Math.hypot(p.x - w.x, p.z - w.z); if (dd < bd) { bd = dd; best = p; } });
      if (best) { sel = best; setWaypoint(best.x, best.z, best.t); } else { sel = null; setWaypoint(w.x, w.z, "Map pin"); }
      buildLegend(); drawBig();
    }
    big.addEventListener("pointerup", up); big.addEventListener("pointercancel", function (e) { delete pts[e.pointerId]; });
    big.addEventListener("wheel", function (e) { e.preventDefault(); zoomBy(e.deltaY < 0 ? 1.15 : 0.87); drawBig(); }, { passive: false });
  })();
  window.addEventListener("keydown", function (e) { if (e.key === "m" || e.key === "M") { if ($("mapov").hidden) openMap("city"); else closeMap(); } if (e.key === "Escape" && !$("mapov").hidden) closeMap(); });

  function mapTick(tm) {
    if (CITY && CITY.M && CITY.M.waterTime) CITY.M.waterTime.value = (tm / 1000) % 3600;
    if (CITY) { CITY.update(P.mode === "car" ? taxi.x : P.x, P.mode === "car" ? taxi.z : P.z, 650); updateCity(Math.min(0.05, (tm - (mapTick.lt || tm)) / 1000)); mapTick.lt = tm; }
    if (P.mode !== "car") { taxiZone.x = taxi.x; taxiZone.z = taxi.z; taxiZone.y = taxi.m.userData.air && taxi.alt > 1.2 ? taxi.alt : 0; }
    var ts = tm / 1000; ANIMS.forEach(function (f) { f(ts); });
    var fl = Math.floor(tm / 160) % 4; polRedM.emissiveIntensity = fl < 2 ? 2.4 : 0.1; polBlueM.emissiveIntensity = fl < 2 ? 0.1 : 2.4;
    if (tm - miniT > 50) { miniT = tm; $("radar").style.visibility = INSIDE ? "hidden" : ""; drawMini(); if (!$("mapov").hidden) drawBig(); }
    areaTick(tm); if (!G.wp && !$("nav").hidden) $("nav").hidden = true;
    missionTick(); if (!mapTick.dt || tm - mapTick.dt > 1000) { mapTick.dt = tm; dailyTick(); if (BRIDGE && cityOV && !DISTRICTS.done) { DISTRICTS.done = true; buildDistricts(cityOV); } if (!BRIDGE) buildBridge(); else if (!TRANSIT) buildTransit(); transitResolve(); }
    if (G.wp) {
      wpMesh.userData.ring.scale.setScalar(1 + 0.15 * Math.sin(tm / 260));
      var dist = Math.hypot(G.wp.x - P.x, G.wp.z - P.z);
      wpMesh.children[0].visible = dist > 9;
      routeTick(tm);
      navTick(); var ar = "", far = ROUTE && routeLen ? routeLen : dist;
      if (false) $("wpTxt").textContent = (ROUTE ? ar + " " : "") + G.wp.t + " \u00b7 " + (far >= 1000 ? (far / 1000).toFixed(1) + " km" : Math.round(far) + " m") + (routeTurn && routeTurn.d <= 160 ? " \u00b7 turn " + (routeTurn.dir > 0 ? "left" : "right") + " in " + Math.round(routeTurn.d) + " m" : "");
      if (dist < 3.2 && !G.wp.mission) { clearWaypoint(); toast("You have arrived"); }
    }
  }

  /* ================= Missions ================= */
  var MISSIONS = [
    { id: "welcome", t: "Welcome to the City", from: "City Hall", d: "Get to know " + here().city + ": eat, visit the travel agency, City Hall and the landmark.", reward: 40,
      steps: [{ t: "Eat at Fresh Mart or Sunny Diner", ev: "ate", at: [-64, -13.3] }, { t: "Visit Global Travel", go: [-49, -12.6], r: 2.6 }, { t: "Check in at City Hall", go: [-100, -9.8], r: 3 }, { t: "See the " + CS.lmName, go: [LMX + 26, 0], r: 5 }] },
    { id: "firstShift", t: "First Day at Work", from: "Job Center", d: "Work one full shift. Your own job pays full salary, any other place pays part-time.", reward: 30,
      steps: [{ t: "Work one full shift anywhere", ev: "shift:*", at: null }] },
    { id: "fare", t: "Taxi Fare", from: "City Dispatch", d: "A customer is waiting outside City Hall. Take them to the Tech Hub in time.", reward: 60, limit: 150,
      steps: [{ t: "Get in the taxi", ev: "taxi", at: "taxi" }, { t: "Pick up the customer at City Hall", go: [-100, -3.6], r: 6, car: true, msg: "Customer is in the car" }, { t: "Drop the customer at the Tech Hub", go: [25, 5.4], r: 6, car: true }] },
    { id: "groceries", t: "Grocery Run", from: "Fresh Mart", d: "Pick up two orders at Fresh Mart and deliver them on foot before the timer ends.", reward: 45, limit: 210,
      steps: [{ t: "Pick up the orders at Fresh Mart", go: [-64, -13.3], r: 2.2, msg: "Orders picked up" }, { t: "Deliver to City Hospital", go: [-135, 9.8], r: 2.6, msg: "Delivered" }, { t: "Deliver to Central School", go: [-100, 9.8], r: 2.6 }] },
    { id: "outskirts", t: "Out of Town", from: "City Bus", d: "Take the bus to the outskirts and visit Green Acres Farm.", reward: 25,
      steps: [{ t: "Go to the bus stop on " + CS.street, go: [9, 9.4], r: 2.6 }, { t: "Take the bus to the outskirts", ev: "busOut", at: [9, 9.4] }, { t: "Walk to Green Acres Farm", go: [-16.4, 69], r: 3 }] },
    { id: "gold", t: "Gold Rush", from: "Gold Mine", d: "Collect three gold nuggets around the mine and sell them at City Bank.", reward: 90, limit: 420,
      steps: [{ t: "Go to the Gold Mine", go: [-112, 108.6], r: 3.2 }, { t: "Find gold nugget 1 of 3", go: [-126, 101], r: 2.2, msg: "Gold nugget found" }, { t: "Find gold nugget 2 of 3", go: [-98, 104], r: 2.2, msg: "Gold nugget found" }, { t: "Find gold nugget 3 of 3", go: [-86, 96], r: 2.2, msg: "Gold nugget found" }, { t: "Sell the gold at City Bank", go: [19, -9.8], r: 2.6 }] },
    { id: "speed", t: "Fast Delivery", from: "Oil Field", d: "Spare parts are needed at the oil field. Drive the taxi there before time runs out.", reward: 50, limit: 90,
      steps: [{ t: "Get in the taxi", ev: "taxi", at: "taxi" }, { t: "Drive to the Oil Field gate", go: [ROADX, 70], r: 7, car: true }] },
    { id: "flyer", t: "Frequent Flyer", from: "Global Travel", d: "Book a flight, check in and clear security.", reward: 50,
      steps: [{ t: "Book a flight at Global Travel", ev: "booked", at: [-49, -12.6] }, { t: "Check in at the airport", ev: "checkin", at: [98, -13.8] }, { t: "Clear security", ev: "security", at: [110, 0] }] },
    { id: "hospital", t: "Night Shift", from: "City Hospital", d: "The hospital is short of staff. Work one shift there.", reward: 35, steps: [{ t: "Work a shift at City Hospital", ev: "shift:hospital", at: [-135, 9.8] }] },
    { id: "oilShift", t: "Black Gold", from: "Oil Field", d: "Help keep the pumps running for one shift.", reward: 35, steps: [{ t: "Work a shift at the Oil Field", ev: "shift:oil", at: [6.4, 70] }] },
    { id: "factoryShift", t: "Assembly Line", from: "Factory", d: "Work one shift on the factory line.", reward: 35, steps: [{ t: "Work a shift at the Factory", ev: "shift:factory", at: [30, 110.4] }] },
    { id: "siteShift", t: "Build It", from: "Construction Site", d: "Help the crew for one shift.", reward: 35, steps: [{ t: "Work a shift at the Construction Site", ev: "shift:site", at: [52, 9.9] }] }
  ];
  /* more missions in the real city: steps with pid follow the real place doors */
  [
    { id: "morning", t: "Morning Routine", from: "Your phone", d: "Leave home, grab a coffee and get to the office on time.", reward: 35, limit: 420, steps: [{ t: "Step out of your home", pid: "home", r: 3 }, { t: "Get a coffee at the cafe", pid: "cafe", r: 3 }, { t: "Walk to the office", pid: "work", r: 3 }] },
    { id: "bankErrand", t: "Bank Errand", from: "City Bank", d: "Your new account card is ready. Pick it up inside the bank.", reward: 25, steps: [{ t: "Go to the bank", pid: "bank", r: 3 }, { t: "Go inside the bank", ev: "enter:bank", pid: "bank" }] },
    { id: "checkup", t: "Health Check", from: "City Hospital", d: "Visit the hospital for your yearly check-up.", reward: 25, steps: [{ t: "Go to the hospital", pid: "hospital", r: 3 }, { t: "Go inside", ev: "enter:hospital", pid: "hospital" }] },
    { id: "explorer", t: "City Explorer", from: "Tourism Office", d: "See the most famous places in the city.", reward: 60, steps: [{ t: "Visit the landmark", pid: "landmark", r: 12 }, { t: "Visit City Hall", pid: "cityhall", r: 4 }, { t: "Visit the hotel", pid: "hotel", r: 4 }, { t: "Visit the school", pid: "school", r: 4 }] },
    { id: "courier", t: "Package Courier", from: "Supermarket", d: "Deliver two parcels across the city before time runs out.", reward: 70, limit: 300, steps: [{ t: "Pick up the parcels at the supermarket", pid: "grocery", r: 3, msg: "Parcels picked up" }, { t: "Deliver to the hotel", pid: "hotel", r: 3, msg: "Delivered" }, { t: "Deliver to the hospital", pid: "hospital", r: 3 }] },
    { id: "taxiShift", t: "Taxi Shift", from: "City Dispatch", d: "Two customers need a ride. Drive them in the taxi.", reward: 80, limit: 360, steps: [{ t: "Get in the taxi (call one from your phone)", ev: "taxi", at: "taxi" }, { t: "Drive to the hotel", pid: "hotel", r: 14, car: true, msg: "Customer dropped off" }, { t: "Drive to City Hall", pid: "cityhall", r: 14, car: true }] },
    { id: "dinner", t: "Dinner Out", from: "Restaurant", d: "Book a table and enjoy a full meal.", reward: 30, steps: [{ t: "Go to the restaurant", pid: "diner", r: 3 }, { t: "Go inside", ev: "enter:diner", pid: "diner" }, { t: "Sit down and eat", ev: "ate", pid: "diner" }] },
    { id: "homeSweet", t: "Home Sweet Home", from: "Landlord", d: "Check your new home and relax on the sofa.", reward: 20, steps: [{ t: "Go home", pid: "home", r: 3 }, { t: "Go inside", ev: "enter:home", pid: "home" }, { t: "Sit on the sofa", ev: "homeSofa", pid: "home" }] },
    { id: "airportRun", t: "Airport Run", from: "EarthPass Air", d: "Drive to the airport terminal by taxi.", reward: 50, steps: [{ t: "Get in the taxi", ev: "taxi", at: "taxi" }, { t: "Drive to the airport", go: [AX1 - 8, 4], r: 14, car: true }] },
    { id: "bigScore", t: "The Big Score", from: "Unknown number", d: "Rob the city bank vault, then lose the police. Getting busted or wasted ends the job.", reward: 600, steps: [{ t: "Go to the bank", pid: "bank", r: 3 }, { t: "Go inside the bank", ev: "enter:bank", pid: "bank" }, { t: "Crack the vault at the back of the bank", ev: "vault", pid: "bank" }, { t: "Escape and lose the police", ev: "lostCops" }] },
    { id: "hotWheels", t: "Hot Wheels", from: "Chop shop", d: "Steal any car off the street and bring it to the airport car park.", reward: 150, steps: [{ t: "Steal a car from the street", ev: "jack" }, { t: "Drive it to the airport car park", go: [AX1 - 8, 4], r: 14, car: true }] },
    { id: "streetKing", t: "King of the Street", from: "Fight club", d: "Win three street fights. Careful, the police may join in.", reward: 90, steps: [{ t: "Knock someone out (1/3)", ev: "ko" }, { t: "Knock someone out (2/3)", ev: "ko" }, { t: "Knock someone out (3/3)", ev: "ko" }] },
    { id: "hotPursuit", t: "Hot Pursuit", from: "Street racer", d: "Get a two-star wanted level, then lose the police.", reward: 120, steps: [{ t: "Get two wanted stars", ev: "wanted2" }, { t: "Lose the police", ev: "lostCops" }] },
    { id: "twoWheels", t: "Two Wheels", from: "Courier", d: "Grab a motorbike off the street and rush a parcel to the cafe.", reward: 90, limit: 300, steps: [{ t: "Take a motorbike from the street", ev: "jackMoto" }, { t: "Ride to the cafe", pid: "cafe", r: 14, car: true }] },
    { id: "rushHour", t: "Rush Hour", from: "City Dispatch", d: "Get a car and race to the hotel, then the bank, in under four minutes.", reward: 80, limit: 240, steps: [{ t: "Get in any car", ev: "taxi", at: null }, { t: "Drive to the hotel", pid: "hotel", r: 14, car: true }, { t: "Drive to the bank", pid: "bank", r: 14, car: true }] },
    { id: "nightShift", t: "Bodyguard", from: "Hotel manager", d: "A guest needs a ride from the hotel to the hospital. Keep your health up on the way.", reward: 70, steps: [{ t: "Get in any car", ev: "taxi", at: null }, { t: "Pick up the guest at the hotel", pid: "hotel", r: 14, car: true, msg: "Guest is in the car" }, { t: "Drive to the hospital", pid: "hospital", r: 14, car: true }] },
    { id: "travelDocs", t: "Travel Documents", from: "Global Travel", d: "Book a flight, check in and get your exit stamp.", reward: 60, steps: [{ t: "Book a flight at Global Travel", ev: "booked", pid: "agency" }, { t: "Check in at the airport", ev: "checkin", at: [98, -13.8] }, { t: "Clear security", ev: "security", at: [110, 0] }, { t: "Get your exit stamp", ev: "immigrationDone", at: [125.8, 0] }] }
  ].forEach(function (m) { MISSIONS.push(m); });
  MISSIONS.push(
    { id: "turfWar", t: "Turf War", from: "Street boss", d: "A rival gang took over the park by the river in Queens. Arm yourself and take them all out.", reward: 260, steps: [{ t: "Get a gun (Arms & Auto or a pickup)", ev: "gotGun", at: [-117, 11.9] }, { t: "Go to the gang hangout in Queens", go: [-190, 84], r: 30 }, { t: "Take out the whole gang", ev: "gangDown" }] },
    { id: "rhinoRampage", t: "Rhino Rampage", from: "Unknown number", d: "Steal the battle tank from the Army Depot and wreck six vehicles. Expect heavy police.", reward: 400, steps: [{ t: "Steal the tank at the Army Depot", ev: "tank", at: [-128, 46] }, { t: "Wreck six vehicles", ev: "wreck6" }] },
    { id: "nitroRun", t: "Nitro Run", from: "Street racer", d: "Get a sports car or superbike, hit the nitro and race to the airport car park in under two minutes.", reward: 180, limit: 150, steps: [{ t: "Get a sports car or superbike (buy or steal)", ev: "sporty" }, { t: "Fire the nitro", ev: "nitro" }, { t: "Race to the airport car park", go: [AX1 - 8, 4], r: 14, car: true }] },
    { id: "fireworks", t: "Fireworks", from: "Demolition crew", d: "Buy a rocket launcher and blow up three cars.", reward: 220, steps: [{ t: "Get a rocket launcher at Arms & Auto", ev: "gotGun", at: [-117, 11.9] }, { t: "Blow up three cars with rockets", ev: "wreck3" }] }
  );
  var MIS = {}; MISSIONS.forEach(function (m) { MIS[m.id] = m; });
  function pidPos(pid) { var pl = pid === "home" ? HOME : cityPlaces[pid]; return pl ? [pl.x, pl.z] : null; }

  /* daily tasks: new every day, paid on completion */
  var DAILY_KIND = [
    function (r) { var pid = ["cafe", "bank", "hotel", "school", "hospital", "cityhall", "landmark", "grocery", "diner"][Math.floor(r() * 9)]; return { k: "visit", pid: pid, t: "Visit " + ((cityPlaces[pid] && cityPlaces[pid].name) || pid), need: 1, pay: 10 }; },
    function () { return { k: "shift", t: "Work 2 shifts", need: 2, pay: 25 }; },
    function () { return { k: "eat", t: "Eat a meal", need: 1, pay: 8 }; },
    function () { return { k: "walk", t: "Walk 1 km", need: 1000, pay: 12 }; },
    function () { return { k: "drive", t: "Drive 2 km", need: 2000, pay: 15 }; },
    function () { return { k: "mission", t: "Finish any mission", need: 1, pay: 20 }; },
    function () { return { k: "inside", t: "Go inside 3 buildings", need: 3, pay: 12 }; }
  ];
  function dailyKey() { return fmtD(now(), here().tz); }
  function ensureDaily() {
    if (G.daily && G.daily.day === dailyKey()) return;
    var r = rng(hash(dailyKey() + G.passport.no)), list = [], used = {};
    while (list.length < 5) { var i = Math.floor(r() * DAILY_KIND.length); if (used[i] && i !== 0) continue; used[i] = 1; var t = DAILY_KIND[i](r); t.have = 0; t.done = false; list.push(t); }
    G.daily = { day: dailyKey(), tasks: list }; save();
  }
  function dailyBump(kind, n, pid) {
    if (!G.daily) return;
    G.daily.tasks.forEach(function (t) {
      if (t.done || t.k !== kind || (t.pid && pid && t.pid !== pid)) return;
      t.have = Math.min(t.need, t.have + (n || 1));
      if (t.have >= t.need) { t.done = true; earn(t.pay, "Daily task \u00b7 " + t.t); toast("Daily task done \u00b7 +" + t.pay + " TOKEN"); }
    });
    save();
  }
  var dailyLast = null;
  function dailyTick() {
    ensureDaily();
    var pos = P.mode === "car" ? [taxi.x, taxi.z] : [P.x, P.z];
    if (dailyLast && !INSIDE) { var d = Math.hypot(pos[0] - dailyLast[0], pos[1] - dailyLast[1]); if (d < 30 && d > 0.05) dailyBump(P.mode === "car" ? "drive" : "walk", d); }
    dailyLast = pos;
    G.daily.tasks.forEach(function (t) { if (!t.done && t.k === "visit") { var pp = pidPos(t.pid); if (pp && Math.hypot(P.x - pp[0], P.z - pp[1]) < (t.pid === "landmark" ? 14 : 5)) dailyBump("visit", 1, t.pid); } });
  }
  var NUGGETS = [[-126, 101], [-98, 104], [-86, 96]].map(function (p) { var n = new THREE.Mesh(new THREE.DodecahedronGeometry(0.35, 0), new THREE.MeshStandardMaterial({ color: 0xe8b84a, metalness: 1, roughness: 0.25, emissive: 0x5a4000 })); n.position.set(p[0], 0.5, p[1]); n.visible = false; n.castShadow = true; scene.add(n); return n; });
  function msg(from, text) { sfx("ping"); G.msgs.unshift({ f: from, x: text, t: now(), n: true }); if (G.msgs.length > 40) G.msgs.length = 40; save(); }
  if (!G.msgs.length) msg("EarthPass", "Welcome, " + G.passport.first + ". You are a " + G.passport.job[0] + ". Open Missions on your phone to start, or work a shift to earn TOKEN.");
  function stepTarget(s) { if (s.go) return s.go; if (s.pid && !s.ev) return pidPos(s.pid); if (s.at === "taxi") return [taxi.x, taxi.z]; if (s.pid) return pidPos(s.pid); return s.at; }
  function aimStep() {
    var m = G.mis && MIS[G.mis.id]; if (!m) return;
    var s = m.steps[G.mis.step], p = stepTarget(s);
    if (p) { G.wp = { x: p[0], z: p[1], t: s.t, mission: true }; wpMesh.position.set(p[0], 0, p[1]); wpMesh.visible = true; } else { G.wp = null; wpMesh.visible = false; $("wpChip").hidden = true; }
    save();
  }
  function startMission(id) {
    var m = MIS[id]; if (!m) return;
    G.mis = { id: id, step: 0, t0: Date.now() }; aimStep(); bigText("mstart", m.t, m.from); closePhone(); sfx("mission", id);
  }
  function bigText(id, a, b, fail) { var el = $(id); el.querySelector("b").textContent = a; el.querySelector("span").textContent = b || ""; el.classList.toggle("fail", !!fail); el.hidden = false; el.classList.remove("show"); void el.offsetWidth; el.classList.add("show"); clearTimeout(el._t); el._t = setTimeout(function () { el.hidden = true; }, 4700); }
  function quitMission(text) { G.mis = null; if (G.wp && G.wp.mission) { G.wp = null; wpMesh.visible = false; $("wpChip").hidden = true; } save(); if (text) toast(text); }
  function advance() {
    var m = MIS[G.mis.id], s = m.steps[G.mis.step];
    if (s.msg) toast(s.msg);
    G.mis.step++;
    if (G.mis.step >= m.steps.length) {
      var rep = G.done[m.id], pay = rep ? Math.round(m.reward / 2) : m.reward;
      G.done[m.id] = (G.done[m.id] || 0) + 1; earn(pay, "Mission \u00b7 " + m.t); dailyBump("mission");
      msg(m.from, "Thank you! \"" + m.t + "\" is complete. +" + pay + " TOKEN sent to your account.");
      quitMission(); bigText("mpass", "Mission passed!", "+" + pay + " TOKEN"); sfx("passed", m.id);
      return;
    }
    aimStep();
  }
  function missionEvent(name) {
    if (name === "ate") dailyBump("eat"); else if (name.indexOf("enter:") === 0) dailyBump("inside"); else if (name.indexOf("shift:") === 0) dailyBump("shift");
    if (!G.mis) return; var m = MIS[G.mis.id]; if (!m) return; var s = m.steps[G.mis.step]; if (!s || !s.ev) return;
    if (s.ev === name || (s.ev.slice(-1) === "*" && name.indexOf(s.ev.slice(0, -1)) === 0)) advance();
  }
  function missionTick() {
    var ch = $("misChip");
    if (!G.mis || !MIS[G.mis.id]) { if (!ch.hidden) { ch.hidden = true; NUGGETS.forEach(function (n) { n.visible = false; }); } return; }
    var m = MIS[G.mis.id], s = m.steps[G.mis.step];
    NUGGETS.forEach(function (n, i) { n.visible = m.id === "gold" && G.mis.step <= i + 1; n.rotation.y += 0.03; n.position.y = 0.5 + Math.sin(performance.now() / 300 + i) * 0.12; });
    if (s.ev === "taxi" && P.mode === "car") { advance(); return; }
    var sg = s.go || (s.pid && !s.ev ? pidPos(s.pid) : null);
    if (sg && (!s.car || P.mode === "car") && Math.hypot(P.x - sg[0], P.z - sg[1]) < s.r) { advance(); return; }
    if (s.pid && G.wp && G.wp.mission) { var tp = stepTarget(s); if (tp && (Math.abs(G.wp.x - tp[0]) > 0.5 || Math.abs(G.wp.z - tp[1]) > 0.5)) { G.wp.x = tp[0]; G.wp.z = tp[1]; wpMesh.position.set(tp[0], 0, tp[1]); } }
    if (s.at === "taxi" && G.wp && P.mode !== "car") { G.wp.x = taxi.x; G.wp.z = taxi.z; wpMesh.position.set(taxi.x, 0, taxi.z); }
    var left = m.limit ? m.limit - (Date.now() - G.mis.t0) / 1000 : null;
    if (left !== null && left <= 0) { msg(m.from, "Too late this time. You can try \"" + m.t + "\" again from Missions."); quitMission("Mission failed \u00b7 time is up"); return; }
    ch.hidden = false; $("misT").textContent = m.t; $("misS").textContent = (G.mis.step + 1) + "/" + m.steps.length + " \u00b7 " + s.t + (left !== null ? " \u00b7 " + Math.floor(left / 60) + ":" + String(Math.floor(left % 60)).padStart(2, "0") : "") + (s.car && P.mode !== "car" ? " \u00b7 in the taxi" : "");
  }

  /* ================= Phone ================= */
  var phoneOpen = false, phoneProp = null;
  var APPS = [
    ["Missions", "MI", "#ff3d8b", "missions"], ["Map", "MP", "#7bd88f", "map"], ["World", "WD", "#5ab0ff", "world"], ["Jobs", "JB", "#f2c230", "jobs"],
    ["Bank", "BK", "#6fa8ff", "bank"], ["Messages", "MS", "#ff8a5c", "msgs"], ["Taxi", "TX", "#f2c230", "taxi"], ["Flights", "FL", "#c9a7ff", "flights"],
    ["Passport", "PP", "#e9ece6", "passport"], ["Shop", "SH", "#ff9a3c", "shop"], ["Clock", "CL", "#9fb3ff", "clock"], ["Weather", "WX", "#2ee6d6", "weather"], ["Camera", "CA", "#ff7a59", "camera"], ["Settings", "ST", "#9aa392", "settings"]
  ];
  function head(title) { return "<div class='ph-h'><button type='button' data-go='home'>Back</button><b>" + title + "</b></div>"; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function phoneApp(id) {
    var b = $("phBody"), h = "";
    if (id === "home") {
      var unread = G.msgs.filter(function (m) { return m.n; }).length;
      h = "<div class='ph-home'>" + APPS.map(function (a) { return "<button class='app' type='button' data-go='" + a[3] + "'><span style='background:" + a[2] + "'>" + a[1] + "</span>" + a[0] + (a[3] === "msgs" && unread ? " (" + unread + ")" : "") + "</button>"; }).join("") + "</div>";
      if (G.mis && MIS[G.mis.id]) h += "<div class='ph-card' style='margin-top:18px'><span class='ph-tag'>ACTIVE MISSION</span><h4>" + MIS[G.mis.id].t + "</h4><p>" + MIS[G.mis.id].steps[G.mis.step].t + "</p></div>";
    } else if (id === "missions") {
      ensureDaily();
      h = head("Missions") + "<p class='ph-tag' style='margin:4px 2px 8px'>DAILY TASKS \u00b7 NEW EVERY DAY</p>" + G.daily.tasks.map(function (t) { var pct = Math.min(100, Math.round(t.have / t.need * 100)); return "<div class='ph-card'><div class='row2'><h4>" + esc(t.t) + "</h4><span class='ph-tag'>" + (t.done ? "DONE \u2713" : "+" + t.pay + " TOKEN") + "</span></div><div style='height:6px;border-radius:3px;background:rgba(255,255,255,.1);overflow:hidden'><i style='display:block;height:100%;width:" + pct + "%;background:#ff3d8b'></i></div></div>"; }).join("") + "<p class='ph-tag' style='margin:14px 2px 8px'>MISSIONS</p>" + MISSIONS.map(function (m) {
        var act = G.mis && G.mis.id === m.id, n = G.done[m.id] || 0;
        return "<div class='ph-card'><div class='row2'><span class='ph-tag'>FROM " + m.from.toUpperCase() + "</span><span class='ph-tag'>" + (n ? "DONE \u00d7" + n : m.reward + " TOKEN") + "</span></div><h4>" + m.t + "</h4><p>" + m.d + (m.limit ? " Time limit " + Math.round(m.limit / 60 * 10) / 10 + " min." : "") + "</p>" +
          "<div class='row2'><span class='ph-tag'>" + m.steps.length + " steps" + (n ? " \u00b7 replay pays " + Math.round(m.reward / 2) : "") + "</span>" + (act ? "<button class='btn ghost' type='button' data-quit='1'>Quit</button>" : "<button class='btn' type='button' data-mis='" + m.id + "'>" + (n ? "Replay" : "Start") + "</button>") + "</div></div>";
      }).join("");
    } else if (id === "jobs") {
      var own = workFor(G.passport.job[0]);
      h = head("Jobs") + "<div class='ph-card'><span class='ph-tag'>YOUR PROFESSION \u00b7 " + G.passport.job[1].toUpperCase() + "</span><h4>" + G.passport.job[0] + "</h4><p>" + (G.passport.job[0] === "Taxi Driver" ? "Drive the taxi from the Taxi Rank. You earn per kilometre." : own ? "Work at " + own.t + ". " + G.passport.job[4] + " TOKEN per shift. You are paid only while you work." : "") + "</p>" +
        (own || G.passport.job[0] === "Taxi Driver" ? "<div class='row2'><span></span><button class='btn' type='button' data-wp='" + (own ? own.x + "," + own.z + "," + own.t : "-63.4,18,Taxi Rank") + "'>Set waypoint</button></div>" : "") + "</div>" +
        "<p class='ph-tag' style='margin:14px 2px 8px'>WORKPLACES \u00b7 PART-TIME PAYS " + GIG + " TOKEN</p>" +
        WORK.map(function (w) { var mine = w.jobs.indexOf(G.passport.job[0]) >= 0; return "<div class='ph-card'><div class='row2'><h4>" + w.t + "</h4>" + (mine ? "<span class='ph-tag'>YOUR JOB</span>" : "") + "</div><p>" + w.jobs.join(", ") + " \u00b7 part-time " + w.gig + "</p><div class='row2'><span></span><button class='btn ghost' type='button' data-wp='" + w.x + "," + w.z + "," + w.t + "'>Go there</button></div></div>"; }).join("") +
        "<p class='ph-tag' style='margin:14px 2px 8px'>GOVERNMENT \u00b7 RUN BY THE TEAM</p>" + GOV.map(function (j) { return "<div class='ph-card'><h4>" + j[0] + "</h4><p>" + j[1] + " \u00b7 team only</p></div>"; }).join("");
    } else if (id === "bank") {
      h = head("City Bank") + "<div class='ph-card'><span class='ph-tag'>BALANCE</span><span class='ph-big'>" + Math.round(G.balance).toLocaleString("en-US") + "</span><p>TOKEN \u00b7 account " + G.passport.no + "</p></div>" +
        (G.tx.length ? G.tx.map(function (t) { return "<div class='ph-card'><div class='row2'><h4>" + esc(t.l) + "</h4><span class='ph-amt " + (t.a < 0 ? "neg" : "pos") + "'>" + (t.a > 0 ? "+" : "") + t.a + "</span></div><p>" + (AIR[t.c] ? AIR[t.c].city + " \u00b7 " : "") + fmtD(t.t, (AIR[t.c] || here()).tz) + " " + fmtT(t.t, (AIR[t.c] || here()).tz) + "</p></div>"; }).join("") : "<p class='ph-tag'>No transactions yet</p>");
    } else if (id === "msgs") {
      h = head("Messages") + G.msgs.map(function (m) { return "<div class='ph-card'><div class='row2'><h4>" + esc(m.f) + "</h4><span class='ph-tag'>" + fmtT(m.t, here().tz) + "</span></div><p>" + esc(m.x) + "</p></div>"; }).join("");
      G.msgs.forEach(function (m) { m.n = false; }); save();
    } else if (id === "taxi") {
      h = head("Taxi") + "<div class='ph-card'><h4>Call a taxi</h4><p>The yellow taxi comes to the nearest road next to you. You drive it yourself." + (G.passport.job[0] === "Taxi Driver" ? " As a taxi driver you earn per kilometre." : "") + "</p><div class='row2'><span class='ph-tag'>FEE 5 TOKEN</span><button class='btn' type='button' data-taxi='1'" + (P.mode === "car" || G.balance < 5 ? " disabled" : "") + ">Call now</button></div></div>";
    } else if (id === "flights") {
      var tr = G.trip;
      h = head("Flights") + (tr ? "<div class='ph-card'><span class='ph-tag'>YOUR TICKET \u00b7 " + tr.no + "</span><h4>" + AIR[tr.from].city + " to " + AIR[tr.to].city + "</h4><p>Departs " + fmtD(tr.dep, AIR[tr.from].tz) + " " + fmtT(tr.dep, AIR[tr.from].tz) + " local \u00b7 seat " + tr.seat + " \u00b7 flight " + dur(tr.dur) + "</p><div class='row2'><span></span><button class='btn' type='button' data-wp='" + (G.flags.checkin ? "156,12,Gate B12" : "98,-13.8,Check-in") + "'>Guide me</button></div></div>" :
        "<div class='ph-card'><h4>No ticket</h4><p>Book flights and visas at Global Travel, next to the airport.</p><div class='row2'><span></span><button class='btn' type='button' data-wp='" + (cityPlaces.agency ? cityPlaces.agency.x.toFixed(1) + "," + cityPlaces.agency.z.toFixed(1) : "56,-10.2") + ",Global Travel'>Go to Global Travel</button></div></div>") +
        "<div class='ph-card'><h4>World map</h4><p>See every airport, local times and flight times.</p><div class='row2'><span></span><button class='btn ghost' type='button' data-go='world'>Open</button></div></div>";
    } else if (id === "clock") {
      h = head("World Clock") + ["JFK", "LAX", "LHR", "CDG", "DXB", "DAC", "SIN", "NRT", "SYD"].map(function (c) { var a = AIR[c]; return "<div class='ph-card'><div class='row2'><h4>" + a.city + "</h4><span class='ph-big' style='font-size:22px'>" + fmtT(now(), a.tz) + "</span></div><p>" + fmtD(now(), a.tz) + " \u00b7 " + a.country + "</p></div>"; }).join("");
    } else if (id === "weather") {
      var aW = here(), A0 = lastAstro || astro(now(), aW.lat, aW.lon), stt = skyTimes(now()), C0 = WX.cur;
      var ph = A0.illum < 0.03 ? "New moon" : A0.illum > 0.97 ? "Full moon" : (A0.waxing ? "Waxing " : "Waning ") + (A0.illum < 0.45 ? "crescent" : A0.illum < 0.55 ? "half moon" : "gibbous");
      h = head("Weather") + "<div class='ph-card'><span class='ph-tag'>" + esc(aW.city).toUpperCase() + " \u00b7 " + fmtT(now(), aW.tz) + "</span><h4 style='font-size:22px;margin-top:6px'>" + esc(WX.label || "--") + (WX.temp != null ? " \u00b7 " + Math.round(WX.temp) + "\u00b0C" : "") + "</h4><p>Clouds " + Math.round(C0.cover * 100) + "% \u00b7 Wind " + Math.round(C0.wind * 3.6) + " km/h" + (C0.rain > 0.05 ? " \u00b7 Rain" : "") + (C0.storm > 0.5 ? " \u00b7 Lightning" : "") + "</p><p class='ph-tag' style='margin-top:6px'>" + esc(WX.src || "") + "</p></div>" +
        "<div class='ph-card'><div class='row2'><h4>Sunrise</h4><b>" + (stt.rise ? fmtClock(stt.rise, aW.tz) : "--") + "</b></div><div class='row2'><h4>Sunset</h4><b>" + (stt.set ? fmtClock(stt.set, aW.tz) : "--") + "</b></div><div class='row2'><h4>Moonrise</h4><b>" + (stt.mrise ? fmtClock(stt.mrise, aW.tz) : "--") + "</b></div><p>" + ph + " \u00b7 " + Math.round(A0.illum * 100) + "% lit</p></div>" +
        "<p class='ph-tag' style='margin:10px 2px 6px'>CHOOSE THE WEATHER</p><div class='ph-card' style='display:flex;flex-wrap:wrap;gap:8px'>" + [["live", "Live (real)"], ["clear", "Sunny"], ["cloudy", "Cloudy"], ["rain", "Rain"], ["storm", "Storm"], ["snow", "Snow"], ["fog", "Fog"]].map(function (o) { return "<button class='btn" + (WX.mode === o[0] ? "" : " ghost") + "' type='button' data-wx='" + o[0] + "' style='min-height:38px;padding:0 14px'>" + o[1] + "</button>"; }).join("") + "</div>" +
        "<div class='ph-card'><div class='row2'><h4>Weather sounds</h4><button class='btn ghost' type='button' data-wxs='1' style='min-height:36px;padding:0 14px'>" + (G.wxSound === false ? "Off" : "On") + "</button></div></div>";
    }
    b.innerHTML = h; b.scrollTop = 0;
  }
  function openPhone() { $("phone").hidden = false; phoneOpen = true; phoneApp("home"); if (phoneProp) phoneProp.visible = true; }
  function closePhone() { $("phone").hidden = true; phoneOpen = false; if (phoneProp) phoneProp.visible = false; }
  function callTaxi() {
    if (P.mode === "car") return;
    if (taxi.m.userData.boat || taxi.m.userData.tank || taxi.m.userData.sport || taxi.m.userData.air) { taxi.alt = 0; CARS.push({ m: taxi.m, x: taxi.x, z: taxi.z, yaw: taxi.yaw, parked: true, boat: !!taxi.m.userData.boat }); var nm = carMesh(0xf2c230, "sedan", true); scene.add(nm); taxi.m = nm; }
    var zx, zz, yaw;
    if (CITY && CITY.inBounds(P.x, P.z)) {
      var rd = CITY.nearestRoad(P.x, P.z, 250, 2); if (!rd) { toast("No road nearby"); return; }
      var off = rd.road.o ? 0 : Math.max(1.4, rd.road.w / 4);
      spend(5, "Taxi call"); taxi.x = rd.x + (-rd.dz) * off; taxi.z = rd.z + rd.dx * off; taxi.yaw = Math.atan2(-rd.dz, rd.dx); taxi.v = 0; closePhone();
      setWaypoint(taxi.x, taxi.z, "Your taxi"); toast("Your taxi has arrived"); return;
    }
    if (P.z > 30 && P.x > -160 && P.x < 90) { if (Math.abs(P.z - 95) < 10) { zx = clamp(P.x, -150, 80); zz = 97; yaw = 0; } else { zx = ROADX + 2.5; zz = clamp(P.z, 20, 160); yaw = Math.PI / 2; } }
    else if (Math.abs(P.z) < 40 && P.x > CITY_X1 - 40 && P.x < CITY_X2) {
      var sd = P.z >= 0 ? 1 : -1; zz = sd * 5.9; yaw = sd > 0 ? 0 : Math.PI; zx = null;
      for (var off = 0; off < 60 && zx === null; off += 1.5) [P.x + off, P.x - off].forEach(function (x) { if (zx !== null) return; var ok = x > CITY_X1 - 30 && x < CITY_X2 - 4; COL.forEach(function (c) { if (ok && c.on && c.tag === "car" && x + 3 > c.x1 && x - 3 < c.x2 && zz + 1.2 > c.z1 && zz - 1.2 < c.z2) ok = false; }); if (ok) zx = x; });
      if (zx === null) { zx = P.x; zz = sd * 3.6; }
    } else { toast("No taxi can reach you here"); return; }
    spend(5, "Taxi call"); taxi.x = zx; taxi.z = zz; taxi.yaw = yaw; taxi.v = 0; closePhone();
    setWaypoint(zx, zz, "Your taxi"); toast("Your taxi has arrived");
  }
  $("phBody").addEventListener("click", function (e) {
    var t = e.target.closest("button"); if (!t) return;
    if (t.dataset.go) {
      var g2 = t.dataset.go;
      if (g2 === "shop") { closePhone(); openShop(); return; }
      if (g2 === "map") { closePhone(); openMap("city"); } else if (g2 === "world") { closePhone(); openMap("world"); }
      else if (g2 === "passport") { closePhone(); openPassport(); } else if (g2 === "settings") { closePhone(); $("bSet").click(); }
      else if (g2 === "camera") { closePhone(); document.body.classList.add("photo"); toast("Photo mode \u00b7 tap the screen to exit"); setTimeout(function () { $("toast").hidden = true; }, 1600); }
      else phoneApp(g2);
    }
    if (t.dataset.mis) startMission(t.dataset.mis);
    if (t.dataset.quit) { quitMission("Mission stopped"); phoneApp("missions"); }
    if (t.dataset.wp) { var p = t.dataset.wp.split(","); closePhone(); setWaypoint(+p[0], +p[1], p.slice(2).join(",")); }
    if (t.dataset.taxi) callTaxi();
    if (t.dataset.wx) { WX.mode = t.dataset.wx; G.wxMode = WX.mode; WX.fast = 6; save(); phoneApp("weather"); toast("Weather: " + t.textContent); }
    if (t.dataset.wxs) { G.wxSound = G.wxSound === false ? true : false; if (G.wxSound === false && WXA) { try { WXA.ac.close(); } catch (e2) {} WXA = null; } else wxAudio(); save(); phoneApp("weather"); }
  });
  $("phHome").addEventListener("click", function () { if ($("phBody").querySelector(".ph-home")) closePhone(); else phoneApp("home"); });
  $("bPhone").addEventListener("click", function () { if (phoneOpen) closePhone(); else openPhone(); });
  window.addEventListener("keydown", function (e) { if ((e.key === "p" || e.key === "P") && $("modal").hidden) { if (phoneOpen) closePhone(); else openPhone(); } });
  document.addEventListener("pointerdown", function () { if (document.body.classList.contains("photo")) setTimeout(function () { document.body.classList.remove("photo"); }, 50); }, true);
  if (G.mis && MIS[G.mis.id]) aimStep(); else G.mis = null;

  /* ================= Real-map city (OpenStreetMap) ================= */
  if (window.PW_SERVER) fetch(window.PW_SERVER + "/game/config", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (c) { setTestTokens(!!c.testTokens); if (c.testTokens) toast("Test mode \u00b7 unlimited tokens"); }).catch(function () {});
  var cityReady = false, SERVER = window.PW_SERVER || null, CITY_OX = -1750, CITY_OZ = -1250, cityHalf = 1500, CMS = 0.5, cityCanvas = null, cityCtx = null, cityOV = null;
  var CITY_NAME = SERVER ? here().city : "Utrecht", CITY_PREVIEW = !SERVER;
  var cityBase = SERVER ? SERVER + "/city/" + G.city : (window.PW_TILES || "tiles/UTR");
  plane(3300, 3300, M.grass, CITY_OX, -0.025, CITY_OZ);
  plane(80, 14, M.asphalt, -226, 0.004, 0);
  function cmX(x) { return (x + cityHalf) * CMS; }
  function drawTileOnMap(key, d) {
    if (!cityCtx) return; var c = cityCtx;
    c.fillStyle = "#3a403a"; c.strokeStyle = "rgba(255,255,255,0.10)"; c.lineWidth = 0.6;
    try { mvTile(key, d); } catch (e) {}
    d.b.forEach(function (b) { var p = b.p; c.beginPath(); c.moveTo(cmX(p[0]), cmX(p[1])); for (var i = 2; i < p.length; i += 2) c.lineTo(cmX(p[i]), cmX(p[i + 1])); c.closePath(); c.fill(); c.stroke(); });
    drawRoadsOn(c, d.r);
  }
  function drawRoadsOn(c, roads) {
    c.lineCap = "round"; c.lineJoin = "round";
    [6, 5, 4, 3, 2, 1, 0].forEach(function (cl) {
      roads.forEach(function (r) {
        if (r.c !== cl) return; var p = r.p;
        c.strokeStyle = cl >= 5 ? "#6b6a5e" : cl <= 1 ? "#d9c37a" : "#8c9196"; c.lineWidth = Math.max(cl >= 5 ? 0.8 : 1.4, (r.w || (cl <= 1 ? 11 : cl <= 3 ? 7 : 4)) * CMS);
        c.beginPath(); c.moveTo(cmX(p[0]), cmX(p[1])); for (var i = 2; i < p.length; i += 2) c.lineTo(cmX(p[i]), cmX(p[i + 1])); c.stroke();
      });
    });
  }
  function drawOverview(ov) {
    cityCanvas = document.createElement("canvas"); cityCanvas.width = cityCanvas.height = Math.round(cityHalf * 2 * CMS); cityCtx = cityCanvas.getContext("2d");
    var c = cityCtx; c.fillStyle = "#1b2a1c"; c.fillRect(0, 0, cityCanvas.width, cityCanvas.height);
    var poly = function (p, col) { c.fillStyle = col; c.beginPath(); c.moveTo(cmX(p[0]), cmX(p[1])); for (var i = 2; i < p.length; i += 2) c.lineTo(cmX(p[i]), cmX(p[i + 1])); c.closePath(); c.fill(); };
    ov.g.forEach(function (g) { poly(g.p, "#2c5a30"); });
    ov.w.forEach(function (w) { if (w.line) { c.strokeStyle = "#2f6f93"; c.lineWidth = w.line * CMS; c.beginPath(); c.moveTo(cmX(w.p[0]), cmX(w.p[1])); for (var i = 2; i < w.p.length; i += 2) c.lineTo(cmX(w.p[i]), cmX(w.p[i + 1])); c.stroke(); } else poly(w.p, "#2f6f93"); });
    var rails = ov.r.filter(function (r) { return r.c === 9; }); c.strokeStyle = "#9a9a9a"; c.setLineDash([3, 3]); c.lineWidth = 1.4;
    rails.forEach(function (r) { var p = r.p; c.beginPath(); c.moveTo(cmX(p[0]), cmX(p[1])); for (var i = 2; i < p.length; i += 2) c.lineTo(cmX(p[i]), cmX(p[i + 1])); c.stroke(); }); c.setLineDash([]);
    drawRoadsOn(c, ov.r.filter(function (r) { return r.c !== 9; }));
    try { buildVectorMap(ov); } catch (e) { console.error(e); }
  }

  /* ===================== Vector map: crisp roads, names, districts ===================== */
  var MV2 = { C: 250, cells: {}, names: [], ver: 0 };
  var MSTY = {
    land: "#211538", park: "#1d5a46", water: "#12608f", shore: "#2b8ab4", bld: "#33244d", bldEdge: "rgba(255,180,220,0.08)", casing: "#120a24",
    road: [["#ff9a3c", 14, 3.2], ["#ff9a3c", 13, 3.0], ["#ff6fa5", 11, 2.6], ["#f3d9ec", 9, 2.2], ["#b79bd1", 7, 1.7], ["#6d5a8a", 4, 1.1], ["#5a4878", 2.4, 0.8]]
  };
  function mvCellAt(x, z) { var k = Math.floor(x / MV2.C) + "," + Math.floor(z / MV2.C); var c = MV2.cells[k]; if (!c) c = MV2.cells[k] = { roads: [], water: null, park: null, bld: null, rail: null }; return c; }
  function mvPath(p, ox, oz, close) { var P2 = new Path2D(); P2.moveTo(p[0] + ox, p[1] + oz); for (var i = 2; i < p.length; i += 2) P2.lineTo(p[i] + ox, p[i + 1] + oz); if (close) P2.closePath(); return P2; }
  function mvAdd(cell, key, path) { if (!cell[key]) cell[key] = new Path2D(); cell[key].addPath(path); }
  function mvRoadAdd(cell, cl, path) { if (!cell.roads[cl]) cell.roads[cl] = new Path2D(); cell.roads[cl].addPath(path); }
  function buildVectorMap(ov) {
    var ox = CITY_OX, oz = CITY_OZ;
    (ov.g || []).forEach(function (g) { mvAdd(mvCellAt(g.p[0] + ox, g.p[1] + oz), "park", mvPath(g.p, ox, oz, true)); });
    (ov.w || []).forEach(function (w) { var c = mvCellAt(w.p[0] + ox, w.p[1] + oz); if (w.line) { (c.wline || (c.wline = [])).push({ p: mvPath(w.p, ox, oz, false), w: w.line }); } else mvAdd(c, "water", mvPath(w.p, ox, oz, true)); });
    var named = {};
    (ov.r || []).forEach(function (r) {
      var p = r.p, mx = p[Math.floor(p.length / 4) * 2] + ox, mz = p[Math.floor(p.length / 4) * 2 + 1] + oz, c = mvCellAt(mx, mz);
      if (r.c === 9) { mvAdd(c, "rail", mvPath(p, ox, oz, false)); return; }
      mvRoadAdd(c, Math.min(6, r.c), mvPath(p, ox, oz, false));
      if (r.n && r.c <= 4) {
        var best = 0, bi = 2; for (var i = 2; i < p.length; i += 2) { var l = Math.hypot(p[i] - p[i - 2], p[i + 1] - p[i - 1]); if (l > best) { best = l; bi = i; } }
        var key = r.n + "|" + Math.floor(mx / 180) + "," + Math.floor(mz / 180);
        if (best > 28 && (!named[key] || named[key].len < best)) named[key] = { n: r.n, x: (p[bi - 2] + p[bi]) / 2 + ox, z: (p[bi - 1] + p[bi + 1]) / 2 + oz, a: Math.atan2(p[bi + 1] - p[bi - 1], p[bi] - p[bi - 2]), len: best, c: r.c };
      }
    });
    MV2.names = Object.keys(named).map(function (k) { return named[k]; }).sort(function (a, b) { return a.c - b.c || b.len - a.len; });
    MV2.ver++;
  }
  function mvTile(key, d) {
    var ox = CITY_OX, oz = CITY_OZ;
    (d.b || []).forEach(function (b) { if (b.m) return; mvAdd(mvCellAt(b.p[0] + ox, b.p[1] + oz), "bld", mvPath(b.p, ox, oz, true)); });
    (d.r || []).forEach(function (r) { if (r.c >= 5) mvRoadAdd(mvCellAt(r.p[0] + ox, r.p[1] + oz), Math.min(6, r.c), mvPath(r.p, ox, oz, false)); });
    MV2.ver++;
  }
  /* draw the city in world coordinates; ctx already maps world metres to the screen, ppm = screen pixels per metre */
  function drawVec(ctx, x1, z1, x2, z2, ppm) {
    var C = MV2.C, cells = [];
    for (var i = Math.floor(x1 / C); i <= Math.floor(x2 / C); i++) for (var j = Math.floor(z1 / C); j <= Math.floor(z2 / C); j++) { var c = MV2.cells[i + "," + j]; if (c) cells.push(c); }
    var px = 1 / ppm;
    ctx.lineCap = "round"; ctx.lineJoin = "round";
    ctx.fillStyle = MSTY.park; cells.forEach(function (c) { if (c.park) ctx.fill(c.park); });
    ctx.fillStyle = MSTY.water; cells.forEach(function (c) { if (c.water) ctx.fill(c.water); });
    ctx.strokeStyle = MSTY.water; cells.forEach(function (c) { (c.wline || []).forEach(function (w) { ctx.lineWidth = Math.max(w.w, 2 * px); ctx.stroke(w.p); }); });
    if (ppm > 0.6) { ctx.fillStyle = MSTY.bld; ctx.strokeStyle = MSTY.bldEdge; ctx.lineWidth = px; cells.forEach(function (c) { if (c.bld) { ctx.fill(c.bld); if (ppm > 1.6) ctx.stroke(c.bld); } }); }
    ctx.setLineDash([3 * px, 3 * px]); ctx.strokeStyle = "#8d8f8a"; ctx.lineWidth = 1.4 * px; cells.forEach(function (c) { if (c.rail) ctx.stroke(c.rail); }); ctx.setLineDash([]);
    var cls = [6, 5, 4, 3, 2, 1, 0];
    cls.forEach(function (cl) { if (cl >= 5 && ppm < 0.9) return; var st = MSTY.road[cl], w = Math.max(st[1], st[2] * px); ctx.strokeStyle = MSTY.casing; ctx.lineWidth = w + 2.2 * px; cells.forEach(function (c) { if (c.roads[cl]) ctx.stroke(c.roads[cl]); }); });
    cls.forEach(function (cl) { if (cl >= 5 && ppm < 0.9) return; var st = MSTY.road[cl], w = Math.max(st[1], st[2] * px); ctx.strokeStyle = st[0]; ctx.lineWidth = w; if (cl === 6) ctx.setLineDash([2 * px, 2 * px]); cells.forEach(function (c) { if (c.roads[cl]) ctx.stroke(c.roads[cl]); }); ctx.setLineDash([]); });
    /* Queens streets and houses next to the city */
    if (QSTREETS.length) { ctx.strokeStyle = MSTY.casing; ctx.lineWidth = 6 + 2.2 * px; QSTREETS.forEach(function (q) { ctx.beginPath(); ctx.moveTo(q[0], q[1]); ctx.lineTo(q[2], q[3]); ctx.stroke(); }); ctx.strokeStyle = MSTY.road[4][0]; ctx.lineWidth = Math.max(6, 1.7 * px); QSTREETS.forEach(function (q) { ctx.beginPath(); ctx.moveTo(q[0], q[1]); ctx.lineTo(q[2], q[3]); ctx.stroke(); }); }
    if (ppm > 0.6) { ctx.fillStyle = "#3a3d36"; QUEENS.forEach(function (q) { ctx.fillRect(q[0], q[2], q[1] - q[0], q[3] - q[2]); }); }
  }
  /* neighbourhood names (real ones for New York; other cities use names from their map data) */
  var DISTRICTS = [];
  function buildDistricts(ov) {
    var lat0 = cityLat(), lon0 = cityLon(), kx = 111320 * Math.cos(lat0 * Math.PI / 180), kz = 110540;
    function ll(lat, lon) { return [(lon - lon0) * kx + CITY_OX, -(lat - lat0) * kz + CITY_OZ]; }
    if (G.city === "JFK") [["Midtown", 40.7549, -73.984, 1], ["Times Square", 40.758, -73.9855, 2], ["Hell's Kitchen", 40.7638, -73.9918, 1], ["Chelsea", 40.7465, -74.0014, 1], ["Murray Hill", 40.7479, -73.9757, 1], ["Kips Bay", 40.742, -73.98, 1], ["Turtle Bay", 40.7527, -73.968, 1], ["Gramercy", 40.7368, -73.9845, 1], ["Garment District", 40.7536, -73.9894, 2], ["Koreatown", 40.7477, -73.9869, 2], ["Flatiron", 40.7411, -73.9897, 2], ["Sutton Place", 40.7577, -73.9617, 2], ["Hudson Yards", 40.7538, -74.002, 1], ["Columbus Circle", 40.7681, -73.9819, 2], ["Tudor City", 40.749, -73.9715, 2], ["Bryant Park", 40.7536, -73.9832, 3]].forEach(function (d) { var p = ll(d[1], d[2]); DISTRICTS.push({ n: d[0], x: p[0], z: p[1], r: d[3] }); });
    (ov.pl || []).forEach(function (p) { DISTRICTS.push({ n: p.n, x: p.x + CITY_OX, z: p.z + CITY_OZ, r: p.k || 1 }); });
    if (BRIDGE && !BRIDGE.land) DISTRICTS.push({ n: G.city === "JFK" ? "East River" : "River", x: (BRIDGE.xa + BRIDGE.xb) / 2, z: -420, r: 1, water: true });
    DISTRICTS.push({ n: G.city === "JFK" ? "Long Island City" : "East Side", x: -110, z: -200, r: 1 }, { n: G.city === "JFK" ? "Hunters Point" : "Riverside", x: -110, z: 240, r: 1 }, { n: here().name || "Airport", x: 330, z: 20, r: 1, air: true }, { n: "Sky Harbor Airfield", x: 400, z: 450, r: 1, air: true });
  }
  function cityLat() { var a = AIR[G.city] || {}; return (CITY && CITY.meta && CITY.meta() && CITY.meta().lat) || a.lat || 40.7549; }
  function cityLon() { var a = AIR[G.city] || {}; return (CITY && CITY.meta && CITY.meta() && CITY.meta().lon) || a.lon || -73.984; }
  function nearestDistrict(x, z) { var best = null, bd = 1e9; DISTRICTS.forEach(function (d) { if (d.r === 3) return; var dd = Math.hypot(d.x - x, d.z - z); if (dd < bd) { bd = dd; best = d; } }); return bd < 750 ? best : null; }
  /* text helpers */
  function haloText(c, t, x, y, fill, halo, lw) { c.lineWidth = lw; c.strokeStyle = halo; c.lineJoin = "round"; c.strokeText(t, x, y); c.fillStyle = fill; c.fillText(t, x, y); }
  function labelsOnBig(c, toS, s, d, W, H) {
    var taken = [];
    function free(x, y, w, h) { for (var i = 0; i < taken.length; i++) { var t = taken[i]; if (x < t[0] + t[2] && x + w > t[0] && y < t[1] + t[3] && y + h > t[1]) return false; } taken.push([x, y, w, h]); return true; }
    c.save(); c.textAlign = "center"; c.textBaseline = "middle";
    /* districts: big spaced capitals */
    DISTRICTS.forEach(function (D) {
      if (D.r === 3 && s < 2.5) return; if (D.r === 2 && s < 0.9) return; if (s > 6 && D.r === 1) return;
      var q = toS(D.x, D.z); if (q.x < -100 || q.y < -40 || q.x > W + 100 || q.y > H + 40) return;
      var fs = Math.round((D.r === 1 ? 15 : 12) * d), t = D.n.toUpperCase().split("").join(String.fromCharCode(8202));
      c.font = "800 " + fs + "px Unbounded, Manrope, sans-serif"; var tw = c.measureText(t).width;
      if (!free(q.x - tw / 2, q.y - fs / 2, tw, fs)) return;
      haloText(c, t, q.x, q.y, D.water ? "rgba(150,200,240,0.75)" : D.air ? "rgba(255,61,139,0.8)" : "rgba(236,240,232,0.72)", "rgba(10,12,11,0.7)", 4 * d);
    });
    /* street names along the roads when zoomed in */
    if (s > 1.25) {
      var fs2 = Math.round(10.5 * d); c.font = "700 " + fs2 + "px Manrope, sans-serif";
      MV2.names.forEach(function (n) {
        var q = toS(n.x, n.z); if (q.x < 0 || q.y < 0 || q.x > W || q.y > H) return;
        var tw = c.measureText(n.n).width; if (tw > n.len * s * 1.15) return;
        if (!free(q.x - tw / 2, q.y - fs2, tw, fs2 * 2)) return;
        var a = n.a; if (a > Math.PI / 2) a -= Math.PI; if (a < -Math.PI / 2) a += Math.PI;
        c.save(); c.translate(q.x, q.y); c.rotate(a); haloText(c, n.n, 0, 0, n.c <= 2 ? "#ffe7b0" : "#f1f3ee", "rgba(8,10,9,0.85)", 3.2 * d); c.restore();
      });
    }
    c.restore();
    return taken;
  }
  /* GPS route: glowing line with chevrons, flag at the end */
  function drawRouteNice(ctx, toS, w, chevrons) {
    if (!ROUTE || ROUTE.length < 2) return;
    ctx.save(); ctx.lineJoin = "round"; ctx.lineCap = "round";
    function path() { ctx.beginPath(); ROUTE.forEach(function (p, i) { var q = toS(p[0], p[1]); if (i) ctx.lineTo(q.x, q.y); else ctx.moveTo(q.x, q.y); }); }
    path(); ctx.lineWidth = w * 2.6; ctx.strokeStyle = "rgba(181,107,255,0.25)"; ctx.stroke();
    path(); ctx.lineWidth = w * 1.7; ctx.strokeStyle = "#f6f0ff"; ctx.stroke();
    path(); ctx.lineWidth = w; ctx.strokeStyle = "#a855f7"; ctx.stroke();
    if (chevrons) {
      var acc = 0, gap = Math.max(26, w * 9); ctx.fillStyle = "#ffffff";
      for (var i = 1; i < ROUTE.length; i++) {
        var a = toS(ROUTE[i - 1][0], ROUTE[i - 1][1]), b = toS(ROUTE[i][0], ROUTE[i][1]), L = Math.hypot(b.x - a.x, b.y - a.y), ang = Math.atan2(b.y - a.y, b.x - a.x);
        for (var t = gap - acc; t < L; t += gap) { var x = a.x + (b.x - a.x) * t / L, y = a.y + (b.y - a.y) * t / L; ctx.save(); ctx.translate(x, y); ctx.rotate(ang); ctx.beginPath(); ctx.moveTo(w * 0.55, 0); ctx.lineTo(-w * 0.35, -w * 0.45); ctx.lineTo(-w * 0.15, 0); ctx.lineTo(-w * 0.35, w * 0.45); ctx.closePath(); ctx.fill(); ctx.restore(); }
        acc = (acc + L) % gap;
      }
    }
    ctx.restore();
  }
  function flagPin(c, x, y, r) {
    c.save(); c.beginPath(); c.arc(x, y, r * 1.5, 0, 7); c.fillStyle = "rgba(168,85,247,0.22)"; c.fill();
    c.beginPath(); c.arc(x, y, r * 0.72, 0, 7); c.fillStyle = "#a855f7"; c.fill(); c.lineWidth = Math.max(2, r * 0.18); c.strokeStyle = "#ffffff"; c.stroke();
    c.fillStyle = "#ffffff"; c.fillRect(x - r * 0.22, y - r * 0.42, r * 0.08, r * 0.8); c.beginPath(); c.moveTo(x - r * 0.14, y - r * 0.42); c.lineTo(x + r * 0.34, y - r * 0.26); c.lineTo(x - r * 0.14, y - r * 0.08); c.closePath(); c.fill(); c.restore();
  }
  /* street and district shown under the minimap, GTA-style area name when you enter a new one */
  var areaT = 0, lastArea = null, lastStreet = "";
  function areaTick(tm) {
    if (tm - areaT < 600) return; areaT = tm;
    if (INSIDE || !CITY) { $("street").hidden = true; return; }
    var px = P.mode === "car" ? taxi.x : P.x, pz = P.mode === "car" ? taxi.z : P.z, st = "";
    if (CITY.inBounds(px, pz)) { var r = CITY.nearestRoad(px, pz, 30); if (r && r.road && r.road.n) st = r.road.n; }
    else if (Math.abs(pz) < 12 && px > -262 && px < 70) st = CS.street; else if (onBridge(px, pz)) st = G.city === "JFK" ? "Queensboro Bridge" : "River Bridge";
    var D = onBridge(px, pz) ? { n: G.city === "JFK" ? "East River" : "River" } : nearestDistrict(px, pz), dn = D ? D.n : "";
    $("street").hidden = !st && !dn; $("stName").textContent = st || dn; $("stArea").textContent = st ? dn : here().city;
    if (dn && dn !== lastArea) { lastArea = dn; var el = $("areaName"); el.querySelector("b").textContent = dn; el.querySelector("span").textContent = here().city; el.classList.remove("show"); void el.offsetWidth; el.classList.add("show"); }
  }
  /* turn-by-turn card */
  function navTick() {
    var el = $("nav"); if (!G.wp) { el.hidden = true; return; }
    var px = P.mode === "car" ? taxi.x : P.x, pz = P.mode === "car" ? taxi.z : P.z, dist = Math.hypot(G.wp.x - px, G.wp.z - pz), far = ROUTE && routeLen ? routeLen : dist;
    el.hidden = false; $("wpChip").hidden = true;
    var fmt = function (m) { return m >= 1000 ? (m / 1000).toFixed(1) + " km" : Math.max(5, Math.round(m / 5) * 5) + " m"; };
    var kind = "up", txt = "Head to " + G.wp.t, dd = far;
    if (far < 25) { kind = "flag"; txt = "Arriving at " + G.wp.t; dd = far; }
    else if (routeTurn && routeTurn.d < 400) { var a = Math.abs(routeTurn.dir); kind = a > 2.4 ? "uturn" : routeTurn.dir > 0 ? (a < 1.0 ? "sleft" : "left") : (a < 1.0 ? "sright" : "right"); dd = routeTurn.d; txt = (kind === "uturn" ? "Make a U-turn" : (a < 1.0 ? "Keep " : "Turn ") + (routeTurn.dir > 0 ? "left" : "right")) + (routeTurn.n ? " onto " + routeTurn.n : ""); }
    else if (ROUTE) { txt = "Continue" + (ROUTE[1] && ROUTE[1][2] ? " on " + ROUTE[1][2] : "") + " · " + G.wp.t; dd = routeTurn ? routeTurn.d : far; }
    $("navIc").className = "nav-ic " + kind; $("navD").textContent = fmt(dd); $("navS").textContent = txt;
    var sp = P.mode === "car" ? (taxi.m.userData.boat ? 10 : 11) : 1.45, mins = Math.max(1, Math.round(far / sp / 60));
    $("navT").textContent = fmt(far); $("navE").textContent = mins + " min";
  }

  /* real places become the game's workplaces and services */
  var CPLACES = [
    { id: "grocery", zone: "grocery", t: ["shop:supermarket", "shop:convenience", "shop:greengrocer"], fn: "Supermarket" },
    { id: "agency", zone: "agency", t: [], fn: "Travel agency · by the airport", rename: "Global Travel", fixed: [56, -10.2], face: Math.PI },
    { id: "cityhall", zone: "cityhall", t: ["townhall", "courthouse", "library"], fn: "City Hall · land office" },
    { id: "work", zone: "job:office", t: ["office"], fn: "Offices" },
    { id: "bank", zone: "job:bank", t: ["bank"], fn: "Bank" },
    { id: "hotel", zone: "job:hotel", t: ["hotel"], fn: "Hotel" },
    { id: "diner", zone: "job:diner", t: ["restaurant", "fast_food"], fn: "Restaurant", eat: true },
    { id: "hospital", zone: "job:hospital", t: ["hospital", "clinic", "doctors"], fn: "Hospital" },
    { id: "school", zone: "job:school", t: ["school", "college", "university"], fn: "School" },
    { id: "cafe", zone: "job:cafe", t: ["cafe"], fn: "Cafe" },
    { id: "tech", zone: "job:tech", t: ["office", "college", "university"], fn: "Tech offices" },
    { id: "police", zone: "police", t: ["police"], fn: "Police" },
    { id: "landmark", zone: null, t: ["attraction", "museum", "place_of_worship", "artwork", "theatre"], fn: "Landmark" }
  ];
  var cityPlaces = {}, doorMarks = [];
  function labelSprite(text, sub) {
    var c = document.createElement("canvas"); c.width = 512; c.height = 128; var g = c.getContext("2d");
    g.fillStyle = "rgba(8,10,8,0.82)"; var r = 22; g.beginPath(); g.moveTo(r, 0); g.arcTo(512, 0, 512, 128, r); g.arcTo(512, 128, 0, 128, r); g.arcTo(0, 128, 0, 0, r); g.arcTo(0, 0, 512, 0, r); g.fill();
    g.fillStyle = "#ff3d8b"; g.fillRect(0, 0, 10, 128);
    g.fillStyle = "#ffffff"; g.font = "800 44px Unbounded, Arial, sans-serif"; g.textBaseline = "middle"; var t = text.length > 18 ? text.slice(0, 17) + "…" : text; g.fillText(t, 30, 50);
    g.fillStyle = "#ff3d8b"; g.font = "600 26px 'JetBrains Mono', monospace"; g.fillText(sub.toUpperCase(), 30, 98);
    var tx = new THREE.CanvasTexture(c); tx.encoding = THREE.sRGBEncoding;
    var s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tx, depthWrite: false, transparent: true })); s.scale.set(4.6, 1.15, 1); return s;
  }
  function assignPlaces(ov) {
    var used = [], old = {};
    PLACES.forEach(function (p) { old[p.id] = [p.x, p.z]; });
    CPLACES.forEach(function (cp) {
      var best = cp.fixed ? { x: cp.fixed[0] - CITY_OX, z: cp.fixed[1] - CITY_OZ, t: "fixed" } : null, bd = cp.fixed ? -1 : 1e9;
      ov.poi.forEach(function (p) {
        if (cp.t.indexOf(p.t) < 0) return;
        var d = Math.hypot(p.x, p.z) + cp.t.indexOf(p.t) * 120; if (d > bd) return;
        if (used.some(function (u) { return Math.hypot(u.x - p.x, u.z - p.z) < 30; })) return;
        bd = d; best = p;
      });
      if (cp.fixed) { /* our own building next to the airport */ }
      else if (!best) { var a = Math.random() * 6.28, rr = 120 + Math.random() * 200; best = { x: Math.cos(a) * rr, z: Math.sin(a) * rr, t: "office" }; }
      if (!cp.fixed) used.push(best);
      var wx = best.x + CITY_OX, wz = best.z + CITY_OZ, nm = cp.rename || best.n || cp.fn;
      var pl = cityPlaces[cp.id] = { cp: cp, x: wx, z: wz, name: nm, fn: cp.fn, resolved: !!cp.fixed, face: cp.face, poi: best };
      var pp = PLACES.filter(function (q) { return q.id === cp.id; })[0];
      if (pp) { pp.x = wx; pp.z = wz; pp.t = nm; pp.d = cp.fn; }
      if (cp.zone) ZONES.forEach(function (z) { if (z.id === cp.zone && z.w) { z.w.x = wx; z.w.z = wz; z.w.t = nm; } });
      if (cp.id !== "landmark") ZONES.push({ id: "door:" + cp.id, x: wx, z: wz, r: 2.2 });
      var ls = labelSprite(nm, cp.fn); ls.position.set(wx, 4.2, wz); scene.add(ls); pl.label = ls;
      var ring = new THREE.Mesh(new THREE.RingGeometry(0.9, 1.15, 32), new THREE.MeshBasicMaterial({ color: 0xff3d8b, transparent: true, opacity: 0.85, depthWrite: false, side: THREE.DoubleSide }));
      ring.rotation.x = -Math.PI / 2; ring.position.set(wx, 0.12, wz); ring.visible = !!cp.zone; scene.add(ring); pl.ring = ring; doorMarks.push(pl);
    });
    /* missions that pointed at old places now point at the real ones */
    MISSIONS.forEach(function (m) { m.steps.forEach(function (s) { ["go", "at"].forEach(function (k) { var v = s[k]; if (!v || typeof v === "string") return; Object.keys(old).forEach(function (id) { if (cityPlaces[id] && Math.hypot(old[id][0] - v[0], old[id][1] - v[1]) < 4) { s[k] = [cityPlaces[id].x, cityPlaces[id].z]; s[k].pid = id; } }); }); }); });
    var inner = {}; Object.keys(PLACE_INT).forEach(function (k) { PLACE_INT[k].slice(1).forEach(function (z) { inner[z] = 1; }); }); ["grocery", "agency", "cityhall", "diner", "police"].forEach(function (z) { inner[z] = 1; });
    ZONES.forEach(function (z) { if (inner[z.id]) { z.x = 99999; z.z = 99999; } });
  }
  /* put each door on the building edge facing the street */
  function resolveDoors() {
    Object.keys(cityPlaces).concat(["home"]).forEach(function (id) {
      var pl = id === "home" ? HOME : cityPlaces[id]; if (!pl || pl.resolved || !CITY) return;
      if (Math.hypot(pl.x - P.x, pl.z - P.z) > 520) return;
      var b = pl.bld || CITY.buildingAt(pl.x, pl.z), road = CITY.nearestRoad(pl.x, pl.z, 160);
      if (!road && CITY.pending()) return;
      var dx = pl.x, dz = pl.z;
      if (b) {
        var p = b.p, best = 1e9, bx = 0, bz = 0, tx = road ? road.x - CITY_OX : dx - CITY_OX, tz = road ? road.z - CITY_OZ : dz - CITY_OZ;
        for (var e = 0, f = p.length - 2; e < p.length; f = e, e += 2) { var x1 = p[f], z1 = p[f + 1], x2 = p[e], z2 = p[e + 1], ex = x2 - x1, ez = z2 - z1, l2 = ex * ex + ez * ez || 1, t = Math.max(0.15, Math.min(0.85, ((tx - x1) * ex + (tz - z1) * ez) / l2)), qx = x1 + ex * t, qz = z1 + ez * t, d = Math.hypot(tx - qx, tz - qz); if (d < best) { best = d; bx = qx; bz = qz; } }
        var ox = tx - bx, oz = tz - bz, ol = Math.hypot(ox, oz) || 1; dx = bx + ox / ol * 1.3 + CITY_OX; dz = bz + oz / ol * 1.3 + CITY_OZ; pl.face = Math.atan2(-ox, -oz);
        pl.bld = b;
        for (var dd = 2.5; dd <= 9 && !freeAt(dx, dz); dd += 1.5) { dx = bx + ox / ol * dd + CITY_OX; dz = bz + oz / ol * dd + CITY_OZ; }
        if (!freeAt(dx, dz) && !CITY.pending()) { var fs = freeSpot(dx, dz); if (fs) { dx = fs.x; dz = fs.z; } }
      } else if (road && road.d > 3) { dx = road.x + (pl.x - road.x) / road.d * Math.min(road.d, (road.road.w / 2 + 2.5)); dz = road.z + (pl.z - road.z) / road.d * Math.min(road.d, (road.road.w / 2 + 2.5)); }
      pl.x = dx; pl.z = dz; pl.resolved = true;
      if (pl.label) pl.label.position.set(dx, 4.2, dz); if (pl.ring) pl.ring.position.set(dx, 0.12, dz);
      ZONES.forEach(function (z) { if (z.id === "door:" + id) { z.x = dx; z.z = dz; } });
      var hp = PLACES.filter(function (q) { return q.id === id; })[0]; if (hp) { hp.x = dx; hp.z = dz; }
      if (id === "home") return;
      var cp = pl.cp;
      if (cp.zone) ZONES.forEach(function (z) { if (z.id === cp.zone && z.w) { z.w.x = dx; z.w.z = dz; } });
      MISSIONS.forEach(function (m) { m.steps.forEach(function (s) { ["go", "at"].forEach(function (k) { var v = s[k]; if (v && typeof v !== "string" && v.pid === id) { v[0] = dx; v[1] = dz; } }); }); });
    });
  }

  /* each passport holder gets a home; better passports get better homes */
  var HOME = null;
  var HOME_TIER = { Legendary: ["Sky Penthouse", 3], Epic: ["Townhouse", 2], Rare: ["Apartment", 1], Common: ["Studio apartment", 0] };
  function pickHome() {
    if (HOME || !CITY) return;
    var list = CITY.buildingsNear(CITY_OX, CITY_OZ, 420); if (list.length < 20) return;
    var tier = HOME_TIER[G.passport.job[1]] || HOME_TIER.Common, rng2 = rng(G.passport.id * 31 + 7);
    var cand = list.filter(function (b) { return tier[1] === 3 ? b.h > 20 : tier[1] === 2 ? (b.k === 0 || b.k === 6) && b.h < 14 : (b.k === 1 || b.k === 0 || b.k === 6) && b.h > 8; });
    if (!cand.length) cand = list;
    if (tier[1] === 3) cand.sort(function (a, b) { return b.h - a.h; }); else cand.sort(function (a, b) { return Math.hypot((a.x1 + a.x2) / 2, (a.z1 + a.z2) / 2) - Math.hypot((b.x1 + b.x2) / 2, (b.z1 + b.z2) / 2); });
    var b = cand[Math.floor(rng2() * Math.min(cand.length, tier[1] === 3 ? 2 : 25))];
    HOME = { x: (b.x1 + b.x2) / 2 + CITY_OX, z: (b.z1 + b.z2) / 2 + CITY_OZ, bld: b, name: tier[0], tier: tier[1], resolved: false };
    var ls = labelSprite("Your " + tier[0].toLowerCase(), "Home"); ls.position.set(HOME.x, 4.2, HOME.z); scene.add(ls); HOME.label = ls;
    var ring = new THREE.Mesh(new THREE.RingGeometry(0.9, 1.15, 32), new THREE.MeshBasicMaterial({ color: 0xff3d8b, transparent: true, opacity: 0.85, depthWrite: false, side: THREE.DoubleSide })); ring.rotation.x = -Math.PI / 2; scene.add(ring); HOME.ring = ring;
    ZONES.push({ id: "door:home", x: HOME.x, z: HOME.z, r: 2.2 });
    PLACES.unshift({ id: "home", t: "Your " + tier[0].toLowerCase(), d: "Home", b: "HM", c: "#ff3d8b", x: HOME.x, z: HOME.z });
    resolveDoors();
  }

  /* city traffic on the real road graph */
  var CT = [], PEDS = [], ctT = 0, ctId = 0;
  /* does car a have car o in its path (same lane ahead, or crossing in front at a junction)? */
  function blocks(a, o) { var dx = o.x - a.x, dz = o.z - a.z, fw = dx * a.hx + dz * a.hz, sd = Math.abs(dx * a.hz - dz * a.hx), dot = o.hx * a.hx + o.hz * a.hz; if (fw <= 0 || fw >= 14) return -1; if (dot > 0.7) return sd < 2.2 ? fw : -1; if (dot < -0.7) return sd < 1.4 ? fw : -1; return sd < 2.6 + Math.max(0, 10 - fw) * 0.3 ? fw : -1; }
  var CT_COL = [0x1f2a44, 0xd8dde4, 0x2b2b2e, 0x8a1c1c, 0x3a5a8c, 0x5e5e66, 0x0f3d3a, 0xf4f4f2, 0x7a4a2a, 0x13306b];
  function roadsNear(maxC) { var out = []; Object.keys(CITY.tiles).forEach(function (k) { CITY.tiles[k].roads.forEach(function (r) { if (r.c <= maxC && r.len > 8) out.push(r); }); }); return out; }
  function placeAgent(a) {
    var pt = CITY.pointAt(a.r, a.s), hx = pt.dx * a.dir, hz = pt.dz * a.dir, off = a.lane;
    a.x = pt.x + (-hz) * off; a.z = pt.z + hx * off; a.hx = hx; a.hz = hz;
  }
  function spawnCar() {
    var rs = roadsNear(3); if (!rs.length) return;
    for (var tries = 0; tries < 12; tries++) {
      var r = rs[Math.floor(Math.random() * rs.length)], s = Math.random() * r.len, pt = CITY.pointAt(r, s), d = Math.hypot(pt.x - P.x, pt.z - P.z);
      if (d < 60 || d > 260) continue;
      if (CT.some(function (o) { return Math.hypot(o.x - pt.x, o.z - pt.z) < 14; })) continue;
      var kinds = ["sedan", "suv", "hatch", "coupe", "sedan", "pickup", "van", "suv"], k = kinds[Math.floor(Math.random() * kinds.length)], isTaxi = Math.random() < 0.12;
      var moto = !isTaxi && Math.random() < 0.2, sporty = Math.random() < (moto ? 0.4 : 0.1), m = sporty ? (moto ? superBike([0xd11a1a, 0x1f5fa8, 0x111316, 0xf2f0ea, 0x2e7d4f][Math.floor(Math.random() * 5)]) : sportCar([0xd11a1a, 0xf2c230, 0x111111, 0x1f5fa8, 0xf4f4f2, 0xff6a00][Math.floor(Math.random() * 6)])) : moto ? motoMesh([0xc8382c, 0x13306b, 0x111316, 0xf2f0ea, 0xff3d8b, 0xe07a1f][Math.floor(Math.random() * 6)]) : carMesh(isTaxi ? 0xf2c230 : CT_COL[Math.floor(Math.random() * CT_COL.length)], k, isTaxi); scene.add(m);
      var a = { id: ++ctId, m: m, r: r, dir: r.o ? 1 : (Math.random() < 0.5 ? 1 : -1), s: s, v: 6, vmax: r.c <= 1 ? 13 : r.c === 2 ? 11 : 8, lane: r.o ? 0 : Math.max(1.4, r.w / 4), x: 0, z: 0, yaw: 0, city: true };
      if (moto) { a.rider = makeActor(Math.random() < 0.7 ? "man" : "woman"); a.rider.play("Drive"); a.vmax = Math.min(a.vmax + 2, 14); a.lane = r.o ? 0.8 : Math.max(1.0, r.w / 4 - 0.4); }
      placeAgent(a); CT.push(a); CARS.push(a); return;
    }
  }
  function dropCar(a) { if (a.rider) { removeActor(a.rider); a.rider = null; } scene.remove(a.m); CT.splice(CT.indexOf(a), 1); var i = CARS.indexOf(a); if (i >= 0) CARS.splice(i, 1); }
  function stepAgent(a, ds, maxC) {
    a.s += ds * a.dir;
    var guard = 0;
    while ((a.s > a.r.len || a.s < 0) && guard++ < 4) {
      var atNode = a.s > a.r.len ? a.r.b : a.r.a, over = a.s > a.r.len ? a.s - a.r.len : -a.s;
      var opts = CITY.next(a.r, atNode).filter(function (q) { return q.c <= maxC && !(q.o && q.b === atNode); });
      if (!opts.length) { if (a.r.o) return false; a.dir = -a.dir; a.s = a.dir > 0 ? over : a.r.len - over; continue; }
      var nr = opts[Math.floor(Math.random() * opts.length)];
      a.r = nr; a.dir = nr.a === atNode ? 1 : -1; a.s = a.dir > 0 ? over : nr.len - over; a.lane = a.city && !nr.o ? Math.max(1.4, nr.w / 4) : a.lane; if (a.city && nr.o) a.lane = 0;
    }
    return true;
  }
  function updateCity(dt) {
    streetTick(dt);
    if (!CITY || !CITY.inBounds(P.x, P.z) && Math.hypot(P.x - CITY_OX, P.z - CITY_OZ) > cityHalf + 400) { while (CT.length) dropCar(CT[0]); return; }
    ctT += dt;
    if (ctT > 0.35) { ctT = 0; if (CT.length < 26) spawnCar(); if (PEDS.length < 18) spawnPed(); resolveDoors(); pickHome(); }
    for (var i = CT.length - 1; i >= 0; i--) {
      var a = CT[i];
      if (a.jacked) continue;
      if (Math.hypot(a.x - P.x, a.z - P.z) > 330) { dropCar(a); continue; }
      var ahead = 99, lx = a.x + a.hx * 7, lz = a.z + a.hz * 7;
      for (var j = 0; j < CT.length; j++) { var o = CT[j]; if (o === a || Math.abs(o.x - a.x) > 16 || Math.abs(o.z - a.z) > 16) continue; var fw = blocks(a, o); if (fw < 0) continue; var head = Math.abs(o.hx * a.hx + o.hz * a.hz) > 0.7; if (!head && blocks(o, a) >= 0 && a.id < o.id) continue; ahead = Math.min(ahead, fw - (head ? (o.m.userData.L + a.m.userData.L) / 2 : a.m.userData.L / 2 + 1.6)); }
      var px = (P.mode === "car" ? taxi.x : P.x) - a.x, pz = (P.mode === "car" ? taxi.z : P.z) - a.z, pf = px * a.hx + pz * a.hz, psd = Math.abs(px * a.hz - pz * a.hx);
      if (pf > 0 && pf < 14 && psd < 2.4) ahead = Math.min(ahead, pf - a.m.userData.L / 2 - 1.2);
      a.stuck = a.v < 0.3 ? (a.stuck || 0) + dt : 0;
      if (a.stuck > 5 && a.stuck < 9) ahead = 99;
      if (a.stuck > 14) { var vx = (a.x - P.x) * Math.sin(cam.yaw) + (a.z - P.z) * Math.cos(cam.yaw); if (vx > 6 || Math.hypot(a.x - P.x, a.z - P.z) > 45) { dropCar(a); continue; } }
      var tv = ahead < 1.5 ? 0 : ahead < 10 ? a.vmax * (ahead - 1.5) / 8.5 : a.vmax;
      a.v += (tv - a.v) * Math.min(1, dt * (tv < a.v ? 4 : 1.2));
      if (!stepAgent(a, a.v * dt, 3)) { dropCar(a); continue; }
      placeAgent(a);
      a.yaw = Math.atan2(-a.hz, a.hx);
      a.m.position.set(a.x, 0.02, a.z); a.m.rotation.y = a.yaw;
      if (a.rider) { a.rider.g.position.set(a.x + a.hx * 0.35, 0.31, a.z + a.hz * 0.35); a.rider.g.rotation.y = Math.atan2(a.hx, a.hz); }
      a.m.userData.wheels.forEach(function (w) { w.rotation.z -= a.v * dt / a.m.userData.r; });
    }
    for (var k = PEDS.length - 1; k >= 0; k--) {
      var pd = PEDS[k];
      if (Math.hypot(pd.x - P.x, pd.z - P.z) > 170) { removeActor(pd.a); PEDS.splice(k, 1); continue; }
      if (pd.st) { if (!streetPed(pd, dt)) { removeActor(pd.a); PEDS.splice(k, 1); } continue; }
      var block = Math.hypot(P.x - pd.x, P.z - pd.z) < 1.2 && ((P.x - pd.x) * pd.hx + (P.z - pd.z) * pd.hz) > 0;
      if (pd.pause > 0) { pd.pause -= dt; pd.a.play(pd.idle || "Idle"); }
      else if (!block) { if (!stepAgent(pd, pd.sp * dt, 4)) { removeActor(pd.a); PEDS.splice(k, 1); continue; } placeAgent(pd); pd.a.play("Walk", { speed: pd.sp / 1.3 }); if (Math.random() < 0.0015) { pd.pause = 3 + Math.random() * 5; pd.idle = ["Phone", "Idle", "Talk", "FoldArms"][Math.floor(Math.random() * 4)]; } }
      else pd.a.play("Idle");
      pd.a.g.position.set(pd.x, 0.105, pd.z); pd.a.g.rotation.y = Math.atan2(pd.hx, pd.hz);
    }
  }
  function spawnPed() {
    var rs = roadsNear(3); if (!rs.length) return;
    for (var tries = 0; tries < 10; tries++) {
      var r = rs[Math.floor(Math.random() * rs.length)], s = Math.random() * r.len, pt = CITY.pointAt(r, s), d = Math.hypot(pt.x - P.x, pt.z - P.z);
      if (d < 25 || d > 140) continue;
      var a = makeActor(null), pd = { a: a, r: r, dir: Math.random() < 0.5 ? 1 : -1, s: s, sp: 1.15 + Math.random() * 0.35, lane: (Math.random() < 0.5 ? 1 : -1) * (r.w / 2 + 1.9), pause: 0, x: 0, z: 0 };
      placeAgent(pd);
      if (CITY.hit(pd.x, pd.z, 0.3)) { removeActor(a); continue; }
      PEDS.push(pd); return;
    }
  }

  /* ================= Street life: fist fights, car theft, wanted level and police ================= */
  var WANTED = 0, lastSeen = 0, COPS = [], PCARS = [], punchCd = 0, punchN = 0, copT = 0, hurtT = 0;
  if (G.hp == null) G.hp = 100;
  var jackZone = { id: "jack", x: 1e9, z: 1e9, r: 3.1, car: null }; ZONES.push(jackZone);
  function drawStars() { var h = ""; for (var i = 0; i < 5; i++) h += "<i class='" + (i < WANTED ? "on" : "") + "'>★</i>"; $("stars").innerHTML = h; $("stars").hidden = WANTED === 0; }
  function setWanted(n, why) {
    n = clamp(n, 0, 5); var up = n > WANTED; WANTED = n; lastSeen = performance.now(); drawStars();
    if (up && why) toast(why);
    if (up) sfx("wanted", n);
    if (n >= 2) missionEvent("wanted2");
  }
  function frontTarget() {
    var fx = Math.sin(P.yaw), fz = Math.cos(P.yaw), best = null, bd = 1.9;
    PEDS.concat(COPS).forEach(function (t) { if (t.st === "ko" || t.st === "getup") return; var dx = t.x - P.x, dz = t.z - P.z, d = Math.hypot(dx, dz); if (d < bd && (dx * fx + dz * fz) / (d || 1) > 0.25) { bd = d; best = t; } });
    return best;
  }
  /* ===================== Weapons, explosions, nitro, sports rides and the tank ===================== */
  var WEAP = {
    fist: { n: "FISTS" },
    pistol: { n: "PISTOL", dmg: 2, rate: 360, range: 42, clip: 36, price: 60 },
    smg: { n: "SMG", dmg: 1, rate: 105, range: 38, clip: 120, price: 150, auto: true },
    shotgun: { n: "SHOTGUN", dmg: 4, rate: 900, range: 16, clip: 24, price: 180, pellets: 5 },
    rifle: { n: "RIFLE", dmg: 3, rate: 150, range: 70, clip: 90, price: 260, auto: true },
    rpg: { n: "ROCKETS", dmg: 0, rate: 1400, range: 140, clip: 6, price: 450, rocket: true }
  };
  var WORDER = ["fist", "pistol", "smg", "shotgun", "rifle", "rpg"];
  if (!G.weapons) G.weapons = {}; if (!G.wsel || !WEAP[G.wsel]) G.wsel = "fist"; if (G.armor == null) G.armor = 0; if (G.nitro == null) G.nitro = 3;
  var FLY = null, heatZone = null;
  var fireCd = 0, firing = false, GANG = [], ROCKETS = [], FX = [], SMOKERS = [], shakeT = 0, gunMesh = null, NITRO = { t: 0, cd: 0 }, TANK = null, cannonCd = 0;
  var BURNT = new THREE.MeshStandardMaterial({ color: 0x1b1918, roughness: 1 }), SMOKE_M = new THREE.MeshStandardMaterial({ color: 0x3a3a3a, roughness: 1, transparent: true, opacity: 0.6, depthWrite: false });
  var PUFF_GEO = new THREE.SphereGeometry(1, 8, 6);
  function armed() { return G.wsel !== "fist" && G.weapons[G.wsel] > 0; }
  function weapUI() {
    if (!WEAP[G.wsel] || (G.wsel !== "fist" && !(G.weapons[G.wsel] > 0))) G.wsel = "fist";
    try { weapWidget(); } catch (e) {}
    $("bHit").textContent = G.wsel === "fist" ? "PUNCH" : WEAP[G.wsel].melee ? "SWING" : "FIRE";
    $("hAr").style.width = Math.max(0, Math.min(100, G.armor)).toFixed(0) + "%";
    $("nN").textContent = G.nitro;
    var bc = $("bChute"); if (bc) bc.innerHTML = "OPEN<small>" + (G.chute || 0) + " LEFT</small>"; document.body.classList.toggle("chuteopen", !!(P.fall && P.fall.chute));
  }
  function nextWeapon() {
    var i = WORDER.indexOf(G.wsel);
    for (var k = 1; k <= WORDER.length; k++) { var w = WORDER[(i + k) % WORDER.length]; if (w === "fist" || G.weapons[w] > 0) { G.wsel = w; break; } }
    weapUI(); toast(WEAP[G.wsel].n + (G.wsel === "fist" ? "" : " · " + G.weapons[G.wsel] + " rounds"));
  }
  function giveWeapon(w, ammo) { G.weapons[w] = (G.weapons[w] || 0) + ammo; G.wsel = w; weapUI(); save(); missionEvent("gotGun"); }

  /* ---------- gun model in the hand ---------- */
  function buildGun() {
    var g = new THREE.Group(), dk = new THREE.MeshStandardMaterial({ color: 0x1c1d1f, roughness: 0.45, metalness: 0.6 }), wood = new THREE.MeshStandardMaterial({ color: 0x5a3a24, roughness: 0.8 }), olive = new THREE.MeshStandardMaterial({ color: 0x4b5320, roughness: 0.7 });
    var V = {};
    V.bat = new THREE.Group(); var bt = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.022, 0.86, 10), wood); bt.rotation.z = Math.PI / 2; bt.position.x = 0.34; V.bat.add(bt); var kn = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 6), wood); kn.position.x = -0.08; V.bat.add(kn);
    V.pistol = new THREE.Group(); gbox(V.pistol, 0.2, 0.05, 0.035, dk, 0.06, 0, 0, true); gbox(V.pistol, 0.05, 0.11, 0.032, dk, -0.01, -0.06, 0, true);
    V.smg = new THREE.Group(); gbox(V.smg, 0.34, 0.07, 0.045, dk, 0.1, 0, 0, true); gbox(V.smg, 0.05, 0.16, 0.035, dk, 0.08, -0.1, 0, true); gbox(V.smg, 0.05, 0.1, 0.035, dk, -0.02, -0.06, 0, true);
    V.shotgun = new THREE.Group(); gbox(V.shotgun, 0.72, 0.05, 0.045, dk, 0.25, 0.02, 0, true); gbox(V.shotgun, 0.3, 0.07, 0.05, wood, -0.12, -0.01, 0, true); gbox(V.shotgun, 0.2, 0.05, 0.05, wood, 0.3, -0.03, 0, true);
    V.rifle = new THREE.Group(); gbox(V.rifle, 0.8, 0.06, 0.045, dk, 0.24, 0.01, 0, true); gbox(V.rifle, 0.05, 0.17, 0.04, dk, 0.2, -0.1, 0, true); gbox(V.rifle, 0.25, 0.09, 0.05, dk, -0.18, -0.01, 0, true);
    V.rpg = new THREE.Group(); var tb = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.05, 12), olive); tb.rotation.z = Math.PI / 2; tb.position.x = 0.2; V.rpg.add(tb); var wh = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.22, 12), olive); wh.rotation.z = -Math.PI / 2; wh.position.x = 0.83; V.rpg.add(wh);
    var chrome = new THREE.MeshStandardMaterial({ color: 0xcfd4da, roughness: 0.25, metalness: 0.9 }), steel = new THREE.MeshStandardMaterial({ color: 0xb8c0c8, roughness: 0.2, metalness: 0.95 }), red = new THREE.MeshStandardMaterial({ color: 0x8a1414, roughness: 0.5 }), tan = new THREE.MeshStandardMaterial({ color: 0x9a8156, roughness: 0.7 });
    function cyl(grp, r1, r2, L, m, x, y, z) { var c = new THREE.Mesh(new THREE.CylinderGeometry(r1, r2, L, 10), m); c.rotation.z = Math.PI / 2; c.position.set(x, y || 0, z || 0); grp.add(c); return c; }
    V.golf = new THREE.Group(); cyl(V.golf, 0.012, 0.016, 0.95, steel, 0.42); gbox(V.golf, 0.12, 0.05, 0.03, dk, 0.9, -0.02, 0, true);
    V.crowbar = new THREE.Group(); cyl(V.crowbar, 0.018, 0.018, 0.78, red, 0.33); var hk = gbox(V.crowbar, 0.1, 0.03, 0.03, red, 0.74, 0.03, 0, true); hk.rotation.z = 0.8;
    V.machete = new THREE.Group(); gbox(V.machete, 0.12, 0.035, 0.03, dk, 0.0, 0, 0, true); var bl = gbox(V.machete, 0.5, 0.07, 0.01, steel, 0.32, 0.01, 0, true);
    V.katana = new THREE.Group(); gbox(V.katana, 0.22, 0.03, 0.03, dk, 0.02, 0, 0, true); gbox(V.katana, 0.02, 0.09, 0.07, chrome, 0.14, 0, 0, true); gbox(V.katana, 0.8, 0.03, 0.006, steel, 0.55, 0.004, 0, true);
    V.revolver = new THREE.Group(); gbox(V.revolver, 0.22, 0.04, 0.03, chrome, 0.08, 0.01, 0, true); cyl(V.revolver, 0.03, 0.03, 0.06, chrome, 0.0, 0.0); gbox(V.revolver, 0.05, 0.11, 0.032, wood, -0.03, -0.06, 0, true);
    V.deagle = new THREE.Group(); gbox(V.deagle, 0.25, 0.065, 0.04, chrome, 0.07, 0, 0, true); gbox(V.deagle, 0.055, 0.12, 0.036, dk, -0.02, -0.07, 0, true);
    V.microsmg = new THREE.Group(); gbox(V.microsmg, 0.24, 0.07, 0.045, dk, 0.06, 0, 0, true); gbox(V.microsmg, 0.04, 0.14, 0.035, dk, 0.03, -0.09, 0, true);
    V.carbine = new THREE.Group(); gbox(V.carbine, 0.78, 0.055, 0.045, tan, 0.24, 0.01, 0, true); gbox(V.carbine, 0.05, 0.16, 0.04, dk, 0.2, -0.1, 0, true); gbox(V.carbine, 0.22, 0.08, 0.05, tan, -0.17, -0.01, 0, true); gbox(V.carbine, 0.14, 0.04, 0.04, dk, 0.2, 0.06, 0, true);
    V.sniper = new THREE.Group(); gbox(V.sniper, 1.05, 0.045, 0.04, dk, 0.32, 0.01, 0, true); cyl(V.sniper, 0.035, 0.035, 0.3, dk, 0.22, 0.07); gbox(V.sniper, 0.28, 0.09, 0.05, wood, -0.2, -0.01, 0, true);
    V.mg = new THREE.Group(); gbox(V.mg, 0.95, 0.07, 0.05, dk, 0.3, 0.01, 0, true); gbox(V.mg, 0.14, 0.14, 0.12, olive, 0.12, -0.08, 0, true); gbox(V.mg, 0.26, 0.09, 0.05, dk, -0.2, -0.01, 0, true);
    V.glauncher = new THREE.Group(); cyl(V.glauncher, 0.06, 0.06, 0.6, olive, 0.25); cyl(V.glauncher, 0.09, 0.09, 0.16, dk, 0.05, -0.02); gbox(V.glauncher, 0.05, 0.12, 0.04, dk, -0.02, -0.08, 0, true);
    V.minigun = new THREE.Group(); for (var mb = 0; mb < 6; mb++) { var aa = mb / 6 * Math.PI * 2; cyl(V.minigun, 0.018, 0.018, 0.85, dk, 0.42, Math.cos(aa) * 0.05, Math.sin(aa) * 0.05); } gbox(V.minigun, 0.3, 0.16, 0.16, dk, -0.02, 0, 0, true); gbox(V.minigun, 0.16, 0.16, 0.1, olive, -0.05, -0.14, 0.06, true);
    Object.keys(V).forEach(function (k) { V[k].visible = false; g.add(V[k]); }); g.userData.V = V; scene.add(g); return g;
  }
  var handW = new THREE.Vector3();
  function gunTick() {
    if (!player) return; if (!gunMesh) gunMesh = buildGun();
    var show = armed() && P.mode === "walk" && !P.swim && !INSIDE && !RIDE && !cine && !P.seat && player.g.visible;
    gunMesh.visible = show; if (!show) return;
    Object.keys(gunMesh.userData.V).forEach(function (k) { gunMesh.userData.V[k].visible = k === G.wsel; });
    var hand = player.bones.hand_r; if (hand) hand.getWorldPosition(handW); else handW.set(P.x, 1.2, P.z);
    gunMesh.position.copy(handW); gunMesh.rotation.set(0, P.yaw - Math.PI / 2, WEAP[G.wsel] && WEAP[G.wsel].melee ? 1.25 : 0);
    if (G.wsel === "rpg") { var ry = P.yaw; gunMesh.position.set(P.x - Math.cos(ry) * 0.2 + Math.sin(ry) * 0.05, standY(P.x, P.z) + 1.52, P.z + Math.sin(ry) * 0.2 + Math.cos(ry) * 0.05); }
  }
  function muzzle() { var fx = Math.sin(P.yaw), fz = Math.cos(P.yaw), len = { pistol: 0.2, smg: 0.3, shotgun: 0.62, rifle: 0.66, rpg: 0.9, revolver: 0.24, deagle: 0.26, microsmg: 0.22, carbine: 0.64, sniper: 0.95, mg: 0.78, glauncher: 0.6, minigun: 0.86 }[G.wsel] || 0.3; var p0 = gunMesh && gunMesh.visible ? gunMesh.position : new THREE.Vector3(P.x, 1.3 + standY(P.x, P.z), P.z); return new THREE.Vector3(p0.x + fx * len, p0.y + 0.02, p0.z + fz * len); }

  /* ---------- effects ---------- */
  function addFx(o) { FX.push(o); return o; }
  function tracer(a, b, col) {
    var g = new THREE.BufferGeometry().setFromPoints([a, b]), l = new THREE.Line(g, new THREE.LineBasicMaterial({ color: col || 0xffe7a0, transparent: true, opacity: 0.9 }));
    scene.add(l); addFx({ kind: "fade", m: l, t: 0, life: 0.09 });
  }
  function flash(p) {
    var s = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffd27a, transparent: true, opacity: 0.95 })); s.position.copy(p); scene.add(s); addFx({ kind: "fade", m: s, t: 0, life: 0.06 });
  }
  function puff(x, y, z, size, life, dark) {
    var m = new THREE.Mesh(PUFF_GEO, dark ? SMOKE_M.clone() : new THREE.MeshStandardMaterial({ color: 0x8a8a88, roughness: 1, transparent: true, opacity: 0.55, depthWrite: false }));
    m.position.set(x, y, z); m.scale.setScalar(size); scene.add(m);
    addFx({ kind: "smoke", m: m, t: 0, life: life, vx: (Math.random() - 0.5) * 0.8, vy: 1.2 + Math.random(), vz: (Math.random() - 0.5) * 0.8, s0: size });
  }
  function explode(x, y, z, R, byPlayer) {
    sfx("boom", [x, z]);
    var fb = new THREE.Mesh(new THREE.SphereGeometry(1, 18, 12), new THREE.MeshBasicMaterial({ color: 0xff9a2a, transparent: true, opacity: 0.95, depthWrite: false })); fb.position.set(x, y + 0.6, z); scene.add(fb);
    var core = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 10), new THREE.MeshBasicMaterial({ color: 0xfff1b0, transparent: true, opacity: 1, depthWrite: false })); core.position.copy(fb.position); scene.add(core);
    var lt = new THREE.PointLight(0xffa040, 6, R * 7, 2); lt.position.set(x, y + 2, z); scene.add(lt);
    addFx({ kind: "boom", m: fb, c: core, l: lt, t: 0, life: 0.75, R: R });
    for (var i = 0; i < 7; i++) puff(x + (Math.random() - 0.5) * R * 0.5, y + 0.8, z + (Math.random() - 0.5) * R * 0.5, 1 + Math.random() * 1.2, 2.6 + Math.random() * 1.5, true);
    var dP = Math.hypot(P.x - x, P.z - z, playerY() - y); shakeT = Math.max(shakeT, 0.6 * Math.min(1, 40 / Math.max(5, dP)));
    CT.forEach(function (a) { if (Math.hypot(a.x - x, a.z - z) < R + 1.5) explodeCar(a, true, byPlayer); });
    PCARS.forEach(function (a) { if (Math.hypot(a.x - x, a.z - z) < R + 1.5) explodeCar(a, true, byPlayer); });
    TRAFFIC.forEach(function (a) { if (Math.hypot(a.x - x, a.z - z) < R + 1.5) explodeCar(a, true, byPlayer); });
    PEDS.concat(COPS, GANG).forEach(function (t) { if (t.st !== "ko" && Math.hypot(t.x - x, t.z - z) < R) hitBy(t, 99, byPlayer); });
    if (dP < R && !(P.mode === "car" && taxi.m.userData.tank)) hurtPlayer(Math.round(45 * (1 - dP / R)) + 5);
    if (byPlayer && CITY && CITY.inBounds(x, z)) setWanted(Math.max(WANTED, 2), "Explosion reported · ★★");
  }
  function explodeCar(a, delay, byPlayer) {
    if (!a || a.burnt || a === taxi || a.boat) return; a.burnt = true; a.v = 0; if (a.vmax !== undefined) a.vmax = 0;
    setTimeout(function () {
      a.m.traverse(function (o) { if (o.isMesh) o.material = BURNT; });
      a.m.rotation.z = (Math.random() - 0.5) * 0.08;
      if (a.rider) { var r = a.rider; a.rider = null; var pd = { a: r, x: a.x + 1.6, z: a.z + 1.2, st: "ko", t: 0, hp: 0 }; r.play("KnockOut", { once: true, restart: true }); PEDS.push(pd); }
      explode(a.x, 0.4, a.z, 6, byPlayer); a.smokeT = 30; SMOKERS.push(a);
      if (byPlayer) { missionEvent("wreck"); if (G.wsel === "rpg") missionEvent("rpgWreck"); if (G.mis) { G.mis.n = (G.mis.n || 0) + 1; if (G.mis.n >= 6) missionEvent("wreck6"); if (G.mis.n >= 3) missionEvent("wreck3"); } }
      setTimeout(function () {
        if (CT.indexOf(a) >= 0) dropCar(a); else if (PCARS.indexOf(a) >= 0) dropPoliceCar(a);
        else if (TRAFFIC.indexOf(a) >= 0) { scene.remove(a.m); var nm = carMesh(CAR_COLORS[Math.floor(Math.random() * CAR_COLORS.length)], "sedan"); scene.add(nm); a.m = nm; a.burnt = false; a.vmax = 11; a.x = a.dir > 0 ? CITY_X1 - 20 : CITY_X2 + 1; }
        else { var i = CARS.indexOf(a); if (i >= 0) CARS.splice(i, 1); scene.remove(a.m); }
        var j = SMOKERS.indexOf(a); if (j >= 0) SMOKERS.splice(j, 1);
      }, 40000);
    }, delay ? 150 + Math.random() * 350 : 0);
  }
  function fxTick(dt) {
    for (var i = FX.length - 1; i >= 0; i--) {
      var f = FX[i]; f.t += dt; var k = f.t / f.life;
      if (f.kind === "fade") { f.m.material.opacity = Math.max(0, 1 - k); }
      else if (f.kind === "boom") { var s = f.R * (0.3 + 0.5 * Math.min(1, k * 2.4)); f.m.scale.setScalar(s); f.m.material.opacity = Math.max(0, 0.95 * (1 - k)); f.c.scale.setScalar(s * 0.6 * (1 - k)); f.c.material.opacity = Math.max(0, 1 - k * 1.6); f.l.intensity = Math.max(0, 6 * (1 - k * 1.3)); }
      else if (f.kind === "smoke") { f.m.position.x += f.vx * dt; f.m.position.y += f.vy * dt; f.m.position.z += f.vz * dt; f.m.scale.setScalar(f.s0 * (1 + k * 1.8)); f.m.material.opacity = Math.max(0, 0.6 * (1 - k)); }
      if (k >= 1) { scene.remove(f.m); if (f.c) scene.remove(f.c); if (f.l) scene.remove(f.l); if (f.m.geometry !== PUFF_GEO) f.m.geometry.dispose(); FX.splice(i, 1); }
    }
    SMOKERS.forEach(function (a) { a.smokeT -= dt; a.smokeAcc = (a.smokeAcc || 0) + dt; if (a.smokeT > 0 && a.smokeAcc > 0.35 && FX.length < 160) { a.smokeAcc = 0; puff(a.x + (Math.random() - 0.5), 1.2, a.z + (Math.random() - 0.5), 0.7, 2.4, true); } });
  }

  /* ---------- targets and damage ---------- */
  function weaponTarget(range, wide) {
    var fx = Math.sin(P.yaw), fz = Math.cos(P.yaw), best = null, bs = 1e9;
    function consider(t, kind) { if (t.st === "ko" || t.st === "getup" || t.burnt) return; var dx = t.x - P.x, dz = t.z - P.z, d = Math.hypot(dx, dz); if (d > range || d < 0.3) return; var dot = (dx * fx + dz * fz) / d; if (dot < (wide ? 0.2 : 0.5)) return; var sc = d * (2.2 - dot) * (kind === "car" || kind === "pcar" ? 1.6 : 1); if (sc < bs) { bs = sc; best = { t: t, kind: kind, d: d }; } }
    GANG.forEach(function (t) { consider(t, "gang"); }); COPS.forEach(function (t) { consider(t, "cop"); }); PEDS.forEach(function (t) { consider(t, "ped"); });
    CT.forEach(function (t) { consider(t, "car"); }); PCARS.forEach(function (t) { consider(t, "pcar"); });
    return best;
  }
  function hitBy(t, dmg, byPlayer) {
    var cop = COPS.indexOf(t) >= 0, gang = GANG.indexOf(t) >= 0;
    t.hp = (t.hp == null ? (cop ? 4 : 3) : t.hp) - dmg; t.t = 0;
    if (t.hp <= 0) {
      if (t.st !== "ko") { t.st = "ko"; t.a.play("KnockOut", { once: true, restart: true, fade: 0.1 }); if (byPlayer !== false) missionEvent("ko"); if (gang) { t.down = true; if (GANG.every(function (o) { return o.down; })) { missionEvent("gangDown"); toast("The gang is down"); } } if (!cop && !gang && Math.random() < 0.5) { var cash = 4 + Math.floor(Math.random() * 10); earn(cash, "Cash picked up"); } }
    } else { t.a.play("HitHead", { once: true, restart: true, fade: 0.08 }); t.stun = 0.5; if (!cop && !gang && t.st !== "fight") t.st = "flee"; if (cop) t.st = "chase"; }
    if (byPlayer !== false) { if (cop) setWanted(Math.max(WANTED + 1, 3), "Shooting at police · ★★★"); else if (!gang && WANTED === 0 && Math.random() < 0.6) setWanted(1, "Shots fired · ★"); }
  }
  function damageTarget(tg, dmg) {
    if (tg.kind === "car" || tg.kind === "pcar") { var a = tg.t; a.hp = (a.hp == null ? (tg.kind === "pcar" ? 10 : 7) : a.hp) - dmg; a.v *= 0.7; if (a.rider && Math.random() < 0.4) { a.vmax = 0; } if (a.hp <= 0) explodeCar(a, false, true); if (tg.kind === "pcar") setWanted(Math.max(WANTED, 3)); }
    else hitBy(tg.t, dmg, true);
  }
  function fireWeapon() {
    if (P.fall) { deployChute(); return; }
    if (G.wsel === "fist" || !WEAP[G.wsel]) { punch(); return; }
    if (WEAP[G.wsel].melee) { swingBat(); return; }
    if (P.mode !== "walk" || P.swim || gesture || cine || CUT || working || P.seat || RIDE || INSIDE) return;
    var w = WEAP[G.wsel], now2 = performance.now(); if (now2 < fireCd) return;
    if (!(G.weapons[G.wsel] > 0)) { toast("Out of ammo"); nextWeapon(); return; }
    fireCd = now2 + w.rate; G.weapons[G.wsel]--; skillAdd("shoot", 0.05); sfx("gun", G.wsel);
    var tg = weaponTarget(w.range, w.pellets); if (tg) P.yaw = Math.atan2(tg.t.x - P.x, tg.t.z - P.z);
    P.aimT = now2 + 1400; player.play(w.rocket ? "Aim" : "Shoot", { once: !w.rocket, restart: true, speed: w.auto ? 2.2 : 1.4, fade: 0.06 }); P.shootT = now2;
    gunTick(); var mz = muzzle(); flash(mz);
    if (w.rocket) { launchRocket(mz, P.yaw, tg, w.rs || 55, w.rr || 7, true); puff(mz.x - Math.sin(P.yaw) * 1.2, mz.y, mz.z - Math.cos(P.yaw) * 1.2, 0.6, 1.2); }
    else for (var k = 0; k < (w.pellets || 1); k++) {
      var ang = P.yaw + (Math.random() - 0.5) * (w.pellets ? 0.22 : 0.05), end;
      if (tg && (k === 0 || Math.random() < 0.55)) { end = new THREE.Vector3(tg.t.x, (tg.kind === "car" || tg.kind === "pcar" ? 0.9 : 1.2) + standY(tg.t.x, tg.t.z), tg.t.z); if (Math.random() < Math.max(0.35, 0.95 - tg.d / (w.range * 1.4)) + sk("shoot") / 250) { damageTarget(tg, w.dmg); skillAdd("shoot", 0.4); } }
      else end = new THREE.Vector3(mz.x + Math.sin(ang) * w.range, mz.y - 0.2, mz.z + Math.cos(ang) * w.range);
      tracer(mz, end);
    }
    PEDS.forEach(function (o) { if (!o.st && Math.hypot(o.x - P.x, o.z - P.z) < 35) { o.st = "flee"; o.t = 0; } });
    if (!tg && WANTED === 0 && CITY && CITY.inBounds(P.x, P.z) && Math.random() < 0.15) setWanted(1, "Shots fired · ★");
    weapUI(); if (Math.random() < 0.2) save();
  }

  /* ---------- rockets and tank shells ---------- */
  function launchRocket(from, yaw, tg, speed, R, byPlayer, dir) {
    var m = new THREE.Group(), body = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.6, 8), new THREE.MeshStandardMaterial({ color: 0x4b5320, roughness: 0.6 })); body.rotation.z = Math.PI / 2; m.add(body);
    var fl = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.5, 8), new THREE.MeshBasicMaterial({ color: 0xffb040 })); fl.rotation.z = Math.PI / 2; fl.position.x = -0.5; m.add(fl);
    var d = dir;
    if (!d) { if (tg) { var ty = (tg.kind === "car" || tg.kind === "pcar" ? 0.8 : 1.0) + standY(tg.t.x, tg.t.z); d = new THREE.Vector3(tg.t.x - from.x, ty - from.y, tg.t.z - from.z).normalize(); } else d = new THREE.Vector3(Math.sin(yaw), -0.015, Math.cos(yaw)).normalize(); }
    m.position.copy(from); m.rotation.y = Math.atan2(-d.z, d.x); scene.add(m);
    ROCKETS.push({ m: m, v: d.multiplyScalar(speed), life: 140 / speed, R: R, by: byPlayer, acc: 0 });
  }
  function rocketTick(dt) {
    for (var i = ROCKETS.length - 1; i >= 0; i--) {
      var r = ROCKETS[i], p = r.m.position; p.addScaledVector(r.v, dt); r.life -= dt; r.acc += dt;
      if (r.acc > 0.04 && FX.length < 160) { r.acc = 0; puff(p.x, p.y, p.z, 0.25, 0.8); }
      var hit = r.life <= 0 || p.y <= standY(p.x, p.z) + 0.05;
      if (!hit && CITY && CITY.hit(p.x, p.z, 0)) { var b = CITY.buildingAt(p.x, p.z); if (!b || !b.h || p.y < b.h) hit = true; }
      if (!hit) { var near = function (o, rr) { return !o.burnt && o.st !== "ko" && Math.hypot(o.x - p.x, o.z - p.z) < rr && p.y < 3.2; }; hit = CT.some(function (o) { return near(o, 2.4); }) || PCARS.some(function (o) { return near(o, 2.6); }) || TRAFFIC.some(function (o) { return near(o, 2.4); }) || PEDS.concat(COPS, GANG).some(function (o) { return near(o, 1.1); }); }
      if (!hit) for (var c = 0; c < COL.length; c++) { var q = COL[c]; if (q.on && q.tag === "bld" && p.x > q.x1 && p.x < q.x2 && p.z > q.z1 && p.z < q.z2 && p.y < 8) { hit = true; break; } }
      if (hit) { scene.remove(r.m); ROCKETS.splice(i, 1); explode(p.x, Math.max(0, p.y - 0.4), p.z, r.R, r.by); }
    }
  }

  /* ---------- gang fights ---------- */
  var GANG_SPOT = [-190, 84];
  function spawnGang(cx, cz, n) {
    sfx("gang", [cx, cz]);
    for (var i = 0; i < n; i++) {
      var a = makeActor("man", 0x8a1c1c), ang = i / n * 6.28, x = cx + Math.cos(ang) * 5, z = cz + Math.sin(ang) * 5;
      a.g.position.set(x, 0.1, z); a.play("Idle"); GANG.push({ a: a, x: x, z: z, hp: 3, st: "idle", t: 0, cd: 1 + Math.random() * 2, face: 0 });
    }
  }
  function clearGang() { GANG.forEach(function (g2) { removeActor(g2.a); }); GANG = []; }
  function gangTick(dt) {
    var m = G.mis && MIS[G.mis.id];
    if (m && m.id === "turfWar" && G.mis.step === 2 && !GANG.length && Math.hypot(P.x - GANG_SPOT[0], P.z - GANG_SPOT[1]) < 90) { spawnGang(GANG_SPOT[0], GANG_SPOT[1], 5); toast("The gang spotted you!"); }
    if (GANG.length && (!m || m.id !== "turfWar") && Math.hypot(P.x - GANG_SPOT[0], P.z - GANG_SPOT[1]) > 200) clearGang();
    var px = P.mode === "car" ? taxi.x : P.x, pz = P.mode === "car" ? taxi.z : P.z;
    GANG.forEach(function (g2) {
      g2.t += dt;
      if (g2.st === "ko") { g2.a.g.position.set(g2.x, 0.1, g2.z); return; }
      if (g2.stun > 0) { g2.stun -= dt; }
      else {
        var d = Math.hypot(px - g2.x, pz - g2.z);
        if (d > 11 && d < 80) { moveFree(g2, px, pz, 3.4, dt); g2.a.play("Jog"); }
        else if (d <= 11) { g2.face = Math.atan2(px - g2.x, pz - g2.z); g2.cd -= dt; g2.a.play("Aim");
          if (g2.cd <= 0) { g2.cd = 1.1 + Math.random() * 1.3; var from = new THREE.Vector3(g2.x + Math.sin(g2.face) * 0.5, 1.35, g2.z + Math.cos(g2.face) * 0.5), hitP = Math.random() < 0.32; tracer(from, new THREE.Vector3(px + (hitP ? 0 : (Math.random() - 0.5) * 3), 1.2, pz + (hitP ? 0 : (Math.random() - 0.5) * 3)), 0xffb070); flash(from); if (hitP && !(P.mode === "car" && taxi.m.userData.tank)) hurtPlayer(P.mode === "car" ? 3 : 7); } }
        else g2.a.play("Idle");
      }
      g2.a.g.position.set(g2.x, 0.1, g2.z); g2.a.g.rotation.y = g2.face;
    });
  }
  /* police shoot back at three stars and up */
  function heatTick() {
    if (WANTED <= 0) { heatZone = null; return; }
    var px = P.mode === "car" ? taxi.x : P.x, pz = P.mode === "car" ? taxi.z : P.z;
    if (performance.now() - lastSeen < 2500 || !heatZone) heatZone = { x: px, z: pz, r: 45 + WANTED * 22 };
  }
  function copGunTick(dt) { heatTick();
    if (WANTED < 3) return; var px = P.mode === "car" ? taxi.x : P.x, pz = P.mode === "car" ? taxi.z : P.z;
    COPS.forEach(function (c) {
      if (c.st === "ko" || c.st === "getup" || c.stun > 0) return; var d = Math.hypot(px - c.x, pz - c.z); if (d > 22 || d < 3) return;
      c.gcd = (c.gcd == null ? 1 + Math.random() * 2 : c.gcd) - dt; if (c.gcd > 0) return; c.gcd = 1.4 + Math.random() * 1.6;
      var f = Math.atan2(px - c.x, pz - c.z), from = new THREE.Vector3(c.x + Math.sin(f) * 0.5, 1.35, c.z + Math.cos(f) * 0.5), hitP = Math.random() < 0.28;
      tracer(from, new THREE.Vector3(px + (hitP ? 0 : (Math.random() - 0.5) * 3), 1.2, pz + (hitP ? 0 : (Math.random() - 0.5) * 3)), 0xa0d0ff); flash(from);
      c.a.play("Shoot", { once: true, restart: true, speed: 1.4 }); if (hitP && !(P.mode === "car" && taxi.m.userData.tank)) hurtPlayer(P.mode === "car" ? 3 : 6);
    });
  }

  /* ---------- nitro ---------- */
  function exhausts(m) { var u = m.userData; if (u.exh) return u.exh; if (u.moto) return [[-0.78, 0.45, 0.16]]; var L = u.L || 4.6; return [[-L / 2 - 0.06, 0.34, 0.42], [-L / 2 - 0.06, 0.34, -0.42]]; }
  function ensureFlames(m) {
    if (m.userData.flames) return m.userData.flames; var list = [];
    exhausts(m).forEach(function (e) {
      var g = new THREE.Group(), o = new THREE.Mesh(new THREE.ConeGeometry(0.15, 1.1, 10, 1, true), new THREE.MeshBasicMaterial({ color: 0xff7a1a, transparent: true, opacity: 0.85, depthWrite: false, blending: THREE.AdditiveBlending }));
      o.rotation.z = Math.PI / 2; o.position.x = -0.55; g.add(o);
      var inn = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.7, 10, 1, true), new THREE.MeshBasicMaterial({ color: 0x9fd8ff, transparent: true, opacity: 0.95, depthWrite: false, blending: THREE.AdditiveBlending })); inn.rotation.z = Math.PI / 2; inn.position.x = -0.35; g.add(inn);
      g.position.set(e[0], e[1], e[2]); g.visible = false; m.add(g); list.push(g);
    });
    m.userData.flames = list; return list;
  }
  function useNitro() {
    if (P.mode !== "car" || taxi.m.userData.boat || taxi.m.userData.tank || NITRO.t > 0 || NITRO.cd > 0) return;
    if (!(G.nitro > 0)) { toast("No nitro left · buy more at Arms & Auto"); return; }
    G.nitro--; NITRO.t = 2.8; NITRO.cd = 1.2; weapUI(); save(); missionEvent("nitro"); toast("NITRO!");
  }
  function nitroTick(dt) {
    if (NITRO.t > 0) NITRO.t -= dt; else if (NITRO.cd > 0) NITRO.cd -= dt;
    var on = NITRO.t > 0 && P.mode === "car";
    if (taxi.m && !taxi.m.userData.boat && !taxi.m.userData.tank && taxi.m.userData.air !== "heli" && (on || taxi.m.userData.flames)) ensureFlames(taxi.m).forEach(function (f) { f.visible = on; if (on) f.scale.set(0.7 + Math.random() * 0.7, 0.85 + Math.random() * 0.3, 0.85 + Math.random() * 0.3); });
    var fov = on ? 64 : 52; if (Math.abs(camera.fov - fov) > 0.05) { camera.fov = lerp(camera.fov, fov, Math.min(1, dt * 4)); camera.updateProjectionMatrix(); }
    $("dN").classList.toggle("on", on); $("dN").disabled = !(G.nitro > 0) && !on;
  }

  /* ---------- sports car, superbike and the tank ---------- */
  function sportCar(color) {
    var m = carMesh(color, "sport"), L = m.userData.L, W = m.userData.W, cf = new THREE.MeshPhysicalMaterial({ color: 0x111214, metalness: 0.4, roughness: 0.35, clearcoat: 1 }), chrome = new THREE.MeshStandardMaterial({ color: 0xd0d4d8, metalness: 0.9, roughness: 0.2 });
    var wing = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.05, W - 0.1), cf); wing.position.set(-L / 2 + 0.25, 1.22, 0); m.add(wing);
    [-1, 1].forEach(function (sd) { var st = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.3, 0.06), cf); st.position.set(-L / 2 + 0.3, 1.05, sd * (W / 2 - 0.35)); m.add(st); var ex = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 0.24, 10), chrome); ex.rotation.z = Math.PI / 2; ex.position.set(-L / 2 - 0.02, 0.34, sd * 0.42); m.add(ex); var sk = new THREE.Mesh(new THREE.BoxGeometry(L * 0.5, 0.09, 0.05), cf); sk.position.set(0, 0.22, sd * (W / 2 + 0.01)); m.add(sk); });
    var spl = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.05, W - 0.05), cf); spl.position.set(L / 2 - 0.05, 0.16, 0); m.add(spl);
    m.userData.vmax = 36; m.userData.acc = 15; m.userData.sport = true; m.userData.exh = [[-L / 2 - 0.12, 0.34, 0.42], [-L / 2 - 0.12, 0.34, -0.42]]; return m;
  }
  function superBike(color) {
    var m = motoMesh(color), paint = new THREE.MeshPhysicalMaterial({ color: color, metalness: 0.5, roughness: 0.28, clearcoat: 1 }), dk = new THREE.MeshStandardMaterial({ color: 0x111316, roughness: 0.5 }), smoke = new THREE.MeshStandardMaterial({ color: 0x2a3a48, transparent: true, opacity: 0.6, roughness: 0.1 });
    var cowl = new THREE.Mesh(new THREE.SphereGeometry(0.3, 16, 12), paint); cowl.scale.set(1.25, 0.75, 0.68); cowl.position.set(0.56, 0.9, 0); m.add(cowl);
    var side = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.36, 0.36), paint); side.position.set(0.22, 0.62, 0); side.rotation.z = 0.15; m.add(side);
    var belly = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.16, 0.3), dk); belly.position.set(0.12, 0.36, 0); m.add(belly);
    var scr = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.02, 0.3), smoke); scr.position.set(0.58, 1.1, 0); scr.rotation.z = 0.7; m.add(scr);
    var tail = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.14, 0.22), paint); tail.position.set(-0.52, 0.82, 0); tail.rotation.z = -0.28; m.add(tail);
    var ex = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 0.36, 10), new THREE.MeshStandardMaterial({ color: 0x9aa0a6, metalness: 0.9, roughness: 0.2 })); ex.rotation.z = Math.PI / 2 + 0.3; ex.position.set(-0.68, 0.66, 0.12); m.add(ex);
    m.traverse(function (o) { if (o.isMesh) o.castShadow = true; });
    m.userData.vmax = 38; m.userData.acc = 17; m.userData.sport = true; m.userData.exh = [[-0.88, 0.72, 0.12]]; return m;
  }
  function tankMesh() {
    var g = new THREE.Group(), olive = tmat(0x4f5a2a, 0.8), dk = tmat(0x23261c, 0.9), metal = tmat(0x2a2c2e, 0.6, 0.4);
    gbox(g, 6.2, 1.0, 3.0, olive, 0, 1.15, 0); var gl = gbox(g, 1.3, 0.7, 3.0, olive, 3.35, 1.0, 0); gl.rotation.z = 0.45;
    [-1, 1].forEach(function (sd) { gbox(g, 6.9, 0.95, 0.78, dk, 0, 0.55, sd * 1.78); gbox(g, 6.6, 0.28, 0.86, olive, 0, 1.12, sd * 1.78); for (var i = 0; i < 6; i++) { var w = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.82, 14), metal); w.rotation.x = Math.PI / 2; w.position.set(-2.6 + i * 1.04, 0.48, sd * 1.78); g.add(w); } });
    var tp = new THREE.Group(); tp.position.set(-0.4, 1.65, 0);
    gbox(tp, 2.9, 0.85, 2.5, olive, 0, 0.42, 0); var hatch = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.18, 14), olive); hatch.position.set(-0.4, 0.92, 0.5); tp.add(hatch);
    var bar = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.15, 4.4, 12), olive); bar.rotation.z = Math.PI / 2; bar.position.set(3.5, 0.45, 0); tp.add(bar);
    var mb = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.42, 12), dk); mb.rotation.z = Math.PI / 2; mb.position.set(5.6, 0.45, 0); tp.add(mb);
    g.add(tp); g.traverse(function (o) { if (o.isMesh) o.castShadow = true; });
    g.userData = { L: 7, W: 3.6, r: 1, wheels: [], tank: true, vmax: 10, acc: 4, turret: tp }; return g;
  }
  /* put the player in a new ride; the current one is parked where it is */
  function swapRide(mesh, x, z, yaw) {
    if (taxi.m && !taxi.m.userData.boat && !taxi.m.userData.tank) CARS.push({ m: taxi.m, x: taxi.x, z: taxi.z, yaw: taxi.yaw, parked: true });
    else if (taxi.m && taxi.m !== mesh && (taxi.m.userData.boat || taxi.m.userData.tank)) CARS.push({ m: taxi.m, x: taxi.x, z: taxi.z, yaw: taxi.yaw, parked: true, boat: !!taxi.m.userData.boat });
    taxi.m = mesh; taxi.x = x; taxi.z = z; taxi.yaw = yaw; taxi.v = 0;
  }
  function tankTurretTick(dt) {
    if (!taxi.m || !taxi.m.userData.tank || P.mode !== "car") return; var tp = taxi.m.userData.turret;
    var vx = -Math.sin(cam.yaw), vz = -Math.cos(cam.yaw), th = Math.atan2(-vz, vx), want = wrapA(th - taxi.yaw);
    tp.rotation.y += clamp(wrapA(want - tp.rotation.y), -1.4 * dt, 1.4 * dt);
  }
  function fireCannon() {
    if (P.mode === "car") sfx("cannon");
    if (inAir()) { airFire(); return; }
    if (P.mode !== "car" || !taxi.m.userData.tank) return; var now2 = performance.now(); if (now2 < cannonCd) return; cannonCd = now2 + 1500;
    var tp = taxi.m.userData.turret, a = taxi.yaw + tp.rotation.y, tipL = 5.9, ox = -0.4, y = groundY(taxi.x, taxi.z) + 2.1;
    var fx = Math.cos(a), fz = -Math.sin(a), bx = taxi.x + Math.cos(taxi.yaw) * ox + fx * tipL, bz = taxi.z - Math.sin(taxi.yaw) * ox + fz * tipL;
    var from = new THREE.Vector3(bx, y, bz); flash(from); puff(bx, y, bz, 1.2, 1.4);
    launchRocket(from, 0, null, 95, 8, true, new THREE.Vector3(fx, -0.02, fz).normalize()); shakeT = Math.max(shakeT, 0.25);
  }

  /* ---------- Arms & Auto shop, army depot, pickups ---------- */
  var SHOP_Z = { x: -117, z: 11.9 }, DEPOT = { x1: -152, x2: -104, z1: 44, z2: 84 };
  (function buildShopAndDepot() {
    var g = new THREE.Group(), x1 = -128, x2 = -106, z1 = 13, z2 = 29, cx = (x1 + x2) / 2;
    gbox(g, x2 - x1, 6.5, z2 - z1, tmat(0x2a2d31, 0.7), cx, 3.25, (z1 + z2) / 2); gbox(g, x2 - x1 + 0.4, 0.4, z2 - z1 + 0.4, tmat(0xc0392b, 0.5), cx, 6.7, (z1 + z2) / 2);
    gbox(g, 8, 2.6, 0.08, GLASS_T, cx - 4, 1.7, z1 - 0.05, true); gbox(g, 2.2, 2.6, 0.1, DARK_T, cx + 3.5, 1.3, z1 - 0.06, true);
    gsign(g, "ARMS & AUTO", 12, 1.6, cx, 4.8, z1 - 0.1, Math.PI, { w: 1024, h: 140, bg: "#c0392b", fg: "#ffffff", size: 96, sub: "GUNS  ·  ARMOR  ·  NITRO  ·  FAST RIDES", subfg: "#111" });
    scene.add(g); solid(x1, x2, z1, z2, "bld");
    plane(22, 8, M.asphalt, cx, 0.02, z2 + 6);
    ZONES.push({ id: "armsShop", x: SHOP_Z.x, z: SHOP_Z.z, r: 2.2 });
    PLACES.push({ id: "arms", t: "Arms & Auto", d: "Guns, armor, nitro, sports rides", b: "AA", c: "#c0392b", x: SHOP_Z.x, z: SHOP_Z.z });
    /* army depot */
    var d = new THREE.Group(), fence = tmat(0x8e979e, 0.5, 0.5), olive = tmat(0x4f5a2a, 0.8), D = DEPOT;
    gbox(d, D.x2 - D.x1, 0.06, D.z2 - D.z1, tmat(0x9a968c, 0.95), (D.x1 + D.x2) / 2, 0.03, (D.z1 + D.z2) / 2, true);
    function fenceRun(ax, az, bx2, bz2) { var L = Math.hypot(bx2 - ax, bz2 - az); var f = gbox(d, L, 2.6, 0.08, new THREE.MeshStandardMaterial({ color: 0x9aa3aa, transparent: true, opacity: 0.45, roughness: 0.6 }), (ax + bx2) / 2, 1.3, (az + bz2) / 2, true); f.rotation.y = -Math.atan2(bz2 - az, bx2 - ax); for (var t = 0; t <= L; t += 4) gbox(d, 0.12, 2.8, 0.12, fence, ax + (bx2 - ax) * t / L, 1.4, az + (bz2 - az) * t / L, true); solid(Math.min(ax, bx2) - 0.1, Math.max(ax, bx2) + 0.1, Math.min(az, bz2) - 0.1, Math.max(az, bz2) + 0.1); }
    fenceRun(D.x1, D.z1, -134, D.z1); fenceRun(-122, D.z1, D.x2, D.z1); fenceRun(D.x1, D.z2, D.x2, D.z2); fenceRun(D.x1, D.z1, D.x1, D.z2); fenceRun(D.x2, D.z1, D.x2, D.z2);
    gbox(d, 2.4, 2.6, 2.4, tmat(0xd8d4c8, 0.8), -136.5, 1.3, D.z1 + 2.2); gbox(d, 2.6, 0.2, 2.6, olive, -136.5, 2.7, D.z1 + 2.2); solid(-137.7, -135.3, D.z1 + 1, D.z1 + 3.4);
    gsign(d, "ARMY DEPOT · RESTRICTED", 8, 0.9, -128, 3.4, D.z1 - 0.1, Math.PI, { w: 1024, h: 116, bg: "#4f5a2a", fg: "#ffffff", size: 66 });
    gbox(d, 0.25, 3.2, 0.25, fence, -134, 1.6, D.z1); gbox(d, 0.25, 3.2, 0.25, fence, -122, 1.6, D.z1); gbox(d, 12.2, 0.3, 0.3, olive, -128, 3.0, D.z1);
    for (var i = 0; i < 6; i++) gbox(d, 1.1, 0.45, 0.6, tmat(0xb8a77a, 1), -146 + i * 1.15, 0.23 + (i % 2) * 0.0, D.z1 + 6);
    for (var j = 0; j < 5; j++) gbox(d, 1.1, 0.45, 0.6, tmat(0xb8a77a, 1), -145.4 + j * 1.15, 0.68, D.z1 + 6);
    var pole = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 9, 8), fence); pole.position.set(-147, 4.5, D.z1 + 10); d.add(pole); gbox(d, 1.8, 1.1, 0.03, tmat(0x2e5a2e, 0.8), -146.05, 8.3, D.z1 + 10, true);
    [[-114, 56, 0x4f5a2a], [-114, 66, 0x4f5a2a]].forEach(function (c) { var t = carMesh(c[2], "truck"); t.position.set(c[0], 0, c[1]); t.rotation.y = Math.PI / 2; scene.add(t); CARS.push({ m: t, x: c[0], z: c[1], yaw: Math.PI / 2, parked: true }); });
    for (var k = 0; k < 4; k++) gbox(d, 1.4, 1.2, 1.4, tmat(0x5a6230, 0.9), -148 + (k % 2) * 1.5, 0.6 + Math.floor(k / 2) * 1.2, D.z2 - 4);
    scene.add(d);
    var tm = tankMesh(); TANK = { m: tm, x: -128, z: 66, yaw: Math.PI / 2, home: true }; tm.position.set(TANK.x, 0, TANK.z); tm.rotation.y = TANK.yaw; scene.add(tm); CARS.push(TANK);
    ZONES.push(TANK.zone = { id: "tank", x: TANK.x, z: TANK.z + 2.6, r: 3 });
    PLACES.push({ id: "depot", t: "Army Depot", d: "A tank is parked here", b: "AD", c: "#7a8a3a", x: -128, z: 46 });
  })();
  var PICKUPS = [];
  function addPickup(kind, x, z) {
    var g = new THREE.Group(), col = kind === "armor" ? 0x3a7bd5 : kind === "health" ? 0xe04040 : 0xff3d8b;
    var ring = new THREE.Mesh(new THREE.TorusGeometry(0.55, 0.05, 8, 24), new THREE.MeshBasicMaterial({ color: col })); ring.rotation.x = Math.PI / 2; ring.position.y = 0.08; g.add(ring);
    var icon = kind === "armor" ? new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.6, 0.18), new THREE.MeshStandardMaterial({ color: col, emissive: col, emissiveIntensity: 0.35 })) : kind === "health" ? new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 0.2), new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: col, emissiveIntensity: 0.25 })) : null;
    if (!icon) { icon = buildGunIcon(kind); } icon.position.y = 1.0; g.add(icon);
    g.position.set(x, standY(x, z), z); scene.add(g); PICKUPS.push({ kind: kind, g: g, icon: icon, x: x, z: z, t: 0 });
  }
  function buildGunIcon(kind) { if (!gunMesh) gunMesh = buildGun(); var v = gunMesh.userData.V[kind].clone(); v.visible = true; v.scale.setScalar(2.2); return v; }
  function pickupTick(dt, t) {
    PICKUPS.forEach(function (p) {
      if (p.t > 0) { p.t -= dt; p.g.visible = p.t <= 0; return; }
      p.icon.rotation.y += dt * 1.6; p.icon.position.y = 1.0 + Math.sin(t * 2 + p.x) * 0.12;
      if (P.mode === "walk" && Math.hypot(P.x - p.x, P.z - p.z) < 1.4) {
        p.t = 180; p.g.visible = false;
        if (p.kind === "armor") { G.armor = 100; toast("Body armor picked up"); } else if (p.kind === "health") { G.hp = 100; toast("Health restored"); }
        else { giveWeapon(p.kind, WEAP[p.kind].clip); toast(WEAP[p.kind].n + " picked up"); }
        weapUI(); save();
      }
    });
  }
  var pickupsCity = false;
  function placeCityPickups() {
    if (pickupsCity || !HOME || !HOME.resolved || !CITY || CITY.pending()) return; pickupsCity = true;
    var f = freeSpot(HOME.x + 6, HOME.z + 6); if (f) addPickup("pistol", f.x, f.z);
    var c2 = cityPlaces.bank; if (c2) { var f2 = freeSpot(c2.x + 8, c2.z - 6); if (f2) addPickup("smg", f2.x, f2.z); }
    var c3 = cityPlaces.police; if (c3) { var f3 = freeSpot(c3.x - 6, c3.z + 6); if (f3) addPickup("armor", f3.x, f3.z); }
  }
  addPickup("rifle", -196, 74); addPickup("health", -118, 38); addPickup("rpg", -148, 80); addPickup("shotgun", 30, 40); addPickup("armor", -60, 30);

  function armsShop() {
    var items = [["pistol", "Pistol + 36 rounds", 60], ["smg", "SMG + 120 rounds", 150], ["shotgun", "Shotgun + 24 shells", 180], ["rifle", "Rifle + 90 rounds", 260], ["rpg", "Rocket launcher + 6 rockets", 450], ["armor", "Body armor", 50], ["health", "First aid kit", 20], ["nitro", "Nitro x3 (for cars and bikes)", 60], ["sportcar", "Sports car, delivered outside", 350], ["superbike", "Superbike, delivered outside", 250]];
    var html = "<div><div class='eyebrow'>Arms & Auto</div><h2>What do you need?</h2></div><div class='row' style='flex-direction:column;gap:7px;max-height:52vh;overflow:auto'>";
    items.forEach(function (it, i) { html += "<button class='btn" + (G.balance < it[2] ? " ghost" : "") + "' type='button' data-buy='" + i + "'" + (G.balance < it[2] ? " disabled" : "") + ">" + it[1] + " · " + it[2] + " TOKEN</button>"; });
    html += "<button class='btn ghost' id='mClose' type='button'>Close</button></div><p class='note'>You have " + tok(G.balance) + ". Armor " + Math.round(G.armor) + " · Nitro " + G.nitro + ".</p>";
    modal(html);
    Array.prototype.forEach.call($("sheet").querySelectorAll("[data-buy]"), function (b) { b.addEventListener("click", function () {
      var it = items[+b.getAttribute("data-buy")]; if (G.balance < it[2]) { toast("Not enough TOKEN"); return; }
      spend(it[2], "Arms & Auto · " + it[1]); var k = it[0];
      if (WEAP[k]) giveWeapon(k, WEAP[k].clip); else if (k === "armor") G.armor = 100; else if (k === "health") G.hp = 100; else if (k === "nitro") G.nitro = Math.min(12, G.nitro + 3);
      else if (k === "sportcar" || k === "superbike") { var m = k === "sportcar" ? sportCar([0xd11a1a, 0xf2c230, 0x111111, 0x1f5fa8, 0xf4f4f2][Math.floor(Math.random() * 5)]) : superBike([0xd11a1a, 0x1f5fa8, 0x111316, 0xf2f0ea, 0x2e7d4f][Math.floor(Math.random() * 5)]); scene.add(m); swapRide(m, -117, 35, 0); setWaypoint(-117, 35, k === "sportcar" ? "Your sports car" : "Your superbike"); missionEvent("sporty"); toast("Your new ride is parked outside"); }
      weapUI(); save(); closeModal(); toast("Bought: " + it[1]);
    }); });
  }
  function stealTank() {
    if (!TANK || P.mode !== "walk") return;
    var i = CARS.indexOf(TANK); if (i >= 0) CARS.splice(i, 1);
    swapRide(TANK.m, TANK.x, TANK.z, TANK.yaw); TANK.zone.x = 99999; TANK.home = false;
    enterTaxi(); cam.tdist = 14; cam.pitch = 0.36; setWanted(Math.max(WANTED, 4), "A tank was stolen! ★★★★"); missionEvent("tank"); toast("Tank! Press FIRE to use the cannon");
  }
  function combatTick(dt, t) {
    airportTick(); gunTick(); fxTick(dt); rocketTick(dt); gangTick(dt); copGunTick(dt); nitroTick(dt); tankTurretTick(dt); pickupTick(dt, t); placeCityPickups();
    if (firing && WEAP[G.wsel] && WEAP[G.wsel].auto) fireWeapon();
    if (P.mode === "walk" && armed() && P.aimT > performance.now() && P.v < 0.3 && !gesture) player.play(performance.now() - (P.shootT || 0) < 250 ? "Shoot" : "Aim", { fade: 0.08 });
    document.body.classList.toggle("intank", P.mode === "car" && !!taxi.m.userData.tank);
    if (shakeT > 0) { shakeT -= dt; camera.position.x += (Math.random() - 0.5) * shakeT * 0.6; camera.position.y += (Math.random() - 0.5) * shakeT * 0.6; }
  }

  /* ===================== Weapon widget (top-right) and the full-screen shop ===================== */
  var WICON = {
    fist: "<path d='M18 9h22a6 6 0 0 1 6 6v6a7 7 0 0 1-7 7H22a9 9 0 0 1-9-9v-5a5 5 0 0 1 5-5z'/><path d='M24 9v8M31 9v8M38 9v8' stroke='#120a24' stroke-width='1.6'/>",
    bat: "<path d='M8 27 52 6a3.2 3.2 0 0 1 3 5.6L13 31a3 3 0 0 1-5-4z'/><circle cx='9' cy='29' r='2.6'/>",
    pistol: "<path d='M10 9h40v8H32l-2 4h-6l-2.5 10h-9l3.5-14H10z'/>",
    smg: "<path d='M4 9h46v7H38v13h-6v-8h-6l-2 8h-8l3-11H4z'/><path d='M2 11h3v4H2z'/>",
    shotgun: "<path d='M2 10h59v5H31l-2 3H17l-8 8H2l6-11H2z'/>",
    rifle: "<path d='M2 9h56v6H42l-3 11h-6l1-11H24l-6 11H7l6-11H2z'/><path d='M30 5h10v3H30z'/>",
    rpg: "<path d='M2 12h44l12-5v18l-12-5H2z'/><path d='M18 19h5v8h-5zM30 19h5v6h-5z'/>",
    golf: "<path d='M12 27 52 5l2 3-40 22z'/><path d='M4 25h11l2 6H3z'/>",
    crowbar: "<path d='M8 26 48 8c4-2 8 0 9 3l-3 1c-1-2-3-2-5-1L10 30z'/>",
    machete: "<path d='M20 17 58 5c3 4 1 9-4 10L22 24z'/><path d='M4 19h17v7H4z'/>",
    katana: "<path d='M18 19 62 4l1 2-44 17z'/><path d='M14 15h4v11h-4z'/><path d='M2 19h12v4H2z'/>",
    revolver: "<path d='M8 9h34v6H28l-1 2h-8l-3 14H7l3-14H8z'/><circle cx='24' cy='14' r='5'/>",
    deagle: "<path d='M6 8h44v9H30l-2 3h-6l-3 11H8l3-14H6z'/>",
    microsmg: "<path d='M8 10h36v7H34v12h-6v-7h-5l-2 7h-7l3-12H8z'/>",
    carbine: "<path d='M2 10h54v5H40l-3 10h-6l1-10H22l-5 10H8l5-10H2z'/><path d='M28 6h8v3h-8z'/>",
    sniper: "<path d='M0 12h60v4H40l-2 9h-6l1-9H22l-6 9H6l6-9H0z'/><path d='M22 5h16v5H22z'/>",
    mg: "<path d='M2 9h58v6H44l-3 10h-7l1-10H26l-2 6h-8l2-6H2z'/><path d='M24 15h10v10H24z'/>",
    glauncher: "<path d='M4 10h46v8H34v8h-8l-2-4H14l-3 6H4l3-10H4z'/><circle cx='22' cy='20' r='6'/>",
    minigun: "<path d='M4 8h44v4H4zM4 13h44v4H4zM4 18h44v4H4z'/><path d='M46 6h10v18H46z'/><path d='M30 22h8v8h-8z'/>"
  };
  function wIcon(k, col) { return "<svg viewBox='0 0 64 34' fill='" + (col || "currentColor") + "'>" + (WICON[k] || WICON.fist) + "</svg>"; }
  WEAP.bat = { n: "BAT", melee: true, dmg: 2, rate: 620, range: 2.1, clip: 1, price: 40 };
  Object.assign(WEAP, {
    golf: { n: "GOLF CLUB", melee: true, dmg: 2, rate: 560, range: 2.2, clip: 1 }, crowbar: { n: "CROWBAR", melee: true, dmg: 2, rate: 520, range: 2.0, clip: 1 },
    machete: { n: "MACHETE", melee: true, dmg: 3, rate: 600, range: 2.1, clip: 1 }, katana: { n: "KATANA", melee: true, dmg: 4, rate: 470, range: 2.5, clip: 1 },
    revolver: { n: "REVOLVER", dmg: 4, rate: 700, range: 50, clip: 24 }, deagle: { n: ".50 HAWK", dmg: 5, rate: 520, range: 55, clip: 28 },
    microsmg: { n: "MICRO SMG", dmg: 1, rate: 85, range: 30, clip: 140, auto: true }, carbine: { n: "CARBINE", dmg: 3, rate: 125, range: 80, clip: 100, auto: true },
    sniper: { n: "SNIPER", dmg: 10, rate: 1300, range: 160, clip: 20 }, mg: { n: "COMBAT MG", dmg: 3, rate: 90, range: 70, clip: 200, auto: true },
    glauncher: { n: "GRENADES", dmg: 0, rate: 1000, range: 90, clip: 10, rocket: true, rs: 34, rr: 6 }, minigun: { n: "MINIGUN", dmg: 2, rate: 45, range: 60, clip: 500, auto: true }
  });
  WORDER = ["fist", "bat", "golf", "crowbar", "machete", "katana", "pistol", "revolver", "deagle", "microsmg", "smg", "shotgun", "rifle", "carbine", "sniper", "mg", "rpg", "glauncher", "minigun"];
  function ammoText(k) { if (k === "fist") return "HANDS"; if (WEAP[k] && WEAP[k].melee) return "MELEE"; return (G.weapons[k] || 0) + " / " + WEAP[k].clip * 4; }
  function weapWidget() {
    var k = G.wsel; $("wIc").innerHTML = wIcon(k); $("wAm").textContent = ammoText(k); $("wNm").textContent = WEAP[k] ? WEAP[k].n : "FISTS";
  }
  function prevWeapon() { var i = WORDER.indexOf(G.wsel); for (var k = 1; k <= WORDER.length; k++) { var w = WORDER[(i - k + WORDER.length * 2) % WORDER.length]; if (w === "fist" || G.weapons[w] > 0) { G.wsel = w; break; } } weapUI(); }
  /* melee swing with the bat */
  function swingBat() {
    if (P.mode !== "walk" || gesture || cine || CUT || P.seat || working || performance.now() < punchCd) return;
    var MW = WEAP[G.wsel] && WEAP[G.wsel].melee ? WEAP[G.wsel] : WEAP.bat; punchCd = performance.now() + MW.rate; punchN++;
    var t0 = frontTarget(); if (t0) P.yaw = Math.atan2(t0.x - P.x, t0.z - P.z); sfx("punch", t0);
    doGesture(0.6, null, punchN % 2 ? "Cross" : "Jab", { passport: false, speed: 1.15 });
    setTimeout(function () { var t = frontTarget(); if (t) { t.hp = (t.hp == null ? 3 : t.hp) - Math.max(1, MW.dmg - 1); hitTarget(t); skillAdd("strength", 0.4); } }, 260);
  }

  /* ---------- catalogue ---------- */
  var RAR = { Common: "#8e8e9a", Uncommon: "#2ecc71", Rare: "#2f8cff", Epic: "#a855f7", Legendary: "#ffb020" };
  var SVG_CAR = "<path d='M6 22l5-9a5 5 0 0 1 4-2h28a5 5 0 0 1 4 2l7 9h3v8h-5a5 5 0 0 1-10 0H22a5 5 0 0 1-10 0H5v-8z'/>";
  var SVG_SUPER = "<path d='M2 31l9-6 15-5h14l13 6 9 2v6h-5a5 5 0 0 1-10 0H22a5 5 0 0 1-10 0H2z'/><path d='M44 18h14v3H44z'/>";
  var SVG_BIKE = "<circle cx='14' cy='24' r='7' fill='none' stroke='currentColor' stroke-width='4'/><circle cx='50' cy='24' r='7' fill='none' stroke='currentColor' stroke-width='4'/><path d='M14 24 26 12h12l12 12M30 12l-4-5h-6'/>";
  var SVG_BOAT = "<path d='M4 20h56l-8 10H12zM18 20l6-10h16l8 10z'/>";
  var SVG_HELI = "<path d='M4 8h56v3H4z'/><path d='M30 11h4v5h-4z'/><path d='M14 18c4-3 14-3 22 0l6 6h14v4H42c0 6-6 9-14 9h-6c-6 0-10-4-10-10 0-4 1-7 2-9z'/><path d='M14 42h28v3H14z'/><path d='M20 37h3v5h-3zM34 37h3v5h-3z'/>";
  var SVG_PLANE = "<path d='M30 4h4l3 18 22 8v5l-22-4-1 14 7 5v3l-11-3-11 3v-3l7-5-1-14-22 4v-5l22-8z'/>";
  var SVG_JET = "<path d='M32 2l4 10 1 12 22 14v6l-22-8-1 10 8 6v4l-12-3-12 3v-4l8-6-1-10-22 8v-6l22-14 1-12z'/>";
  var SVG_TANK = "<path d='M6 36h50l4 8-6 8H10l-6-8z'/><path d='M16 24h24l4 10H12z'/><path d='M40 27h22v4H40z'/>";
  var SVG_JEEP = "<path d='M6 24l4-10h26l6 10h14v10h-5a5 5 0 0 1-10 0H22a5 5 0 0 1-10 0H4V24z'/><path d='M14 8h18v3H14z'/>";
  var SVG_SKI = "<path d='M4 36h44l12-8 2 4-10 10H10z'/><path d='M26 24h10l4 10H24z'/><path d='M36 18h3l2 8h-3z'/>";
  var SVG_YACHT = "<path d='M2 36h60l-8 12H10z'/><path d='M14 26h34l6 10H10z'/><path d='M22 18h18l4 8H20z'/>";
  var SVG_CHUTE = "<path d='M6 24C6 11 18 4 32 4s26 7 26 20c-4-3-8-3-11 0-4-3-8-3-11 0-3-3-8-3-11 0-4-3-8-3-11 0-3-3-6-3-8 0z'/><path d='M8 25l22 22M56 25 34 47M32 25v22' stroke='currentColor' stroke-width='2' fill='none'/><path d='M28 46h8v10h-8z'/>";
  var SVG_FOOD = "<path d='M10 22h44l-4 26H14z'/><path d='M8 16h48v5H8z'/><path d='M40 4l4 1-3 11h-4z'/>";
  var CATS = [
    { id: "melee", n: "Melee", ic: "bat" }, { id: "hand", n: "Handguns", ic: "pistol" }, { id: "auto", n: "Rifles", ic: "rifle" }, { id: "heavy", n: "Heavy", ic: "rpg" },
    { id: "gear", n: "Gear", svg: "<path d='M32 4 54 12v14c0 12-9 20-22 26C19 46 10 38 10 26V12z'/>" },
    { id: "cars", n: "Cars", svg: SVG_CAR }, { id: "super", n: "Super", svg: SVG_SUPER }, { id: "bikes", n: "Bikes", svg: SVG_BIKE },
    { id: "boats", n: "Boats", svg: SVG_BOAT }, { id: "air", n: "Aircraft", svg: SVG_HELI }, { id: "army", n: "Army", svg: SVG_TANK }
  ];
  /* top speed bars: land vehicles against 60 m/s, aircraft against 140 m/s */
  function vst(vmax, acc, hand, air) { var kmh = Math.round(vmax * 3.6), top = air ? 140 : 60; return [["Top speed", Math.min(100, Math.round(vmax / top * 100)), kmh + " km/h"], ["Acceleration", Math.min(100, Math.round(acc / (air ? 30 : 28) * 100)), acc > 18 ? "Insane" : acc > 13 ? "Very fast" : acc > 9 ? "Fast" : acc > 6 ? "Medium" : "Slow"], ["Handling", hand, hand > 85 ? "Razor" : hand > 70 ? "Sharp" : hand > 55 ? "Steady" : "Heavy"]]; }
  function wst(dmg, rate, range, ammo) { return [["Damage", dmg[0], dmg[1]], ["Fire rate", rate[0], rate[1]], ["Range", range[0], range[1]], ["Ammo", ammo[0], ammo[1]]]; }
  function mst(dmg, sp) { return [["Damage", dmg, Math.round(dmg / 25) + " hit" + (dmg >= 50 ? "s" : "")], ["Speed", sp, sp > 70 ? "Fast" : "Medium"], ["Range", 20, "Melee"]]; }
  var ITEMS = [
    { id: "bat", cat: "melee", n: "Baseball Bat", r: "Common", price: 40, w: "bat", st: mst(45, 55) },
    { id: "golf", cat: "melee", n: "Golf Club", r: "Common", price: 55, w: "golf", st: mst(45, 65) },
    { id: "crowbar", cat: "melee", n: "Crowbar", r: "Uncommon", price: 70, w: "crowbar", st: mst(50, 70) },
    { id: "machete", cat: "melee", n: "Machete", r: "Rare", price: 110, w: "machete", st: mst(70, 60) },
    { id: "katana", cat: "melee", n: "Katana", r: "Epic", price: 220, w: "katana", st: mst(95, 85) },
    { id: "pistol", cat: "hand", n: "Pistol", r: "Common", price: 60, w: "pistol", st: wst([35, "20"], [40, "Medium"], [45, "42 m"], [30, "36"]) },
    { id: "revolver", cat: "hand", n: "Heavy Revolver", r: "Uncommon", price: 140, w: "revolver", st: wst([70, "40"], [25, "Slow"], [55, "50 m"], [20, "24"]) },
    { id: "deagle", cat: "hand", n: ".50 Desert Hawk", r: "Rare", price: 230, w: "deagle", st: wst([85, "50"], [35, "Medium"], [60, "55 m"], [22, "28"]) },
    { id: "microsmg", cat: "hand", n: "Micro SMG", r: "Rare", price: 210, w: "microsmg", st: wst([20, "10"], [95, "Extreme"], [32, "30 m"], [90, "140"]) },
    { id: "smg", cat: "auto", n: "SMG", r: "Uncommon", price: 150, w: "smg", st: wst([25, "10"], [90, "Very fast"], [40, "38 m"], [80, "120"]) },
    { id: "shotgun", cat: "auto", n: "Pump Shotgun", r: "Uncommon", price: 180, w: "shotgun", st: wst([85, "40"], [20, "Slow"], [18, "16 m"], [22, "24"]) },
    { id: "rifle", cat: "auto", n: "Assault Rifle", r: "Rare", price: 260, w: "rifle", st: wst([55, "30"], [80, "Fast"], [75, "70 m"], [65, "90"]) },
    { id: "carbine", cat: "auto", n: "Carbine Rifle", r: "Rare", price: 330, w: "carbine", st: wst([58, "30"], [85, "Fast"], [82, "80 m"], [72, "100"]) },
    { id: "sniper", cat: "auto", n: "Sniper Rifle", r: "Epic", price: 520, w: "sniper", st: wst([100, "100"], [10, "Very slow"], [100, "160 m"], [16, "20"]) },
    { id: "mg", cat: "auto", n: "Combat MG", r: "Epic", price: 700, w: "mg", st: wst([60, "30"], [92, "Very fast"], [72, "70 m"], [100, "200"]) },
    { id: "rpg", cat: "heavy", n: "Rocket Launcher", r: "Epic", price: 450, w: "rpg", st: wst([100, "Explosive"], [10, "Very slow"], [100, "140 m"], [8, "6"]) },
    { id: "glauncher", cat: "heavy", n: "Grenade Launcher", r: "Epic", price: 620, w: "glauncher", st: wst([90, "Explosive"], [25, "Slow"], [65, "90 m"], [14, "10"]) },
    { id: "minigun", cat: "heavy", n: "Minigun", r: "Legendary", price: 1400, w: "minigun", st: wst([60, "20"], [100, "Insane"], [60, "60 m"], [100, "500"]) },
    { id: "armor", cat: "gear", n: "Body Armor", r: "Uncommon", price: 50, st: [["Protection", 70, "100"]], svg: "<path d='M32 4 54 12v14c0 12-9 20-22 26C19 46 10 38 10 26V12z'/>" },
    { id: "health", cat: "gear", n: "First Aid Kit", r: "Common", price: 20, st: [["Heal", 100, "Full"]], svg: "<path d='M24 6h16v18h18v16H40v18H24V40H6V24h18z'/>" },
    { id: "snack", cat: "gear", n: "Snack & Soda", r: "Common", price: 12, st: [["Food", 100, "Full"]], svg: SVG_FOOD },
    { id: "chute", cat: "gear", n: "Parachute", r: "Rare", price: 120, st: [["Uses", 25, "1 jump"], ["Glide", 70, "9 m/s"], ["Safe landing", 90, "Yes"]], svg: SVG_CHUTE, cnt: "chute" },
    { id: "chute3", cat: "gear", n: "Parachute x3", r: "Epic", price: 300, st: [["Uses", 75, "3 jumps"], ["Glide", 70, "9 m/s"], ["Safe landing", 90, "Yes"]], svg: SVG_CHUTE, cnt: "chute" },
    { id: "nitro", cat: "gear", n: "Nitro x3", r: "Rare", price: 60, st: [["Boost", 80, "+45% speed"], ["Uses", 30, "3"]], svg: "<path d='M22 4h20v8l-4 4v40a6 6 0 0 1-12 0V16l-4-4z'/>", cnt: "nitro" },
    { id: "nitro10", cat: "gear", n: "Nitro x10", r: "Epic", price: 180, st: [["Boost", 80, "+45% speed"], ["Uses", 100, "10"]], svg: "<path d='M22 4h20v8l-4 4v40a6 6 0 0 1-12 0V16l-4-4z'/>", cnt: "nitro" },
    { id: "sedan", cat: "cars", n: "Cruiser Sedan", r: "Common", price: 150, rent: 25, veh: "sedan", st: vst(22, 8.5, 60) },
    { id: "pickup", cat: "cars", n: "Hauler Pickup", r: "Common", price: 180, rent: 30, veh: "pickup", st: vst(21, 7.5, 45) },
    { id: "van", cat: "cars", n: "Metro Van", r: "Common", price: 200, rent: 30, veh: "van", st: vst(20, 7, 45) },
    { id: "suv", cat: "cars", n: "Ranger SUV", r: "Uncommon", price: 220, rent: 35, veh: "suv", st: vst(22, 8.5, 55) },
    { id: "ev", cat: "cars", n: "Volt EV", r: "Rare", price: 420, rent: 45, veh: "ev", st: vst(31, 17, 78) },
    { id: "muscle", cat: "cars", n: "Stallion GT", r: "Rare", price: 480, rent: 50, veh: "muscle", st: vst(33, 14, 62) },
    { id: "lux", cat: "cars", n: "Atlas Luxury SUV", r: "Epic", price: 650, rent: 60, veh: "lux", st: vst(30, 11, 66) },
    { id: "sportcar", cat: "super", n: "Viper GT", r: "Epic", price: 350, rent: 60, veh: "sport", st: vst(36, 15, 80) },
    { id: "veloce", cat: "super", n: "Apex Veloce", r: "Epic", price: 900, rent: 90, veh: "veloce", col: 0xff7a1a, st: vst(42, 18, 84) },
    { id: "phantom", cat: "super", n: "Phantom S", r: "Legendary", price: 1500, rent: 120, veh: "phantom", col: 0x15161a, st: vst(44, 19, 86) },
    { id: "raptor", cat: "super", n: "Raptor V12", r: "Legendary", price: 2200, rent: 160, veh: "raptor", col: 0xf2c230, st: vst(47, 21, 88) },
    { id: "nova", cat: "super", n: "Nova X Hypercar", r: "Legendary", price: 3500, rent: 220, veh: "nova", col: 0x7b2cff, st: vst(51, 23, 90) },
    { id: "titan", cat: "super", n: "Titan EV Hyper", r: "Legendary", price: 5000, rent: 300, veh: "titan", col: 0xf4f4f2, st: vst(55, 27, 92) },
    { id: "bike", cat: "bikes", n: "City Scooter", r: "Common", price: 90, rent: 15, veh: "moto", st: vst(22, 10, 85) },
    { id: "dirt", cat: "bikes", n: "Dune Dirt Bike", r: "Uncommon", price: 180, rent: 25, veh: "dirt", st: vst(27, 13, 82) },
    { id: "superbike", cat: "bikes", n: "Hayate R1", r: "Rare", price: 250, rent: 40, veh: "superbike", st: vst(38, 17, 78) },
    { id: "chopper", cat: "bikes", n: "Bolt Chopper", r: "Rare", price: 320, rent: 40, veh: "chopper", st: vst(31, 11, 60) },
    { id: "pulse", cat: "bikes", n: "Pulse E-Bike", r: "Epic", price: 520, rent: 55, veh: "pulse", col: 0x111316, st: vst(41, 22, 86) },
    { id: "ronin", cat: "bikes", n: "Ronin RR", r: "Legendary", price: 900, rent: 80, veh: "ronin", col: 0xd11a1a, st: vst(45, 21, 84) },
    { id: "jetski", cat: "boats", n: "Jet Ski", r: "Uncommon", price: 140, rent: 20, veh: "jetski", st: vst(21, 9, 88) },
    { id: "speedboat", cat: "boats", n: "Speedboat", r: "Rare", price: 300, rent: 25, veh: "boat", st: vst(19, 7, 65) },
    { id: "racer", cat: "boats", n: "Cigarette Racer", r: "Epic", price: 800, rent: 70, veh: "racer", col: 0xff3d8b, st: vst(28, 9, 60) },
    { id: "yacht", cat: "boats", n: "Luxury Yacht", r: "Legendary", price: 2800, rent: 200, veh: "yacht", st: vst(13, 3, 30) },
    { id: "heli", cat: "air", n: "Sparrow Helicopter", r: "Epic", price: 1200, rent: 150, veh: "heli", air: 1, col: 0x1f5fa8, st: vst(40, 10, 80, true) },
    { id: "heli2", cat: "air", n: "Skylark Executive", r: "Legendary", price: 2400, rent: 220, veh: "heli2", air: 1, col: 0x111214, st: vst(50, 12, 82, true) },
    { id: "attack", cat: "air", n: "Buzzard Attack Heli", r: "Legendary", price: 4200, rent: 380, veh: "attack", air: 1, col: 0x3d4a2a, st: vst(46, 12, 85, true).concat([["Weapons", 90, "Rockets"]]) },
    { id: "cub", cat: "air", n: "Cub Light Plane", r: "Epic", price: 1500, rent: 140, veh: "cub", air: 1, col: 0xf2c230, st: vst(60, 9, 70, true) },
    { id: "jet", cat: "air", n: "Lux Private Jet", r: "Legendary", price: 6500, rent: 450, veh: "jet", air: 1, col: 0xff3d8b, st: vst(105, 13, 55, true) },
    { id: "fighter", cat: "air", n: "Raven Fighter Jet", r: "Legendary", price: 9500, rent: 700, veh: "fighter", air: 1, col: 0x5a6470, st: vst(140, 30, 90, true).concat([["Weapons", 100, "Missiles"]]) },
    { id: "jeep", cat: "army", n: "Army Jeep", r: "Uncommon", price: 400, rent: 40, veh: "jeep", st: vst(27, 12, 70) },
    { id: "armored", cat: "army", n: "Armored Truck", r: "Rare", price: 1100, rent: 90, veh: "armored", st: vst(21, 7, 40).concat([["Armor", 80, "Heavy"]]) },
    { id: "tankbuy", cat: "army", n: "Bulldog Battle Tank", r: "Legendary", price: 5500, rent: 600, veh: "tank", st: [["Top speed", 18, "36 km/h"], ["Armor", 100, "Max"], ["Cannon", 100, "Explosive"]] }
  ];
  ITEMS.forEach(function (it) {
    if (it.svg || it.w) return;
    it.svg = { super: SVG_SUPER, bikes: SVG_BIKE, boats: SVG_BOAT, cars: SVG_CAR, army: SVG_JEEP }[it.cat];
    if (it.veh === "tank") it.svg = SVG_TANK; else if (it.veh === "jetski") it.svg = SVG_SKI; else if (it.veh === "yacht") it.svg = SVG_YACHT;
    else if (it.air) it.svg = /heli|attack/.test(it.veh) ? SVG_HELI : it.veh === "cub" ? SVG_PLANE : SVG_JET;
  });
  var VEHCOL = [0xd11a1a, 0xf2c230, 0x111111, 0x1f5fa8, 0xf4f4f2, 0xff3d8b, 0x2e7d4f];
  /* ---------- extra rides: hypercars, bikes, boats, aircraft ---------- */
  function glowMat(c, i) { return new THREE.MeshStandardMaterial({ color: c, emissive: c, emissiveIntensity: i || 1.3, roughness: 0.4 }); }
  var GLOW_TEX = null;
  function underglow(m, col, k) {
    if (!GLOW_TEX) GLOW_TEX = canvasTex(128, 128, function (g, w, h) { var gr = g.createRadialGradient(w / 2, h / 2, 2, w / 2, h / 2, w / 2); gr.addColorStop(0, "rgba(255,255,255,0.95)"); gr.addColorStop(0.55, "rgba(255,255,255,0.45)"); gr.addColorStop(1, "rgba(255,255,255,0)"); g.fillStyle = gr; g.fillRect(0, 0, w, h); });
    var L = m.userData.L, W = m.userData.W, gl = new THREE.Mesh(new THREE.PlaneGeometry(L * (k || 1.25), W * 1.9), new THREE.MeshBasicMaterial({ color: col, map: GLOW_TEX, transparent: true, opacity: 0.85, depthWrite: false, blending: THREE.AdditiveBlending }));
    gl.rotation.x = -Math.PI / 2; gl.position.y = 0.05; gl.renderOrder = 2; m.add(gl); return m;
  }
  function hyperCar(col, style) {
    var m = sportCar(col), U = m.userData, L = U.L, W = U.W, cf = tmat(0x0d0e10, 0.32, 0.45), chrome = tmat(0xd8dde2, 0.18, 0.95);
    var accent = style === "titan" ? 0x2ee6d6 : style === "phantom" ? 0xffffff : style === "nova" ? 0xff3d8b : 0xffd23f;
    gbox(m, 0.05, 0.05, W - 0.55, glowMat(accent, 1.8), L / 2 + 0.02, 0.6, 0, true);
    gbox(m, 0.05, 0.06, W - 0.3, glowMat(0xff2030, 1.6), -L / 2 - 0.02, 0.74, 0, true);
    [-1, 1].forEach(function (sd) { var it = gbox(m, 1.0, 0.3, 0.07, cf, -0.5, 0.5, sd * (W / 2 + 0.01), true); it.rotation.y = sd * 0.05; gbox(m, 1.6, 0.04, 0.05, style === "phantom" ? chrome : glowMat(accent, 0.9), 0.2, 0.33, sd * (W / 2 + 0.02), true); });
    if (style === "veloce" || style === "raptor") {
      gbox(m, 0.55, 0.06, W + 0.12, cf, -L / 2 + 0.28, 1.5, 0, true);
      [-1, 1].forEach(function (sd) { gbox(m, 0.1, 0.5, 0.05, cf, -L / 2 + 0.36, 1.24, sd * 0.55, true); gbox(m, 0.6, 0.24, 0.04, cf, -L / 2 + 0.28, 1.5, sd * (W / 2 + 0.07), true); });
    }
    if (style === "raptor" || style === "nova") { gbox(m, 1.1, 0.16, 0.34, cf, -0.55, 1.2, 0, true); gbox(m, 1.5, 0.3, 0.03, cf, -1.3, 1.25, 0, true); }
    if (style === "nova" || style === "titan") { gbox(m, 0.08, 0.08, W - 0.2, glowMat(accent, 1.4), -L / 2 + 0.05, 0.98, 0, true); }
    if (style === "phantom") { gbox(m, L * 0.62, 0.025, 0.04, chrome, 0.1, 1.15, 0, true); }
    m.scale.set(1.04, style === "nova" || style === "titan" ? 0.9 : 0.94, 1.04);
    underglow(m, accent);
    var spec = { veloce: [42, 18], phantom: [44, 19], raptor: [47, 21], nova: [51, 23], titan: [55, 27] }[style] || [40, 17];
    U.vmax = spec[0]; U.acc = spec[1]; U.sport = true; U.hyper = style; return m;
  }
  function evCar(col) { var m = carMesh(col, "hatch"), U = m.userData; gbox(m, 0.04, 0.05, U.W - 0.4, glowMat(0xbff6ff, 1.6), U.L / 2 + 0.01, 0.66, 0, true); gbox(m, 0.04, 0.05, U.W - 0.3, glowMat(0xff2030, 1.4), -U.L / 2 - 0.01, 0.86, 0, true); U.vmax = 31; U.acc = 17; U.sport = true; return m; }
  function muscleCar(col) {
    var m = carMesh(col, "coupe"), U = m.userData, wh = tmat(0xf4f4f2, 0.4), dk = tmat(0x111214, 0.5);
    gbox(m, 0.9, 0.16, 0.6, dk, U.L / 2 - 1.0, 0.95, 0, true);
    [-0.22, 0.22].forEach(function (z) { gbox(m, U.L * 0.96, 0.02, 0.14, wh, 0, 0.9, z, true); });
    U.vmax = 33; U.acc = 14; U.sport = true; U.exh = [[-U.L / 2 - 0.1, 0.32, 0.5], [-U.L / 2 - 0.1, 0.32, -0.5]]; return m;
  }
  function luxSuv(col) {
    var m = carMesh(col, "suv"), U = m.userData, ch = tmat(0xd8dde2, 0.18, 0.95);
    [-1, 1].forEach(function (sd) { gbox(m, U.L * 0.55, 0.05, 0.05, ch, -0.3, 1.86, sd * (U.W / 2 - 0.22), true); gbox(m, U.L * 0.7, 0.05, 0.04, ch, 0, 0.42, sd * (U.W / 2 + 0.01), true); });
    gbox(m, 0.05, 0.36, U.W * 0.5, ch, U.L / 2 + 0.01, 0.78, 0, true); U.vmax = 30; U.acc = 11; return m;
  }
  function armyCar(kind) {
    var m = carMesh(kind === "armored" ? 0x3a3f44 : 0x4f5a2a, kind === "armored" ? "van" : "suv"), U = m.userData, dk = tmat(0x1b1d18, 0.7);
    if (kind === "jeep") { var sp = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.38, 0.22, 16), dk); sp.rotation.z = Math.PI / 2; sp.position.set(-U.L / 2 - 0.12, 0.9, 0); m.add(sp); gbox(m, 0.24, 0.12, U.W - 0.4, glowMat(0xfff2c8, 0.8), 0.2, 1.86, 0, true); U.vmax = 27; U.acc = 12; }
    else { for (var i = 0; i < 5; i++) gbox(m, 0.05, 0.5, 0.04, dk, U.L / 2 - 2.5 + i * 0.22, 1.6, U.W / 2 + 0.03, true); gbox(m, 0.06, 0.5, U.W * 0.8, dk, U.L / 2 + 0.03, 0.6, 0, true); U.vmax = 21; U.acc = 7; U.armored = true; }
    return m;
  }
  function bikeVariant(kind, col) {
    var m = kind === "pulse" || kind === "ronin" ? superBike(col) : motoMesh(col), U = m.userData, ch = tmat(0xd8dde2, 0.18, 0.95);
    if (kind === "dirt") { m.scale.set(1.02, 1.1, 1.0); gbox(m, 0.05, 0.22, 0.18, tmat(0xf4f4f2, 0.5), 0.68, 1.0, 0, true); U.vmax = 27; U.acc = 13; }
    else if (kind === "chopper") { [-0.07, 0.07].forEach(function (z) { var r = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.9, 8), ch); r.position.set(0.92, 0.6, z); r.rotation.z = 0.55; m.add(r); }); gbox(m, 0.05, 0.4, 0.05, ch, 0.38, 1.36, 0.25, true); gbox(m, 0.05, 0.4, 0.05, ch, 0.38, 1.36, -0.25, true); U.vmax = 31; U.acc = 11; }
    else if (kind === "pulse") { underglow(m, 0x2ee6d6, 1.5); gbox(m, 0.7, 0.03, 0.03, glowMat(0x2ee6d6, 1.8), 0.1, 0.62, 0.17, true); gbox(m, 0.7, 0.03, 0.03, glowMat(0x2ee6d6, 1.8), 0.1, 0.62, -0.17, true); U.vmax = 41; U.acc = 22; }
    else if (kind === "ronin") { underglow(m, 0xff3d8b, 1.5); U.vmax = 45; U.acc = 21; }
    return m;
  }
  function jetSki(col) {
    var g = new THREE.Group(), L = 3.2, W = 1.2, paint = tmat(col, 0.35, 0.2);
    var h = new THREE.Mesh(hullGeo(L, W, 0.7, 0.4), WHITE_T); h.position.y = -0.3; h.castShadow = true; g.add(h);
    var st = new THREE.Mesh(hullGeo(L * 1.01, W * 1.03, 0.16, 0.4), paint); st.position.y = 0.2; g.add(st);
    gbox(g, 1.1, 0.2, 0.42, DARK_T, -0.35, 0.45, 0); gbox(g, 0.6, 0.32, 0.6, paint, 0.55, 0.42, 0);
    var bar = gbox(g, 0.06, 0.06, 0.7, DARK_T, 0.45, 0.78, 0, true); bar.rotation.y = 0;
    var b = finishBoat(g, L, W, false, 0.42); b.userData.vmax = 21; b.userData.acc = 9; b.userData.seatX = -0.3; return b;
  }
  function racerBoat(col) {
    var g = new THREE.Group(), L = 10, W = 2.6, paint = tmat(col, 0.3, 0.3);
    var h = new THREE.Mesh(hullGeo(L, W, 1.0, 0.45), WHITE_T); h.position.y = -0.4; h.castShadow = true; g.add(h);
    var st = new THREE.Mesh(hullGeo(L * 1.004, W * 1.02, 0.28, 0.45), paint); st.position.y = 0.32; g.add(st);
    gbox(g, 3.2, 0.06, W - 0.4, tmat(0xcbb999, 0.85), -1.8, 0.62, 0);
    var ws = gbox(g, 0.06, 0.4, W - 0.5, tmat(0x9fc3d6, 0.05, 0.3, { transparent: true, opacity: 0.55 }), -0.1, 0.85, 0, true); ws.rotation.z = 0.7;
    [-0.45, 0.45].forEach(function (z) { gbox(g, 0.6, 0.7, 0.45, DARK_T, -L / 2 + 0.1, 0.55, z); });
    gbox(g, 0.7, 0.4, 0.6, WHITE_T, -1.2, 0.82, -0.5); gbox(g, 0.7, 0.4, 0.6, WHITE_T, -1.2, 0.82, 0.5);
    var b = finishBoat(g, L, W, false, 0.62); b.userData.vmax = 28; b.userData.acc = 9; b.userData.seatX = -1.0; return b;
  }
  function yachtBoat() {
    var g = new THREE.Group(), L = 18, W = 5, navy = tmat(0x10234a, 0.35), wood = tmat(0xa8794e, 0.7), glass = tmat(0x11161c, 0.08, 0.6, { transparent: true, opacity: 0.85 });
    var h = new THREE.Mesh(hullGeo(L, W, 2.2, 0.32), WHITE_T); h.position.y = -1.0; h.castShadow = true; g.add(h);
    var st = new THREE.Mesh(hullGeo(L * 1.003, W * 1.01, 0.3, 0.32), navy); st.position.y = 0.95; g.add(st);
    gbox(g, L * 0.8, 0.08, W - 0.5, wood, -0.6, 1.22, 0);
    gbox(g, 8.5, 1.7, W - 1.2, WHITE_T, -0.8, 2.1, 0); gbox(g, 8.2, 0.9, W - 1.12, glass, -0.8, 2.3, 0, true);
    gbox(g, 5, 1.2, W - 1.8, WHITE_T, -1.4, 3.5, 0); gbox(g, 4.7, 0.6, W - 1.72, glass, -1.4, 3.6, 0, true);
    gbox(g, 6, 0.1, W - 1.0, WHITE_T, -1.6, 4.15, 0); gbox(g, 0.12, 1.4, 0.12, tmat(0xd8dde2, 0.2, 0.9), -1.2, 4.9, 0);
    for (var i = 0; i < 9; i++) [-1, 1].forEach(function (sd) { gbox(g, 0.05, 0.6, 0.05, tmat(0xd8dde2, 0.2, 0.9), -L / 2 + 1.5 + i * 1.8, 1.55, sd * (W / 2 - 0.3), true); });
    [-1, 1].forEach(function (sd) { gbox(g, L * 0.86, 0.05, 0.05, tmat(0xd8dde2, 0.2, 0.9), -0.4, 1.85, sd * (W / 2 - 0.3), true); });
    gsign(g, "EARTHPASS ONE", 3.4, 0.5, -L / 2 + 0.05, 0.4, 0, -Math.PI / 2, { w: 512, h: 80, bg: "#10234a", fg: "#ffd23f", size: 52 });
    var b = finishBoat(g, L, W, true, 1.3); b.userData.vmax = 13; b.userData.acc = 3; b.userData.seatX = 2.6; b.userData.seatY = 1.3; return b;
  }
  /* aircraft (x forward, origin on the ground unless gy says otherwise) */
  function airify(m, air, o) { var U = m.userData; U.air = air; U.wheels = U.wheels || []; U.r = U.r || 0.4; for (var k in o) U[k] = o[k]; return m; }
  function heliMesh(kind, col) {
    var m = helicopter(col), dk = tmat(0x1b1d18, 0.6), gold = tmat(0xffd23f, 0.3, 0.6);
    if (kind === "heli2") { gbox(m, 4.2, 0.12, 2.5, gold, -0.2, 1.62, 0, true); }
    if (kind === "attack") {
      [-1, 1].forEach(function (sd) { gbox(m, 0.7, 0.1, 1.4, dk, -0.1, 1.55, sd * 1.75, true); var pod = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 1.3, 12), dk); pod.rotation.z = Math.PI / 2; pod.position.set(0.1, 1.38, sd * 2.25); m.add(pod); });
      var gun = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.2, 8), dk); gun.rotation.z = Math.PI / 2; gun.position.set(2.6, 0.95, 0); m.add(gun);
    }
    return airify(m, "heli", { L: 9, W: 2.6, vmax: kind === "heli2" ? 50 : kind === "attack" ? 46 : 40, acc: kind === "heli2" ? 12 : 10, gy: 0, armed: kind === "attack", pods: [[0.8, 1.38, 2.25], [0.8, 1.38, -2.25]] });
  }
  function propPlane(col) {
    var g = new THREE.Group(), paint = tmat(col, 0.35, 0.2), wh = tmat(0xf4f4f2, 0.35), dk = tmat(0x16181a, 0.5), glass = tmat(0x1a2a3a, 0.05, 0.6, { transparent: true, opacity: 0.8 });
    var body = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.32, 6.2, 16), wh); body.rotation.z = Math.PI / 2; body.position.set(-0.6, 1.45, 0); body.castShadow = true; g.add(body);
    var cowl = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.64, 1.1, 16), paint); cowl.rotation.z = -Math.PI / 2; cowl.position.set(3.0, 1.45, 0); g.add(cowl);
    var spin = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.42, 14), dk); spin.rotation.z = -Math.PI / 2; spin.position.set(3.75, 1.45, 0); g.add(spin);
    var prop = new THREE.Group(); prop.position.set(3.62, 1.45, 0); [0, 1].forEach(function (k) { var b = new THREE.Mesh(new THREE.BoxGeometry(0.06, 2.0, 0.16), dk); b.rotation.x = k * Math.PI / 2; prop.add(b); }); g.add(prop);
    gbox(g, 1.5, 0.75, 1.15, glass, 1.4, 1.95, 0, true); gbox(g, 1.6, 0.14, 11, paint, 1.0, 2.38, 0);
    [-1, 1].forEach(function (sd) { var s = gbox(g, 0.08, 1.4, 0.08, dk, 0.9, 1.7, sd * 2.2, true); s.rotation.x = sd * 0.62; var w = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.2, 14), dk); w.rotation.x = Math.PI / 2; w.position.set(0.9, 0.32, sd * 1.15); g.add(w); var l = gbox(g, 0.08, 0.9, 0.08, dk, 0.9, 0.7, sd * 0.85, true); l.rotation.x = sd * 0.5; });
    var nw = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.16, 12), dk); nw.rotation.x = Math.PI / 2; nw.position.set(2.8, 0.24, 0); g.add(nw); gbox(g, 0.06, 0.8, 0.06, dk, 2.8, 0.66, 0, true);
    gbox(g, 1.0, 0.08, 3.6, paint, -3.6, 1.6, 0); var fin = gbox(g, 1.2, 1.3, 0.08, paint, -3.6, 2.2, 0); fin.rotation.z = -0.35;
    gbox(g, 3.2, 0.12, 1.26, paint, -0.2, 1.3, 0, true);
    g.traverse(function (o) { if (o.isMesh) o.castShadow = true; });
    return airify(g, "plane", { L: 7.5, W: 2.2, vmax: 60, acc: 9, stall: 22, gy: 0, prop: prop });
  }
  function fighterJet(col) {
    var g = new THREE.Group(), grey = tmat(col, 0.45, 0.35), dk = tmat(0x1a1c1f, 0.5), glass = tmat(0xffb020, 0.08, 0.7, { transparent: true, opacity: 0.75 });
    var prof = []; for (var i = 0; i <= 30; i++) { var t = i / 30, x = -7 + t * 15, r = x > 4 ? 0.85 * Math.pow(Math.max(0.02, (8 - x) / 4), 0.7) : x < -6 ? 0.6 : 0.85; prof.push(new THREE.Vector2(Math.max(0.02, r), x)); }
    var fg = new THREE.LatheGeometry(prof, 18); fg.rotateZ(-Math.PI / 2); var fus = new THREE.Mesh(fg, grey); fus.position.y = 1.7; g.add(fus);
    var can = new THREE.Mesh(new THREE.SphereGeometry(0.62, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), glass); can.scale.set(2.2, 0.8, 0.85); can.position.set(3.4, 2.3, 0); g.add(can);
    var ws = new THREE.Shape(); ws.moveTo(2.5, 0); ws.lineTo(-4.5, 0); ws.lineTo(-5.5, 5.6); ws.lineTo(-3.6, 5.6); ws.lineTo(2.5, 0);
    var wgeo = new THREE.ExtrudeGeometry(ws, { depth: 0.16, bevelEnabled: false });
    [-1, 1].forEach(function (sd) { var w = new THREE.Mesh(wgeo, grey); w.rotation.x = sd > 0 ? Math.PI / 2 : -Math.PI / 2; w.position.set(0, 1.55, sd * 0.5); g.add(w);
      var tf = gbox(g, 2.2, 2.2, 0.1, grey, -5.6, 2.9, sd * 0.9); tf.rotation.x = sd * 0.25; tf.rotation.z = -0.4;
      var mis = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 2.2, 8), tmat(0xf4f4f2, 0.4)); mis.rotation.z = Math.PI / 2; mis.position.set(-1.6, 1.3, sd * 3.4); g.add(mis);
      var w2 = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.2, 12), dk); w2.rotation.x = Math.PI / 2; w2.position.set(-0.8, 0.3, sd * 1.3); g.add(w2); gbox(g, 0.1, 1.1, 0.1, dk, -0.8, 0.8, sd * 1.25, true); });
    var nw = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.16, 12), dk); nw.rotation.x = Math.PI / 2; nw.position.set(4.6, 0.22, 0); g.add(nw); gbox(g, 0.08, 1.2, 0.08, dk, 4.6, 0.8, 0, true);
    var ab = new THREE.Mesh(new THREE.ConeGeometry(0.5, 2.6, 14, 1, true), new THREE.MeshBasicMaterial({ color: 0xff9a3c, transparent: true, opacity: 0.0, depthWrite: false, blending: THREE.AdditiveBlending })); ab.rotation.z = Math.PI / 2; ab.position.set(-8.2, 1.7, 0); g.add(ab);
    g.traverse(function (o) { if (o.isMesh && o !== ab) o.castShadow = true; });
    return airify(g, "plane", { L: 15, W: 2.4, vmax: 140, acc: 30, stall: 40, gy: 0, armed: true, ab: ab, pods: [[-0.6, 1.3, 3.4], [-0.6, 1.3, -3.4]] });
  }
  function jetMesh(col) { var m = bizjet(col); return airify(m, "plane", { L: 18, W: 3, vmax: 105, acc: 13, stall: 36, gy: 1.62 }); }
  function vehMesh(kind, col) {
    var m;
    switch (kind) {
      case "sport": return sportCar(col);
      case "superbike": return superBike(col);
      case "moto": m = motoMesh(col); m.userData.vmax = 22; m.userData.acc = 10; return m;
      case "boat": return speedboat(col);
      case "veloce": case "phantom": case "raptor": case "nova": case "titan": return hyperCar(col, kind);
      case "ev": return evCar(col);
      case "muscle": return muscleCar(col);
      case "lux": return luxSuv(col);
      case "van": m = carMesh(col, "van"); m.userData.vmax = 20; m.userData.acc = 7; return m;
      case "pickup": m = carMesh(col, "pickup"); m.userData.vmax = 21; m.userData.acc = 7.5; return m;
      case "jeep": case "armored": return armyCar(kind);
      case "dirt": case "chopper": case "pulse": case "ronin": return bikeVariant(kind, col);
      case "jetski": return jetSki(col);
      case "racer": return racerBoat(col);
      case "yacht": return yachtBoat();
      case "heli": case "heli2": case "attack": return heliMesh(kind, col);
      case "cub": return propPlane(col);
      case "jet": return jetMesh(col);
      case "fighter": return fighterJet(col);
      case "tank": return tankMesh();
    }
    return carMesh(col, kind);
  }
  function owned(it) { if (it.w) return G.weapons[it.w] > 0; if (it.veh) return (G.garage || []).indexOf(it.id) >= 0; return false; }
  function itemCount(it) { if (it.cnt === "chute") return G.chute || 0; if (it.cnt === "nitro") return G.nitro || 0; return 0; }
  /* a stretch of water long enough for a hull of length L near (x, z) */
  function waterSpot(x, z, L, yaw) {
    var cs = Math.cos(yaw), sn = Math.sin(yaw);
    function ok(px, pz) { for (var k = -1; k <= 1; k += 0.5) { var qx = px + cs * k * (L / 2 + 1.5), qz = pz - sn * k * (L / 2 + 1.5); if (!isWater(qx, qz) || deckAt(qx, qz)) return false; } return true; }
    if (ok(x, z)) return [x, z];
    for (var r = 4; r <= 140; r += 4) for (var a = 0; a < 6.28; a += 0.4) { var px = x + Math.cos(a) * r, pz = z + Math.sin(a) * r; if (ok(px, pz)) return [px, pz]; }
    return [x, z];
  }
  /* an open patch (no buildings) for a helicopter near (x, z) */
  function heliSpot(x, z) {
    function ok(px, pz) { for (var a = 0; a < 6.28; a += 0.8) { var qx = px + Math.cos(a) * 5.5, qz = pz + Math.sin(a) * 5.5; if (!freeAt(qx, qz) || deepWater(qx, qz)) return false; } return freeAt(px, pz) && !deepWater(px, pz); }
    for (var r = 0; r <= 90; r += 5) for (var a = 0; a < 6.28; a += r ? 0.5 : 7) { var px = x + Math.cos(a) * r, pz = z + Math.sin(a) * r; if (ok(px, pz)) return [px, pz]; }
    return [x + 6, z + 6];
  }
  function deliver(it, rented, spot) {
    if (P.mode === "car" && taxi.m.userData.air && taxi.alt - topAt(taxi.x, taxi.z) > 2) { toast("Land first, then order a new ride"); return; }
    var col = it.col !== undefined ? it.col : VEHCOL[Math.floor(Math.random() * VEHCOL.length)], m = vehMesh(it.veh, col); scene.add(m);
    var U = m.userData, x, z, yaw = 0, hop = false;
    if (spot) { x = spot.x; z = spot.z; yaw = spot.yaw || 0; hop = true; }
    else if (U.air === "plane") { x = 214; z = 95; yaw = 0; hop = true; }
    else if (U.air === "heli") { var hs = heliSpot(P.lv ? P.x + 30 : P.x, P.z); x = hs[0]; z = hs[1]; yaw = P.yaw - Math.PI / 2; hop = true; }
    else if (U.boat) { if (!TRANSIT || !TRANSIT.river) toast("Boats are delivered to the ferry pier on the river"); var ws = waterSpot(-264, 52.2, U.L, Math.PI); x = ws[0]; z = ws[1]; yaw = Math.PI; }
    else if (CITY && CITY.inBounds(P.x, P.z)) { var rd = CITY.nearestRoad(P.x, P.z, 200, 2); if (rd) { var off = Math.max(1.4, rd.road.w / 4); x = rd.x - rd.dz * off; z = rd.z + rd.dx * off; yaw = Math.atan2(-rd.dz, rd.dx); } }
    if (x === undefined) { x = P.x + 4; z = P.z + 4; }
    if (!hop && !U.boat) { var fsp = findCarSpot(m, x, z, yaw); x = fsp[0]; z = fsp[1]; yaw = fsp[2]; }
    if (P.mode === "car") { taxi.v = 0; exitTaxi(); }
    swapRide(m, x, z, yaw); m.userData.rented = !!rented; taxi.alt = spot ? spot.alt || 0 : 0; taxi.vy = 0; taxi.pitch = 0; taxi.roll = 0; taxi.thr = 0; taxi.rpm = 0;
    m.position.set(x, (U.gy || 0) + taxi.alt, z); m.rotation.set(0, yaw, 0);
    missionEvent("sporty");
    if (hop) {
      /* aircraft: you are taken straight to the cockpit */
      $("fade").classList.add("on");
      setTimeout(function () { if (P.fall) endFall(true); P.lv = null; P.x = x; P.z = z; if (spot && spot.alt) taxi.alt = spot.alt; enterTaxi(); $("fade").classList.remove("on"); bigText("mstart", it.n, U.air === "plane" ? "Hold GAS to speed up, then UP to take off" : "Hold UP to take off · GAS to fly forward"); }, 650);
      return;
    }
    setWaypoint(x, z, it.n); toast((rented ? "Rented " : "Delivered ") + it.n + " · follow the purple line");
  }

  /* ---------- 3D preview (its own small renderer) ---------- */
  var SP = null;
  function shopPreview(canvas) {
    if (SP) return SP;
    var r = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true }); r.setPixelRatio(Math.min(2, window.devicePixelRatio || 1)); r.outputEncoding = THREE.sRGBEncoding;
    var sc = new THREE.Scene(), cam2 = new THREE.PerspectiveCamera(32, 1, 0.1, 100);
    sc.add(new THREE.HemisphereLight(0xffe0f0, 0x2a0f3f, 0.9)); var key = new THREE.DirectionalLight(0xffffff, 1.2); key.position.set(3, 6, 5); sc.add(key);
    var rim = new THREE.DirectionalLight(0xff3d8b, 1.0); rim.position.set(-5, 3, -4); sc.add(rim); var rim2 = new THREE.DirectionalLight(0x2ee6d6, 0.6); rim2.position.set(5, 2, -5); sc.add(rim2);
    var disc = new THREE.Mesh(new THREE.CircleGeometry(3.2, 48), new THREE.MeshBasicMaterial({ map: canvasTex(256, 256, function (g, w, h) { var gr = g.createRadialGradient(w / 2, h / 2, 4, w / 2, h / 2, w / 2); gr.addColorStop(0, "rgba(255,61,139,0.75)"); gr.addColorStop(0.5, "rgba(255,154,60,0.25)"); gr.addColorStop(1, "rgba(0,0,0,0)"); g.fillStyle = gr; g.fillRect(0, 0, w, h); }), transparent: true, depthWrite: false }));
    disc.rotation.x = -Math.PI / 2; disc.position.y = 0.005; sc.add(disc);
    var actor = People.create(player.traits); sc.add(actor.g); actor.play("Idle");
    var gun = buildGun(); scene.remove(gun); sc.add(gun);
    SP = { r: r, sc: sc, cam: cam2, actor: actor, gun: gun, obj: null, item: null, t: 0, raf: 0, canvas: canvas };
    return SP;
  }
  function previewShow(it) {
    var S = SP; if (!S) return; S.item = it;
    if (S.obj) { S.sc.remove(S.obj); S.obj = null; }
    var hasActor = !it.veh; S.actor.g.visible = hasActor;
    Object.keys(S.gun.userData.V).forEach(function (k) { S.gun.userData.V[k].visible = !!it.w && k === it.w; });
    if (it.w) S.actor.play(WEAP[it.w].melee ? "Idle" : it.w === "rpg" ? "Aim" : "GunIdle", { restart: true });
    else if (it.id === "armor" || it.id === "health" || it.id === "nitro") S.actor.play("Interact", { restart: true });
    if (it.veh) { S.obj = vehMesh(it.veh, it.col !== undefined ? it.col : VEHCOL[(it.id.length * 3) % VEHCOL.length]); if (S.obj.userData.boat) S.obj.position.y = 0.45; else if (S.obj.userData.gy) S.obj.position.y = S.obj.userData.gy; S.sc.add(S.obj); }
  }
  function previewLoop() {
    var S = SP; if (!S || $("shop").hidden) { if (S) S.raf = 0; return; }
    S.raf = requestAnimationFrame(previewLoop);
    var c = S.canvas, w = c.clientWidth, h = c.clientHeight; if (c.width !== Math.round(w * S.r.getPixelRatio()) || c.height !== Math.round(h * S.r.getPixelRatio())) { S.r.setSize(w, h, false); S.cam.aspect = w / Math.max(1, h); S.cam.setViewOffset(w, h, -w * 0.12, -h * 0.08, w, h); S.cam.updateProjectionMatrix(); }
    var dt = 1 / 60; S.t += dt; S.actor.update(dt);
    var it = S.item || {};
    if (it.veh) { var L = S.obj && S.obj.userData.L || 4.6, dist = Math.max(5.2, L * (S.obj.userData.air ? 2.15 : 1.75)); S.obj.rotation.y = S.t * 0.45; S.cam.position.set(dist * 0.85, dist * 0.4, dist * 0.85); S.cam.lookAt(0, 0.5, 0); }
    else { S.actor.g.rotation.y = Math.sin(S.t * 0.5) * 0.6 - 0.3; S.cam.position.set(1.2, 1.35, 4.4); S.cam.lookAt(0, 1.0, 0);
      if (it.w && S.gun) { var hand = S.actor.bones.hand_r, hp = new THREE.Vector3(); if (hand) { S.actor.g.updateMatrixWorld(true); hand.getWorldPosition(hp); } S.gun.visible = true; S.gun.position.copy(hp); S.gun.rotation.set(0, S.actor.g.rotation.y - Math.PI / 2, WEAP[it.w].melee ? 1.2 : 0); if (it.w === "rpg") S.gun.position.set(-0.2, 1.52, 0.05); } else if (S.gun) S.gun.visible = false; }
    S.r.render(S.sc, S.cam);
  }

  /* ---------- shop UI ---------- */
  var shopCat = "hand", shopSel = null;
  function openShop(cat) {
    sfx("shopOpen");
    if (cat) shopCat = cat; $("shop").hidden = false; document.body.classList.add("shopping"); closePhone();
    try { shopPreview($("spCv")); } catch (e) { console.error(e); }
    renderShop(); if (SP && !SP.raf) previewLoop();
  }
  function closeShop() { $("shop").hidden = true; document.body.classList.remove("shopping"); }
  function renderShop() {
    $("shBal").textContent = Math.round(G.balance).toLocaleString("en-US");
    $("shCats").innerHTML = CATS.map(function (c) { return "<button type='button' class='" + (c.id === shopCat ? "on" : "") + "' data-cat='" + c.id + "' aria-label='" + c.n + "'>" + (c.ic ? wIcon(c.ic) : "<svg viewBox='0 0 64 60' fill='currentColor'>" + c.svg + "</svg>") + "<span>" + c.n + "</span></button>"; }).join("");
    var list = ITEMS.filter(function (i) { return i.cat === shopCat; });
    if (!shopSel || shopSel.cat !== shopCat) shopSel = list[0];
    $("shList").innerHTML = list.map(function (i) { var ow = owned(i), cn = itemCount(i); return "<button type='button' class='sh-it" + (i === shopSel ? " on" : "") + "' data-it='" + i.id + "' style='--rc:" + RAR[i.r] + "'><i>" + (i.w ? wIcon(i.w) : "<svg viewBox='0 0 64 60' fill='currentColor'>" + i.svg + "</svg>") + (ow ? "<em>" + (i.w && G.wsel === i.w ? "EQUIPPED" : "OWNED") + "</em>" : cn ? "<em>\u00d7" + cn + "</em>" : "") + "</i><b class='nm'>" + i.n + "</b><small class='pr'>" + (ow && i.veh ? "IN GARAGE" : i.price.toLocaleString("en-US") + " TOKEN") + "</small></button>"; }).join("");
    var it = shopSel; if (!it) return;
    $("shName").textContent = it.n; $("shRar").textContent = it.r; $("shRar").style.background = RAR[it.r];
    $("shStats").innerHTML = it.st.map(function (q) { return "<div class='st'><span>" + q[0] + "</span><b><i style='width:" + q[1] + "%'></i></b><em>" + q[2] + "</em></div>"; }).join("");
    var ow = owned(it), acts = "";
    if (it.w) acts = ow ? (G.wsel === it.w ? "<button class='sb' type='button' data-a='unequip'><small>EQUIPPED</small>UNEQUIP</button>" : "<button class='sb' type='button' data-a='equip'><small>OWNED</small>EQUIP</button>") + (WEAP[it.w].melee ? "" : "<button class='sb' type='button' data-a='buy'><small>AMMO +" + WEAP[it.w].clip + "</small>" + Math.round(it.price * 0.4) + " TOKEN</button>") : "<button class='sb' type='button' data-a='buy'><small>BUY</small>" + it.price + " TOKEN</button>";
    else if (it.veh) acts = (ow ? "<button class='sb' type='button' data-a='call'><small>OWNED</small>DELIVER</button>" : "<button class='sb' type='button' data-a='buy'><small>BUY</small>" + it.price + " TOKEN</button>") + "<button class='sb' type='button' data-a='rent'><small>RENT</small>" + it.rent + " TOKEN</button>";
    else acts = "<button class='sb' type='button' data-a='buy'><small>BUY</small>" + it.price + " TOKEN</button>";
    $("shActs").innerHTML = acts;
    Array.prototype.forEach.call($("shActs").querySelectorAll("button"), function (b) { var a = b.getAttribute("data-a"), cost = a === "buy" ? (it.w && ow ? Math.round(it.price * 0.4) : it.price) : a === "rent" ? it.rent : 0; if (cost && G.balance < cost) b.disabled = true; });
    previewShow(it);
  }
  function shopAct(a) {
    var it = shopSel; if (!it) return;
    var ow = owned(it), cost = a === "buy" ? (it.w && ow ? Math.round(it.price * 0.4) : it.price) : a === "rent" ? it.rent : 0;
    if (cost && G.balance < cost) { toast("Not enough TOKEN"); return; }
    if (it.veh && inAir() && taxi.alt - topAt(taxi.x, taxi.z) > 2) { toast("Land first, then order a new ride"); return; }
    if (cost) spend(cost, (a === "rent" ? "Rent · " : "Shop · ") + it.n);
    if (it.w) { if (a === "buy") giveWeapon(it.w, WEAP[it.w].melee ? 1 : WEAP[it.w].clip); else if (a === "equip") { G.wsel = it.w; weapUI(); } else if (a === "unequip") { G.wsel = "fist"; weapUI(); } }
    else if (it.id === "armor") G.armor = 100; else if (it.id === "health") G.hp = 100; else if (it.id === "snack") G.food = 100; else if (it.id === "nitro") G.nitro = Math.min(30, G.nitro + 3); else if (it.id === "nitro10") G.nitro = Math.min(30, G.nitro + 10); else if (it.id === "chute") G.chute = (G.chute || 0) + 1; else if (it.id === "chute3") G.chute = (G.chute || 0) + 3;
    else if (it.veh) { if (a === "buy") { (G.garage = G.garage || []).push(it.id); } closeShop(); deliver(it, a === "rent"); }
    if (a === "buy" || a === "rent") { var fl = $("shFlash"); fl.classList.remove("go"); void fl.offsetWidth; fl.classList.add("go"); }
    save(); weapUI(); if (!$("shop").hidden) renderShop();
  }
  $("shCats").addEventListener("click", function (e) { var b = e.target.closest("[data-cat]"); if (!b) return; shopCat = b.getAttribute("data-cat"); shopSel = null; renderShop(); });
  $("shList").addEventListener("click", function (e) { var b = e.target.closest("[data-it]"); if (!b) return; var id = b.getAttribute("data-it"); shopSel = ITEMS.filter(function (i) { return i.id === id; })[0]; renderShop(); });
  $("shActs").addEventListener("click", function (e) { var b = e.target.closest("[data-a]"); if (b && !b.disabled) shopAct(b.getAttribute("data-a")); });
  $("shBack").addEventListener("click", closeShop);
  $("wPrev").addEventListener("pointerdown", function (e) { e.preventDefault(); e.stopPropagation(); prevWeapon(); });
  $("wNext").addEventListener("pointerdown", function (e) { e.preventDefault(); e.stopPropagation(); nextWeapon(); });
  $("wIc").addEventListener("click", function () { openShop(WEAP[G.wsel] && WEAP[G.wsel].melee ? "melee" : G.wsel === "rpg" ? "heavy" : G.wsel === "pistol" || G.wsel === "fist" ? "hand" : "auto"); });
  window.addEventListener("keydown", function (e) { if (e.key === "Escape" && !$("shop").hidden) closeShop(); if ((e.key === "b" || e.key === "B") && $("modal").hidden && !e.repeat) { if ($("shop").hidden) openShop(); else closeShop(); } });

  weapUI();
  /* ===================== Getting in and out of cars: walk to the door, open it, pull the driver out, sit, close ===================== */
  var VSEQ = null;
  function carPose(c) { return { x: c.x, z: c.z, yaw: c.yaw !== undefined ? c.yaw : (c.dir > 0 ? 0 : Math.PI) }; }
  function locW(p, lx, lz) { var cs = Math.cos(p.yaw), sn = Math.sin(p.yaw); return { x: p.x + lx * cs + lz * sn, z: p.z - lx * sn + lz * cs }; }
  function toLoc(p, x, z) { var dx = x - p.x, dz = z - p.z, cs = Math.cos(p.yaw), sn = Math.sin(p.yaw); return { x: dx * cs - dz * sn, z: dx * sn + dz * cs }; }
  function setDoor(m, k) {
    var D = m.userData.door; if (!D) return;
    if (k > 0.01 && !D.cab && D.mk) { D.cab = D.mk(); m.add(D.cab); }
    D.piv.rotation.y = -1.15 * k;
  }
  function hasDoor(m) { var U = m.userData; return !!(U.door && !U.moto && !U.boat && !U.air && !U.tank); }
  /* user pressed "get in": walk round to the driver door, open it, (pull the driver out), sit, close */
  function boardVehicle(jackCar) {
    var car = jackCar || taxi, m = car.m;
    if (!hasDoor(m) || VSEQ || INSIDE) { if (jackCar) carjackNow(jackCar); else { enterTaxi(); if (m.userData.tank) cam.tdist = 14; } return; }
    var pose = carPose(car), D = m.userData.door, st = locW(pose, D.stand[0], D.stand[1]), lp = toLoc(pose, P.x, P.z), path = [];
    if (lp.z > -m.userData.W / 2 - 0.2) { var endX = lp.x >= 0 ? m.userData.L / 2 + 0.9 : -m.userData.L / 2 - 0.9; var a1 = locW(pose, endX, Math.max(lp.z, m.userData.W / 2 + 0.7)), a2 = locW(pose, endX, -m.userData.W / 2 - 0.7); if (lp.z > 0) path.push(a1); path.push(a2); }
    path.push(st);
    VSEQ = { kind: "in", car: car, m: m, pose: pose, path: path, seg: 0, t: 0, phase: "walk", jack: !!jackCar };
    if (jackCar) { jackCar.jacked = true; jackCar.v = 0; jackCar.vmax = 0; }
    $("prompt").hidden = true; curZone = null;
  }
  function leaveVehicle() {
    if (VSEQ) return;
    if (P.mode === "car" && hasDoor(taxi.m) && Math.abs(taxi.v) <= 1.5 && !INSIDE && !onBridge(taxi.x, taxi.z)) { taxi.v = 0; VSEQ = { kind: "out", car: taxi, m: taxi.m, pose: carPose(taxi), t: 0, phase: "open" }; sfx("door_open", [taxi.x, taxi.z]); return; }
    exitTaxi();
  }
  function vseqTick(dt) {
    var S = VSEQ; if (!S) return; S.t += dt;
    var D = S.m.userData.door, pose = S.pose;
    if (S.kind === "in") {
      if (S.phase === "walk") {
        var tg = S.path[S.seg], dx = tg.x - P.x, dz = tg.z - P.z, d = Math.hypot(dx, dz), sp = 2.6;
        if (d > 0.05) { var stp = Math.min(d, sp * dt); P.x += dx / d * stp; P.z += dz / d * stp; P.yaw += wrapA(Math.atan2(dx, dz) - P.yaw) * Math.min(1, dt * 12); player.play("Walk", { speed: 1.4, fade: 0.15 }); }
        if (d < 0.08 || S.t > 4) { S.seg++; if (S.seg >= S.path.length) { S.phase = "open"; S.t = 0; sfx("door_open", [pose.x, pose.z]); var face = locW(pose, D.stand[0], 0); P.yaw = Math.atan2(face.x - P.x, face.z - P.z); player.play("Open", { once: true, restart: true, speed: 1.6 }); } }
      } else if (S.phase === "open") {
        var k = Math.min(1, S.t / 0.45); setDoor(S.m, k * k * (3 - 2 * k));
        if (S.t >= 0.5) { S.t = 0; S.phase = S.jack ? "drag" : "sit"; if (S.jack) { var drv = S.car.rider || makeActor(Math.random() < 0.6 ? "man" : "woman"); S.car.rider = null; S.drv = drv; var sp0 = locW(pose, D.seat[0], D.seat[1]); drv.g.position.set(sp0.x, 0.25, sp0.z); drv.g.rotation.y = Math.atan2(Math.cos(pose.yaw), -Math.sin(pose.yaw)); drv.play("Sit"); player.play("Push", { once: true, restart: true, speed: 0.9 }); } else player.play("SitDown", { once: true, restart: true, speed: 1.5 }); }
      } else if (S.phase === "drag") {
        var a = S.drv, k2 = Math.min(1, S.t / 1.1), p0 = locW(pose, D.seat[0], D.seat[1]), p1 = locW(pose, D.stand[0] - 0.2, D.stand[1] - 1.7);
        if (S.t > 0.25) { var e = Math.min(1, (S.t - 0.25) / 0.6); a.g.position.set(lerp(p0.x, p1.x, e), lerp(0.25, 0, e), lerp(p0.z, p1.z, e)); a.g.rotation.y = Math.atan2(P.x - a.g.position.x, P.z - a.g.position.z); if (!S.ko && e > 0.55) { S.ko = true; a.play("KnockOut", { once: true, restart: true }); } }
        if (S.t > 0.35 && S.t < 0.4) player.play("Cross", { once: true, restart: true, speed: 0.8 });
        if (k2 >= 1) { S.phase = "sit"; S.t = 0; var pd = { a: a, x: p1.x, z: p1.z, st: "ko", t: 4.2, hp: 1, face: a.g.rotation.y }; PEDS.push(pd); player.play("SitDown", { once: true, restart: true, speed: 1.5 }); }
      } else if (S.phase === "sit") {
        var k3 = Math.min(1, S.t / 0.55), a0 = locW(pose, D.stand[0], D.stand[1]), a1 = locW(pose, D.seat[0], D.seat[1]);
        P.x = lerp(a0.x, a1.x, k3); P.z = lerp(a0.z, a1.z, k3); P.yaw = Math.atan2(Math.cos(pose.yaw), -Math.sin(pose.yaw)); S.sink = k3 * 0.3;
        if (k3 >= 1) { S.phase = "close"; S.t = 0; player.g.visible = false; sfx("door_close", [pose.x, pose.z]); }
      } else if (S.phase === "close") {
        var k4 = Math.min(1, S.t / 0.35); setDoor(S.m, 1 - k4);
        if (k4 >= 1) { var car = S.car, jack = S.jack; VSEQ = null; setDoor(S.m, 0); if (jack) carjackNow(car, true); else { enterTaxi(); if (S.m.userData.tank) cam.tdist = 14; } }
      }
    } else {
      if (S.phase === "open") {
        var k5 = Math.min(1, S.t / 0.4); setDoor(S.m, k5 * k5 * (3 - 2 * k5));
        if (k5 >= 1) { taxi.v = 0; exitTaxi();
          /* if getting out was refused, close the door again and stay in the seat */
          if (P.mode !== "walk") { setDoor(S.m, 0); VSEQ = null; player.g.visible = false; return; }
          var s0 = locW(pose, D.seat[0], D.seat[1]); S.to = locW(pose, D.stand[0], D.stand[1]); var q = { x: S.to.x, z: S.to.z }; collide(q, 0.32); if (CITY) CITY.collide(q, 0.34); S.to = q; P.x = s0.x; P.z = s0.z; P.yaw = Math.atan2(S.to.x - s0.x, S.to.z - s0.z); player.g.visible = true; player.play("StandUp", { once: true, restart: true, speed: 1.6 }); S.phase = "out"; S.t = 0; }
      } else if (S.phase === "out") {
        var k6 = Math.min(1, S.t / 0.55), s1 = locW(pose, D.seat[0], D.seat[1]);
        P.x = lerp(s1.x, S.to.x, k6); P.z = lerp(s1.z, S.to.z, k6); S.sink = (1 - k6) * 0.3;
        if (k6 >= 1) { S.phase = "close"; S.t = 0; sfx("door_close", [pose.x, pose.z]); var fc = locW(pose, D.stand[0], 0); P.yaw = Math.atan2(fc.x - P.x, fc.z - P.z); player.play("Push", { once: true, restart: true, speed: 1.4 }); }
      } else if (S.phase === "close") {
        var k7 = Math.min(1, S.t / 0.35); setDoor(S.m, 1 - k7);
        if (k7 >= 1) { setDoor(S.m, 0); VSEQ = null; player.play("Idle"); }
      }
    }
  }
  /* ===================== Heights, roofs and falling ===================== */
  /* the highest solid surface at (x, z): tower, city buildings, hand-built blocks, the bridge deck */
  function topAt(x, z) {
    var h = 0;
    if (TOWER) { var th = TOWER.topAt(x, z); if (th > h) h = th; }
    if (CITY && CITY.inBounds(x, z)) { var b = CITY.buildingAt(x, z); if (b) h = Math.max(h, b.h || 10); }
    for (var i = 0; i < COL.length; i++) { var c = COL[i]; if (c.on && c.tag === "bld" && !c.hf && x > c.x1 && x < c.x2 && z > c.z1 && z < c.z2) h = Math.max(h, c.h || 12); }
    if (onBridge(x, z)) h = Math.max(h, bridgeY(x));
    return h;
  }
  /* a walkable surface for the player at (x, z) at height y (a roof, the tower deck...) or null for the street */
  function surfaceAt(x, z, y) {
    if (y < 1.2) return null;
    if (TOWER) { var ts = TOWER.surface(x, z, y); if (ts) return ts; }
    if (onBridge(x, z) && Math.abs(bridgeY(x) - y) < 1.5) return null;
    if (CITY && CITY.inBounds(x, z)) { var b = CITY.buildingAt(x, z); if (b && Math.abs((b.h || 10) - y) < 2) return { id: "roof", y: b.h || 10, col: [], inside: function (px, pz) { return CITY.buildingAt(px, pz) === b; } }; }
    for (var i = 0; i < COL.length; i++) { var c = COL[i]; if (c.on && c.tag === "bld" && !c.hf && x > c.x1 && x < c.x2 && z > c.z1 && z < c.z2) { var cc = c; return { id: "roof", y: c.h || 12, col: [], inside: function (px, pz) { return px > cc.x1 && px < cc.x2 && pz > cc.z1 && pz < cc.z2; } }; } }
    return null;
  }
  function collideList(list, p, r) {
    for (var i = 0; i < list.length; i++) {
      var c = list[i], cx = clamp(p.x, c.x1, c.x2), cz = clamp(p.z, c.z1, c.z2), dx = p.x - cx, dz = p.z - cz, d2 = dx * dx + dz * dz;
      if (d2 < r * r) { if (d2 > 1e-8) { var d = Math.sqrt(d2), k = (r - d) / d; p.x += dx * k; p.z += dz * k; } else { var l = p.x - c.x1, rr = c.x2 - p.x, t = p.z - c.z1, b = c.z2 - p.z, mn = Math.min(l, rr, t, b); if (mn === l) p.x = c.x1 - r; else if (mn === rr) p.x = c.x2 + r; else if (mn === t) p.z = c.z1 - r; else p.z = c.z2 + r; } }
    }
  }
  function playerY() { return P.fall ? P.fall.y : P.mode === "car" && taxi.m && taxi.m.userData.air ? taxi.alt : P.lv ? P.lv.y : (onBridge(P.x, P.z) ? bridgeY(P.x) : 0); }
  if (G.chute == null) G.chute = 0;
  /* parachute canopy */
  var CHUTE = (function () {
    var g = new THREE.Group(), tex = canvasTex(512, 128, function (c, w, h) { var cols = ["#ff3d8b", "#ff9a3c", "#ffd23f", "#2ee6d6", "#6b2bd9", "#ff3d8b", "#ff9a3c", "#ffd23f"]; for (var i = 0; i < 8; i++) { c.fillStyle = cols[i]; c.fillRect(i * w / 8, 0, w / 8 + 1, h); } c.fillStyle = "rgba(255,255,255,0.9)"; c.font = "900 44px Arial Black, Arial"; c.textAlign = "center"; c.fillText("EARTHPASS", w * 0.25, h * 0.62); c.fillText("EARTHPASS", w * 0.75, h * 0.62); });
    var can = new THREE.Mesh(new THREE.SphereGeometry(3.4, 24, 8, 0, Math.PI * 2, 0, Math.PI * 0.32), new THREE.MeshStandardMaterial({ map: tex, side: THREE.DoubleSide, roughness: 0.7 }));
    can.scale.set(1.5, 0.75, 0.82); can.position.y = 3.8; can.castShadow = true; g.add(can);
    var pts = []; for (var i = 0; i < 8; i++) { var a = i / 8 * Math.PI * 2, rx = Math.cos(a) * 3.4 * Math.sin(Math.PI * 0.32) * 1.5, rz = Math.sin(a) * 3.4 * Math.sin(Math.PI * 0.32) * 0.82; pts.push(new THREE.Vector3(rx, 3.8 + 3.4 * Math.cos(Math.PI * 0.32) * 0.75, rz), new THREE.Vector3(0, 0.15, rz > 0 ? 0.18 : -0.18)); }
    var lines = new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: 0x222222 })); g.add(lines);
    g.visible = false; scene.add(g); return g;
  })();
  function startFall(y, vx, vz) {
    if (P.mode === "car") { driveUI(false); P.mode = "walk"; }
    P.fall = { y: y, vy: 0, vx: vx || 0, vz: vz || 0, chute: false, t: 0, y0: y };
    P.lv = null; P.swim = false; P.seat = null; player.g.visible = true; $("prompt").hidden = true; curZone = null;
    cam.tdist = 8; cam.pitch = 0.5; $("bRun").textContent = "RUN"; document.body.classList.add("falling"); weapUI();
    if (TOWER && TOWER.crowd && !(Math.abs(P.x - TOWER.x) < 30 && Math.abs(P.z - TOWER.z) < 30)) TOWER.leave();
  }
  function deployChute(auto) {
    var F = P.fall; if (!F || F.chute) return false;
    if (!(G.chute > 0)) { if (!auto) toast("No parachute! Buy one in the shop (B)"); return false; }
    sfx("chute");
    G.chute--; save(); F.chute = true; F.ct = 0; F.vx *= 0.4; F.vz *= 0.4; CHUTE.visible = true; CHUTE.scale.set(0.1, 0.1, 0.1); cam.tdist = 11; cam.pitch = 0.22;
    toast("Parachute open · steer with the joystick"); weapUI(); return true;
  }
  function endFall(silent) {
    P.fall = null; CHUTE.visible = false; document.body.classList.remove("falling"); player.g.rotation.x = 0; cam.tdist = 6.2; cam.pitch = 0.32; weapUI();
  }
  function fallTick(dt, ix, iz, mag) {
    var F = P.fall; F.t += dt;
    var cy = Math.cos(cam.yaw), sy = Math.sin(cam.yaw), wx = ix * cy + iz * sy, wz = -ix * sy + iz * cy, fl = topAt(P.x, P.z);
    if (!F.chute) {
      F.vy = Math.max(-52, F.vy - 9.8 * dt);
      var sp = 15 * Math.min(1, mag); F.vx = lerp(F.vx, wx / (Math.hypot(wx, wz) || 1) * sp, 1 - Math.exp(-dt * 1.2)); F.vz = lerp(F.vz, wz / (Math.hypot(wx, wz) || 1) * sp, 1 - Math.exp(-dt * 1.2));
      if (mag > 0.1) P.yaw += wrapA(Math.atan2(wx, wz) - P.yaw) * Math.min(1, dt * 3);
      if (G.chute > 0 && F.y - fl < 60 && F.y - fl > 8 && F.t > 1) deployChute(true);
      blendTo(player, "Swim", dt, 0.45);
    } else {
      F.ct += dt; var k = Math.min(1, F.ct / 0.7); CHUTE.scale.set(k, k, k);
      F.vy = lerp(F.vy, iz > 0.3 ? -7.5 : -4.6, 1 - Math.exp(-dt * 2.4));
      P.yaw -= ix * dt * 1.25;
      var gs = iz < -0.3 ? 11 : iz > 0.3 ? 5 : 8.5; F.vx = lerp(F.vx, Math.sin(P.yaw) * gs, 1 - Math.exp(-dt * 1.5)); F.vz = lerp(F.vz, Math.cos(P.yaw) * gs, 1 - Math.exp(-dt * 1.5));
      blendTo(player, "JumpAir", dt, 0.3);
      var bc = P.yaw + Math.PI, dc = wrapA(bc - cam.yaw); cam.yaw += dc * Math.min(1, dt * 1.2);
    }
    var nx = P.x + F.vx * dt, nz = P.z + F.vz * dt, ny = F.y + F.vy * dt, nh = topAt(nx, nz);
    if (nh > F.y + 0.3) { F.vx *= -0.3; F.vz *= -0.3; nx = P.x; nz = P.z; nh = fl; }
    P.x = nx; P.z = nz; F.y = ny;
    if (F.y <= nh + 0.02) landFall(nh);
  }
  function landFall(h) {
    var F = P.fall, v = -F.vy, chute = F.chute; endFall();
    var s = surfaceAt(P.x, P.z, h); P.lv = s;
    if (!s && h < 1.2 && isWater(P.x, P.z) && !deckAt(P.x, P.z)) { P.swim = true; if (v > 30) hurtPlayer(60); toast(chute ? "Splash down! Swim to the shore" : "Splash!"); return; }
    if (v > 26) { hurtPlayer(250); return; }
    if (v > 12) { hurtPlayer(Math.round((v - 12) * 6)); toast("Hard landing!"); }
    else { player.play("JumpLand", { once: true, restart: true }); if (chute) { skillAdd("fly", 2); bigText("mpass", "Nice landing!", "Parachute jump · +" + 25 + " TOKEN"); earn(25, "Parachute landing"); missionEvent("chuteLand"); } }
    if (!s) { var q = { x: P.x, z: P.z }; collide(q, 0.32); if (CITY) CITY.collide(q, 0.34); P.x = q.x; P.z = q.z; }
  }

  /* ===================== Flying: helicopters and planes ===================== */
  var AIRB = { up: 0, down: 0 }, WRECKS = [], airFireCd = 0;
  function inAir() { return P.mode === "car" && taxi.m && !!taxi.m.userData.air; }
  function airUD() { return ((AIRB.up || keys[" "] || keys.e) ? 1 : 0) - ((AIRB.down || keys.q || keys.c) ? 1 : 0); }
  function flyUI(on) {
    var U = on && taxi.m ? taxi.m.userData : {};
    document.body.classList.toggle("flying", !!on); document.body.classList.toggle("armedair", !!(on && U.armed));
    $("dG").innerHTML = on ? (U.air === "plane" ? "THR<br>+" : "FWD") : "GAS"; $("dB").innerHTML = on ? (U.air === "plane" ? "THR<br>&minus;" : "BACK") : "BRAKE<br>REV";
    AIRB.up = AIRB.down = 0; ["dU", "dD"].forEach(function (id) { $(id).classList.remove("on"); });
  }
  function airGas() { return drive.gas || keys.w || keys.arrowup ? 1 : 0; }
  function airBrk() { return drive.brake || keys.s || keys.arrowdown ? 1 : 0; }
  function airSteer() { return (drive.left || keys.a || keys.arrowleft ? 1 : 0) - (drive.right || keys.d || keys.arrowright ? 1 : 0); }
  function airTick(dt, busy) {
    var U = taxi.m.userData, gas = airGas(), brk = airBrk(), st = airSteer(), ud = airUD(), fs = 1 + sk("fly") / 300;
    if (busy) { gas = brk = st = ud = 0; }
    taxi.alt = taxi.alt || 0; taxi.vy = taxi.vy || 0; taxi.pitch = taxi.pitch || 0; taxi.roll = taxi.roll || 0;
    var fl = topAt(taxi.x, taxi.z), ground = taxi.alt <= fl + 0.08, cs = Math.cos(taxi.yaw), sn = Math.sin(taxi.yaw), VM = U.vmax * (NITRO.t > 0 ? 1.35 : 1);
    if (U.air === "heli") {
      taxi.rpm = Math.min(1, (taxi.rpm || 0) + dt * 0.55);
      var spun = taxi.rpm > 0.8, vyT = !spun ? (ground ? 0 : -6) : ud > 0 ? 8.5 * fs : ud < 0 ? -7 : 0;
      taxi.vy = lerp(taxi.vy, vyT, 1 - Math.exp(-dt * 2.6));
      var hvT = ground ? 0 : (gas - brk * 0.45) * VM;
      taxi.v = lerp(taxi.v, hvT, 1 - Math.exp(-dt * (Math.abs(hvT) > Math.abs(taxi.v) ? 0.6 * (U.acc / 10) : 0.9)));
      if (spun) taxi.yaw += st * 1.35 * fs * dt;
      taxi.pitch = lerp(taxi.pitch, -clamp(taxi.v / U.vmax, -0.5, 1) * 0.3, 1 - Math.exp(-dt * 3)); taxi.roll = lerp(taxi.roll, ground ? 0 : -st * 0.24, 1 - Math.exp(-dt * 3));
    } else {
      taxi.thr = clamp((taxi.thr || 0) + (gas ? 0.55 : 0) * dt - (brk ? 0.7 : 0) * dt, 0, 1);
      var tv = taxi.thr * VM; if (ground && brk && taxi.thr < 0.05) tv = 0;
      var rate = tv > taxi.v ? U.acc / Math.max(20, U.vmax) * 0.9 : (ground && brk ? 1.6 : 0.25);
      taxi.v = lerp(taxi.v, tv, 1 - Math.exp(-dt * rate)); if (NITRO.t > 0 && !busy) taxi.v += 10 * dt;
      if (ground) {
        taxi.yaw += st * dt * 0.8 * clamp(taxi.v / 5, 0, 1) / (1 + taxi.v / 30); taxi.roll = lerp(taxi.roll, 0, 1 - Math.exp(-dt * 4));
        taxi.pitch = lerp(taxi.pitch, ud > 0 && taxi.v > U.stall * 0.92 ? 0.2 : 0, 1 - Math.exp(-dt * 2.5));
      } else {
        taxi.roll = lerp(taxi.roll, -st * 0.8, 1 - Math.exp(-dt * 2.2));
        taxi.pitch = lerp(taxi.pitch, ud * 0.42 * Math.min(1.2, fs), 1 - Math.exp(-dt * 1.5));
        taxi.yaw += -taxi.roll * 0.62 * dt * clamp(taxi.v / U.stall, 0.4, 1.2) * fs;
      }
      var lift = clamp((taxi.v - U.stall * 0.72) / (U.stall * 0.28), 0, 1), vyT2 = taxi.v * Math.sin(taxi.pitch) * lift - (1 - lift) * 15;
      if (ground && vyT2 < 0) vyT2 = 0;
      var agl = taxi.alt - fl; if (!ground && agl < 10 && vyT2 < -2.5) vyT2 = lerp(-2.5, vyT2, agl / 10);
      taxi.vy = lerp(taxi.vy, vyT2, 1 - Math.exp(-dt * 3));
      if (U.prop) U.prop.rotation.x += dt * (8 + taxi.thr * 70);
      if (U.ab) U.ab.material.opacity = NITRO.t > 0 ? 0.9 : taxi.thr > 0.85 ? 0.45 : 0;
    }
    var sp = taxi.v, nx = taxi.x + cs * sp * dt, nz = taxi.z - sn * sp * dt, na = taxi.alt + taxi.vy * dt, reach = (U.L || 8) * 0.5 * (sp >= 0 ? 1 : -1);
    var hN = topAt(nx + cs * reach, nz - sn * reach), hC = topAt(nx, nz);
    if (hN > taxi.alt + 0.5 || hC > taxi.alt + 0.5) {
      if (Math.abs(sp) > (U.air === "heli" ? 15 : 12)) { airCrash(); return; }
      if (Math.abs(sp) > 3) toast("Bump!"); taxi.v = -sp * 0.25; nx = taxi.x; nz = taxi.z; hC = fl;
    }
    if (na <= hC) {
      if (taxi.vy < (U.air === "plane" ? -13 : -9.5) || (U.air === "plane" && !ground && (Math.abs(taxi.roll) > 0.75 || taxi.pitch < -0.32))) { taxi.x = nx; taxi.z = nz; taxi.alt = hC; airCrash(); return; }
      if (!ground && taxi.vy < -2) toast(U.air === "heli" ? "Touchdown" : "Smooth landing");
      na = hC; taxi.vy = Math.max(0, taxi.vy);
    }
    na = Math.min(na, 1500);
    var moved = Math.hypot(nx - taxi.x, nz - taxi.z); if (na > hC + 3) skillAdd("fly", moved * 0.004);
    taxi.x = nx; taxi.z = nz; taxi.alt = na; P.x = taxi.x; P.z = taxi.z;
    if (taxi.alt < 0.4 && hC < 0.2 && isWater(taxi.x, taxi.z) && !deckAt(taxi.x, taxi.z) && deepWater(taxi.x, taxi.z)) { taxi.alt = 0; sinkCar(); return; }
  }
  function placeAir(dt) {
    var m = taxi.m, U = m.userData; m.rotation.order = "YZX";
    m.position.set(taxi.x, (taxi.alt || 0) + (U.gy || 0), taxi.z); m.rotation.set(taxi.roll || 0, taxi.yaw, taxi.pitch || 0);
    if (U.rotor) { U.rotor.rotation.y += dt * 30 * (taxi.rpm || 0); U.tail.rotation.z += dt * 45 * (taxi.rpm || 0); }
  }
  function airFire() {
    var U = taxi.m.userData, now2 = performance.now(); if (!U.armed || now2 < airFireCd) return; airFireCd = now2 + 650;
    var cp = Math.cos(taxi.pitch || 0), dir = new THREE.Vector3(Math.cos(taxi.yaw) * cp, Math.sin(taxi.pitch || 0) - (U.air === "heli" ? 0.12 : 0.02), -Math.sin(taxi.yaw) * cp).normalize();
    taxi.m.updateMatrixWorld(true);
    (U.pods || [[2, 1, 0]]).forEach(function (pd) { var from = new THREE.Vector3(pd[0] + 1.2, pd[1], pd[2]).applyMatrix4(taxi.m.matrixWorld); flash(from); launchRocket(from, 0, null, U.air === "plane" ? Math.max(120, taxi.v + 70) : 95, 8, true, dir.clone()); });
    shakeT = Math.max(shakeT, 0.15);
  }
  function newRankTaxi() { var nm = carMesh(0xf2c230, "sedan", true); scene.add(nm); taxi.m = nm; taxi.x = -65.5; taxi.z = 18; taxi.yaw = Math.PI / 2; taxi.v = 0; taxi.alt = 0; taxi.vy = 0; taxi.pitch = 0; taxi.roll = 0; taxi.skip = false; }
  /* leave the aircraft in flight: you fall (open the parachute!) and the aircraft goes down */
  function bailOut() {
    var U = taxi.m.userData, sp = taxi.v;
    WRECKS.push({ m: taxi.m, x: taxi.x, z: taxi.z, yaw: taxi.yaw, alt: taxi.alt, v: taxi.v, vy: taxi.vy, pitch: taxi.pitch, roll: taxi.roll, gy: U.gy || 0, rotor: U.rotor, t: 0 });
    var ox = taxi.x - Math.sin(taxi.yaw) * 2.6, oz = taxi.z - Math.cos(taxi.yaw) * 2.6, y = taxi.alt + (U.gy || 0) + 0.5;
    flyUI(false); driveUI(false); P.mode = "walk"; P.x = ox; P.z = oz; P.yaw = Math.atan2(Math.cos(taxi.yaw), -Math.sin(taxi.yaw));
    startFall(y, Math.cos(taxi.yaw) * sp * 0.5, -Math.sin(taxi.yaw) * sp * 0.5);
    newRankTaxi(); toast(G.chute > 0 ? "You jumped! Press OPEN (or Space) to open the parachute" : "You jumped without a parachute!");
  }
  function airCrash() {
    var U = taxi.m.userData, x = taxi.x, z = taxi.z, y = taxi.alt, fl = topAt(x, z);
    explode(x, y + 0.5, z, 9, false); taxi.m.traverse(function (o) { if (o.isMesh) o.material = BURNT; });
    var w = { m: taxi.m, x: x, z: z, yaw: taxi.yaw, alt: y, v: 0, vy: -2, pitch: taxi.pitch, roll: taxi.roll, gy: U.gy || 0, t: 0, dead: true };
    WRECKS.push(w); flyUI(false); driveUI(false); P.mode = "walk"; player.g.visible = true;
    P.x = x - Math.sin(taxi.yaw) * 3.5; P.z = z - Math.cos(taxi.yaw) * 3.5; cam.tdist = 6.2; cam.pitch = 0.32; $("bRun").textContent = "RUN";
    newRankTaxi(); bigText("mpass", "CRASH!", U.air === "heli" ? "Your helicopter is wrecked" : "Your plane is wrecked", true);
    if (y - fl > 5) { startFall(y + 1, 0, 0); hurtPlayer(20); }
    else { var s = surfaceAt(P.x, P.z, fl); P.lv = s; if (!s) { var q = { x: P.x, z: P.z }; collide(q, 0.32); if (CITY) CITY.collide(q, 0.34); P.x = q.x; P.z = q.z; } hurtPlayer(45); }
  }
  function wreckTick(dt) {
    for (var i = WRECKS.length - 1; i >= 0; i--) {
      var w = WRECKS[i], fl = topAt(w.x, w.z); w.t += dt;
      if (!w.down) {
        w.vy = Math.max(-45, w.vy - 9.8 * dt); w.v *= (1 - dt * 0.25); w.x += Math.cos(w.yaw) * w.v * dt; w.z -= Math.sin(w.yaw) * w.v * dt; w.alt += w.vy * dt;
        w.pitch = lerp(w.pitch || 0, -0.5, dt * 0.6); w.roll = (w.roll || 0) + dt * 0.8; if (w.rotor) w.rotor.rotation.y += dt * 8;
        var hf = topAt(w.x, w.z);
        if (w.alt <= hf) { w.alt = hf; w.down = true; if (!w.dead) { explode(w.x, hf + 0.5, w.z, 9, true); w.m.traverse(function (o) { if (o.isMesh) o.material = BURNT; }); } w.pitch = 0; w.roll = 0.2; w.smokeT = 25; }
      } else if (w.t > 40) { scene.remove(w.m); WRECKS.splice(i, 1); continue; }
      w.m.rotation.order = "YZX"; w.m.position.set(w.x, w.alt + (w.down ? 0 : w.gy), w.z); w.m.rotation.set(w.roll || 0, w.yaw, w.pitch || 0);
      if (w.down && w.smokeT > 0) { w.smokeT -= dt; if (Math.random() < dt * 4) puff(w.x + (Math.random() - 0.5) * 2, w.alt + 1.5, w.z + (Math.random() - 0.5) * 2, 1.2, 3, true); }
    }
  }
  [["dU", "up"], ["dD", "down"]].forEach(function (pr) {
    var el = $(pr[0]), k = pr[1];
    function dn(e) { e.preventDefault(); e.stopPropagation(); try { el.setPointerCapture(e.pointerId); } catch (x) {} AIRB[k] = 1; el.classList.add("on"); }
    function upf() { AIRB[k] = 0; el.classList.remove("on"); }
    el.addEventListener("pointerdown", dn); el.addEventListener("pointerup", upf); el.addEventListener("pointercancel", upf); el.addEventListener("lostpointercapture", upf);
    el.addEventListener("contextmenu", function (e) { e.preventDefault(); });
  });
  window.addEventListener("keydown", function (e) {
    if (e.key === " " && P.fall) { e.preventDefault(); deployChute(); }
    if (e.key === "Enter" && P.mode === "car" && !e.repeat && $("modal").hidden && $("shop").hidden) leaveVehicle();
  });
  $("bChute").addEventListener("pointerdown", function (e) { e.preventDefault(); e.stopPropagation(); deployChute(); });
  /* ===================== EarthPass Tower: 100 floors, glass lift, sky deck, base jump, Sky Club (floor 101), helipad ===================== */
  var TOWER = null;
  (function buildTower() {
    var TX = 110, TZ = -140, SH = 17, CH = 12, PH = 23, PODH = 14, TOP = 400, CLUBY = 404.4, ROOF = 413.6, BOARD = 9;
    var g = new THREE.Group(); g.name = "tower"; scene.add(g);
    function fm(o) { var m = new THREE.MeshStandardMaterial(o); m.fog = false; return m; }
    function bx(w, h, d, m, x, y, z, sh) { var o = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m); o.position.set(x, y, z); if (sh !== false) { o.castShadow = true; o.receiveShadow = true; } g.add(o); return o; }
    /* facade: 4 bays x 8 floors per tile, warm lit windows at night */
    var o3s = new THREE.Object3D(), r = rng(9101), lit = []; for (var i = 0; i < 32; i++) lit.push(r() < 0.3);
    function facadeTex(emit) {
      return canvasTex(256, 512, function (c, w, h) {
        c.fillStyle = emit ? "#000" : "#132238"; c.fillRect(0, 0, w, h);
        for (var fl = 0; fl < 8; fl++) for (var b = 0; b < 4; b++) {
          var x = b * 64, y = fl * 64, on = lit[fl * 4 + b];
          if (emit) { if (on) { c.fillStyle = (fl + b) % 3 ? "#ffd9a0" : "#ffeacc"; c.fillRect(x + 4, y + 4, 56, 48); } continue; }
          var gr = c.createLinearGradient(x, y, x + 64, y + 52); gr.addColorStop(0, "#2d5a86"); gr.addColorStop(0.5, "#1c3b5c"); gr.addColorStop(1, "#3a6c98"); c.fillStyle = gr; c.fillRect(x + 4, y + 4, 56, 48);
          c.fillStyle = "rgba(255,255,255,0.10)"; c.fillRect(x + 4, y + 4, 56, 14);
          c.fillStyle = "#c9d3de"; c.fillRect(x, y, 4, 64); c.fillStyle = "#5e6b7a"; c.fillRect(x + 4, y + 52, 60, 12);
        }
      }, true);
    }
    var fMap = facadeTex(false), fEm = facadeTex(true);
    fMap.repeat.set(34 / 16, TOP / 32); fEm.repeat.copy(fMap.repeat);
    var glassM = fm({ map: fMap, emissive: 0xffffff, emissiveMap: fEm, emissiveIntensity: 0, roughness: 0.18, metalness: 0.55 }); nightMats.push(glassM);
    var finM = fm({ color: 0xe9e7f1, roughness: 0.3, metalness: 0.7 }), neonM = fm({ color: 0xff3d8b, emissive: 0xff3d8b, emissiveIntensity: 1.1, roughness: 0.4 }), tealM = fm({ color: 0x2ee6d6, emissive: 0x2ee6d6, emissiveIntensity: 1.1, roughness: 0.4 });
    var stoneM = fm({ color: 0xd7d1c8, roughness: 0.75 }), darkM = fm({ color: 0x15111f, roughness: 0.5, metalness: 0.3 });
    var railGlass = fm({ color: 0x9fd6ff, transparent: true, opacity: 0.28, roughness: 0.05, metalness: 0.2, depthWrite: false });
    /* podium: two wings and a back block around an open atrium with the glass lift */
    var podMap = fMap.clone(); podMap.needsUpdate = true; podMap.repeat.set(4, PODH / 32 * 2);
    var podM = fm({ map: podMap, roughness: 0.25, metalness: 0.5 });
    [[TX - PH, TX - 6], [TX + 6, TX + PH]].forEach(function (p) { bx(p[1] - p[0], PODH, PH * 2, podM, (p[0] + p[1]) / 2, PODH / 2, TZ); bx(p[1] - p[0] + 0.6, 0.8, PH * 2 + 0.6, stoneM, (p[0] + p[1]) / 2, PODH + 0.4, TZ); });
    bx(12, PODH, PH - SH, podM, TX, PODH / 2, TZ - (PH + SH) / 2);
    /* the shaft, corner fins and the neon sky-lobby bands */
    bx(SH * 2, TOP - 0.3, SH * 2, glassM, TX, (TOP - 0.3) / 2, TZ);
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(function (c) { bx(1.6, TOP + 2, 1.6, finM, TX + c[0] * SH, TOP / 2 + 1, TZ + c[1] * SH); });
    [100, 200, 300].forEach(function (y) { bx(SH * 2 + 1.2, 1.2, SH * 2 + 1.2, neonM, TX, y, TZ, false); });
    bx(SH * 2 + 1.2, 0.7, SH * 2 + 1.2, tealM, TX, TOP - 2.2, TZ, false);
    /* deck slab, railing with gaps for the lift door (south) and the jump board (east) */
    bx(SH * 2 + 0.8, 0.5, SH * 2 + 0.8, stoneM, TX, TOP - 0.25, TZ);
    function railRun(x1, z1, x2, z2) { var L = Math.hypot(x2 - x1, z2 - z1), m = bx(L, 1.1, 0.06, railGlass, (x1 + x2) / 2, TOP + 0.55, (z1 + z2) / 2, false); m.rotation.y = -Math.atan2(z2 - z1, x2 - x1); var t = bx(L, 0.07, 0.1, finM, (x1 + x2) / 2, TOP + 1.12, (z1 + z2) / 2, false); t.rotation.y = m.rotation.y; }
    var E = SH - 0.1;
    railRun(TX - E, TZ - E, TX + E, TZ - E); railRun(TX - E, TZ - E, TX - E, TZ + E);
    railRun(TX - E, TZ + E, TX - 1.7, TZ + E); railRun(TX + 1.7, TZ + E, TX + E, TZ + E);
    railRun(TX + E, TZ - E, TX + E, TZ - 1.6); railRun(TX + E, TZ + 1.6, TX + E, TZ + E);
    /* jump board */
    var stripe = canvasTex(256, 64, function (c, w, h) { for (var i = 0; i < 16; i++) { c.fillStyle = i % 2 ? "#111" : "#ffd23f"; c.beginPath(); c.moveTo(i * 24 - 20, h); c.lineTo(i * 24, 0); c.lineTo(i * 24 + 24, 0); c.lineTo(i * 24 + 4, h); c.fill(); } }, true);
    var bm = fm({ color: 0x8a8f98, roughness: 0.6, metalness: 0.5 }); bx(BOARD, 0.3, 3, bm, TX + SH + BOARD / 2, TOP - 0.15, TZ);
    var stp = new THREE.Mesh(new THREE.PlaneGeometry(BOARD, 0.5), fm({ map: stripe, roughness: 0.6 })); stp.rotation.x = -Math.PI / 2; stp.position.set(TX + SH + BOARD / 2, TOP + 0.01, TZ - 1.25); g.add(stp); var stp2 = stp.clone(); stp2.position.z = TZ + 1.25; g.add(stp2);
    [-1, 1].forEach(function (sd) { var rl = bx(BOARD - 2, 0.06, 0.06, finM, TX + SH + (BOARD - 2) / 2, TOP + 1.0, TZ + sd * 1.45, false); for (var k = 0; k <= 3; k++) bx(0.06, 1.0, 0.06, finM, TX + SH + k * (BOARD - 2) / 3, TOP + 0.5, TZ + sd * 1.45, false); });
    var js = new THREE.Mesh(new THREE.PlaneGeometry(4, 1.2), fm({ map: signTex("BASE JUMP", { w: 512, h: 150, bg: "#ff3d8b", fg: "#ffffff", size: 96 }), emissive: 0xffffff, emissiveIntensity: 0.25 }));
    js.material.emissiveMap = js.material.map; js.position.set(TX + SH + 0.4, TOP + 3.3, TZ); js.rotation.y = Math.PI / 2; g.add(js);
    [-1, 1].forEach(function (sd) { bx(0.16, 3.5, 0.16, finM, TX + SH + 0.4, TOP + 1.75, TZ + sd * 1.5, false); });
    /* floor-100 core (lift lobby, stairs up to the club) */
    bx(CH * 2, CLUBY - TOP, CH * 2, darkM, TX, (TOP + CLUBY) / 2, TZ);
    var dsign = new THREE.Mesh(new THREE.PlaneGeometry(5, 1.1), fm({ map: signTex("SKY CLUB  ↑  FLOOR 101", { w: 1024, h: 200, bg: "#15111f", fg: "#ff3d8b", size: 92 }), emissive: 0xffffff, emissiveIntensity: 0.6 }));
    dsign.material.emissiveMap = dsign.material.map; dsign.position.set(TX - 5, TOP + 3.3, TZ + CH + 0.02); g.add(dsign);
    bx(2.2, 2.6, 0.08, fm({ color: 0x2a1a44, emissive: 0x6b2bd9, emissiveIntensity: 0.5 }), TX - 5, TOP + 1.3, TZ + CH + 0.03, false);
    bx(3.2, 2.8, 0.08, fm({ color: 0x9aa3ad, metalness: 0.8, roughness: 0.25 }), TX, TOP + 1.4, TZ + CH + 0.03, false);
    /* Sky Club box (floor 101): glass walls, roof slab with helipad */
    var clubGlass = fm({ color: 0x2a1450, transparent: true, opacity: 0.42, roughness: 0.05, metalness: 0.4, emissive: 0x3a0f55, emissiveIntensity: 0.35, side: THREE.DoubleSide, depthWrite: false });
    var WH = ROOF - 0.6 - CLUBY;
    [[0, -CH, 0], [0, CH, 0], [-CH, 0, 1], [CH, 0, 1]].forEach(function (w) { var m = bx(w[2] ? 0.16 : CH * 2, WH, w[2] ? CH * 2 : 0.16, clubGlass, TX + w[0], CLUBY + WH / 2, TZ + w[1], false); m.renderOrder = 3; });
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(function (c) { bx(0.4, WH, 0.4, finM, TX + c[0] * CH, CLUBY + WH / 2, TZ + c[1] * CH, false); });
    bx(CH * 2 + 0.6, 0.6, CH * 2 + 0.6, darkM, TX, ROOF - 0.3, TZ);
    bx(CH * 2 + 0.7, 0.18, CH * 2 + 0.7, neonM, TX, ROOF - 0.62, TZ, false);
    var padTex = canvasTex(512, 512, function (c, w, h) { c.fillStyle = "#23272e"; c.fillRect(0, 0, w, h); c.strokeStyle = "#ffd23f"; c.lineWidth = 18; c.beginPath(); c.arc(w / 2, h / 2, w * 0.38, 0, Math.PI * 2); c.stroke(); c.fillStyle = "#ffffff"; c.font = "900 260px Arial Black, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("H", w / 2, h / 2 + 10); c.strokeStyle = "rgba(255,255,255,0.8)"; c.lineWidth = 8; c.strokeRect(14, 14, w - 28, h - 28); });
    var pad = new THREE.Mesh(new THREE.PlaneGeometry(CH * 2 - 1, CH * 2 - 1), fm({ map: padTex, roughness: 0.85 })); pad.rotation.x = -Math.PI / 2; pad.position.set(TX, ROOF + 0.01, TZ); pad.receiveShadow = true; g.add(pad);
    [[0, 1], [-1, 0], [1, 0]].forEach(function (s) { bx(s[0] ? 0.06 : CH * 2, 0.06, s[0] ? CH * 2 : 0.06, finM, TX + s[0] * (CH - 0.1), ROOF + 0.9, TZ + s[1] * (CH - 0.1), false); });
    bx(CH + 8.6, 0.06, 0.06, finM, TX + (CH - 8.6) / 2, ROOF + 0.9, TZ - CH + 0.1, false);
    for (var pk = -CH; pk <= CH; pk += 4) [[pk, -CH], [pk, CH], [-CH, pk], [CH, pk]].forEach(function (p) { if (p[1] === -CH && p[0] < -8.6) return; bx(0.06, 0.9, 0.06, finM, TX + clamp(p[0], -CH + 0.1, CH - 0.1), ROOF + 0.45, TZ + clamp(p[1], -CH + 0.1, CH - 0.1), false); });
    /* outdoor stair from the Sky Deck (floor 100) up to the helipad, with an L-shaped landing */
    var SX0 = TX + 13, SX1 = TX - 12.6, SZ0 = TZ - 15.5, SZ1 = TZ - 13.7, NST = 40, run = (SX0 - SX1) / NST, rise = (ROOF - TOP) / NST, SW = SZ1 - SZ0;
    var stepM = fm({ color: 0x3a3546, roughness: 0.7, metalness: 0.3 }), steps = new THREE.InstancedMesh(new THREE.BoxGeometry(run + 0.02, rise, SW), stepM, NST), nos = new THREE.InstancedMesh(new THREE.BoxGeometry(0.06, 0.04, SW), neonM, NST);
    for (var si = 0; si < NST; si++) { o3s.position.set(SX0 - (si + 0.5) * run, TOP + (si + 0.5) * rise, (SZ0 + SZ1) / 2); o3s.updateMatrix(); steps.setMatrixAt(si, o3s.matrix); o3s.position.set(SX0 - si * run - 0.03, TOP + (si + 1) * rise, (SZ0 + SZ1) / 2); o3s.updateMatrix(); nos.setMatrixAt(si, o3s.matrix); }
    steps.castShadow = true; steps.receiveShadow = true; g.add(steps); g.add(nos);
    var sLen = Math.hypot(SX0 - SX1, ROOF - TOP), sAng = Math.atan2(ROOF - TOP, SX0 - SX1);
    var slab = bx(sLen, 0.3, SW, stepM, (SX0 + SX1) / 2, (TOP + ROOF) / 2 - 0.35, (SZ0 + SZ1) / 2); slab.rotation.z = -sAng;
    [SZ0 + 0.05, SZ1 - 0.05].forEach(function (z) { var rl = bx(sLen, 0.07, 0.07, finM, (SX0 + SX1) / 2, (TOP + ROOF) / 2 + 1.0, z, false); rl.rotation.z = -sAng; for (var k = 0; k <= NST; k += 4) bx(0.05, 1.0, 0.05, finM, SX0 - k * run, TOP + k * rise + 0.5, z, false); });
    bx(SX1 - (TX - 15) + 0.02, 0.4, 4.2, stoneM, (SX1 + TX - 15) / 2, ROOF - 0.2, TZ - 13.5);
    bx(TX - 8.6 - SX1, 0.4, 2.2, stoneM, (SX1 + TX - 8.6) / 2, ROOF - 0.2, TZ - 12.5);
    bx(0.06, 0.06, 4.2, finM, TX - 14.95, ROOF + 0.9, TZ - 13.5, false); bx(SX1 - (TX - 15), 0.06, 0.06, finM, (SX1 + TX - 15) / 2, ROOF + 0.9, TZ - 15.55, false); bx(TX - 8.6 - SX1, 0.06, 0.06, finM, (SX1 + TX - 8.6) / 2, ROOF + 0.9, TZ - 13.45, false);
    [[TX - 14.8, TZ - 15.4], [TX - 14.8, TZ - 11.6], [TX + 6, SZ0 - 0.2], [TX - 2, SZ0 - 0.2], [TX - 9, SZ0 - 0.2]].forEach(function (c) { var hgt = c[0] > TX - 14 ? TOP + (SX0 - c[0]) / (SX0 - SX1) * (ROOF - TOP) - 0.4 - TOP : ROOF - TOP - 0.4; bx(0.35, hgt, 0.35, finM, c[0], TOP + hgt / 2, c[1]); });
    var stSign = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 0.6), fm({ map: signTex("HELIPAD \u2191", { w: 512, h: 120, bg: "#15111f", fg: "#ffd23f", size: 80 }), emissive: 0xffffff, emissiveIntensity: 0.5 })); stSign.material.emissiveMap = stSign.material.map; stSign.position.set(SX0 + 0.6, TOP + 2.2, SZ1 + 0.02); g.add(stSign);
    /* a helicopter waiting on the pad */
    var padHeli = helicopter(0xff3d8b); padHeli.position.set(TX + 3, ROOF, TZ + 3); padHeli.rotation.y = -0.6; g.add(padHeli);
    /* antenna with a blinking warning light */
    var ant = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.5, 34, 8), finM); ant.position.set(TX + CH - 1.2, ROOF + 17, TZ + CH - 1.2); g.add(ant);
    var beacon = new THREE.Mesh(new THREE.SphereGeometry(0.55, 10, 8), new THREE.MeshBasicMaterial({ color: 0xff2020, fog: false })); beacon.position.set(TX + CH - 1.2, ROOF + 34.4, TZ + CH - 1.2); g.add(beacon);
    /* huge lit name on each face near the top */
    [[0, SH + 0.05, 0], [0, -SH - 0.05, Math.PI], [SH + 0.05, 0, Math.PI / 2], [-SH - 0.05, 0, -Math.PI / 2]].forEach(function (f) {
      var t = signTex("EARTHPASS", { w: 1024, h: 180, bg: "rgba(0,0,0,0)", fg: "#ffffff", size: 140 }), m = new THREE.Mesh(new THREE.PlaneGeometry(26, 4.6), fm({ map: t, transparent: true, emissive: 0xff7ab8, emissiveMap: t, emissiveIntensity: 0.9 }));
      m.position.set(TX + f[0], TOP - 9, TZ + f[1]); m.rotation.y = f[2]; g.add(m);
    });
    var fr = new THREE.Mesh(new THREE.PlaneGeometry(10, 1.6), fm({ map: signTex("EARTHPASS TOWER", { w: 1024, h: 170, bg: "#15111f", fg: "#ffffff", size: 108 }), emissive: 0xffffff, emissiveIntensity: 0.35 })); fr.material.emissiveMap = fr.material.map;
    [-1, 1].forEach(function (sd) { var s = fr.clone(); s.position.set(TX + sd * 14.5, 10.5, TZ + PH + 0.05); g.add(s); });
    bx(12.4, 0.5, 6.4, finM, TX, PODH + 0.25, TZ + SH + 3, false);
    /* exterior glass lift: rails on the south face and the capsule */
    [-1, 1].forEach(function (sd) { bx(0.22, TOP + 1, 0.22, finM, TX + sd * 1.7, TOP / 2, TZ + SH + 0.3, false); });
    var cap = new THREE.Group(); cap.position.set(TX, 0, TZ + SH + 1.45); g.add(cap);
    var capG = fm({ color: 0xbfe6ff, transparent: true, opacity: 0.3, roughness: 0.05, metalness: 0.3, depthWrite: false });
    [[0, -1.2, 0], [0, 1.2, 0], [-1.5, 0, 1], [1.5, 0, 1]].forEach(function (w) { var m = new THREE.Mesh(new THREE.BoxGeometry(w[2] ? 0.06 : 3, 2.6, w[2] ? 2.4 : 0.06), capG); m.position.set(w[0], 1.4, w[1]); cap.add(m); });
    var cf = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.14, 2.6), finM); cf.position.y = 0.07; cap.add(cf); var cr = cf.clone(); cr.position.y = 2.76; cap.add(cr);
    var cl = new THREE.Mesh(new THREE.BoxGeometry(3.1, 0.06, 0.06), tealM); cl.position.set(0, 2.66, 1.22); cap.add(cl);
    /* plaza and the access road from the airport road */
    var pv = canvasTex(256, 256, function (c, w, h) { c.fillStyle = "#c9c2b6"; c.fillRect(0, 0, w, h); c.strokeStyle = "rgba(90,80,70,0.35)"; c.lineWidth = 2; for (var i = 0; i <= w; i += 32) { c.beginPath(); c.moveTo(i, 0); c.lineTo(i, h); c.stroke(); c.beginPath(); c.moveTo(0, i); c.lineTo(w, i); c.stroke(); } }, true);
    pv.repeat.set(12, 9); var plz = plane(64, 48, new THREE.MeshStandardMaterial({ map: pv, roughness: 0.9 }), TX, 0.02, TZ + PH + 24); plz.receiveShadow = true;
    plane(10, 82, M.asphalt, 72, 0.016, -55); plane(40, 10, M.asphalt, 92, 0.017, -96);
    mapRect(67, 77, -96, -14, "#3a2a55"); mapRect(72, 112, -101, -91, "#3a2a55"); mapRect(TX - 32, TX + 32, TZ + PH, TZ + PH + 48, "#4a3a66");
    mapRect(TX - PH, TX + PH, TZ - PH, TZ + PH, "#6b2bd9"); mapRect(TX - SH, TX + SH, TZ - SH, TZ + SH, "#ff3d8b");
    [[TX - 26, TZ + PH + 10], [TX + 26, TZ + PH + 10], [TX - 26, TZ + PH + 38], [TX + 26, TZ + PH + 38]].forEach(function (p) { tree(p[0], p[1], 1.1); });
    var fount = new THREE.Mesh(new THREE.CylinderGeometry(5, 5.4, 0.7, 28), stoneM); fount.position.set(TX, 0.35, TZ + PH + 22); g.add(fount);
    var water = new THREE.Mesh(new THREE.CylinderGeometry(4.5, 4.5, 0.1, 28), new THREE.MeshStandardMaterial({ color: 0x2ea8d8, roughness: 0.1, metalness: 0.3, emissive: 0x0a3550, emissiveIntensity: 0.4 })); water.position.set(TX, 0.66, TZ + PH + 22); g.add(water);
    solid(TX - 5.4, TX + 5.4, TZ + PH + 16.6, TZ + PH + 27.4);
    /* collisions on the ground (heights come from topAt) */
    function topAtT(x, z) {
      var dx = x - TX, dz = z - TZ, ax = Math.abs(dx), az = Math.abs(dz);
      if (ax < CH + 0.3 && az < CH + 0.3) return ROOF;
      if (x > TX - 15 && x < TX - 8.6 && z > TZ - 15.6 && z < TZ - 11.4 && !(x > TX - 12.6 && z < TZ - 13.6)) return ROOF;
      if (ax < SH + 0.4 && az < SH + 0.4) return TOP;
      if (dx >= SH && dx < SH + BOARD && az < 1.5) return TOP;
      if (ax < PH && az < PH && !(ax < 6 && dz > SH)) return PODH;
      return 0;
    }
    [solid(TX - SH, TX + SH, TZ - SH, TZ + SH, "bld"), solid(TX - PH, TX - 6, TZ - PH, TZ + PH, "bld"), solid(TX + 6, TX + PH, TZ - PH, TZ + PH, "bld"), solid(TX - 6, TX + 6, TZ - PH, TZ - SH, "bld")].forEach(function (c) { c.hf = topAtT; });
    solid(TX - 1.6, TX + 1.6, TZ + SH, TZ + SH + 2.7);
    /* ---- the Sky Club interior ---- */
    var club = new THREE.Group(); g.add(club);
    var floorM = new THREE.MeshStandardMaterial({ color: 0x0c0a12, roughness: 0.18, metalness: 0.4 }); floorM.fog = false;
    var fl0 = new THREE.Mesh(new THREE.BoxGeometry(CH * 2 - 0.3, 0.06, CH * 2 - 0.3), floorM); fl0.position.set(TX, CLUBY + 0.03, TZ); fl0.receiveShadow = true; club.add(fl0);
    var NT = 8, TS = 1.15, tiles = new THREE.InstancedMesh(new THREE.BoxGeometry(TS - 0.06, 0.05, TS - 0.06), new THREE.MeshBasicMaterial({ color: 0xffffff, fog: false }), NT * NT), o3 = new THREE.Object3D();
    for (var ti = 0; ti < NT * NT; ti++) { o3.position.set(TX + ((ti % NT) - NT / 2 + 0.5) * TS, CLUBY + 0.07, TZ + 1 + (Math.floor(ti / NT) - NT / 2 + 0.5) * TS); o3.updateMatrix(); tiles.setMatrixAt(ti, o3.matrix); tiles.setColorAt(ti, new THREE.Color(0xff3d8b)); }
    club.add(tiles);
    /* DJ booth and LED wall */
    var ledC = document.createElement("canvas"); ledC.width = 512; ledC.height = 192; var ledT = new THREE.CanvasTexture(ledC); ledT.encoding = THREE.sRGBEncoding;
    var led = new THREE.Mesh(new THREE.PlaneGeometry(15, 5.6), new THREE.MeshBasicMaterial({ map: ledT, fog: false })); led.position.set(TX, CLUBY + 4.2, TZ - CH + 0.2); club.add(led);
    var desk = new THREE.Mesh(new THREE.BoxGeometry(6, 1.15, 1.5), fm({ color: 0x15111f, roughness: 0.4, metalness: 0.5 })); desk.position.set(TX, CLUBY + 0.6, TZ - 8.4); club.add(desk);
    var dstrip = new THREE.Mesh(new THREE.BoxGeometry(6.02, 0.1, 0.02), tealM); dstrip.position.set(TX, CLUBY + 0.9, TZ - 7.64); club.add(dstrip);
    [-1.4, 1.4].forEach(function (x) { var tt = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.05, 20), fm({ color: 0x222222, roughness: 0.3 })); tt.position.set(TX + x, CLUBY + 1.2, TZ - 8.4); club.add(tt); });
    var stage = new THREE.Mesh(new THREE.BoxGeometry(10, 0.4, 4), fm({ color: 0x1d1530, roughness: 0.5 })); stage.position.set(TX, CLUBY + 0.2, TZ - 9.6); club.add(stage);
    /* bar with glowing bottles */
    var barM = fm({ color: 0x1a1426, roughness: 0.35, metalness: 0.4 }), barTop = fm({ color: 0xf4f0ff, roughness: 0.2, metalness: 0.2 });
    var bar = new THREE.Mesh(new THREE.BoxGeometry(9, 1.1, 1.1), barM); bar.position.set(TX - 6, CLUBY + 0.55, TZ + 8.4); club.add(bar);
    var bt = new THREE.Mesh(new THREE.BoxGeometry(9.2, 0.08, 1.3), barTop); bt.position.set(TX - 6, CLUBY + 1.14, TZ + 8.4); club.add(bt);
    var bstrip = new THREE.Mesh(new THREE.BoxGeometry(9.02, 0.06, 0.02), neonM); bstrip.position.set(TX - 6, CLUBY + 0.25, TZ + 7.84); club.add(bstrip);
    var shelf = new THREE.Mesh(new THREE.BoxGeometry(9, 2.2, 0.4), barM); shelf.position.set(TX - 6, CLUBY + 2.2, TZ + CH - 0.4); club.add(shelf);
    var BOT = 36, bots = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.06, 0.08, 0.34, 8), new THREE.MeshBasicMaterial({ color: 0xffffff, fog: false }), BOT), bc = [0xff3d8b, 0x2ee6d6, 0xffd23f, 0x7dffb0, 0xff9a3c, 0xa855f7];
    for (var bi = 0; bi < BOT; bi++) { o3.position.set(TX - 10.2 + (bi % 18) * 0.48, CLUBY + 1.6 + Math.floor(bi / 18) * 0.62, TZ + CH - 0.66); o3.updateMatrix(); bots.setMatrixAt(bi, o3.matrix); bots.setColorAt(bi, new THREE.Color(bc[bi % bc.length])); }
    club.add(bots);
    /* VIP sofas */
    var sofaM = fm({ color: 0x5b1a3a, roughness: 0.8 }), tblM = fm({ color: 0xd9c9ff, roughness: 0.25, metalness: 0.6 });
    [-6, -1.5, 3].forEach(function (z) { var s = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.5, 3.2), sofaM); s.position.set(TX + CH - 1.0, CLUBY + 0.25, TZ + z); club.add(s); var bk = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.9, 3.2), sofaM); bk.position.set(TX + CH - 0.45, CLUBY + 0.6, TZ + z); club.add(bk); var t = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.45, 18), tblM); t.position.set(TX + CH - 2.6, CLUBY + 0.23, TZ + z); club.add(t); });
    /* light beams, LED ceiling strips, disco ball */
    var beams = [];
    for (var k = 0; k < 6; k++) {
      var bmM = new THREE.MeshBasicMaterial({ color: 0xff3d8b, transparent: true, opacity: 0.16, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false });
      var cone = new THREE.Mesh(new THREE.ConeGeometry(1.5, 7.6, 18, 1, true), bmM); cone.geometry.translate(0, -3.8, 0);
      var piv = new THREE.Group(); piv.position.set(TX - 7.5 + k * 3, ROOF - 0.9, TZ - 5 + (k % 2) * 6); piv.add(cone); club.add(piv); beams.push({ p: piv, m: bmM, ph: k * 1.1 });
    }
    for (var s2 = -9; s2 <= 9; s2 += 4.5) { var ls = new THREE.Mesh(new THREE.BoxGeometry(CH * 2 - 1, 0.06, 0.12), s2 % 9 === 0 ? neonM : tealM); ls.position.set(TX, ROOF - 0.66, TZ + s2); club.add(ls); }
    var ball = new THREE.Mesh(new THREE.IcosahedronGeometry(0.7, 1), fm({ color: 0xe8e8f0, metalness: 1, roughness: 0.12, flatShading: true })); ball.position.set(TX, ROOF - 1.9, TZ + 1); club.add(ball);
    var cord = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1.2, 4), darkM); cord.position.set(TX, ROOF - 1.0, TZ + 1); club.add(cord);
    var cSign = new THREE.Mesh(new THREE.PlaneGeometry(6, 1.3), fm({ map: signTex("SKY CLUB 101", { w: 1024, h: 220, bg: "#15111f", fg: "#ff3d8b", size: 150 }), emissive: 0xffffff, emissiveIntensity: 0.8 })); cSign.material.emissiveMap = cSign.material.map; cSign.position.set(TX - 6, CLUBY + 4.0, TZ + CH - 0.15); cSign.rotation.y = Math.PI; club.add(cSign);
    var L1 = new THREE.PointLight(0xff3d8b, 0, 26, 2), L2 = new THREE.PointLight(0x2ee6d6, 0, 26, 2); L1.position.set(TX - 4, CLUBY + 5, TZ); L2.position.set(TX + 4, CLUBY + 5, TZ + 2); g.add(L1); g.add(L2);
    var Ld = new THREE.PointLight(0xfff0e0, 0, 40, 2); Ld.position.set(TX, TOP + 6, TZ + SH + 2); g.add(Ld);
    /* parachute kiosk on the deck */
    var kio = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.1, 2.4), fm({ color: 0xff9a3c, roughness: 0.5 })); kio.position.set(TX + 15.6, TOP + 0.55, TZ - 7); g.add(kio);
    var ks = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 0.7), fm({ map: signTex("PARACHUTES", { w: 512, h: 140, bg: "#15111f", fg: "#ffd23f", size: 84 }), emissive: 0xffffff, emissiveIntensity: 0.4 })); ks.material.emissiveMap = ks.material.map; ks.position.set(TX + 14.78, TOP + 1.9, TZ - 7); ks.rotation.y = -Math.PI / 2; g.add(ks);
    var chuteBag = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.6, 0.3), fm({ color: 0xff3d8b, roughness: 0.7 })); chuteBag.position.set(TX + 15.2, TOP + 1.4, TZ - 6.4); g.add(chuteBag);

    /* ---- surfaces the player can stand on ---- */
    function clampBox(h) { return function (p) { p.x = clamp(p.x, TX - h, TX + h); p.z = clamp(p.z, TZ - h, TZ + h); }; }
    var DECK = { id: "deck", y: TOP, col: [{ x1: TX + 14.8, x2: TX + 16.4, z1: TZ - 8.2, z2: TZ - 5.8 }], inside: function (x, z) { return x - TX < SH + BOARD + 0.2; },
      clamp: function (p) {
        var dx = p.x - TX, dz = p.z - TZ;
        if (dx > SH - 1 && Math.abs(dz) < 1.6) { dz = clamp(dz, -1.25, 1.25); }
        else { dx = clamp(dx, -SH + 0.45, SH - 0.45); dz = clamp(dz, -SH + 0.45, SH - 0.45); }
        if (Math.abs(dx) < CH + 0.35 && Math.abs(dz) < CH + 0.35) { var ox = CH + 0.35 - Math.abs(dx), oz = CH + 0.35 - Math.abs(dz); if (ox < oz) dx = Math.sign(dx || 1) * (CH + 0.35); else dz = Math.sign(dz || 1) * (CH + 0.35); }
        p.x = TX + dx; p.z = TZ + dz;
      } };
    var CLUB = { id: "club", y: CLUBY, inside: function () { return true; }, clamp: clampBox(CH - 0.5), camBox: function (c) { c.x = clamp(c.x, TX - CH + 0.6, TX + CH - 0.6); c.z = clamp(c.z, TZ - CH + 0.6, TZ + CH - 0.6); c.y = clamp(c.y, CLUBY + 1.2, ROOF - 1.4); },
      col: [{ x1: TX - 3.1, x2: TX + 3.1, z1: TZ - 11.6, z2: TZ - 7.6 }, { x1: TX - 10.6, x2: TX - 1.4, z1: TZ + 7.8, z2: TZ + 9.0 }, { x1: TX + CH - 3.2, x2: TX + CH, z1: TZ - 7.8, z2: TZ + 4.8 }] };
    function inR(p, r) { return p.x >= r[0] && p.x <= r[1] && p.z >= r[2] && p.z <= r[3]; }
    var PADR = [[TX - CH + 0.45, TX + CH - 0.45, TZ - CH + 0.45, TZ + CH - 0.45], [TX - 14.65, SX1, TZ - 15.25, TZ - 11.3], [SX1, TX - 8.95, TZ - 13.3, TZ - 11.3]];
    var PAD = { id: "pad", y: ROOF, inside: function () { return true; }, col: [{ x1: TX + CH - 1.8, x2: TX + CH - 0.6, z1: TZ + CH - 1.8, z2: TZ + CH - 0.6 }, { x1: TX + 0.6, x2: TX + 5.4, z1: TZ + 1.6, z2: TZ + 4.4 }],
      clamp: function (p) { for (var i = 0; i < PADR.length; i++) if (inR(p, PADR[i])) return; var best = null, bd = 1e9; PADR.forEach(function (r) { var q = { x: clamp(p.x, r[0], r[1]), z: clamp(p.z, r[2], r[3]) }, d = Math.hypot(q.x - p.x, q.z - p.z); if (d < bd) { bd = d; best = q; } }); p.x = best.x; p.z = best.z; },
      link: function (x, z) { return z > SZ0 + 0.2 && z < SZ1 - 0.2 && x > SX1 && x < SX1 + 3 ? STAIR : null; } };
    var STAIR = { id: "stair", y: TOP, col: [], inside: function () { return true; },
      clamp: function (p) { p.z = clamp(p.z, SZ0 + 0.32, SZ1 - 0.32); p.x = clamp(p.x, SX1 - 0.4, SX0 + 0.6); },
      link: function (x, z) { return x > SX0 + 0.35 ? DECK : x < SX1 - 0.15 ? PAD : null; },
      yAt: function (x) { return TOP + clamp((SX0 - x) / (SX0 - SX1), 0, 1) * (ROOF - TOP); } };
    DECK.link = function (x, z) { return z > SZ0 + 0.2 && z < SZ1 - 0.2 && x < SX0 + 0.3 && x > SX0 - 3 ? STAIR : null; };
    DECK.col.push({ x1: SX0 - 5.2, x2: SX0 + 0.05, z1: SZ0 - 0.1, z2: SZ1 + 0.1 }, { x1: TX + 5.8, x2: TX + 6.2, z1: SZ0 - 0.4, z2: SZ0 }, { x1: TX - 2.2, x2: TX - 1.8, z1: SZ0 - 0.4, z2: SZ0 }, { x1: TX - 9.2, x2: TX - 8.8, z1: SZ0 - 0.4, z2: SZ0 });
    function podIn(x, z) { var dx = x - TX, dz = z - TZ, ax = Math.abs(dx), az = Math.abs(dz); return ax < PH && az < PH && !(ax < SH && az < SH) && !(ax < 6 && dz > SH); }
    var POD = { id: "podium", y: PODH, col: [], inside: podIn };
    function surface(x, z, y) {
      var dx = x - TX, dz = z - TZ, ax = Math.abs(dx), az = Math.abs(dz);
      if (Math.abs(y - ROOF) < 2.5 && ((ax < CH + 0.3 && az < CH + 0.3) || PADR.some(function (r) { return x >= r[0] - 0.3 && x <= r[1] + 0.3 && z >= r[2] - 0.3 && z <= r[3] + 0.3; }))) return PAD;
      if (Math.abs(y - TOP) < 2.5 && ((ax < SH + 0.4 && az < SH + 0.4) || (dx >= SH && dx < SH + BOARD && az < 1.5))) return DECK;
      if (Math.abs(y - PODH) < 2.5 && podIn(x, z)) return POD;
      return null;
    }

    /* ---- the crowd: only while you are up there ---- */
    var crowd = [];
    function spawnCrowd() {
      if (crowd.length) return;
      function put(a, x, z, y, face, anim, sp) { a.g.position.set(x, y, z); a.g.rotation.y = face; a.play(anim, { speed: sp || 1 }); a.tower = true; crowd.push(a); return a; }
      for (var i = 0; i < 16; i++) { var a = makeActor(i % 2 ? "woman" : "man"); put(a, TX + (Math.random() - 0.5) * 8, TZ + 1 + (Math.random() - 0.5) * 8, CLUBY + 0.1, Math.PI + (Math.random() - 0.5) * 1.6, "Dance", 0.8 + Math.random() * 0.45); }
      put(makeActor("man"), TX, TZ - 9.0, CLUBY + 0.4, 0, "Dance", 0.55);
      put(makeActor("woman"), TX - 7, TZ + 9.6, CLUBY + 0.05, Math.PI, "Interact", 0.8); put(makeActor("man"), TX - 3.5, TZ + 9.6, CLUBY + 0.05, Math.PI, "Talk", 0.9);
      put(makeActor("woman"), TX - 8, TZ + 6.9, CLUBY + 0.05, 0, "Talk", 1); put(makeActor("man"), TX - 4.5, TZ + 6.9, CLUBY + 0.05, 0, "Talk", 1.1);
      put(makeActor("officer"), TX - 9, TZ + 4, CLUBY + 0.05, Math.PI / 2, "FoldArms", 1);
      put(makeActor("woman"), TX - 9, TZ + 15.6, TOP + 0.04, 0, "Phone", 1); put(makeActor("man"), TX + 7, TZ + 15.6, TOP + 0.04, 0, "Idle", 1); put(makeActor("man"), TX + 15.6, TZ - 5.4, TOP + 0.04, -Math.PI / 2, "Idle", 1);
      L1.intensity = 2.2; L2.intensity = 2.2; Ld.intensity = 1.4;
    }
    function leave() { crowd.forEach(function (a) { removeActor(a); }); crowd.length = 0; L1.intensity = L2.intensity = Ld.intensity = 0; clubMusic(false); }
    var ledT0 = 0, beat = 0;
    function tick(dt, t) {
      beacon.visible = Math.floor(t * 1.1) % 2 === 0;
      var near = P.lv && (P.lv === DECK || P.lv === CLUB || P.lv === PAD) || (Math.abs(P.x - TX) < 60 && Math.abs(P.z - TZ) < 60 && playerY() > 300);
      if (!near) return;
      beat = t * 124 / 60;
      var bp = beat % 1, pulse = Math.pow(1 - bp, 3);
      for (var i = 0; i < NT * NT; i++) { var cx = i % NT, cz = Math.floor(i / NT), h = ((cx + cz) * 0.09 + Math.floor(beat) * 0.17) % 1; tiles.setColorAt(i, new THREE.Color().setHSL(h, 1, 0.35 + 0.25 * (((cx + cz + Math.floor(beat)) % 2) ? pulse : 0.2))); }
      tiles.instanceColor.needsUpdate = true;
      beams.forEach(function (b, k) { b.p.rotation.z = Math.sin(t * 0.9 + b.ph) * 0.55; b.p.rotation.x = Math.cos(t * 0.7 + b.ph) * 0.45; b.m.color.setHSL(((t * 0.08) + k / 6) % 1, 1, 0.55); b.m.opacity = 0.1 + 0.12 * pulse; });
      ball.rotation.y += dt * 0.8; L1.intensity = 1.4 + pulse * 2.2; L2.intensity = 1.4 + (1 - pulse) * 1.6; L1.color.setHSL((t * 0.05) % 1, 1, 0.55);
      if (t - ledT0 > 0.12) { ledT0 = t; var c = ledC.getContext("2d"), w = ledC.width, h2 = ledC.height; var gr = c.createLinearGradient(0, 0, w, h2); gr.addColorStop(0, "hsl(" + ((t * 30) % 360) + ",100%,30%)"); gr.addColorStop(1, "hsl(" + ((t * 30 + 140) % 360) + ",100%,22%)"); c.fillStyle = gr; c.fillRect(0, 0, w, h2);
        for (var e = 0; e < 32; e++) { var v = Math.abs(Math.sin(t * 3 + e * 0.7) * Math.sin(t * 1.3 + e)) * (0.45 + pulse * 0.55); c.fillStyle = "rgba(255,255,255," + (0.35 + v * 0.5) + ")"; c.fillRect(e * 16 + 2, h2 - v * h2 * 0.8, 12, v * h2 * 0.8); }
        c.fillStyle = "#fff"; c.font = "900 64px Arial Black, Arial"; c.textAlign = "center"; c.shadowColor = "#ff3d8b"; c.shadowBlur = 18; c.fillText("EARTHPASS", w / 2, 82); c.shadowBlur = 0; ledT.needsUpdate = true; }
    }
    function setCap(y) { cap.position.y = y; }
    TOWER = { x: TX, z: TZ, SH: SH, CH: CH, PH: PH, TOP: TOP, CLUBY: CLUBY, ROOF: ROOF, PODH: PODH, BOARD: BOARD, topAt: topAtT, surface: surface, DECK: DECK, CLUB: CLUB, PAD: PAD, POD: POD, STAIR: STAIR, padHeli: padHeli, cap: cap, setCap: setCap, crowd: crowd, spawn: spawnCrowd, leave: leave, tick: tick, g: g };
    DISTRICTS.push({ n: "EarthPass Tower", x: TX, z: TZ + 30, r: 1 });
  })();
  /* ---- street art: murals on hand-built walls and plain-text billboards ---- */
  (function () {
    var T = TOWER, sb = new StickerBatch();
    [[-1, 0], [1, 4], [-1, 13], [1, 6]].forEach(function (m, k) { sb.add(T.x + m[0] * (k < 2 ? 18.5 : 10.5), k < 2 ? 5.2 : 4.2, T.z + T.PH, 0, 1, k < 2 ? 6.5 : 4.2, m[1]); });
    [-1, 1].forEach(function (sd, k) { sb.add(T.x + sd * T.PH, 7, T.z + 6, sd, 0, 9, k ? 12 : 15); sb.add(T.x + sd * T.PH, 7, T.z - 10, sd, 0, 9, k ? 9 : 2); });
    sb.add(-128, 3.3, 18, -1, 0, 4.6, 10); sb.add(-128, 3.3, 25, -1, 0, 3.6, 7); sb.add(-106, 3.3, 21, 1, 0, 5, 8); sb.add(-117, 3.2, 29, 0, 1, 5.5, 11);
    sb.mesh();
    function billboard(x, z, yaw, title, sub, bg) {
      var g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = yaw; scene.add(g);
      [-4.5, 4.5].forEach(function (px) { var p = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.28, 8, 10), M.dark); p.position.set(px, 4, 0); p.castShadow = true; g.add(p); });
      var t = signTex(title, { w: 1024, h: 420, bg: bg || "#120a24", fg: "#ffffff", size: 150, sub: sub, subfg: "#2ee6d6" }), bd = new THREE.Mesh(new THREE.BoxGeometry(13, 5.4, 0.3), new THREE.MeshStandardMaterial({ color: 0x15111f, roughness: 0.5 })); bd.position.y = 9.6; g.add(bd);
      var face = new THREE.Mesh(new THREE.PlaneGeometry(12.6, 5.1), new THREE.MeshStandardMaterial({ map: t, emissive: 0xffffff, emissiveMap: t, emissiveIntensity: 0.3, roughness: 0.6 })); face.position.set(0, 9.6, 0.16); g.add(face); nightMats.push(face.material);
      var back = face.clone(); back.rotation.y = Math.PI; back.position.z = -0.16; g.add(back);
      [-1, 1].forEach(function (sd) { stick(g, sd > 0 ? 6 : 0, 2.4, sd * 7.4, 9.8, 0.2, 1); });
      var c = Math.cos(yaw), s2 = Math.sin(yaw); [-4.5, 4.5].forEach(function (px) { var wx = x + px * c, wz = z - px * s2; solid(wx - 0.3, wx + 0.3, wz - 0.3, wz + 0.3); });
    }
    billboard(18, -40, 0, "MINT ON OPENSEA", "EARTHPASS PASSPORT \u00b7 3,333 ON ROBINHOOD CHAIN");
    billboard(-80, 40, Math.PI, "GM, CITIZEN", "YOUR PASSPORT TO THE REAL WORLD \u00b7 EARTHPASS");
    billboard(T.x - 40, T.z + 56, 0.25, "WAGMI", "EARTHPASS TOWER \u00b7 SKY CLUB \u00b7 FLOOR 101", "#5a1f8c");
  })();
  /* ---- zones up the tower (each zone has a height y) ---- */
  ZONES.push({ id: "towerLift", x: TOWER.x, z: TOWER.z + TOWER.SH + 3.4, r: 2.2 });
  ZONES.push({ id: "towerLiftTop", x: TOWER.x, z: TOWER.z + TOWER.SH - 1.3, r: 1.8, y: TOWER.TOP });
  ZONES.push({ id: "clubDoor", x: TOWER.x - 5, z: TOWER.z + TOWER.CH + 1.0, r: 1.7, y: TOWER.TOP });
  ZONES.push({ id: "chuteKiosk", x: TOWER.x + 14.0, z: TOWER.z - 7, r: 1.8, y: TOWER.TOP });
  ZONES.push({ id: "towerJump", x: TOWER.x + TOWER.SH + TOWER.BOARD - 1.2, z: TOWER.z, r: 1.8, y: TOWER.TOP });
  ZONES.push({ id: "clubExit", x: TOWER.x - 5, z: TOWER.z + TOWER.CH - 1.2, r: 1.6, y: TOWER.CLUBY });
  ZONES.push({ id: "clubRoof", x: TOWER.x + TOWER.CH - 1.4, z: TOWER.z - TOWER.CH + 1.4, r: 1.6, y: TOWER.CLUBY });
  ZONES.push({ id: "clubBar", x: TOWER.x - 6, z: TOWER.z + 7.1, r: 1.8, y: TOWER.CLUBY });
  ZONES.push({ id: "clubDance", x: TOWER.x, z: TOWER.z + 1, r: 2.4, y: TOWER.CLUBY });
  ZONES.push({ id: "clubDJ", x: TOWER.x + 3.6, z: TOWER.z - 6.9, r: 1.6, y: TOWER.CLUBY });
  ZONES.push({ id: "padHeli", x: TOWER.x + 3, z: TOWER.z + 6.2, r: 2.2, y: TOWER.ROOF });
  ZONES.push({ id: "padDown", x: TOWER.x + TOWER.CH - 1.4, z: TOWER.z - TOWER.CH + 1.4, r: 1.6, y: TOWER.ROOF });
  function towerZoneInfo(id) {
    switch (id) {
      case "towerLift": return { t: "EarthPass Tower · express lift", d: "100 floors up in 30 seconds · Sky Deck, Sky Club, helipad", b: "Call the lift" };
      case "towerLiftTop": return { t: "Lift · Floor 100", d: "Go down to the lobby or up to the helipad", b: "Use the lift" };
      case "clubDoor": return { t: "Sky Club · Floor 101", d: "The highest party in the city. Free entry tonight.", b: "Go up" };
      case "chuteKiosk": return { t: "Parachute kiosk", d: "You have " + (G.chute || 0) + " parachute" + (G.chute === 1 ? "" : "s") + ". One costs 150 TOKEN.", b: "Buy · 150", off: G.balance < 150 };
      case "towerJump": return { t: "Base jump · 400 m", d: G.chute > 0 ? "You have " + G.chute + " parachute" + (G.chute === 1 ? "" : "s") + ". Open it with OPEN or Space." : "You have no parachute! Buy one at the kiosk.", b: "Jump!" };
      case "clubExit": return { t: "Stairs", d: "Down to the Sky Deck (floor 100)", b: "Go down" };
      case "clubRoof": return { t: "Stairs to the roof", d: "Helipad on top of the tower", b: "Go up" };
      case "padDown": return { t: "Stairs", d: "Down to the Sky Club", b: "Go down" };
      case "padHeli": return TOWER.padHeli.visible ? { t: "Tower helicopter", d: "Rent it and take off from the roof \u00b7 150 TOKEN", b: "Rent \u00b7 150", off: G.balance < 150 } : null;
      case "clubBar": return { t: "Sky Bar", d: "Neon mocktail · 15 TOKEN · restores energy", b: "Order · 15", off: G.balance < 15 };
      case "clubDance": return { t: "Dance floor", d: "Show them your moves", b: "Dance" };
      case "clubDJ": return { t: "DJ booth", d: CLUBA ? "Music is playing" : "Music is off", b: CLUBA ? "Music off" : "Music on" };
    }
    return null;
  }
  function towerAct(id) {
    var T = TOWER;
    switch (id) {
      case "towerLift": case "towerLiftTop": liftMenu(); return true;
      case "clubDoor": hopTo(T.CLUB, T.x - 5, T.z + T.CH - 2.0, Math.PI, "Sky Club · Floor 101"); return true;
      case "clubExit": hopTo(T.DECK, T.x - 5, T.z + T.CH + 1.6, 0, "Sky Deck · Floor 100"); return true;
      case "clubRoof": hopTo(T.PAD, T.x + T.CH - 2.4, T.z - T.CH + 2.4, Math.PI / 4, "Roof helipad · 414 m"); return true;
      case "padHeli": if (G.balance < 150) return true; spend(150, "Tower helicopter"); T.padHeli.visible = false; deliver(ITEMS.filter(function (i) { return i.id === "heli"; })[0], true, { x: T.x + 3, z: T.z + 3, alt: T.ROOF, yaw: -0.6 }); return true;
      case "padDown": hopTo(T.CLUB, T.x + T.CH - 2.4, T.z - T.CH + 2.6, Math.PI, "Sky Club · Floor 101"); return true;
      case "chuteKiosk": if (G.balance < 150) { toast("Not enough TOKEN"); return true; } spend(150, "Parachute"); G.chute = (G.chute || 0) + 1; save(); weapUI(); toast("Parachute bought · you have " + G.chute); return true;
      case "towerJump": jumpMenu(); return true;
      case "clubBar": if (G.balance < 15) return true; sfx("bar"); spend(15, "Sky Bar"); G.food = Math.min(100, G.food + 25); G.hp = Math.min(100, G.hp + 15); doGesture(1.6, null, "Eat", { passport: false }); toast("Neon mocktail · +energy"); missionEvent("clubBar"); return true;
      case "clubDance": P.yaw = Math.PI; doGesture(9, null, "Dance", { passport: false }); clubMusic(true); missionEvent("clubDance"); return true;
      case "clubDJ": clubMusic(!CLUBA); return true;
    }
    return false;
  }
  /* go to another level of the tower with a short fade */
  function hopTo(S, x, z, yaw, label) {
    $("fade").classList.add("on");
    setTimeout(function () { P.lv = S; P.x = x; P.z = z; P.yaw = yaw; cam.yaw = yaw + Math.PI; P.v = 0; TOWER.spawn(); if (S === TOWER.CLUB) clubMusic(true); $("fade").classList.remove("on"); if (label) toast(label); }, 450);
  }
  function liftMenu() {
    var at = P.lv ? P.lv.id : "lobby", T = TOWER;
    var opts = [["lobby", "Lobby", "Ground floor · plaza"], ["deck", "Floor 100 · Sky Deck", "Open-air terrace · base jump"], ["club", "Floor 101 · Sky Club", "The party at the top"], ["pad", "Roof · Helipad", "414 m · land your helicopter here"]];
    modal("<div><div class='eyebrow'>EarthPass Tower · glass lift</div><h2>Choose a floor</h2></div><div class='row' style='flex-direction:column;gap:8px'>" + opts.map(function (o) { return "<button class='btn" + (o[0] === at ? " ghost" : "") + "' type='button' data-fl='" + o[0] + "'" + (o[0] === at ? " disabled" : "") + "><b>" + o[1] + "</b><br><small style='opacity:.75'>" + o[2] + "</small></button>"; }).join("") + "<button class='btn ghost' id='mClose' type='button'>Cancel</button></div>");
    Array.prototype.forEach.call($("sheet").querySelectorAll("[data-fl]"), function (b) { b.addEventListener("click", function () { closeModal(); liftRide(b.getAttribute("data-fl")); }); });
  }
  var LIFT = null;
  function liftRide(to) {
    sfx("lift", to);
    var T = TOWER, fromY = P.lv ? Math.min(P.lv.y, T.TOP) : 0, toY = to === "lobby" ? 0 : T.TOP;
    if (to !== "lobby" && fromY === T.TOP) { var S0 = to === "club" ? T.CLUB : to === "pad" ? T.PAD : T.DECK; hopTo(S0, to === "pad" ? T.x + T.CH - 2.4 : T.x, to === "pad" ? T.z - T.CH + 2.4 : to === "club" ? T.z + T.CH - 2.0 : T.z + T.SH - 1.5, Math.PI, null); return; }
    T.spawn(); SCANNING = true; P.v = 0; document.body.classList.add("cinema");
    $("fade").classList.add("on");
    setTimeout(function () {
      player.g.visible = false; $("fade").classList.remove("on");
      LIFT = { t: 0, from: fromY, to: toY, dur: 3 + Math.abs(toY - fromY) / 70, dest: to };
    }, 450);
  }
  function liftTick(dt) {
    if (!LIFT) return; var T = TOWER; LIFT.t += dt;
    var k = Math.min(1, LIFT.t / LIFT.dur), e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2, y = LIFT.from + (LIFT.to - LIFT.from) * e;
    T.setCap(y);
    var up = LIFT.to > LIFT.from, cz = T.z + T.SH + 1.45;
    camOverride = { exact: true, pos: new THREE.Vector3(T.x + 24, Math.max(2.5, y + (up ? -4 : 9)), cz + 30), look: new THREE.Vector3(T.x, y + 1.4, cz) };
    $("cine").hidden = false; $("cine").textContent = "EarthPass Tower · Floor " + Math.max(1, Math.round(y / 4));
    if (k >= 1) {
      var dest = LIFT.dest; LIFT = null; sfx("ding"); $("fade").classList.add("on");
      setTimeout(function () {
        camOverride = null; document.body.classList.remove("cinema"); $("cine").hidden = true; SCANNING = false; player.g.visible = true; $("fade").classList.remove("on");
        if (dest === "lobby") { P.lv = null; P.x = T.x; P.z = T.z + T.SH + 3.6; P.yaw = 0; cam.yaw = Math.PI; T.leave(); toast("Lobby · EarthPass Tower"); }
        else if (dest === "deck") { P.lv = T.DECK; P.x = T.x - 1.2; P.z = T.z + T.SH - 1.6; P.yaw = -Math.PI / 2; cam.yaw = Math.PI / 2; bigText("mstart", "Sky Deck", "Floor 100 · 400 m above the city"); missionEvent("skyDeck"); }
        else if (dest === "club") { P.lv = T.CLUB; P.x = T.x - 5; P.z = T.z + T.CH - 2.0; P.yaw = Math.PI; cam.yaw = 0; clubMusic(true); bigText("mstart", "Sky Club", "Floor 101 · the party never stops"); missionEvent("skyClub"); }
        else { P.lv = T.PAD; P.x = T.x + T.CH - 2.4; P.z = T.z - T.CH + 2.4; P.yaw = Math.PI / 4; cam.yaw = P.yaw + Math.PI; toast("Roof helipad · 414 m"); }
      }, 450);
    }
  }
  function jumpMenu() {
    if (G.chute > 0) { baseJump(); return; }
    modal("<div><div class='eyebrow'>Base jump · 400 m</div><h2>You have no parachute!</h2></div><p class='note'>Jumping without one is deadly. Parachutes are sold at the kiosk on this deck and in the shop.</p><div class='row'><button class='btn ghost' id='mClose' type='button'>Cancel</button><button class='btn ghost' id='jNo' type='button'>Jump anyway</button><button class='btn' id='jBuy' type='button'" + (G.balance < 150 ? " disabled" : "") + ">Buy one · 150 &amp; jump</button></div>");
    $("jNo").addEventListener("click", function () { closeModal(); baseJump(); });
    $("jBuy").addEventListener("click", function () { if (G.balance < 150) return; spend(150, "Parachute"); G.chute = (G.chute || 0) + 1; save(); closeModal(); baseJump(); });
  }
  function baseJump() {
    var T = TOWER; P.yaw = Math.PI / 2; cam.yaw = P.yaw + Math.PI; P.x = T.x + T.SH + T.BOARD - 0.4; P.z = T.z;
    startFall(T.TOP + 0.1, 5.5, 0); P.fall.vy = 3.2;
    bigText("mstart", "BASE JUMP!", G.chute > 0 ? "Open the parachute: OPEN button or Space" : "No parachute… good luck"); missionEvent("baseJump");
  }
  /* a small synth beat for the club (Web Audio, made in code) */
  var CLUBA = null;
  function clubMusic(on) { if (on) { if (SND) SND.club(true, clubSynth); else clubSynth(true); } else { if (SND) SND.club(false); clubSynth(false); } }
  function clubSynth(on) {
    if (!on) { if (CLUBA) { clearInterval(CLUBA.iv); try { CLUBA.ac.close(); } catch (e) {} CLUBA = null; } return; }
    if (CLUBA) return;
    try {
      var AC = window.AudioContext || window.webkitAudioContext; if (!AC) return; var ac = new AC(), out = ac.createGain(); out.gain.value = 0.16; out.connect(ac.destination);
      var noise = ac.createBuffer(1, ac.sampleRate * 0.25, ac.sampleRate), nd = noise.getChannelData(0); for (var i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
      var step = 60 / 124 / 4, next = ac.currentTime + 0.05, n = 0, bass = [45, 45, 57, 45, 48, 45, 52, 43];
      function kick(t) { var o = ac.createOscillator(), gn = ac.createGain(); o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.12); gn.gain.setValueAtTime(1, t); gn.gain.exponentialRampToValueAtTime(0.001, t + 0.3); o.connect(gn); gn.connect(out); o.start(t); o.stop(t + 0.32); }
      function hat(t, v, len) { var s = ac.createBufferSource(), f = ac.createBiquadFilter(), gn = ac.createGain(); s.buffer = noise; f.type = "highpass"; f.frequency.value = len > 0.1 ? 1400 : 7000; gn.gain.setValueAtTime(v, t); gn.gain.exponentialRampToValueAtTime(0.001, t + len); s.connect(f); f.connect(gn); gn.connect(out); s.start(t); s.stop(t + len + 0.02); }
      function bassN(t, m) { var o = ac.createOscillator(), f = ac.createBiquadFilter(), gn = ac.createGain(); o.type = "sawtooth"; o.frequency.value = 440 * Math.pow(2, (m - 69) / 12); f.type = "lowpass"; f.frequency.setValueAtTime(900, t); f.frequency.exponentialRampToValueAtTime(180, t + 0.2); gn.gain.setValueAtTime(0.32, t); gn.gain.exponentialRampToValueAtTime(0.001, t + 0.22); o.connect(f); f.connect(gn); gn.connect(out); o.start(t); o.stop(t + 0.24); }
      function chord(t) { [69, 72, 76].forEach(function (m) { var o = ac.createOscillator(), gn = ac.createGain(); o.type = "triangle"; o.frequency.value = 440 * Math.pow(2, (m - 69) / 12); gn.gain.setValueAtTime(0.06, t); gn.gain.exponentialRampToValueAtTime(0.001, t + 0.45); o.connect(gn); gn.connect(out); o.start(t); o.stop(t + 0.5); }); }
      var iv = setInterval(function () {
        if (ac.state === "suspended") ac.resume();
        while (next < ac.currentTime + 0.2) { var s = n % 16; if (s % 4 === 0) kick(next); if (s % 4 === 2) hat(next, 0.25, 0.05); if (s === 4 || s === 12) hat(next, 0.4, 0.16); if (s % 2 === 1) bassN(next, bass[(n >> 1) % 8]); if (s === 6 || s === 14) chord(next); next += step; n++; }
      }, 50);
      CLUBA = { ac: ac, iv: iv };
    } catch (e) { CLUBA = null; }
  }

  /* ===================== Airport: entrance screening, boarding e-gate, duty free ===================== */
  var SCANNING = false;
  function hasWeapons() { return !!(G.weapons && Object.keys(G.weapons).some(function (k) { return G.weapons[k] > 0; })); }
  function entranceCheck() {
    if (hasWeapons()) {
      modal("<div><div class='eyebrow'>Entrance security</div><h2>Weapons are not allowed inside</h2></div><p class='note'>Your weapons go in a secure locker and are given back when you leave the airport.</p><div class='row'><button class='btn ghost' id='mClose' type='button'>Not now</button><button class='btn' id='lockGo' type='button'>Use the locker</button></div>");
      $("lockGo").addEventListener("click", function () { G.locker = G.locker || {}; Object.keys(G.weapons).forEach(function (k) { G.locker[k] = (G.locker[k] || 0) + G.weapons[k]; }); G.weapons = {}; G.wsel = "fist"; weapUI(); save(); closeModal(); toast("Weapons stored in locker"); gateScan(); });
      return;
    }
    gateScan();
  }
  function gateScan() {
    var ex = AX1 - 3; SCANNING = true; P.x = ex - 1.6; P.z = 0; P.yaw = Math.PI / 2; P.v = 0;
    document.body.classList.add("cinema"); camOverride = { pos: new THREE.Vector3(ex - 3.6, 1.9, 2.6), look: new THREE.Vector3(ex + 0.4, 1.2, 0), exact: true };
    var hud = $("scanhud"); hud.hidden = false; $("scanT").textContent = "ENTRANCE SCAN"; $("scanD").textContent = "Bag on the belt, then walk through the arch"; $("scanBar").style.width = "0%";
    var t0 = performance.now(), dur = 2800;
    var iv = setInterval(function () {
      var k = (performance.now() - t0) / dur; P.x = ex - 1.6 + Math.min(1, k) * 3.2; player.play(k < 1 ? "Walk" : "Idle"); $("scanBar").style.width = Math.min(100, k * 100).toFixed(0) + "%";
      if (k >= 1) { clearInterval(iv); $("scanT").textContent = "CLEAR ✓"; $("scanD").textContent = "Welcome to " + here().name;
        setTimeout(function () { hud.hidden = true; camOverride = null; document.body.classList.remove("cinema"); entryOk = true; applyBlocks(); P.x = AX1 + 1.6; P.z = 0; P.yaw = Math.PI / 2; cam.yaw = P.yaw + Math.PI; SCANNING = false; toast("Entrance security cleared"); missionEvent("entrySec"); }, 900); }
    }, 50);
  }
  function airportTick() {
    if (!blockEntry) return;
    var inTerm = P.x > AX1 + 0.4 && P.x < AX2 && Math.abs(P.z) < AZ;
    if (inTerm && !entryOk) { entryOk = true; applyBlocks(); }
    if (entryOk && !inTerm && !SCANNING && !cine && (P.x < AX1 - 6 || Math.abs(P.z) > 13 || P.x > AX2 + 1) && P.x < 5000) {
      entryOk = false; applyBlocks();
      if (G.locker && P.x < AX1 - 6) { Object.keys(G.locker).forEach(function (k) { G.weapons[k] = (G.weapons[k] || 0) + G.locker[k]; }); G.locker = null; weapUI(); save(); toast("Your weapons were returned from the locker"); }
    }
    if (inTerm && hasWeapons() && !SCANNING) { G.locker = G.locker || {}; Object.keys(G.weapons).forEach(function (k) { G.locker[k] = (G.locker[k] || 0) + G.weapons[k]; }); G.weapons = {}; G.wsel = "fist"; weapUI(); }
  }
  function boardingScan(done) {
    SCANNING = true; P.x = 155.7; P.z = 12; P.yaw = Math.PI / 2; P.v = 0; player.play("Interact", { restart: true });
    document.body.classList.add("cinema"); camOverride = { pos: new THREE.Vector3(153.4, 2.1, 15.4), look: new THREE.Vector3(157.6, 1.0, 11.4), exact: true };
    var hud = $("scanhud"); hud.hidden = false; $("scanT").textContent = "BOARDING PASS"; $("scanD").textContent = "Hold your pass over the scanner"; $("scanBar").style.width = "0%";
    var t0 = performance.now();
    var iv = setInterval(function () {
      var k = (performance.now() - t0) / 1500; $("scanBar").style.width = Math.min(100, k * 100).toFixed(0) + "%";
      if (k >= 1) { clearInterval(iv); $("scanT").textContent = "ACCESS GRANTED ✓"; $("scanD").textContent = (G.trip ? G.trip.no + " · seat " + G.trip.seat + (G.trip.cls && G.trip.cls !== "Economy" ? " · " + G.trip.cls : "") : "") + " · have a nice flight";
        if (egateFlaps) { egateFlaps[0].position.z = 10.95; egateFlaps[1].position.z = 13.05; }
        setTimeout(function () { hud.hidden = true; camOverride = null; document.body.classList.remove("cinema"); SCANNING = false; done(); setTimeout(function () { if (egateFlaps) { egateFlaps[0].position.z = 11.55; egateFlaps[1].position.z = 12.45; } }, 9000); }, 1100); }
    }, 50);
  }
  function dutyFree() {
    var items = [["Perfume", 35], ["Swiss chocolate", 8], ["Sunglasses", 24], ["Watch", 120], ["Teddy bear souvenir", 15], ["Headphones", 60], ["Travel pillow", 12]];
    var html = "<div><div class='eyebrow'>Duty free · " + here().code + "</div><h2>Tax-free shopping</h2></div><div class='row' style='flex-direction:column;gap:7px;max-height:50vh;overflow:auto'>";
    items.forEach(function (it, i) { html += "<button class='btn" + (G.balance < it[1] ? " ghost" : "") + "' type='button' data-buy='" + i + "'" + (G.balance < it[1] ? " disabled" : "") + ">" + it[0] + " · " + it[1] + " TOKEN</button>"; });
    html += "<button class='btn ghost' id='mClose' type='button'>Close</button></div><p class='note'>You have " + tok(G.balance) + ". Bought items go in your bag.</p>";
    modal(html);
    Array.prototype.forEach.call($("sheet").querySelectorAll("[data-buy]"), function (b) { b.addEventListener("click", function () { var it = items[+b.getAttribute("data-buy")]; if (G.balance < it[1]) return; spend(it[1], "Duty free · " + it[0]); (G.bag = G.bag || []).push(it[0]); save(); closeModal(); toast("Bought " + it[0] + " · tax free"); missionEvent("dutyFree"); }); });
  }
  /* a destination poster for travel agencies */
  function posterTex(city, c1, c2) {
    return canvasTex(256, 384, function (g, w, h) {
      var gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, c1); gr.addColorStop(1, c2); g.fillStyle = gr; g.fillRect(0, 0, w, h);
      g.fillStyle = "rgba(255,255,255,0.85)"; g.beginPath(); g.arc(w * 0.7, h * 0.28, 34, 0, 7); g.fill();
      g.fillStyle = "rgba(10,12,20,0.75)"; for (var i = 0; i < 12; i++) { var bw = 14 + (i * 37) % 22, bh = 60 + (i * 53) % 120; g.fillRect(i * 22, h * 0.72 - bh, bw, bh); } g.fillRect(0, h * 0.72, w, h * 0.28);
      g.fillStyle = "#fff"; g.font = "800 40px Unbounded, Arial"; g.textAlign = "center"; g.fillText(city, w / 2, h * 0.84);
      g.font = "700 15px 'JetBrains Mono', monospace"; g.fillStyle = "#ff3d8b"; g.fillText("FLY EARTHPASS AIR", w / 2, h * 0.93);
    });
  }
  /* extra staff and decor for every interior */
  function dressInterior(id, o, r) {
    if (id === "home" || !r || !r.W) return;
    var W = r.W, D = r.D;
    npc(null, o.x - W / 2 + 1.4, o.z - D / 2 + 1.5, Math.PI / 4, ["Interact", "Talk", "Idle"][Math.floor(Math.random() * 3)]);
    if (W >= 12) npc(null, o.x + W / 2 - 1.4, o.z - D / 2 + 1.5, -Math.PI / 4, ["Talk", "Interact", "Phone"][Math.floor(Math.random() * 3)]);
    plant(o.x - W / 2 + 0.7, o.z + D / 2 - 0.9); plant(o.x + W / 2 - 0.7, o.z + D / 2 - 0.9);
    for (var i = -1; i <= 1; i += 2) { var lamp = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.5, 0.25, 16, 1, true), new THREE.MeshStandardMaterial({ color: 0x222222, side: THREE.DoubleSide, emissive: 0xffe2a8, emissiveIntensity: 0.25 })); lamp.position.set(o.x + i * W / 4, 2.9, o.z); scene.add(lamp); }
  }
  function punch() {
    if (P.mode !== "walk" || gesture || cine || CUT || P.seat || working || performance.now() < punchCd) return;
    punchCd = performance.now() + 560; punchN++;
    var t0 = frontTarget(); if (t0) P.yaw = Math.atan2(t0.x - P.x, t0.z - P.z); sfx("punch", t0);
    doGesture(0.55, null, punchN % 2 ? "Jab" : "Cross", { passport: false, speed: 1.3 });
    setTimeout(function () { var t = frontTarget(); if (t) hitTarget(t); }, 230);
  }
  function hitTarget(t) {
    var cop = COPS.indexOf(t) >= 0;
    t.hp = (t.hp == null ? (cop ? 4 : 3) : t.hp) - (Math.random() < sk("strength") / 160 ? 2 : 1); t.t = 0; skillAdd("strength", 0.6);
    var dx = t.x - P.x, dz = t.z - P.z, d = Math.hypot(dx, dz) || 1; t.x += dx / d * 0.35; t.z += dz / d * 0.35; t.face = Math.atan2(-dx, -dz);
    if (t.hp <= 0) {
      t.st = "ko"; t.a.play("KnockOut", { once: true, restart: true, fade: 0.1 }); missionEvent("ko");
      if (!cop && Math.random() < 0.5) { var cash = 3 + Math.floor(Math.random() * 8); earn(cash, "Cash picked up"); toast("+" + cash + " TOKEN"); }
    } else { t.a.play("HitHead", { once: true, restart: true, fade: 0.08 }); t.stun = 0.55; if (!cop && t.st !== "fight") t.st = Math.random() < 0.4 ? "fight" : "flee"; if (cop) t.st = "chase"; }
    PEDS.forEach(function (o) { if (o !== t && !o.st && Math.hypot(o.x - P.x, o.z - P.z) < 14) { o.st = "flee"; o.t = 0; } });
    if (cop) setWanted(Math.max(WANTED + 1, 2), "Assaulting an officer");
    else if (WANTED === 0 && Math.random() < 0.55) setWanted(1, "The police saw that · ★");
  }
  function hurtPlayer(n) {
    if (G.armor > 0) { var ab = Math.min(G.armor, n * 0.7); G.armor -= ab; n -= ab; } G.hp = Math.max(0, G.hp - n); hurtT = performance.now(); weapUI(); $("hurt").classList.remove("on"); void $("hurt").offsetWidth; $("hurt").classList.add("on");
    if (G.hp <= 0) wasted();
  }
  function moveFree(o, tx, tz, sp, dt) {
    var dx = tx - o.x, dz = tz - o.z, d = Math.hypot(dx, dz) || 1, st = Math.min(d, sp * dt), p = { x: o.x + dx / d * st, z: o.z + dz / d * st };
    collide(p, 0.32); if (CITY) CITY.collide(p, 0.34); o.face = Math.atan2(dx, dz); if (deepWater(p.x, p.z) && !deepWater(o.x, o.z)) return; o.x = p.x; o.z = p.z;
  }
  /* pedestrians that are fighting, knocked out or running away */
  function streetPed(pd, dt) {
    pd.t = (pd.t || 0) + dt; var dP = Math.hypot(pd.x - P.x, pd.z - P.z);
    if (pd.stun > 0) pd.stun -= dt;
    else if (pd.st === "ko") { if (pd.t > 6.5) { pd.st = "getup"; pd.t = 0; pd.a.play("GetUp", { once: true, restart: true }); } }
    else if (pd.st === "getup") { if (pd.t > 2.2) { pd.st = "flee"; pd.t = 0; pd.hp = 2; } }
    else if (pd.st === "flee") { moveFree(pd, pd.x + (pd.x - P.x) * 5, pd.z + (pd.z - P.z) * 5, 3.7, dt); pd.a.play("Jog", { speed: 1.1 }); if (pd.t > 12 || dP > 80) return false; }
    else if (pd.st === "fight") {
      if (dP > 26 || P.mode === "car") { pd.st = "flee"; pd.t = 0; }
      else if (dP > 1.15) { moveFree(pd, P.x, P.z, 2.8, dt); pd.a.play("Jog"); }
      else { pd.face = Math.atan2(P.x - pd.x, P.z - pd.z); pd.swing = (pd.swing || 0) - dt; if (pd.swing <= 0) { pd.swing = 1.25; pd.a.play(Math.random() < 0.5 ? "Jab" : "Cross", { once: true, restart: true }); setTimeout(function () { if (pd.st === "fight" && Math.hypot(pd.x - P.x, pd.z - P.z) < 1.5 && P.mode === "walk") hurtPlayer(7); }, 260); } }
    }
    pd.a.g.position.set(pd.x, 0.105, pd.z); if (pd.face !== undefined) pd.a.g.rotation.y = pd.face;
    return true;
  }
  /* police on foot and in cars */
  function spawnCop() {
    var ang = Math.random() * Math.PI * 2, R = 36 + Math.random() * 16, x = P.x + Math.cos(ang) * R, z = P.z + Math.sin(ang) * R, r = CITY.nearestRoad(x, z, 80);
    if (r) { x = r.x; z = r.z; } if (CITY.hit(x, z, 0.4)) return;
    var a = makeActor("officer"); COPS.push({ a: a, x: x, z: z, hp: 4, st: "chase", t: 0, grab: 0 });
  }
  function spawnPoliceCar() {
    var r = CITY.nearestRoad(taxi.x - Math.cos(taxi.yaw) * 70, taxi.z + Math.sin(taxi.yaw) * 70, 120); if (!r) return;
    var m = carMesh(0xf4f4f2, "sedan", "police"); scene.add(m);
    var c = { m: m, x: r.x, z: r.z, yaw: Math.atan2(-(taxi.z - r.z), taxi.x - r.x), v: 6, close: 0 }; PCARS.push(c); CARS.push(c);
  }
  function dropPoliceCar(c) { scene.remove(c.m); PCARS.splice(PCARS.indexOf(c), 1); var i = CARS.indexOf(c); if (i >= 0) CARS.splice(i, 1); }
  function clearPolice() { COPS.forEach(function (c) { removeActor(c.a); }); COPS = []; while (PCARS.length) dropPoliceCar(PCARS[0]); }
  function outcome(title, sub, fee, label, where) {
    var fee2 = Math.min(Math.max(0, Math.floor(G.balance)), fee);
    $("busted").innerHTML = "<b>" + title + "</b><span>" + sub + (fee2 ? " · −" + fee2 + " TOKEN" : "") + "</span>"; $("busted").hidden = false;
    if (G.mis) { quitMission(); setTimeout(function () { bigText("mpass", "Mission failed", title.toLowerCase(), true); }, 2600); }
    setTimeout(function () {
      fadeTo(function () {
        if (P.mode === "car") { taxi.v = 0; exitTaxi(); }
        if (P.fall) endFall(); if (P.lv && TOWER) TOWER.leave(); P.lv = null;
        if (fee2) spend(fee2, label); G.hp = 100; setWanted(0); clearPolice();
        var w = pidPos(where) || pidPos("home"); if (w) { var f = freeSpot(w[0], w[1]) || { x: w[0], z: w[1] }; place(f.x, f.z, P.yaw, P.yaw + Math.PI); }
        $("busted").hidden = true;
      });
    }, 1600);
  }
  function busted() { sfx("wasted"); G.weapons = {}; G.wsel = "fist"; G.armor = 0; try { weapUI(); } catch (e) {} outcome("BUSTED", "The police took you in", 40 + WANTED * 25, "Police fine", "police"); }
  function wasted() { sfx("wasted"); outcome("WASTED", "You woke up at the hospital", 30, "Hospital bill", "hospital"); }
  function carjack(a) { if (!a || a.jacked || P.mode !== "walk" || VSEQ) return; boardVehicle(a); }
  function carjackNow(a, seq) {
    if (!a || (a.jacked && !seq) || P.mode !== "walk") return;
    a.jacked = true; a.v = 0; a.vmax = 0; sfx("jacked", a);
    if (seq) {
      if (taxi.m && taxi.m !== a.m) CARS.push({ m: taxi.m, x: taxi.x, z: taxi.z, yaw: taxi.yaw, parked: true });
      var ci = CT.indexOf(a); if (ci >= 0) CT.splice(ci, 1); var cj = CARS.indexOf(a); if (cj >= 0) CARS.splice(cj, 1);
      taxi.m = a.m; taxi.x = a.x; taxi.z = a.z; taxi.yaw = a.yaw; taxi.alt = 0; enterTaxi();
      setWanted(Math.max(WANTED, 1), "Vehicle theft reported \u00b7 \u2605"); missionEvent("jack"); return;
    }
    var yaw = a.yaw, W = a.m.userData.W, lx = 0.3, lz = -(W / 2 + 0.75);
    P.x = a.x + lx * Math.cos(yaw) + lz * Math.sin(yaw); P.z = a.z - lx * Math.sin(yaw) + lz * Math.cos(yaw); P.yaw = Math.atan2(a.x - P.x, a.z - P.z);
    doGesture(0.9, function () {
      var drv = a.rider || makeActor(Math.random() < 0.6 ? "man" : "woman"); a.rider = null;
      var dl = -(W / 2 + 1.6), dx = 0.2 * Math.cos(yaw) + dl * Math.sin(yaw), dz = -0.2 * Math.sin(yaw) + dl * Math.cos(yaw);
      var pd = { a: drv, x: a.x + dx, z: a.z + dz, st: "ko", t: 4.2, hp: 1, face: Math.atan2(-dx, -dz) }; drv.play("KnockOut", { once: true, restart: true }); PEDS.push(pd);
      if (taxi.m && taxi.m !== a.m) CARS.push({ m: taxi.m, x: taxi.x, z: taxi.z, yaw: taxi.yaw, parked: true });
      var i = CT.indexOf(a); if (i >= 0) CT.splice(i, 1); var j = CARS.indexOf(a); if (j >= 0) CARS.splice(j, 1);
      taxi.m = a.m; taxi.x = a.x; taxi.z = a.z; taxi.yaw = a.yaw;
      enterTaxi(); if (a.m.userData.moto) { cam.tdist = 6.5; player.g.visible = true; }
      setWanted(Math.max(WANTED, 1), "Vehicle theft reported · ★"); missionEvent("jack"); if (a.m.userData.moto) missionEvent("jackMoto");
    }, "Push", { passport: false, speed: 1.6 });
  }
  function streetTick(dt) {
    var now2 = performance.now();
    /* nearest slow car on the street can be stolen */
    jackZone.car = null; jackZone.x = 1e9;
    if (P.mode === "walk" && !INSIDE && !gesture) { var bd = 3.6; CT.forEach(function (a) { if (a.jacked || Math.abs(a.v) > 7) return; var d = Math.hypot(a.x - P.x, a.z - P.z); if (d < bd) { bd = d; jackZone.car = a; } }); if (jackZone.car) { jackZone.x = jackZone.car.x; jackZone.z = jackZone.car.z; } }
    /* people never walk through you or your vehicle */
    var veh = P.mode === "car" && taxi.m, vL = veh ? taxi.m.userData.L / 2 + 0.35 : 0, vW = veh ? taxi.m.userData.W / 2 + 0.35 : 0, cs = Math.cos(taxi.yaw), sn = Math.sin(taxi.yaw);
    PEDS.concat(COPS).forEach(function (t) {
      if (t.st === "ko" || t.st === "getup") return;
      if (veh) {
        var dx = t.x - taxi.x, dz = t.z - taxi.z, lx = dx * cs - dz * sn, lz = dx * sn + dz * cs;
        if (Math.abs(lx) < vL && Math.abs(lz) < vW) {
          if (Math.abs(taxi.v) > 3.5) { t.st = "ko"; t.t = 0; t.hp = 0; t.a.play("KnockOut", { once: true, restart: true, fade: 0.08 }); var k2 = Math.sign(taxi.v) * 1.6; t.x += cs * k2; t.z -= sn * k2; t.face = Math.atan2(-cs * k2, sn * k2); if (COPS.indexOf(t) >= 0) setWanted(WANTED + 1, "You hit an officer"); else if (WANTED === 0 && Math.random() < 0.5) setWanted(1, "Hit and run \u00b7 \u2605"); PEDS.forEach(function (o) { if (!o.st && Math.hypot(o.x - t.x, o.z - t.z) < 14) { o.st = "flee"; o.t = 0; } }); }
          else { var push = (vW - Math.abs(lz)) * (lz < 0 ? -1 : 1); t.x += sn * push; t.z += cs * push; }
          if (!t.st) t.a.g.position.set(t.x, 0.105, t.z);
        }
      } else if (P.mode === "walk") {
        var ddx = P.x - t.x, ddz = P.z - t.z, d2 = Math.hypot(ddx, ddz);
        if (d2 < 0.6 && d2 > 0.001) { P.x = t.x + ddx / d2 * 0.6; P.z = t.z + ddz / d2 * 0.6; }
      }
    });
    /* health regenerates slowly */
    if (G.hp < 100 && now2 - hurtT > 6000) G.hp = Math.min(100, G.hp + dt * 2);
    $("hHp").style.width = G.hp.toFixed(0) + "%"; $("hpBar").classList.toggle("low", G.hp < 30);
    /* wanted level */
    if (WANTED >= 3 && INSIDE && INSIDE.id === "bank") lastSeen = now2;
    if (WANTED > 0) {
      var tgtX = P.mode === "car" ? taxi.x : P.x, tgtZ = P.mode === "car" ? taxi.z : P.z;
      copT += dt;
      if (copT > 2.2 && !INSIDE && CITY && CITY.inBounds(tgtX, tgtZ)) { copT = 0; if (COPS.length < Math.min(1 + WANTED, 5) && P.mode === "walk") spawnCop(); if (P.mode === "car" && WANTED >= 2 && PCARS.length < Math.min(WANTED - 1, 3)) spawnPoliceCar(); }
      if (now2 - lastSeen > 24000) { lastSeen = now2; setWanted(WANTED - 1); if (WANTED === 0) { toast("You lost the police"); missionEvent("lostCops"); } }
    }
    for (var i = COPS.length - 1; i >= 0; i--) {
      var c = COPS[i], tx = P.mode === "car" ? taxi.x : P.x, tz = P.mode === "car" ? taxi.z : P.z, d = Math.hypot(c.x - tx, c.z - tz); c.t += dt;
      if (d > 160 || (WANTED === 0 && c.t > 8)) { removeActor(c.a); COPS.splice(i, 1); continue; }
      if (c.stun > 0) c.stun -= dt;
      else if (c.st === "ko") { if (c.t > 7) { c.st = "getup"; c.t = 0; c.a.play("GetUp", { once: true, restart: true }); } }
      else if (c.st === "getup") { if (c.t > 2.2) { c.st = "chase"; c.hp = 3; } }
      else if (WANTED === 0) { moveFree(c, c.x + (c.x - tx), c.z + (c.z - tz), 1.4, dt); c.a.play("Walk"); }
      else {
        if (d < 65 && !INSIDE) lastSeen = now2;
        if (P.mode === "car") {
          if (d < 2.4 && Math.abs(taxi.v) > 4) { c.st = "ko"; c.t = 0; c.hp = 0; c.a.play("KnockOut", { once: true, restart: true }); setWanted(WANTED + 1, "You hit an officer"); }
          else if (d < 3 && Math.abs(taxi.v) < 1) { c.grab += dt; c.a.play("Interact"); if (c.grab > 2) { busted(); return; } }
          else { c.grab = 0; moveFree(c, tx, tz, 4.0, dt); c.a.play("Jog"); }
        } else if (d > 1.25) { c.grab = Math.max(0, c.grab - dt); moveFree(c, tx, tz, 3.9, dt); c.a.play("Jog"); }
        else { c.face = Math.atan2(tx - c.x, tz - c.z); c.grab += dt; c.a.play("Interact"); if (c.grab > 1.1 && !INSIDE) { busted(); return; } }
      }
      c.a.g.position.set(c.x, 0.105, c.z); if (c.face !== undefined) c.a.g.rotation.y = c.face;
    }
    for (var j = PCARS.length - 1; j >= 0; j--) {
      var pc = PCARS[j], gx = P.mode === "car" ? taxi.x : P.x, gz = P.mode === "car" ? taxi.z : P.z, dd = Math.hypot(gx - pc.x, gz - pc.z);
      if (WANTED === 0 || dd > 260) { dropPoliceCar(pc); continue; }
      if (dd < 60) lastSeen = now2;
      var want2 = Math.atan2(-(gz - pc.z), gx - pc.x), dy = ((want2 - pc.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
      pc.yaw += clamp(dy, -1.6 * dt, 1.6 * dt);
      var tv = dd < 9 ? 0 : Math.min(20, 6 + dd * 0.2); pc.v += (tv - pc.v) * Math.min(1, dt * 1.5);
      var np = { x: pc.x + Math.cos(pc.yaw) * pc.v * dt, z: pc.z - Math.sin(pc.yaw) * pc.v * dt }, q = { x: np.x, z: np.z };
      if (CITY) CITY.collide(q, 1.3); collide(q, 1.1); if (Math.hypot(q.x - np.x, q.z - np.z) > 0.01) pc.v *= 0.6;
      if (deepWater(q.x, q.z)) { pc.v *= 0.2; } else { pc.x = q.x; pc.z = q.z; }
      pc.m.position.set(pc.x, 0.02 + groundY(pc.x, pc.z), pc.z); pc.m.rotation.y = pc.yaw; pc.m.userData.wheels.forEach(function (w) { w.rotation.z -= pc.v * dt / pc.m.userData.r; });
      if (P.mode === "car" && dd < 7 && Math.abs(taxi.v) < 1.5) { pc.close += dt; if (pc.close > 2.5) { busted(); return; } } else pc.close = Math.max(0, pc.close - dt);
      if (P.mode === "walk" && dd < 14 && pc.v < 1 && COPS.length < 6) { var a2 = makeActor("officer"); COPS.push({ a: a2, x: pc.x + 1.5, z: pc.z + 1.5, hp: 4, st: "chase", t: 0, grab: 0 }); dropPoliceCar(pc); }
    }
    /* flashing light bars */
    var fl = Math.floor(now2 / 200) % 2; if (PCARS.length) { polRedM.emissiveIntensity = fl ? 1.8 : 0.12; polBlueM.emissiveIntensity = fl ? 0.12 : 1.8; } else if (polRedM.emissiveIntensity !== 1) { polRedM.emissiveIntensity = 1; polBlueM.emissiveIntensity = 1; }
  }

  function startCity() {
    CITY = World.create({ scene: scene, base: cityBase, code: SERVER ? G.city : "UTR", ox: CITY_OX, oz: CITY_OZ, aniso: renderer.capabilities.getMaxAnisotropy(), onTile: drawTileOnMap, style: { brick: 0.45 } });
    return CITY.load(function (j) { $("lmsg").textContent = "BUILDING THE REAL MAP OF " + CITY_NAME.toUpperCase() + " \u00b7 " + Math.round((j.progress || 0) * 100) + "%"; $("lbar").style.width = Math.round((j.progress || 0) * 100) + "%"; }).then(function (m) {
      cityHalf = m.half;
      return fetch(cityBase + "/overview.json").then(function (r) { return r.json(); }).catch(function () { return { r: [], w: [], g: [], poi: [] }; });
    }).then(function (ov) {
      cityOV = ov; buildWater(ov); drawOverview(ov); assignPlaces(ov);
      if (!G.arrival && !(G.trip && (G.trip.stage === "boarded" || G.trip.stage === "inflight")) && !G.pos) { P.x = CITY_OX; P.z = CITY_OZ; }
      if (G.pos && !G.arrival) { P.x = G.pos[0]; P.z = G.pos[1]; }
      CITY.update(P.x, P.z, 650);
      return new Promise(function (res) {
        var t0 = performance.now(), iv = setInterval(function () {
          $("lmsg").textContent = "LOADING REAL STREETS · " + CITY.loaded() + " BLOCKS";
          pickHome();
          if ((CITY.loaded() > 6 && CITY.pending() < 6 && HOME) || performance.now() - t0 > 25000) { clearInterval(iv); pickHome(); if (HOME && !G.pos && !G.arrival) { resolveDoors(); var rd = CITY.nearestRoad(HOME.x, HOME.z, 200); P.x = HOME.x; P.z = HOME.z; if (rd) { P.yaw = Math.atan2(rd.x - HOME.x, rd.z - HOME.z); } cam.yaw = P.yaw + Math.PI; } cityReady = true; if (CITY.hit(P.x, P.z, 0.3)) unstick(false); setTimeout(function () { buildVCOL(); if (!vcolIv) vcolIv = setInterval(buildVCOL, 20000);
            CARS.forEach(function (c) { if (c.dir || c.city || !c.m || c.m.userData.boat || c.m.userData.air || c.jacked) return; var yw = c.yaw !== undefined ? c.yaw : (c.dir > 0 ? 0 : Math.PI); if (!carFreeAt(c.m, c.x, c.z, yw)) { var f2 = findCarSpot(c.m, c.x, c.z, yw); c.x = f2[0]; c.z = f2[1]; c.yaw = f2[2]; c.m.position.x = c.x; c.m.position.z = c.z; c.m.rotation.y = c.yaw; } });
            if (P.mode !== "car" && !carFreeAt(taxi.m, taxi.x, taxi.z, taxi.yaw)) { var fs = findCarSpot(taxi.m, taxi.x, taxi.z, taxi.yaw); taxi.x = fs[0]; taxi.z = fs[1]; taxi.yaw = fs[2]; taxi.m.position.set(taxi.x, taxi.m.position.y, taxi.z); taxi.m.rotation.y = taxi.yaw; } }, 400); res(); }
        }, 250);
      });
    }).catch(function (e) { console.error(e); toast("City map could not load"); });
  }

  /* ================= Interiors: go inside real buildings to work, shop, eat and live ================= */
  var INSIDE = null, INT = {}, intSlot = 0;
  var IM = {
    oak: new THREE.MeshStandardMaterial({ color: 0x9c7048, roughness: 0.55 }), walnut: new THREE.MeshStandardMaterial({ color: 0x5b3d26, roughness: 0.5 }),
    tileF: new THREE.MeshStandardMaterial({ map: canvasTex(256, 256, function (g, w, h) { g.fillStyle = "#a9a59c"; g.fillRect(0, 0, w, h); g.strokeStyle = "#8b877e"; g.lineWidth = 2; for (var i = 0; i <= w; i += 64) { g.beginPath(); g.moveTo(i, 0); g.lineTo(i, h); g.stroke(); g.beginPath(); g.moveTo(0, i); g.lineTo(w, i); g.stroke(); } }, true), roughness: 0.3 }),
    woodF: new THREE.MeshStandardMaterial({ map: canvasTex(256, 256, function (g, w, h) { for (var i = 0; i < 16; i++) { g.fillStyle = ["#8a6240", "#7d5636", "#94693f", "#83603b"][i % 4]; g.fillRect(0, i * 16, w, 16); g.fillStyle = "rgba(0,0,0,0.18)"; g.fillRect(0, i * 16, w, 1); g.fillRect((i * 97) % w, i * 16, 1, 16); } }, true), roughness: 0.5 }),
    carpet: new THREE.MeshStandardMaterial({ color: 0x3d4757, roughness: 1 }),
    wallW: new THREE.MeshStandardMaterial({ color: 0xb9b1a4, roughness: 0.9 }), wallG: new THREE.MeshStandardMaterial({ color: 0x9fb2ad, roughness: 0.9 }), wallB: new THREE.MeshStandardMaterial({ color: 0x23313f, roughness: 0.8 }),
    fabricG: new THREE.MeshStandardMaterial({ color: 0x5f6b73, roughness: 1 }), fabricR: new THREE.MeshStandardMaterial({ color: 0x8a3a2a, roughness: 1 }), white: new THREE.MeshStandardMaterial({ color: 0xd8d6d0, roughness: 0.4 }),
    steel: new THREE.MeshStandardMaterial({ color: 0xb8bec4, roughness: 0.25, metalness: 0.85 }), black: new THREE.MeshStandardMaterial({ color: 0x15171a, roughness: 0.4 }),
    screen: new THREE.MeshStandardMaterial({ color: 0x0b1a2a, emissive: 0x3a7fc4, emissiveIntensity: 0.6, roughness: 0.2 }), glass: new THREE.MeshStandardMaterial({ color: 0x9fc4d6, transparent: true, opacity: 0.35, roughness: 0.1 }),
    green: new THREE.MeshStandardMaterial({ color: 0x3f7a3a, roughness: 0.9, flatShading: true }), neon: M.neon
  };
  var PRODUCT = ["#d94a3a", "#f2c230", "#3a7fd9", "#4ab04a", "#f28c30", "#e9e6df", "#8a3ad9", "#2bb3a8"].map(function (c) { return new THREE.MeshStandardMaterial({ color: c, roughness: 0.6 }); });
  function ib(w, h, d, mat, x, y, z, solidIt, ry) { var m = box(w, h, d, mat, x, y, z); if (ry) m.rotation.y = ry; if (solidIt) { var hw = ry ? d / 2 : w / 2, hd = ry ? w / 2 : d / 2; solid(x - hw, x + hw, z - hd, z + hd, "furn"); } return m; }
  function chair(x, z, ry, mat) { ib(0.5, 0.06, 0.5, mat || IM.black, x, 0.46, z, false); ib(0.5, 0.55, 0.06, mat || IM.black, x - Math.sin(ry) * 0.24, 0.75, z - Math.cos(ry) * 0.24, false, ry); ib(0.06, 0.44, 0.06, IM.steel, x, 0.22, z, false); }
  function desk(x, z, ry) { ib(1.5, 0.05, 0.75, IM.oak, x, 0.75, z, true, ry); ib(0.05, 0.72, 0.7, IM.steel, x - 0.7, 0.37, z, false, ry); ib(0.05, 0.72, 0.7, IM.steel, x + 0.7, 0.37, z, false, ry); var s = ib(0.62, 0.38, 0.04, IM.screen, x, 1.1, z - 0.22, false, ry); ib(0.05, 0.3, 0.05, IM.black, x, 0.88, z - 0.24); ib(0.45, 0.02, 0.15, IM.black, x, 0.78, z + 0.05); return s; }
  function shelf(x, z, w, ry) { ib(w, 2, 0.5, IM.white, x, 1, z, true, ry); for (var s = 0; s < 4; s++) for (var i = 0; i < Math.floor(w / 0.22); i++) { var p = PRODUCT[(i * 3 + s * 5 + Math.floor(x * 7)) % PRODUCT.length]; var dx = -w / 2 + 0.15 + i * 0.22; ib(0.16, 0.24 + (i % 3) * 0.04, 0.2, p, x + (ry ? 0 : dx), 0.35 + s * 0.45, z + (ry ? dx : 0.18), false); } }
  function plant(x, z) { ib(0.45, 0.45, 0.45, IM.walnut, x, 0.22, z, true); var c = new THREE.Mesh(new THREE.IcosahedronGeometry(0.55, 1), IM.green); c.position.set(x, 1.05, z); c.castShadow = true; scene.add(c); }
  function bed(x, z, ry, big) { var w = big ? 1.9 : 1.1; ib(w, 0.4, 2.1, IM.walnut, x, 0.2, z, true, ry); ib(w - 0.1, 0.2, 2, IM.white, x, 0.5, z, false, ry); ib(w - 0.1, 0.12, 1.2, big ? IM.fabricR : IM.fabricG, x, 0.62, z + 0.35, false, ry); ib(w, 1, 0.12, IM.walnut, x, 0.6, z - 1.05, false, ry); ib(0.5, 0.14, 0.32, IM.white, x - (big ? 0.45 : 0), 0.66, z - 0.75); if (big) ib(0.5, 0.14, 0.32, IM.white, x + 0.45, 0.66, z - 0.75); }
  function sofa(x, z, ry, mat) { ib(2.2, 0.45, 0.56, mat || IM.fabricG, x, 0.25, z, true, ry); ib(2.2, 0.55, 0.2, mat || IM.fabricG, x - Math.sin(ry) * 0.38, 0.7, z - Math.cos(ry) * 0.38, true, ry); ib(0.18, 0.62, 0.76, mat || IM.fabricG, x + Math.cos(ry) * 1.1, 0.31, z - Math.sin(ry) * 1.1 - Math.cos(ry) * 0.1, false, ry); ib(0.18, 0.62, 0.76, mat || IM.fabricG, x - Math.cos(ry) * 1.1, 0.31, z + Math.sin(ry) * 1.1 - Math.cos(ry) * 0.1, false, ry); }
  function tv(x, z, ry) { ib(1.8, 0.5, 0.45, IM.walnut, x, 0.25, z, true, ry); ib(1.5, 0.85, 0.06, IM.screen, x, 1.05, z, false, ry); }
  function kitchen(x, z, w) { ib(w, 0.9, 0.65, IM.white, x, 0.45, z, true); ib(w, 0.04, 0.68, IM.black, x, 0.92, z); ib(0.6, 0.04, 0.5, IM.steel, x - w / 2 + 0.6, 0.95, z); ib(0.7, 1.9, 0.65, IM.steel, x + w / 2 + 0.4, 0.95, z, true); ib(w, 0.7, 0.35, IM.white, x, 1.9, z - 0.15); }
  function counter(x, z, w, ry) { ib(w, 1.05, 0.7, IM.walnut, x, 0.52, z, true, ry); ib(w + 0.05, 0.05, 0.78, IM.black, x, 1.07, z, false, ry); }
  function chalkBoard(x, z, w) { ib(w, 1.2, 0.05, new THREE.MeshStandardMaterial({ color: 0x24402e, roughness: 0.9 }), x, 1.7, z); }
  /* where to stand so the Sit animation lands the hips on the seat (it moves the hips 0.245 m back) */
  function sitSpot(cx, cz, yaw, back) { var f = 0.245 - (back - 0.12); return { x: cx + Math.sin(yaw) * f, z: cz + Math.cos(yaw) * f }; }
  function sitNpc(kind, cx, cz, yaw, anim, back) { var p = sitSpot(cx, cz, yaw, back || 0.21); return npc(kind, p.x, p.z, yaw, anim); }
  function npc(kind, x, z, yaw, anim) { var a = makeActor(kind); a.g.position.set(x, 0.035, z); a.g.rotation.y = yaw; a.play(anim || "Idle"); staticNpcs.push(a); return a; }
  function signboard(text, x, y, z, ry) { sign(text, 4, 0.55, x, y, z, ry, { bg: "#0b0d0b", fg: "#ff3d8b", size: 70, w: 1024, h: 140 }); }

  /* the room shell: floor, four walls with a doorway on the south wall */
  function shellRoom(o, W, D, floor, wall, title) {
    var x0 = o.x, z0 = o.z, t = 0.2, H = 3.2, walls = [];
    plane(W, D, floor, x0, 0.03, z0);
    walls.push(box(W, H, t, wall, x0, H / 2, z0 - D / 2));
    walls.push(box(t, H, D, wall, x0 - W / 2, H / 2, z0));
    walls.push(box(t, H, D, wall, x0 + W / 2, H / 2, z0));
    walls.push(box(W / 2 - 0.8, H, t, wall, x0 - W / 4 - 0.4, H / 2, z0 + D / 2));
    walls.push(box(W / 2 - 0.8, H, t, wall, x0 + W / 4 + 0.4, H / 2, z0 + D / 2));
    walls.push(box(1.6, H - 2.4, t, wall, x0, H - (H - 2.4) / 2, z0 + D / 2));
    solid(x0 - W / 2 - 0.2, x0 + W / 2 + 0.2, z0 - D / 2 - 0.2, z0 - D / 2 + 0.1, "wall"); solid(x0 - W / 2 - 0.2, x0 - W / 2 + 0.1, z0 - D / 2, z0 + D / 2, "wall"); solid(x0 + W / 2 - 0.1, x0 + W / 2 + 0.2, z0 - D / 2, z0 + D / 2, "wall");
    solid(x0 - W / 2, x0 - 0.8, z0 + D / 2 - 0.1, z0 + D / 2 + 0.2, "wall"); solid(x0 + 0.8, x0 + W / 2, z0 + D / 2 - 0.1, z0 + D / 2 + 0.2, "wall"); solid(x0 - 1.2, x0 + 1.2, z0 + D / 2 + 0.6, z0 + D / 2 + 0.9, "wall");
    room(x0 - W / 2, x0 + W / 2, z0 - D / 2, z0 + D / 2 + 1, walls);
    var mat = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.9), IM.neon); mat.rotation.x = -Math.PI / 2; mat.position.set(x0, 0.04, z0 + D / 2 - 0.5); scene.add(mat);
    if (title) signboard(title.toUpperCase(), x0, 2.6, z0 - D / 2 + 0.12, 0);
    return { exit: { x: x0, z: z0 + D / 2 - 0.6 }, W: W, D: D };
  }
  /* zone helpers: move an existing zone (with its job data) to a spot inside, or add a new one */
  function zoneAt(id, x, z, face, r) { var f = null; ZONES.forEach(function (q) { if (q.id === id) f = q; }); if (!f) { f = { id: id, x: x, z: z, r: r || 1.4 }; ZONES.push(f); } f.x = x; f.z = z; f.r = r || 1.4; f.face = face; return f; }

  var INT_BUILD = {
    office: function (o, pl, job) {
      var s = shellRoom(o, 16, 12, IM.carpet, IM.wallW, pl.name);
      for (var r = 0; r < 2; r++) for (var c = 0; c < 4; c++) { var x = o.x - 5.4 + c * 3.6, z = o.z - 3 + r * 3.6; desk(x, z, 0); chair(x, z + 0.75, Math.PI); if (!(r === 1 && c === 1)) sitNpc(null, x, z + 0.75, Math.PI, Math.random() < 0.5 ? "Sit" : "SitTalk"); }
      plant(o.x - 7.2, o.z - 5.2); plant(o.x + 7.2, o.z - 5.2);
      var os = sitSpot(o.x - 1.8, o.z + 1.35, Math.PI, 0.21); zoneAt(job, o.x - 1.8, o.z + 1.75, Math.PI, 1.2).seat = { x: os.x, z: os.z, yaw: Math.PI, anim: "Sit" };
      return s;
    },
    bank: function (o, pl, job) {
      var s = shellRoom(o, 16, 12, IM.tileF, IM.wallG, pl.name);
      counter(o.x, o.z - 2.5, 10); for (var i = 0; i < 4; i++) { ib(0.04, 0.6, 0.7, IM.glass, o.x - 4 + i * 2.6, 1.4, o.z - 2.5); }
      npc(null, o.x - 3, o.z - 3.4, 0, "Talk"); npc(null, o.x + 3, o.z - 3.4, 0, "Interact"); npc(null, o.x, o.z - 1.6, Math.PI, "Idle"); npc(null, o.x + 3, o.z - 1.6, Math.PI, "Talk");
      ib(0.9, 1.8, 0.5, IM.steel, o.x + 7.2, 0.9, o.z + 2, true); plant(o.x - 7.2, o.z + 4);
      zoneAt(job, o.x - 0.2, o.z - 3.4, 0, 1.2);
      var vd = new THREE.Mesh(new THREE.CylinderGeometry(1.15, 1.15, 0.35, 32), IM.steel); vd.rotation.x = Math.PI / 2; vd.position.set(o.x + 6, 1.3, o.z - 5.78); scene.add(vd);
      for (var sp2 = 0; sp2 < 3; sp2++) { var bar = ib(1.6, 0.08, 0.08, IM.black, o.x + 6, 1.3, o.z - 5.55, false); bar.rotation.z = sp2 * Math.PI / 3; }
      sign("VAULT", 2.2, 0.4, o.x + 6, 2.75, o.z - 5.88, 0, { size: 80, w: 512, h: 96 });
      zoneAt("vaultDoor", o.x + 6, o.z - 4.4, 0, 1.3);
      return s;
    },
    hotel: function (o, pl, job) {
      var s = shellRoom(o, 16, 12, IM.woodF, IM.wallW, pl.name);
      counter(o.x - 3, o.z - 3, 5); sofa(o.x + 4, o.z + 2, Math.PI, IM.fabricR); sofa(o.x + 4, o.z - 1.5, 0, IM.fabricR); ib(1.2, 0.4, 0.8, IM.walnut, o.x + 4, 0.2, o.z + 0.3, true);
      npc(null, o.x - 1.6, o.z - 3.8, 0, "Talk"); sitNpc(null, o.x + 3.5, o.z + 2, Math.PI, "Sit", 0.28); plant(o.x - 7, o.z + 4.5); plant(o.x + 7, o.z - 5);
      zoneAt(job, o.x - 3.8, o.z - 3.8, 0, 1.2);
      return s;
    },
    restaurant: function (o, pl, job) {
      var s = shellRoom(o, 16, 12, IM.woodF, IM.wallW, pl.name);
      kitchen(o.x - 2, o.z - 5.3, 8); counter(o.x - 2, o.z - 3.6, 8);
      for (var i = 0; i < 3; i++) { var tx = o.x - 5 + i * 4, tz = o.z + 1.6; ib(1.1, 0.05, 1.1, IM.oak, tx, 0.75, tz, true); ib(0.08, 0.72, 0.08, IM.steel, tx, 0.37, tz); chair(tx - 0.85, tz, Math.PI / 2); chair(tx + 0.85, tz, -Math.PI / 2); if (i !== 1) sitNpc(null, tx + 0.85, tz, -Math.PI / 2, "Eat"); }
      npc(null, o.x - 4, o.z - 4.6, 0, "Interact");
      zoneAt(job, o.x + 0.5, o.z - 4.6, 0, 1.2);
      var ds = sitSpot(o.x - 1.85, o.z + 1.6, Math.PI / 2, 0.21), ez = zoneAt("diner", o.x - 2.3, o.z + 1.6, Math.PI / 2, 1.2); ez.seat = { x: ds.x, z: ds.z, yaw: Math.PI / 2, anim: "Eat" };
      return s;
    },
    cafe: function (o, pl, job) {
      var s = shellRoom(o, 14, 10, IM.woodF, IM.wallW, pl.name);
      counter(o.x - 1, o.z - 2.6, 6); ib(0.6, 0.6, 0.5, IM.steel, o.x - 3, 1.35, o.z - 2.6); ib(0.6, 0.6, 0.5, IM.steel, o.x - 2.2, 1.35, o.z - 2.6);
      for (var i = 0; i < 3; i++) { var tx = o.x - 4 + i * 3.5, tz = o.z + 1.8; ib(0.8, 0.05, 0.8, IM.oak, tx, 0.75, tz, true); chair(tx, tz + 0.7, Math.PI); if (i !== 2) sitNpc(null, tx, tz + 0.7, Math.PI, i ? "SitTalk" : "Sit"); }
      zoneAt(job, o.x - 1, o.z - 3.4, 0, 1.2);
      return s;
    },
    shop: function (o, pl, job) {
      var s = shellRoom(o, 18, 14, IM.tileF, IM.wallW, pl.name);
      for (var i = 0; i < 4; i++) shelf(o.x - 6 + i * 3, o.z - 1.5, 4.6, Math.PI / 2);
      shelf(o.x, o.z - 6.4, 14, 0); counter(o.x + 6, o.z + 3.5, 3, 0);
      npc(null, o.x + 6, o.z + 2.6, Math.PI, "Interact"); npc(null, o.x - 4.5, o.z, Math.PI / 2, "PickUp"); npc(null, o.x + 1.5, o.z + 1, -Math.PI / 2, "Idle");
      zoneAt("grocery", o.x + 6, o.z + 4.4, Math.PI, 1.3);
      zoneAt(job, o.x - 1.5, o.z - 5.6, 0, 1.2);
      return s;
    },
    hospital: function (o, pl, job) {
      var s = shellRoom(o, 18, 12, IM.tileF, IM.wallG, pl.name);
      for (var i = 0; i < 4; i++) { bed(o.x - 6 + i * 4, o.z - 3.4, 0, false); ib(0.05, 2.2, 2.6, IM.fabricG, o.x - 4 + i * 4, 1.1, o.z - 3.4); npc(null, o.x - 6 + i * 4, o.z - 3.6, 0, i % 2 ? "Sit" : "Idle"); }
      counter(o.x + 5, o.z + 2.5, 4); npc(null, o.x + 5, o.z + 1.7, Math.PI, "Talk");
      zoneAt(job, o.x - 4, o.z - 1.7, Math.PI, 1.2);
      return s;
    },
    school: function (o, pl, job) {
      var s = shellRoom(o, 14, 12, IM.woodF, IM.wallW, pl.name);
      chalkBoard(o.x, o.z - 5.85, 6);
      for (var r = 0; r < 3; r++) for (var c = 0; c < 4; c++) { var x = o.x - 4.5 + c * 3, z = o.z - 1.5 + r * 2.2; ib(1, 0.05, 0.6, IM.oak, x, 0.72, z, true); chair(x, z + 0.55, Math.PI); sitNpc(null, x, z + 0.55, Math.PI, (r + c) % 3 ? "Sit" : "SitTalk"); }
      zoneAt(job, o.x, o.z - 4.6, 0, 1.2);
      return s;
    },
    cityhall: function (o, pl) {
      var s = shellRoom(o, 16, 12, IM.tileF, IM.wallW, pl.name);
      counter(o.x, o.z - 3, 8); npc("officer", o.x - 2, o.z - 3.9, 0, "Talk"); npc("officer", o.x + 2, o.z - 3.9, 0, "Interact");
      ib(0.05, 2.2, 0.05, IM.steel, o.x - 6, 1.1, o.z - 5); var fl = ib(1.2, 0.7, 0.02, new THREE.MeshStandardMaterial({ color: 0x3a5a8c }), o.x - 5.4, 1.9, o.z - 5);
      zoneAt("cityhall", o.x, o.z - 2.2, Math.PI, 1.4);
      return s;
    },
    agency: function (o, pl) {
      var s = shellRoom(o, 16, 12, IM.carpet, IM.wallW, "Global Travel");
      [-4.6, 0, 4.6].forEach(function (dx, i) {
        desk(o.x + dx, o.z - 2.6, 0); chair(o.x + dx, o.z - 3.4, 0); sitNpc(i === 1 ? "woman" : null, o.x + dx, o.z - 3.4, 0, i === 1 ? "SitTalk" : "Sit");
        chair(o.x + dx, o.z - 1.7, Math.PI); if (i !== 1) sitNpc(null, o.x + dx, o.z - 1.7, Math.PI, "SitTalk");
        sign("DESK " + (i + 1), 1.2, 0.3, o.x + dx, 1.9, o.z - 2.95, 0, { bg: "#0d2a4a", fg: "#ffffff", size: 70, w: 384, h: 96 });
      });
      zoneAt("agency", o.x, o.z - 1.0, Math.PI, 1.3);
      [["PARIS", "#ff8a65", "#5e35b1"], ["TOKYO", "#f06292", "#1a237e"], ["DUBAI", "#ffd54f", "#e65100"], ["LONDON", "#90caf9", "#37474f"]].forEach(function (pc, i) {
        var side = i < 2 ? -1 : 1, pz = o.z - 2 + (i % 2) * 3.4, m = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 1.95), new THREE.MeshStandardMaterial({ map: posterTex(pc[0], pc[1], pc[2]), roughness: 0.5 }));
        m.position.set(o.x + side * (8 - 0.12), 1.75, pz); m.rotation.y = -side * Math.PI / 2; scene.add(m);
      });
      sign(function () { return "NOW SERVING  A-" + String(1 + Math.floor(Date.now() / 45000) % 60).padStart(2, "0"); }, 3.2, 0.5, o.x - 5.6, 2.55, o.z - 5.88, 0, { bg: "#000", fg: "#ffcf5a", size: 64, w: 1024, h: 160 });
      [-6.2, -5.5, -4.8, -4.1, 4.1, 4.8, 5.5, 6.2].forEach(function (dx) { var cz = o.z + 3.4; chair(o.x + dx, cz, Math.PI); var sp = sitSpot(o.x + dx, cz, Math.PI, 0.21); ZONES.push({ id: "sit", x: o.x + dx, z: cz - 0.6, r: 0.6, seat: { x: sp.x, z: sp.z, yaw: Math.PI, anim: "Sit" } }); });
      solid(o.x - 6.5, o.x - 3.8, o.z + 3.2, o.z + 3.7); solid(o.x + 3.8, o.x + 6.5, o.z + 3.2, o.z + 3.7);
      var globe = new THREE.Mesh(new THREE.SphereGeometry(0.45, 24, 16), new THREE.MeshStandardMaterial({ color: 0x3a8ee6, roughness: 0.4 })); globe.position.set(o.x - 6.8, 1.35, o.z - 4.6); scene.add(globe); ib(0.5, 0.9, 0.5, IM.walnut, o.x - 6.8, 0.45, o.z - 4.6, true);
      return s;
    },
    police: function (o, pl) { var s = shellRoom(o, 12, 10, IM.tileF, IM.wallB, pl.name); counter(o.x, o.z - 2, 5); npc("officer", o.x, o.z - 2.8, 0, "Talk"); zoneAt("police", o.x, o.z - 1.2, Math.PI, 1.4); return s; },
    home: function (o, pl) {
      var tier = HOME ? HOME.tier : 0, big = tier >= 2, W = [10, 14, 18, 22][tier], D = [8, 11, 13, 15][tier];
      var s = shellRoom(o, W, D, tier >= 1 ? IM.woodF : IM.carpet, tier === 3 ? IM.wallB : IM.wallW, null);
      bed(o.x - W / 2 + 1.6, o.z - D / 2 + 1.4, 0, big); sofa(o.x + 1, o.z + 0.6, Math.PI, tier === 3 ? IM.fabricR : IM.fabricG); tv(o.x + 1, o.z - D / 2 + 0.5, 0);
      kitchen(o.x + W / 2 - 2.6, o.z + D / 2 - 1.2, Math.min(4, W / 3)); plant(o.x - W / 2 + 0.6, o.z + D / 2 - 0.8);
      if (tier >= 1) { ib(1.4, 0.05, 0.9, IM.oak, o.x - 1.5, 0.75, o.z + 2.2, true); chair(o.x - 1.5, o.z + 2.9, Math.PI); }
      if (tier >= 2) { plant(o.x + W / 2 - 0.6, o.z - D / 2 + 0.6); ib(2.4, 1.8, 0.35, IM.walnut, o.x - W / 2 + 0.3, 0.9, o.z + 1, true, Math.PI / 2); }
      if (tier === 3) { for (var i = 0; i < 4; i++) ib(2.2, 2.4, 0.06, IM.glass, o.x - W / 2 + 2 + i * 2.4, 1.6, o.z - D / 2 + 0.15); var pool = plane(4, 2.2, new THREE.MeshStandardMaterial({ color: 0x2aa6c9, roughness: 0.05, metalness: 0.3 }), o.x + W / 2 - 3, 0.05, o.z - 1); }
      var hs = sitSpot(o.x + 1, o.z + 0.6, Math.PI, 0.28), rz = zoneAt("homeSofa", o.x + 1, o.z - 0.3, Math.PI, 1.3); rz.seat = { x: hs.x, z: hs.z, yaw: Math.PI, anim: "Sit" };
      zoneAt("homeBed", o.x - W / 2 + 1.6, o.z - D / 2 + 3, Math.PI, 1.3);
      zoneAt("homeFridge", o.x + W / 2 - 2.6, o.z + D / 2 - 2.1, 0, 1.3);
      return s;
    }
  };
  var PLACE_INT = { grocery: ["shop", "job:mart"], agency: ["agency"], cityhall: ["cityhall"], work: ["office", "job:office"], bank: ["bank", "job:bank"], hotel: ["hotel", "job:hotel"], diner: ["restaurant", "job:diner"], hospital: ["hospital", "job:hospital"], school: ["school", "job:school"], cafe: ["cafe", "job:cafe"], tech: ["office", "job:tech"], police: ["police"], home: ["home"] };
  function buildInterior(id) {
    if (INT[id]) return INT[id];
    var spec = PLACE_INT[id], pl = id === "home" ? HOME : cityPlaces[id];
    var o = { x: 6000 + (intSlot % 4) * 60, z: -300 + Math.floor(intSlot / 4) * 60 }; intSlot++;
    var r = INT_BUILD[spec[0]](o, { name: pl ? pl.name : id }, spec[1]);
    try { dressInterior(spec[0], o, r); } catch (e) {}
    r.exitZone = zoneAt("exit:" + id, r.exit.x, r.exit.z, 0, 1.2); r.o = o; INT[id] = r; return r;
  }
  function enterPlace(id) {
    var pl = id === "home" ? HOME : cityPlaces[id]; if (!pl) return;
    var r = buildInterior(id);
    fadeTo(function () {
      INSIDE = { id: id, ret: { x: pl.x, z: pl.z, yaw: (pl.face || 0) + Math.PI } };
      place(r.exit.x, r.exit.z - 0.8, Math.PI, 0); cam.tdist = 7.5; cam.pitch = 0.85;
      toast(id === "home" ? "Welcome home" : "Inside " + pl.name);
      missionEvent("enter:" + id);
    });
  }
  function leavePlace() {
    if (!INSIDE) return; var ret = INSIDE.ret;
    fadeTo(function () {
      INSIDE = null; if (P.seat) standUp();
      /* step out onto the pavement and frame the street, not the wall we just came out of */
      var ox = ret.x + Math.sin(ret.yaw) * 3, oz = ret.z + Math.cos(ret.yaw) * 3; if (CITY && !freeAt(ox, oz)) { ox = ret.x; oz = ret.z; }
      place(ox, oz, ret.yaw, ret.yaw + Math.PI * 0.72); cam.tdist = 6; cam.dist = 6; cam.pitch = 0.34;
      if (CITY && !freeAt(ox, oz)) setTimeout(function () { unstick(false); }, 120);
    });
  }
  function fadeTo(fn) { var f = $("fade"); f.classList.add("on"); setTimeout(function () { fn(); setTimeout(function () { f.classList.remove("on"); }, 250); }, 450); }
  function place(x, z, yaw, cy) { if (P.fall) endFall(); if (P.lv && TOWER) TOWER.leave(); P.lv = null; P.x = x; P.z = z; P.yaw = yaw; cam.yaw = cy; camera.position.set(x + Math.sin(cy) * 5, 3.5, z + Math.cos(cy) * 5); }
  /* dark backdrop around the interior area so rooms do not float in the sky */
  (function () { var bd = new THREE.Mesh(new THREE.BoxGeometry(420, 60, 420), new THREE.MeshBasicMaterial({ color: 0x0b0e12, side: THREE.BackSide, fog: false })); bd.position.set(6090, 20, -210); scene.add(bd); plane(420, 420, new THREE.MeshStandardMaterial({ color: 0x15181c, roughness: 1 }), 6090, -0.01, -210); })();
  /* ---- never get stuck: find open ground (preferably a street) and move the player there ---- */
  var stuckT = 0;
  function freeAt(a, b) { if (CITY && CITY.hit(a, b, 0.55)) return false; var q = { x: a, z: b }; collide(q, 0.32); return Math.hypot(q.x - a, q.z - b) < 0.05; }
  function trapped() {
    for (var k = 0; k < 8; k++) { var dx = Math.cos(k * Math.PI / 4), dz = Math.sin(k * Math.PI / 4), q = { x: P.x + dx * 1.2, z: P.z + dz * 1.2 }; collide(q, 0.32); if (CITY) CITY.collide(q, 0.34); if ((q.x - P.x) * dx + (q.z - P.z) * dz > 0.6) return false; }
    return true;
  }
  function freeSpot(x, z) {
    var r = CITY ? CITY.nearestRoad(x, z, 400) : null, cs = r ? [[r.x, r.z]] : []; cs.push([x, z]);
    for (var c = 0; c < cs.length; c++) for (var d = 0; d <= 40; d += 1.5) for (var k = 0; k < 12; k++) { var a = cs[c][0] + Math.cos(k * Math.PI / 6) * d, b = cs[c][1] + Math.sin(k * Math.PI / 6) * d; if (freeAt(a, b)) return { x: a, z: b }; if (!d) break; }
    return null;
  }
  function unstick(msg) {
    var f = freeSpot(P.x, P.z); if (!f) return;
    P.x = f.x; P.z = f.z;
    if (msg) toast("Moved you to the street");
  }
  function sitAt(seat) { P.seat = seat; P.x = seat.x; P.z = seat.z; P.yaw = seat.yaw; player.play("SitDown", { once: true, fade: 0.2 }); setTimeout(function () { if (P.seat) player.play(seat.anim || "Sit"); }, 900); }
  function standUp() { P.seat = null; player.play("StandUp", { once: true, fade: 0.2 }); }

  /* ================= Airport cinematics: body scan + passport stamp ================= */
  var camOverride = null, armsUp = 0, SCAN_X = 112, IMM_X = 128;
  var _vA = new THREE.Vector3(), _vB = new THREE.Vector3(), _qW = new THREE.Quaternion(), _qP = new THREE.Quaternion();
  function aimBone(bone, child, dir, w) {
    if (!bone || !child) return;
    bone.getWorldPosition(_vA); child.getWorldPosition(_vB);
    var cur = _vB.sub(_vA).normalize(), sw = new THREE.Quaternion().setFromUnitVectors(cur, dir), id = new THREE.Quaternion(); sw.slerp(id, 1 - w);
    bone.getWorldQuaternion(_qW); var nw = sw.multiply(_qW); bone.parent.getWorldQuaternion(_qP); bone.quaternion.copy(_qP.invert().multiply(nw)); bone.updateMatrixWorld(true);
  }
  function poseArmsUp(a, w) {
    if (w <= 0.01) return; a.g.updateMatrixWorld(true); var q = a.g.quaternion, b = a.bones;
    [["l", 1], ["r", -1]].forEach(function (s) {
      var up = new THREE.Vector3(s[1] * 0.55, 0.83, 0.05).applyQuaternion(q).normalize(), fo = new THREE.Vector3(s[1] * 0.12, 0.99, 0.05).applyQuaternion(q).normalize();
      aimBone(b["upperarm_" + s[0]], b["lowerarm_" + s[0]], up, w); aimBone(b["lowerarm_" + s[0]], b["hand_" + s[0]], fo, w);
    });
  }
  function bodyScan(done) {
    sfx("scanStart"); var done0 = done; done = function () { sfx("scanEnd"); if (done0) done0.apply(this, arguments); };
    document.body.classList.add("cinema"); P.x = SCAN_X; P.z = 0.05; P.yaw = -Math.PI / 2;
    camOverride = { pos: new THREE.Vector3(SCAN_X - 3.4, 1.6, 0.6), look: new THREE.Vector3(SCAN_X, 1.15, 0) };
    var hud = $("scanhud"); hud.hidden = false; $("scanT").textContent = "BODY SCAN"; $("scanD").textContent = "Stand still with your arms up"; $("scanBar").style.width = "0%";
    var t0 = performance.now(), dur = 3600;
    scanFlash = t0; scanSweep = { t0: t0, dur: dur };
    var iv = setInterval(function () {
      var k = (performance.now() - t0) / dur; armsUp = Math.min(1, k * 4) * (k < 0.9 ? 1 : Math.max(0, (1 - k) * 10));
      $("scanBar").style.width = Math.min(100, k * 100).toFixed(0) + "%";
      if (k >= 1) { clearInterval(iv); armsUp = 0; $("scanT").textContent = "CLEAR ✓"; $("scanD").textContent = "No items found. Have a good flight."; scanSweep = null;
        setTimeout(function () { hud.hidden = true; camOverride = null; document.body.classList.remove("cinema"); P.yaw = Math.PI / 2; cam.yaw = P.yaw + Math.PI; done(); }, 1300); }
    }, 60);
  }
  var scanSweep = null, scanCurtain = (function () { var m = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.08, 2.2), new THREE.MeshBasicMaterial({ color: 0xff3d8b, transparent: true, opacity: 0.85 })); m.visible = false; scene.add(m); var c = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 2.4), new THREE.MeshBasicMaterial({ color: 0xff3d8b, transparent: true, opacity: 0.08, side: THREE.DoubleSide, depthWrite: false })); c.rotation.y = Math.PI / 2; c.visible = false; scene.add(c); return { bar: m, glow: c }; })();
  function tickScan(tm) {
    if (!scanSweep) { scanCurtain.bar.visible = scanCurtain.glow.visible = false; return; }
    var k = (tm - scanSweep.t0) / scanSweep.dur, y = 0.15 + (0.5 - 0.5 * Math.cos(k * Math.PI * 4)) * 2.1;
    scanCurtain.bar.visible = scanCurtain.glow.visible = true; scanCurtain.bar.position.set(SCAN_X, y, 0); scanCurtain.glow.position.set(SCAN_X, 1.2, 0);
  }
  /* passport page with stamps, drawn on a canvas */
  function drawStamp(c, st, x, y, rot, ink) {
    var A = AIR[st.code] || here(), arr = st.kind === "in", col = ink || (arr ? "#1f4fa8" : "#a8231f");
    c.save(); c.translate(x, y); c.rotate(rot); c.strokeStyle = col; c.fillStyle = col; c.globalAlpha = 0.82;
    if (arr) { c.lineWidth = 5; c.beginPath(); c.roundRect ? c.roundRect(-110, -62, 220, 124, 14) : c.rect(-110, -62, 220, 124); c.stroke(); c.lineWidth = 2; c.beginPath(); c.roundRect ? c.roundRect(-100, -52, 200, 104, 10) : c.rect(-100, -52, 200, 104); c.stroke(); }
    else { c.lineWidth = 5; c.beginPath(); c.arc(0, 0, 74, 0, 7); c.stroke(); c.lineWidth = 2; c.beginPath(); c.arc(0, 0, 64, 0, 7); c.stroke(); }
    c.textAlign = "center"; c.textBaseline = "middle";
    c.font = "800 34px 'JetBrains Mono', monospace"; c.fillText(st.code, 0, arr ? -16 : -14);
    c.font = "700 14px 'JetBrains Mono', monospace"; c.fillText((arr ? "ADMITTED" : "DEPARTED") + " · " + (A.country || "").toUpperCase().slice(0, 14), 0, arr ? 14 : 12);
    c.font = "700 15px 'JetBrains Mono', monospace"; c.fillText(st.date || "", 0, arr ? 36 : 32);
    c.font = "800 20px Arial"; c.fillText(arr ? "✈ ←" : "✈ →", 0, arr ? -44 : -44);
    c.globalCompositeOperation = "destination-out"; for (var i = 0; i < 260; i++) { c.globalAlpha = Math.random() * 0.6; c.fillRect(-120 + Math.random() * 240, -80 + Math.random() * 160, 2 + Math.random() * 3, 2 + Math.random() * 3); }
    c.restore();
  }
  function drawPage(c, stamps, upto) {
    var w = 560, h = 760; c.globalCompositeOperation = "source-over"; c.globalAlpha = 1;
    var gr = c.createLinearGradient(0, 0, w, h); gr.addColorStop(0, "#f3ecd8"); gr.addColorStop(1, "#e6dcc0"); c.fillStyle = gr; c.fillRect(0, 0, w, h);
    c.strokeStyle = "rgba(60,90,120,0.10)"; c.lineWidth = 1; for (var i = 0; i < 60; i++) { c.beginPath(); for (var x = 0; x <= w; x += 8) { var y = i * 14 + Math.sin(x / 40 + i) * 6; if (x) c.lineTo(x, y); else c.moveTo(x, y); } c.stroke(); }
    c.fillStyle = "rgba(19,36,74,0.75)"; c.font = "800 18px 'JetBrains Mono', monospace"; c.textAlign = "center"; c.fillText("VISAS  ·  STAMPS", w / 2, 40);
    c.fillStyle = "rgba(19,36,74,0.4)"; c.font = "600 12px 'JetBrains Mono', monospace"; c.fillText("EARTHPASS · " + G.passport.no, w / 2, h - 22);
    stamps.slice(Math.max(0, upto - 6), upto).forEach(function (st, i) { var r = rng(i * 13 + st.t % 997); drawStamp(c, st, 150 + (i % 2) * 260 + (r() - 0.5) * 30, 150 + Math.floor(i / 2) * 200 + (r() - 0.5) * 30, (r() - 0.5) * 0.5); });
  }
  function stampSequence(st, caption, done) {
    var ov = $("stampov"), cv = $("scv"), c = cv.getContext("2d"), list = G.stamps.concat([st]), n = list.length, idx = Math.min(5, n - 1) ;
    drawPage(c, G.stamps, G.stamps.length); ov.hidden = false; $("scap").textContent = "";
    var sp = $("stamper"); sp.classList.remove("go"); void sp.offsetWidth; sp.classList.add("go");
    var pos = Math.min(n, 6) - 1, px = 150 + (pos % 2) * 260, py = 150 + Math.floor(pos / 2) * 200;
    sp.style.left = (px / 560 * 100) + "%"; sp.style.top = (py / 760 * 100) + "%";
    setTimeout(function () { drawPage(c, list, n); var o = $("spage") || ov.querySelector(".spage"); o.style.transform = "rotate(-3deg) translateY(4px)"; setTimeout(function () { o.style.transform = ""; }, 120); $("scap").textContent = caption; }, 680);
    setTimeout(function () { ov.hidden = true; done(); }, 2900);
  }
  /* ================= Cinematic cutscenes (Vice City style camera moves) ================= */
  var CUT = null;
  var DESK = (function () {
    var g = {}, PX = 127.7;
    var scan = box(0.42, 0.08, 0.34, M.dark, PX + 0.35, 1.36, -3.35, { shadow: false });
    var glassTop = box(0.34, 0.01, 0.26, new THREE.MeshStandardMaterial({ color: 0x1b3550, emissive: 0x0a2a44, emissiveIntensity: 0.6, roughness: 0.1 }), PX + 0.35, 1.405, -3.35, { shadow: false });
    var led = box(0.04, 0.03, 0.04, new THREE.MeshStandardMaterial({ color: 0x330000, emissive: 0xff2020, emissiveIntensity: 1.2 }), PX + 0.52, 1.42, -3.24, { shadow: false });
    var beam = box(0.02, 0.012, 0.26, new THREE.MeshBasicMaterial({ color: 0xff3d8b }), PX + 0.2, 1.42, -3.35, { shadow: false }); beam.visible = false;
    var mc = document.createElement("canvas"); mc.width = 512; mc.height = 320; var mt = new THREE.CanvasTexture(mc); mt.encoding = THREE.sRGBEncoding;
    var mon = box(0.62, 0.4, 0.04, new THREE.MeshBasicMaterial({ map: mt, toneMapped: false }), PX - 0.35, 1.62, -3.72, { shadow: false }); mon.rotation.y = 0.35;
    box(0.66, 0.44, 0.03, M.dark, PX - 0.35 - 0.01, 1.62, -3.75, { shadow: false }).rotation.y = 0.35;
    function screen(state, photo) {
      var c = mc.getContext("2d"); c.fillStyle = "#07121c"; c.fillRect(0, 0, 512, 320); c.fillStyle = "#ff3d8b"; c.fillRect(0, 0, 512, 34);
      c.fillStyle = "#07121c"; c.font = "800 18px 'JetBrains Mono', monospace"; c.fillText("BORDER CONTROL · " + here().code, 14, 23);
      if (photo) { c.drawImage(photo, 18, 52, 150, 190); c.strokeStyle = "#ff3d8b"; c.lineWidth = 3; c.strokeRect(18, 52, 150, 190); }
      c.fillStyle = "#e9ece6"; c.font = "700 20px 'JetBrains Mono', monospace";
      c.fillText((G.passport.last || "").toUpperCase(), 190, 78); c.fillText((G.passport.first || "").toUpperCase(), 190, 104);
      c.font = "600 16px 'JetBrains Mono', monospace"; c.fillStyle = "#9aa392"; c.fillText("PASSPORT " + G.passport.no, 190, 134); c.fillText("NATIONALITY USA", 190, 158);
      c.font = "800 26px Unbounded, Arial"; c.fillStyle = state === "match" ? "#ff3d8b" : state === "scan" ? "#ffb02e" : "#9aa392";
      c.fillText(state === "match" ? "MATCH ✓ 98.7%" : state === "scan" ? "SCANNING…" : "WAITING", 190, 214);
      if (state === "scan") { c.fillStyle = "rgba(255,61,139,0.5)"; c.fillRect(18, 52 + (performance.now() / 6) % 190, 150, 3); }
      mt.needsUpdate = true;
    }
    screen("wait");
    var pp = new THREE.Group(); var cover = new THREE.Mesh(new THREE.BoxGeometry(0.125, 0.012, 0.175), new THREE.MeshStandardMaterial({ color: 0x13244a, roughness: 0.5 })); pp.add(cover);
    var gold = new THREE.Mesh(new THREE.CircleGeometry(0.028, 20), new THREE.MeshStandardMaterial({ color: 0xd8b04a, metalness: 0.9, roughness: 0.3 })); gold.rotation.x = -Math.PI / 2; gold.position.y = 0.007; pp.add(gold);
    var paper = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.003, 0.09), new THREE.MeshStandardMaterial({ color: 0xf4f2ea, roughness: 0.8 })); paper.position.set(0.02, 0.012, 0.03); paper.rotation.y = 0.3; pp.add(paper);
    pp.visible = false; scene.add(pp);
    g.scan = scan; g.led = led; g.beam = beam; g.screen = screen; g.pp = pp; g.PX = PX;
    return g;
  })();
  var FLY = null;
  function flyProp(obj, from, to, dur, lift) { obj.visible = true; FLY = { o: obj, a: from.clone(), b: to.clone(), t0: performance.now(), dur: dur, lift: lift || 0.25 }; }
  function handPos() { var v = new THREE.Vector3(); if (player.bones.hand_r) player.bones.hand_r.getWorldPosition(v); else v.set(P.x, 1.1, P.z); return v; }
  function V(a) { return new THREE.Vector3(a[0], a[1], a[2]); }
  function ease(k) { return k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2; }
  function cutscene(shots, done) {
    document.body.classList.add("cinema");
    CUT = { shots: shots, i: -1, t0: 0, done: done };
    nextShot();
  }
  function nextShot() {
    CUT.i++; if (CUT.i >= CUT.shots.length) { var d = CUT.done; CUT = null; camOverride = null; document.body.classList.remove("cinema"); if (d) d(); return; }
    CUT.t0 = performance.now(); var s = CUT.shots[CUT.i]; if (s.at) s.at();
  }
  function tickCut(tm) {
    if (FLY) { var k = Math.min(1, (tm - FLY.t0) / FLY.dur), e = ease(k); FLY.o.position.lerpVectors(FLY.a, FLY.b, e); FLY.o.position.y += Math.sin(k * Math.PI) * FLY.lift; FLY.o.rotation.y = e * 0.6; if (k >= 1) FLY = null; }
    if (!CUT) return;
    var s = CUT.shots[CUT.i], k2 = Math.min(1, (tm - CUT.t0) / (s.dur * (window.__cutSlow || 1))), e2 = ease(k2);
    camOverride = { exact: true, pos: V(s.from.p).lerp(V(s.to ? s.to.p : s.from.p), e2), look: V(s.from.l).lerp(V(s.to ? s.to.l : s.from.l), e2) };
    if (s.tick) s.tick(k2);
    if (k2 >= 1) nextShot();
  }
  function findNpc(x, z) { return staticNpcs.filter(function (n) { return Math.abs(n.g.position.x - x) < 1.2 && Math.abs(n.g.position.z - z) < 1.2; })[0]; }

  function immigrationSequence(a, arr) {
    var PX = DESK.PX, off = findNpc(PX, -4.05) || findNpc(IMM_X + 0.3, -3.6);
    if (off) { off.g.position.set(PX, 0.05, -4.05); off.g.rotation.y = 0; }
    P.x = PX; P.z = -2.35; P.yaw = Math.PI; P.v = 0;
    var photo = new Image(); try { photo.src = People.portrait(renderer, player.traits, 150, 190); } catch (e) {}
    var scanAt = new THREE.Vector3(PX + 0.35, 1.43, -3.35), st = { code: a.code, kind: arr ? "in" : "out", t: now(), date: fmtD(now(), a.tz).toUpperCase().replace(/^\w+,?\s*/, "") };
    cutscene([
      { dur: 1700, from: { p: [PX - 1.6, 2.1, 0.6], l: [PX, 1.4, -3.6] }, to: { p: [PX - 0.75, 1.8, -0.9], l: [PX + 0.1, 1.35, -3.6] }, at: function () { player.play("Interact", { restart: true }); passportProp.visible = true; } },
      { dur: 1600, from: { p: [PX - 1.7, 1.55, -2.5], l: [PX + 0.2, 1.3, -3.1] }, to: { p: [PX - 1.35, 1.5, -2.8], l: [PX + 0.25, 1.32, -3.2] }, at: function () { passportProp.visible = false; flyProp(DESK.pp, handPos(), scanAt, 1100, 0.18); if (off) off.play("Interact", { restart: true }); } },
      { dur: 2000, from: { p: [PX + 0.85, 1.8, -2.55], l: [PX + 0.35, 1.36, -3.35] }, to: { p: [PX + 0.5, 1.62, -2.85], l: [PX + 0.35, 1.36, -3.35] }, at: function () { DESK.beam.visible = true; DESK.screen("scan", photo); },
        tick: function (k) { DESK.beam.position.x = PX + 0.2 + Math.abs(Math.sin(k * Math.PI * 3)) * 0.3; if (k > 0.75) { DESK.led.material.emissive.setHex(0x20ff40); DESK.screen("match", photo); } else DESK.screen("scan", photo); } },
      { dur: 1400, from: { p: [PX + 0.4, 1.75, -2.3], l: [PX - 0.25, 1.5, -3.9] }, to: { p: [PX + 0.25, 1.7, -2.6], l: [PX - 0.3, 1.5, -3.9] }, at: function () { DESK.beam.visible = false; if (off) off.play("Talk"); } },
      { dur: 3000, from: { p: [PX + 0.25, 1.7, -2.6], l: [PX - 0.3, 1.5, -3.9] }, at: function () { stampSequence(st, arr ? "WELCOME TO " + a.country.toUpperCase() : "EXIT STAMP · HAVE A SAFE TRIP", function () {}); } },
      { dur: 1600, from: { p: [PX + 1.3, 1.9, -0.7], l: [PX, 1.35, -3.0] }, to: { p: [PX + 0.6, 2.2, 1.6], l: [PX, 1.3, -2.4] }, at: function () { if (off) off.play("Yes", { restart: true }); flyProp(DESK.pp, scanAt, handPos(), 1000, 0.15); setTimeout(function () { DESK.pp.visible = false; passportProp.visible = true; player.play("Yes", { restart: true }); }, 1000); } }
    ], function () {
      passportProp.visible = false; DESK.led.material.emissive.setHex(0xff2020); DESK.screen("wait");
      G.stamps.push(st); if (arr) G.flags.entry = true; else G.flags.immigration = true;
      save(); applyBlocks(); if (off) off.play("Idle"); player.play("Idle"); P.x = IMM_X - 2.2; P.z = 0; P.yaw = Math.PI / 2; cam.yaw = P.yaw + Math.PI;
      toast((arr ? "Entry" : "Exit") + " stamp · " + a.code); missionEvent(arr ? "entry" : "immigrationDone");
    });
  }
  /* check-in: hand over passport and ticket, agent scans, boarding pass prints */
  var PRINTED = (function () { var m = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.003, 0.08), new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0x222222 })); m.visible = false; scene.add(m); return m; })();
  function checkinSequence(done) {
    var ag = findNpc(98, -17.6); if (ag) { ag.g.position.set(98, 0.05, -17.0); ag.g.rotation.y = 0; }
    P.x = 98; P.z = -14.85; P.yaw = Math.PI; P.v = 0;
    var desk = new THREE.Vector3(98, 1.2, -16), printer = new THREE.Vector3(99.9, 0.72, -15.2);
    cutscene([
      { dur: 1600, from: { p: [99.8, 1.9, -12.6], l: [98, 1.3, -16.6] }, to: { p: [99.0, 1.7, -13.6], l: [98, 1.25, -16.4] }, at: function () { player.play("Interact", { restart: true }); passportProp.visible = true; } },
      { dur: 1500, from: { p: [96.4, 1.5, -15.0], l: [98.2, 1.2, -16] }, to: { p: [96.7, 1.45, -15.3], l: [98.2, 1.2, -16] }, at: function () { passportProp.visible = false; flyProp(DESK.pp, handPos(), desk, 1000, 0.15); if (ag) ag.play("PickUp", { restart: true }); } },
      { dur: 1900, from: { p: [98.6, 1.75, -15.1], l: [98, 1.2, -16.6] }, to: { p: [98.3, 1.7, -15.4], l: [98, 1.3, -16.9] }, at: function () { if (ag) ag.play("Interact", { restart: true }); } },
      { dur: 1700, from: { p: [101.2, 1.2, -14.4], l: [99.9, 0.72, -15.2] }, to: { p: [100.9, 1.1, -14.7], l: [99.9, 0.72, -15.2] }, at: function () { PRINTED.visible = true; PRINTED.position.copy(printer); },
        tick: function (k) { PRINTED.position.set(99.9 - 0.05 + k * 0.16, 0.73, -15.2); } },
      { dur: 1500, from: { p: [99.5, 1.9, -12.9], l: [98, 1.3, -15.8] }, to: { p: [98.4, 2.3, -11.4], l: [98, 1.3, -15.2] }, at: function () { PRINTED.visible = false; flyProp(DESK.pp, desk, handPos(), 900, 0.12); if (ag) ag.play("Yes", { restart: true }); setTimeout(function () { DESK.pp.visible = false; passportProp.visible = true; }, 900); } }
    ], function () { passportProp.visible = false; if (ag) ag.play("Idle"); P.x = 98; P.z = -13.6; P.yaw = 0; cam.yaw = P.yaw + Math.PI; done(); });
  }

  $("pB").addEventListener("click", function () {
    if (!curZone) return;
    if (curZone.z.id === "car") { leaveVehicle(); return; }
    act(curZone.z); curZone = null; $("prompt").hidden = true;
  });
  $("rideSkip").addEventListener("click", function () { skipRide(); });

  /* ===================== Sound: voices with subtitles, phone calls, effects, engine loops, radio and club music =====================
     Files live in assets/audio (made with ElevenLabs). If a file is missing the game stays silent for it and still shows the subtitle. */
  SND = (function () {
    var BASE = "assets/audio/", AC = null, master = null, bus = {}, BUF = {}, LOAD = {}, BAD = {};
    var LOOPS = { s_engine_car: 1, s_engine_sport: 1, s_engine_bike: 1, s_steps: 1, s_run: 1, s_heli: 1, s_prop: 1, s_jet: 1, s_boat: 1, s_siren: 1, s_crowd: 1, s_swim: 1 };
    var pref = { on: true, vol: 0.85, music: 0.7, st: 0 };
    try { var sp = JSON.parse(localStorage.getItem("ep_snd") || "null"); if (sp) for (var pk in sp) pref[pk] = sp[pk]; } catch (e) {}
    function savePref() { try { localStorage.setItem("ep_snd", JSON.stringify(pref)); } catch (e) {} }
    var TXT = {"m_welcome":"Hi, this is City Hall. Welcome to the city! Come see us, grab your card, and take a look around.","m_firstShift":"Job Center here. Your first shift is waiting. Work it all the way through and you get paid today.","m_fare":"Dispatch here. A customer is waiting outside City Hall. Get them to the Tech Hub, and don't be late.","m_groceries":"Hey partner, Fresh Mart calling. Two orders, on foot, and the clock is ticking. Hustle!","m_outskirts":"City Bus here. Hop on and ride out to the farm. Fresh air, open roads. You'll love it.","m_gold":"Well howdy! There's gold out at the mine. Find three nuggets and sell 'em at the bank.","m_speed":"The pumps are down at the oil field! We need those spare parts. Floor it!","m_flyer":"Global Travel here. Your trip starts now. Book a flight, check in and clear security.","m_hospital":"This is City Hospital. We're short of staff tonight. Can you work one shift for us?","m_oilShift":"Oil Field again. Come keep the pumps running for one shift. Good money, honest work.","m_factoryShift":"The line's moving fast at the factory today. We could sure use an extra pair of hands.","m_siteShift":"Construction crew here. Grab a hard hat and help us build something big.","m_morning":"Good morning, sweetheart! Up you get. Grab a coffee and get to the office on time, okay?","m_bankErrand":"City Bank calling. Your new account card is ready. Pick it up inside whenever you like.","m_checkup":"Hello, City Hospital here. It's time for your yearly check-up. We'll see you soon.","m_explorer":"Tourism Office! This city is full of famous places. Go see them all and take some photos.","m_courier":"Supermarket here. Two parcels, two addresses, not much time. You in?","m_taxiShift":"Dispatch again. Two customers need a ride. Grab the taxi and keep them happy.","m_dinner":"Good evening, the restaurant here. Your table is ready. Come hungry!","m_homeSweet":"Hi, it's your landlord. Your new place is all ready. Go check it out and put your feet up.","m_airportRun":"EarthPass Air calling. Your flight leaves soon. Get a taxi to the terminal.","m_bigScore":"You don't know me, but I know you. The city bank vault... is full tonight. Want in?","m_hotWheels":"I need a car. Any car. Take one off the street and bring it to the airport car park. No questions.","m_streetKing":"Yo! Fight club's open. Win three fights on the street and you're the king. Watch out for cops!","m_hotPursuit":"Hey hotshot! Get two stars on your back, then lose the cops. Let's see what you've got.","m_twoWheels":"Courier here. Grab a motorbike and rush this parcel to the cafe. Fast!","m_rushHour":"Dispatch! Rush hour job. Hotel, then the bank, under four minutes. Go, go, go!","m_nightShift":"Hotel front desk. One of our guests needs a ride to the hospital. Please keep them safe.","m_travelDocs":"Global Travel again. Book your flight, check in, and get that exit stamp in your passport.","m_turfWar":"A rival crew took the park by the river. That's our turf. Gear up and take it back.","m_rhinoRampage":"There's a tank at the Army Depot. Borrow it. Wreck six cars. Heh. Have fun.","m_nitroRun":"Nitro run! Grab something fast, hit the boost, and race me to the airport car park. Two minutes!","m_fireworks":"Demolition crew here. We need fireworks. Get a rocket launcher and blow up three cars!","p_official":"Wonderful job. Thank you so much. The payment is in your account.","p_pro":"Nice work, that's done. Your money's on the way.","p_work":"Now that's what I call a job well done, partner!","p_shady":"Hah. Not bad. Not bad at all. Your cut is waiting.","p_boss":"Respect. The street knows your name now.","p_racer":"Okay, okay, you're fast! I'll get you next time.","p_young":"Yo, that was crazy! You're a legend!","p_mom":"I'm so proud of you, sweetheart.","c_mom":"Hi honey, it's mom. Just checking you're eating properly. Call me when you land somewhere new, okay? Love you!","c_friend":"Bro! Sky Club, floor one oh one, tonight. Best view in the city. Take the glass lift. Don't be late!","c_boss":"Hey, it's your manager. Don't forget your shift today. Clock in on time and the pay is yours.","c_travel":"Global Travel here with a special offer. Flights to Tokyo, Dubai and London are on sale today. Come see us!","c_racer":"Heard you got a new ride. Prove it. Meet me on the expressway. Loser buys the nitro.","c_bank":"City Bank here. A new payment just landed in your account. Have a lovely day.","c_tip":"Psst. There's a kiosk on the tower deck that sells parachutes. Four hundred meters down... What a ride.","c_shop":"Arms and Auto. New hypercars just came in. The Titan is fast as lightning. Come take a look.","b_m_watch":"Hey! Watch where you're going!","b_m_problem":"Whoa, what's your problem, man?","b_m_help":"Help! Somebody call the police!","b_m_nicecar":"Nice ride!","b_m_hi":"Hey, how's it going?","b_f_excuse":"Excuse me!","b_f_away":"Get away from me!","b_f_help":"Help! Police!","b_f_hi":"Hi there! Beautiful day, isn't it?","b_f_wow":"Oh my gosh, is that a helicopter?","b_cop_freeze":"Freeze! Police!","b_cop_hands":"Hands where I can see them!","b_cop_pull":"Pull over! Now!","b_cop_backup":"Suspect is armed. Requesting backup!","b_gang_turf":"You're on our turf!","b_gang_get":"Get him!","b_gang_wrong":"Wrong neighborhood, friend.","b_jack_mycar":"Hey! That's my car!","b_jack_crazy":"Are you crazy?! Give it back!","b_shop_welcome":"Welcome to Arms and Auto. Take your time.","b_shop_thanks":"Pleasure doing business.","b_bar_hi":"Hey, welcome to the Sky Bar. What can I get you?","b_bar_drink":"One neon mocktail, coming right up. Enjoy the view.","b_dj_noise":"Sky Club in the house! Make some noise!","b_dj_citizens":"This one goes out to all the citizens of EarthPass!","b_att_welcome":"Welcome aboard! Your seat is just down the aisle. Enjoy your flight.","b_att_pass":"Boarding pass, please. Thank you!","b_sec_bags":"Please place your bags on the belt and walk through the arch.","b_sec_clear":"You're all clear. Have a good flight.","b_lift_up":"Going up. Sky Deck, floor one hundred.","b_lift_down":"Going down. Lobby.","a_boarding":"Attention please. EarthPass Air flight now boarding at gate B twelve. Please have your boarding pass and passport ready.","a_security":"For your safety, please do not leave bags unattended. Weapons are not allowed past security.","a_tower":"Welcome to EarthPass Tower. The Sky Deck and the Sky Club are open. The glass lift is on your left.","r1_a":"You're tuned to Sunset FM, the hottest drive-time hits in EarthPass! Windows down, volume up. Let's ride.","r1_b":"Sunset FM. Traffic is moving on the expressway, the sky is gorgeous, and this next track is pure fire.","r2_a":"Neon Beat one oh one. Real beats for real streets. Stay smooth, stay safe, and keep that wallet locked.","r2_b":"This is Neon Beat. If you're cruising past the tower tonight, look up. That's the Sky Club. Now, back to the music.","r3_a":"Hey, you're listening to Ocean Drive Chill. Slow down, breathe, and enjoy the ride.","r3_b":"Ocean Drive Chill. Sun's going down, the city lights are coming up. Here's something easy for your evening."}, ROLE = {"welcome":"official","firstShift":"official","fare":"pro","groceries":"work","outskirts":"pro","gold":"work","speed":"work","flyer":"official","hospital":"official","oilShift":"work","factoryShift":"work","siteShift":"work","morning":"mom","bankErrand":"official","checkup":"official","explorer":"official","courier":"pro","taxiShift":"pro","dinner":"pro","homeSweet":"mom","airportRun":"official","bigScore":"shady","hotWheels":"shady","streetKing":"young","hotPursuit":"racer","twoWheels":"pro","rushHour":"pro","nightShift":"official","travelDocs":"official","turfWar":"boss","rhinoRampage":"shady","nitroRun":"racer","fireworks":"work"};
    var CALLS = [["c_mom", "Mom"], ["c_friend", "Jay"], ["c_boss", "Your manager"], ["c_travel", "Global Travel"], ["c_racer", "Ember"], ["c_bank", "City Bank"], ["c_tip", "Unknown number"], ["c_shop", "Arms & Auto"]];
    var ST = [{ n: "Sunset FM", l: ["r1_a", "mu_sunset1", "r1_b", "mu_sunset2"] }, { n: "Neon Beat 101", l: ["r2_a", "mu_neon1", "r2_b", "mu_neon2"] }, { n: "Ocean Drive Chill", l: ["r3_a", "mu_chill1", "r3_b", "mu_chill2"] }];
    /* ---- page parts: subtitles, incoming call, radio button ---- */
    var css = document.createElement("style");
    css.textContent = "#sub{position:fixed;left:50%;bottom:118px;transform:translateX(-50%);max-width:min(720px,86vw);background:rgba(14,9,26,.82);color:#fff;border-radius:14px;padding:9px 15px;font:600 15px/1.35 system-ui,sans-serif;text-align:center;z-index:40;pointer-events:none;box-shadow:0 6px 24px rgba(0,0,0,.35)}#sub b{display:block;font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:#2ee6d6;margin-bottom:2px}" +
      "#callBan{position:fixed;left:50%;top:128px;transform:translateX(-50%);display:flex;align-items:center;gap:10px;background:rgba(14,9,26,.92);color:#fff;border-radius:18px;padding:10px 12px 10px 16px;z-index:45;box-shadow:0 8px 28px rgba(0,0,0,.45);font-family:system-ui,sans-serif}#callBan .cb-who{display:flex;flex-direction:column;min-width:130px}#callBan .cb-who span{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:#ff9a3c}#callBan .cb-who b{font-size:17px}#callBan button{border:0;border-radius:12px;padding:10px 14px;font:700 14px system-ui,sans-serif;color:#fff;cursor:pointer}#cbNo{background:#d1283c}#cbYes{background:#18a55a}" +
      "#bRadio{position:fixed;left:50%;bottom:22px;transform:translateX(-232px);display:none;border:0;border-radius:14px;background:rgba(14,9,26,.85);color:#fff;font:700 12px system-ui,sans-serif;padding:9px 12px;z-index:30;min-width:96px;text-align:left;line-height:1.15;cursor:pointer}#bRadio small{display:block;font-size:10px;color:#2ee6d6;letter-spacing:.08em}body.driving #bRadio{display:block}";
    document.head.appendChild(css);
    var subEl = document.createElement("div"); subEl.id = "sub"; subEl.hidden = true; subEl.innerHTML = "<b></b><span></span>"; document.body.appendChild(subEl);
    var callEl = document.createElement("div"); callEl.id = "callBan"; callEl.hidden = true; callEl.innerHTML = "<div class='cb-who'><span>Incoming call</span><b></b></div><button id='cbNo' type='button'>Decline</button><button id='cbYes' type='button'>Answer</button>"; document.body.appendChild(callEl);
    var rBtn = document.createElement("button"); rBtn.id = "bRadio"; rBtn.type = "button"; document.body.appendChild(rBtn);
    function radioLabel() { rBtn.innerHTML = "<small>RADIO</small>" + (pref.st < ST.length ? ST[pref.st].n : "Off"); }
    radioLabel();
    /* ---- audio engine ---- */
    function ctx() {
      if (AC) return AC; try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return null; }
      master = AC.createGain(); master.connect(AC.destination);
      ["sfx", "vox", "amb", "mus"].forEach(function (k) { bus[k] = AC.createGain(); bus[k].connect(master); });
      applyVol(); return AC;
    }
    function applyVol() { if (!AC) return; master.gain.value = pref.on ? pref.vol : 0; bus.mus.gain.value = pref.music; bus.amb.gain.value = 0.8; }
    function unlock() { var c = ctx(); if (c && c.state === "suspended") c.resume(); }
    ["pointerdown", "keydown", "touchstart"].forEach(function (e) { window.addEventListener(e, unlock, { passive: true }); });
    function buf(n) {
      if (BUF[n]) return Promise.resolve(BUF[n]); if (BAD[n]) return Promise.resolve(null); if (LOAD[n]) return LOAD[n];
      var c = ctx(); if (!c) return Promise.resolve(null);
      LOAD[n] = fetch(BASE + n + ".mp3").then(function (r) { if (!r.ok) throw new Error(r.status); return r.arrayBuffer(); })
        .then(function (ab) { return new Promise(function (ok, no) { c.decodeAudioData(ab, ok, no); }); })
        .then(function (b) { BUF[n] = prep(n, b); return BUF[n]; }).catch(function () { BAD[n] = 1; return null; });
      return LOAD[n];
    }
    /* clean each clip once after loading: trim silence, even out the volume, and make loops seamless with a cross-fade */
    function prep(n, b) {
      var ch = b.numberOfChannels, len = b.length, sr = b.sampleRate, d = new Float32Array(len), i, k;
      for (k = 0; k < ch; k++) { var x = b.getChannelData(k); for (i = 0; i < len; i++) d[i] += x[i] / ch; }
      var pk = 0; for (i = 0; i < len; i++) { var av = Math.abs(d[i]); if (av > pk) pk = av; }
      if (pk < 1e-4) return { b: b, off: 0, dur: b.duration, g: 1 };
      var loop = !!LOOPS[n], th = pk * (loop ? 0.003 : 0.012), s0 = 0, s1 = len - 1;
      while (s0 < len - 1 && Math.abs(d[s0]) < th) s0++; while (s1 > s0 && Math.abs(d[s1]) < th * 0.5) s1--;
      if (loop) {
        var L = s1 - s0 + 1, X = Math.floor(Math.min(0.3 * sr, L / 4)), out = new Float32Array(L - X), ss = 0;
        for (i = 0; i < L - X; i++) out[i] = d[s0 + i];
        for (i = 0; i < X; i++) { var t = i / X; out[i] = d[s0 + i] * Math.sin(t * Math.PI / 2) + d[s0 + L - X + i] * Math.cos(t * Math.PI / 2); }
        for (i = 0; i < out.length; i++) ss += out[i] * out[i];
        var rms = Math.sqrt(ss / out.length) || 1e-4, nb = AC.createBuffer(1, out.length, sr); nb.getChannelData(0).set(out);
        return { b: nb, off: 0, dur: nb.duration, g: Math.min(0.11 / rms, 0.95 / pk) };
      }
      var voice = n.indexOf("s_") !== 0; s0 = Math.max(0, s0 - Math.floor(sr * (voice ? 0.03 : 0.002))); s1 = Math.min(len - 1, s1 + Math.floor(sr * (voice ? 0.1 : 0.05)));
      var g = 0.92 / pk;
      if (voice) { var sv = 0; for (i = s0; i <= s1; i++) sv += d[i] * d[i]; var vr = Math.sqrt(sv / Math.max(1, s1 - s0 + 1)) || 1e-4; g = Math.min(0.13 / vr, 0.95 / pk); }
      return { b: b, off: s0 / sr, dur: (s1 - s0) / sr, g: g };
    }
    function camD(at) { return Math.hypot(at[0] - camera.position.x, at[1] - camera.position.z); }
    function play(n, o) {
      o = o || {}; var c = ctx(); if (!c || !pref.on) { if (o.onend) setTimeout(o.onend, 50); return null; }
      if (o.at && camD(o.at) > (o.far || 120)) { if (o.onend) setTimeout(o.onend, 50); return null; }
      var h = { stop: function () { h.dead = true; if (h.src) try { h.src.stop(); } catch (e) {} } };
      buf(n).then(function (b) {
        if (!b || h.dead) { if (o.onend) o.onend(); return; }
        var s = c.createBufferSource(), g = c.createGain(), v = (o.vol == null ? 1 : o.vol) * b.g; s.buffer = b.b; s.playbackRate.value = o.rate || 1;
        if (o.at) v *= Math.pow(Math.max(0, 1 - camD(o.at) / (o.far || 120)), 1.4);
        g.gain.value = v; var head = g;
        if (o.phone) { var hp = c.createBiquadFilter(), lp = c.createBiquadFilter(); hp.type = "highpass"; hp.frequency.value = 320; lp.type = "lowpass"; lp.frequency.value = 3300; hp.connect(lp); lp.connect(g); head = hp; }
        s.connect(head); g.connect(bus[o.bus || "sfx"]); s.onended = function () { if (o.onend) o.onend(); };
        s.start(0, b.off, b.dur); h.src = s;
      });
      return h;
    }
    /* looping layers that cross-fade when the sound changes */
    function Slot(b) { this.b = b; this.n = null; this.s = null; this.g = null; }
    Slot.prototype.set = function (n, vol, rate) {
      var c = AC; if (!c) return; if (!pref.on) n = null;
      if (n !== this.n) {
        if (this.s) { var os = this.s, og = this.g; og.gain.setTargetAtTime(0, c.currentTime, 0.08); setTimeout(function () { try { os.stop(); } catch (e) {} os.disconnect(); og.disconnect(); }, 500); }
        this.s = this.g = null; this.n = n; var me = this;
        if (n) buf(n).then(function (b) { if (!b || me.n !== n || me.s) return; var s = c.createBufferSource(), g = c.createGain(); s.buffer = b.b; s.loop = true; g.gain.value = 0; s.connect(g); g.connect(bus[me.b]); s.start(0, Math.random() * b.dur * 0.9); me.s = s; me.g = g; me.pg = b.g; });
      }
      if (this.g) { this.g.gain.setTargetAtTime((vol || 0) * (this.pg || 1), c.currentTime, 0.12); this.s.playbackRate.setTargetAtTime(rate || 1, c.currentTime, 0.1); }
    };
    var S = { eng: new Slot("sfx"), feet: new Slot("sfx"), siren: new Slot("amb"), amb: new Slot("amb") };
    /* ---- voices and subtitles ---- */
    var vq = [], vCur = null, duck = 1, subT = null, clock = 0, lastV = -99;
    function sub(who, text, dur) { subEl.querySelector("b").textContent = who || ""; subEl.querySelector("span").textContent = text; subEl.hidden = false; clearTimeout(subT); subT = setTimeout(function () { subEl.hidden = true; }, dur * 1000 + 700); }
    function say(key, o) {
      o = o || {}; if (!TXT[key]) return;
      if (vCur) { if ((o.prio || 0) >= 2 && vq.length < 4) vq.push([key, o]); return; }
      vCur = key; duck = o.sub === false ? 0.7 : 0.3; var fin = false;
      var done = function () { if (fin) return; fin = true; vCur = null; duck = 1; lastV = clock; if (vq.length) { var nx = vq.shift(); setTimeout(function () { say(nx[0], nx[1]); }, 400); } };
      if (o.sub !== false) sub(o.who, TXT[key], Math.max(2.2, TXT[key].length / 15));
      if (!pref.on || !play(key, { bus: "vox", vol: o.vol || 1, phone: o.phone, at: o.at, far: o.far, onend: done })) setTimeout(done, o.sub === false ? 200 : Math.max(2200, TXT[key].length * 65));
      setTimeout(done, 20000);
    }
    function isF(a) { return !!a && (a.kind === "woman" || (a.kind && typeof a.kind === "object" && a.kind.sex === "F")); }
    function bark(key, at) { if (vCur || clock - lastV < 2) return; say(key, { sub: false, at: at, far: 45, prio: 0 }); }
    /* ---- radio: three stations that keep playing while you are out of the car ---- */
    var RA = null, RG = null, rOn = false, rIdx = -1, rItem = 0, rFail = 0;
    function itemDur(n) { return n.indexOf("mu_") === 0 ? 90 : 8; }
    function radioEl() {
      if (RA) return RA; RA = new Audio(); RA.preload = "auto";
      var c = ctx(); if (c && c.createMediaElementSource) { try { var src = c.createMediaElementSource(RA); RG = c.createGain(); src.connect(RG); RG.connect(bus.mus); } catch (e) { RG = null; } }
      RA.addEventListener("ended", function () { if (rOn) radioNext(); });
      RA.addEventListener("error", function () { if (rOn && ++rFail < 6) setTimeout(radioNext, 800); });
      return RA;
    }
    function radioLive(st) { var l = ST[st].l, tot = 0; l.forEach(function (n) { tot += itemDur(n); }); var p = (Date.now() / 1000 + st * 57) % tot; for (var i = 0; i < l.length; i++) { var d = itemDur(l[i]); if (p < d) return [i, l[i].indexOf("mu_") === 0 ? p : 0]; p -= d; } return [0, 0]; }
    function radioPlay(st, i, off) {
      var a = radioEl(); rIdx = st; rItem = i; a.src = BASE + ST[st].l[i] + ".mp3";
      var go = function () { try { if (off) a.currentTime = off; } catch (e) {} var pr = a.play(); if (pr && pr.catch) pr.catch(function () {}); };
      if (off) a.addEventListener("loadedmetadata", function f() { a.removeEventListener("loadedmetadata", f); go(); }); else go();
    }
    function radioNext() { if (rIdx >= 0) radioPlay(rIdx, (rItem + 1) % ST[rIdx].l.length, 0); }
    function radioTick() {
      var want = P.mode === "car" && pref.on && pref.st < ST.length && !cine;
      if (want && (!rOn || rIdx !== pref.st)) { rOn = true; rFail = 0; var lv = radioLive(pref.st); radioPlay(pref.st, lv[0], lv[1]); }
      else if (!want && rOn) { rOn = false; if (RA) RA.pause(); }
      if (RG) RG.gain.setTargetAtTime(want ? duck : 0, AC.currentTime, 0.25); else if (RA) RA.volume = Math.max(0, Math.min(1, pref.music * pref.vol * duck));
    }
    rBtn.addEventListener("click", function (e) { e.preventDefault(); unlock(); pref.st = (pref.st + 1) % (ST.length + 1); savePref(); rOn = false; radioLabel(); toast(pref.st < ST.length ? "Radio · " + ST[pref.st].n : "Radio off"); });
    /* ---- club track (falls back to the synth beat if the file is missing) ---- */
    var CA = null, CG = null, cOn = false, cFail = false;
    function club(on, fb) {
      if (!on) { cOn = false; if (CA) CA.pause(); return; }
      if (cFail || !pref.on) { if (fb) fb(true); return; }
      cOn = true;
      if (!CA) {
        CA = new Audio(BASE + "mu_club.mp3"); CA.loop = true; var c = ctx();
        if (c && c.createMediaElementSource) try { var s = c.createMediaElementSource(CA); CG = c.createGain(); s.connect(CG); CG.connect(bus.mus); } catch (e) {}
        CA.addEventListener("error", function () { cFail = true; if (cOn && fb) fb(true); });
      }
      var pr = CA.play(); if (pr && pr.catch) pr.catch(function () {});
    }
    /* ---- phone calls ---- */
    var callT = 150 + Math.random() * 120, ringing = null, callI = Math.floor(Math.random() * CALLS.length);
    function ring(cl) {
      ringing = { c: cl, n: 0 }; callEl.querySelector("b").textContent = cl[1]; callEl.hidden = false;
      var rg = function () { if (!ringing) return; if (ringing.n++ >= 4) { endCall(false); return; } ringing.h = play("s_ring", { vol: 0.75 }); ringing.to = setTimeout(rg, 3300); }; rg();
    }
    function endCall(ans) {
      var r = ringing; if (!r) return; ringing = null; clearTimeout(r.to); if (r.h) r.h.stop(); callEl.hidden = true;
      if (ans) say(r.c[0], { who: r.c[1] + " · phone call", phone: true, prio: 3 }); else msg(r.c[1], "Missed call");
    }
    callEl.querySelector("#cbYes").addEventListener("click", function () { unlock(); endCall(true); });
    callEl.querySelector("#cbNo").addEventListener("click", function () { endCall(false); });
    function callTick(dt) {
      if (ringing || cine || CUT || VSEQ || G.mis) return;
      callT -= dt; if (callT > 0 || vCur) return;
      callT = 300 + Math.random() * 240; ring(CALLS[callI++ % CALLS.length]);
    }
    /* ---- voices around you ---- */
    var paT = 25, djT = 6, hiT = 10, wowT = 0, towT = 0, thr = {};
    function every(k, s) { if (thr[k] && clock - thr[k] < s) return false; thr[k] = clock; return true; }
    function ambient(dt) {
      paT -= dt; djT -= dt; hiT -= dt; wowT -= dt; towT -= dt;
      if (paT < 0 && !vCur && P.mode !== "car" && P.x > AX1 && P.x < AX2 && Math.abs(P.z) < 30) { paT = 70 + Math.random() * 60; say(Math.random() < 0.6 ? "a_boarding" : "a_security", { who: "Airport announcement", prio: 1 }); }
      if (P.lv && P.lv.id === "club" && djT < 0 && !vCur) { djT = 45 + Math.random() * 40; say(Math.random() < 0.5 ? "b_dj_noise" : "b_dj_citizens", { who: "DJ", prio: 1 }); }
      if (TOWER && towT < 0 && P.mode === "walk" && !P.lv && Math.hypot(P.x - TOWER.x, P.z - TOWER.z) < 26) { towT = 600; say("a_tower", { who: "EarthPass Tower", prio: 1 }); }
      if (hiT < 0 && P.mode === "walk" && !vCur) {
        hiT = 4; for (var i = 0; i < PEDS.length; i++) { var pd = PEDS[i]; if (pd.st || !pd.a) continue; if (Math.hypot(pd.x - P.x, pd.z - P.z) < 2.4) { hiT = 30; if (Math.random() < 0.4) bark(isF(pd.a) ? "b_f_hi" : "b_m_hi", [pd.x, pd.z]); break; } }
      }
      if (wowT < 0 && P.mode === "car" && taxi.m && PEDS.length) {
        var U = taxi.m.userData, fast = (U.sport || (U.vmax || 0) >= 30) && Math.abs(taxi.v) > 6, heli = U.air === "heli" && (taxi.alt || 0) < 45;
        if (fast || heli) for (var j = 0; j < PEDS.length; j++) { var q = PEDS[j]; if (!q.a || q.st) continue; if (Math.hypot(q.x - taxi.x, q.z - taxi.z) < (heli ? 35 : 9)) { wowT = 40; bark(heli ? "b_f_wow" : (isF(q.a) ? "b_f_wow" : "b_m_nicecar"), [q.x, q.z]); break; } }
      }
    }
    var lastSwim = false;
    function tick(dt) {
      if (!AC) return; clock += dt;
      var car = P.mode === "car" && taxi.m, U = car ? taxi.m.userData : null;
      if (car) {
        var VM = U.vmax || 22, k = Math.min(1, Math.abs(taxi.v) / VM), n, vol, rate;
        if (U.air === "heli") { n = "s_heli"; vol = 0.55; rate = 0.9 + Math.min(0.3, (taxi.alt || 0) > 0.5 ? 0.15 : 0); }
        else if (U.air) { n = U.prop ? "s_prop" : "s_jet"; vol = 0.45 + (taxi.thr || 0) * 0.3; rate = 0.8 + (taxi.thr || 0) * 0.5; }
        else if (U.boat) { n = "s_boat"; vol = 0.3 + k * 0.4; rate = 0.8 + k * 0.7; }
        else if (U.moto) { n = "s_engine_bike"; vol = 0.3 + k * 0.4; rate = 0.8 + k * 1.3; }
        else { n = U.sport || VM >= 30 || U.tank ? "s_engine_sport" : "s_engine_car"; vol = 0.26 + k * 0.42; rate = (U.tank ? 0.55 : 0.75) + k * 1.1 + (drive.gas ? 0.06 : 0); }
        S.eng.set(n, vol, rate);
      } else S.eng.set(null);
      var walking = !car && !P.fall && !P.seat && !cine && !CUT && !VSEQ && P.v > 0.6;
      if (walking) S.feet.set(P.swim ? "s_swim" : P.v > 4.4 ? "s_run" : "s_steps", P.swim ? 0.45 : 0.32, P.swim ? 1 : P.v > 4.4 ? P.v / 5.4 : Math.max(0.7, P.v / 2.4)); else S.feet.set(null);
      if (P.swim && !lastSwim) play("s_splash", { vol: 0.8 }); lastSwim = !!P.swim;
      S.siren.set(WANTED > 0 && COPS.length ? "s_siren" : null, Math.min(0.45, 0.12 + WANTED * 0.07), 1);
      var high = (P.lv && P.lv.y > 50) || (car && (taxi.alt || 0) > 30);
      S.amb.set(INSIDE || (P.lv && P.lv.id === "club") ? null : "s_crowd", high ? 0.05 : 0.2, 1);
      if (CG) CG.gain.setTargetAtTime(cOn ? duck : 0, AC.currentTime, 0.3);
      radioTick(); callTick(dt); ambient(dt);
    }
    /* ---- game events ---- */
    var GUN = { pistol: ["s_pistol", 1], revolver: ["s_pistol", 0.85], deagle: ["s_pistol", 0.75], microsmg: ["s_rifle", 1.25, 0.32], smg: ["s_rifle", 1.15, 0.38], rifle: ["s_rifle", 1, 0.42], carbine: ["s_rifle", 1.05, 0.4], mg: ["s_rifle", 0.9, 0.36], minigun: ["s_rifle", 1.35, 0.28], shotgun: ["s_shotgun", 1], sniper: ["s_pistol", 0.6], rpg: ["s_rocket", 1], glauncher: ["s_rocket", 1.2] };
    function ev(k, a, b) {
      switch (k) {
        case "door_open": play("s_door_open", { vol: 0.8, at: a, far: 40 }); break;
        case "door_close": play("s_door_close", { vol: 0.9, at: a, far: 40 }); break;
        case "gun": var gs = GUN[a] || ["s_pistol", 1]; if (gs[2] && !every("gun", gs[2])) break; play(gs[0], { vol: 0.8, rate: gs[1] * (0.96 + Math.random() * 0.08) }); break;
        case "cannon": play(a === "mg" ? "s_rifle" : "s_rocket", { vol: 0.85 }); break;
        case "punch": play("s_punch", { vol: 0.9, rate: 0.9 + Math.random() * 0.2 }); if (a && a.a && Math.random() < 0.6) setTimeout(function () { bark(isF(a.a) ? (Math.random() < 0.5 ? "b_f_away" : "b_f_help") : (Math.random() < 0.5 ? "b_m_problem" : "b_m_help"), [a.x, a.z]); }, 450); break;
        case "boom": play("s_explosion", { vol: 1, at: a, far: 420 }); break;
        case "crash": if (every("crash", 0.7)) play("s_crash", { vol: Math.min(1, 0.35 + a / 20) }); break;
        case "tires": if (every("tires", 1.6)) play("s_tires", { vol: 0.55 }); break;
        case "horn": if (every("horn", 0.6)) play("s_horn", { vol: 0.8 }); break;
        case "chute": play("s_chute", { vol: 0.9 }); break;
        case "splash": play("s_splash", { vol: 0.9 }); break;
        case "wasted": play("s_wasted", { vol: 1 }); break;
        case "cash": if (every("cash", 0.8)) play("s_cash", { vol: 0.7 }); if (!$("shop").hidden && every("thanks", 25)) setTimeout(function () { say("b_shop_thanks", { who: "Arms & Auto", prio: 1 }); }, 500); break;
        case "earn": if (a >= 5 && every("earn", 1)) play("s_cash", { vol: 0.6 }); break;
        case "ping": if (every("ping", 1.5)) play("s_ping", { vol: 0.6 }); break;
        case "ding": play("s_ding", { vol: 0.8 }); break;
        case "mission": var mm = MIS[a]; play("s_ping", { vol: 0.6 }); if (mm) setTimeout(function () { say("m_" + a, { who: mm.from, prio: 3 }); }, 700); break;
        case "passed": var mp = MIS[a]; play("s_passed", { vol: 0.9 }); if (mp && ROLE[a]) setTimeout(function () { say("p_" + ROLE[a], { who: mp.from, prio: 3 }); }, 2000); break;
        case "wanted": if (!every("cop", 7)) break; say(P.mode === "car" ? "b_cop_pull" : a >= 3 && Math.random() < 0.5 ? "b_cop_backup" : (Math.random() < 0.5 ? "b_cop_freeze" : "b_cop_hands"), { sub: false, prio: 1 }); break;
        case "gang": if (every("gang", 20)) setTimeout(function () { say("b_gang_turf", { sub: false, at: a, far: 60, prio: 1 }); }, 900); break;
        case "gangShoot": if (every("gangS", 9)) say(Math.random() < 0.5 ? "b_gang_get" : "b_gang_wrong", { sub: false, prio: 0 }); break;
        case "jacked": setTimeout(function () { say(isF(a && a.rider) || Math.random() < 0.4 ? "b_jack_crazy" : "b_jack_mycar", { sub: false, at: a ? [a.x, a.z] : null, far: 50, prio: 1 }); }, 1100); break;
        case "shopOpen": if (every("shopHi", 90)) say("b_shop_welcome", { who: "Arms & Auto", prio: 1 }); break;
        case "bar": say("b_bar_hi", { who: "Bartender", prio: 2 }); say("b_bar_drink", { who: "Bartender", prio: 2 }); break;
        case "lift": say(a === "lobby" ? "b_lift_down" : "b_lift_up", { who: "Lift", prio: 2 }); break;
        case "scanStart": say("b_sec_bags", { who: "Security", prio: 2 }); break;
        case "scanEnd": say("b_sec_clear", { who: "Security", prio: 2 }); break;
        case "board": say("b_att_pass", { who: "Gate agent", prio: 2 }); break;
        case "boardDoor": say("b_att_welcome", { who: "Cabin crew", prio: 2 }); break;
      }
    }
    return {
      ev: ev, tick: tick, club: club, say: say, ring: function (i) { ring(CALLS[(i || 0) % CALLS.length]); }, answer: function () { endCall(true); }, pref: pref, savePref: savePref, applyVol: applyVol, radioLabel: radioLabel, stations: ST,
      state: function () { return { ctx: !!AC, ctxState: AC && AC.state, loaded: Object.keys(BUF).length, missing: Object.keys(BAD), voice: vCur, radio: rOn ? ST[rIdx].n + " #" + rItem : "off", eng: S.eng.n, feet: S.feet.n, amb: S.amb.n, siren: S.siren.n }; }
    };
  })();
  window.__pw = { SND: function () { return SND; }, setTestTokens: setTestTokens, onBridge: onBridge, buildVCOL: buildVCOL, VCOL: function () { return VCOL; }, vHit: vHit, findCarSpot: findCarSpot, carFreeAt: carFreeAt, clk: clk, vseqStep: function (n, dt) { for (var i = 0; i < n && VSEQ; i++) vseqTick(dt || 0.05); return VSEQ ? VSEQ.phase : "none:" + P.mode; }, wxStep: function (n, dt) { for (var i = 0; i < n; i++) wxTick(dt || 0.05, performance.now() / 1000); updateSky(now()); }, wx: WX, astro: astro, skyU: skyU, updateSky: updateSky, strike: strike, vseq: function () { return VSEQ; }, boardVehicle: boardVehicle, leaveVehicle: leaveVehicle, tower: function () { return TOWER; }, topAt: topAt, surfaceAt: surfaceAt, startFall: startFall, deployChute: deployChute, liftRide: liftRide, hopTo: hopTo, baseJump: baseJump, deliver: deliver, ITEMS: ITEMS, vehMesh: vehMesh, airb: AIRB, wrecks: WRECKS, clubMusic: clubMusic, inAir: inAir, setLv: function (id) { P.lv = id ? TOWER[id] : null; }, airStep: function (n, dt) { for (var i = 0; i < n; i++) { if (P.mode === "car" && taxi.m.userData.air) airTick(dt || 0.05, false); else if (P.fall) fallTick(dt || 0.05, 0, 0, 0); } return [taxi.alt, taxi.v, taxi.x, taxi.z]; }, fall: function () { return P.fall; }, keys: keys, openShop: openShop, closeShop: closeShop, giveWeapon: giveWeapon, fireWeapon: fireWeapon, fireCannon: fireCannon, stealTank: stealTank, useNitro: useNitro, sportCar: sportCar, superBike: superBike, swapRide: swapRide, gang: function () { return GANG; }, nitro: function () { return NITRO; }, tank: function () { return TANK; }, armsShop: armsShop, weaponTarget: weaponTarget, fx: function () { return FX.length; }, transit: function () { return TRANSIT; }, boats: function () { return BOATS; }, ride: function () { return RIDE; }, rideAct: function (id) { rideAct({ id: id }); }, startRide: startRide, rentBoat: rentBoat, deckAt: deckAt, RG: function (c) { return routeGraph(c); }, bridge: function () { return BRIDGE && [BRIDGE.pts, BRIDGE.xa, BRIDGE.xb, !!BRIDGE.land]; }, water: function (x, z) { return [isWater(x, z), deepWater(x, z)]; }, swim: function () { return !!P.swim; }, sinking: function () { return !!SINK; }, swimY: function (v) { SWIM_Y = v; }, groundY: groundY, resetBridge: function () { if (BRIDGE && BRIDGE.g) scene.remove(BRIDGE.g); BRIDGE = null; buildBridge(); return BRIDGE && [BRIDGE.pts, !!BRIDGE.land]; }, checkinSequence: checkinSequence, immigrationSequence2: function(){ return immigrationSequence(here(), false); }, stampSequence: stampSequence, bodyScan: bodyScan, immigrationSequence: immigrationSequence, here: here, cityPlaces: cityPlaces, CITY: function () { return CITY; }, drive: drive, enterTaxi: enterTaxi, exitTaxi: exitTaxi, carHits: carHits, collide: collide, carPush: carPush, COL: COL, CARS: CARS, openMap: openMap, setWaypoint: setWaypoint, P: P, cam: cam, G: G, zones: ZONES, act: act, setSpeed: setSpeed, taxi: taxi, board: board, applyBlocks: applyBlocks, refreshSigns: refreshSigns, save: save, enterPlace: enterPlace, leavePlace: leavePlace, home: function () { return HOME; }, inside: function () { return INSIDE; }, unstick: unstick, trapped: trapped, freeAt: freeAt, player: function () { return player; }, scene: scene, camera: camera, cine: function () { return cine; }, jet: jet, showFlight: showFlight, punch: punch, PEDS: function () { return PEDS; }, COPS: function () { return COPS; }, CT: function () { return CT; }, setWanted: setWanted, wanted: function () { return WANTED; }, carjack: carjack, startMission: startMission, spawnCop: spawnCop, findRoute: function (a, b, c, d, e) { return findRoute(a, b, c, d, e); }, setCam: function (p, l) { camOverride = p ? { pos: new THREE.Vector3(p[0], p[1], p[2]), look: new THREE.Vector3(l[0], l[1], l[2]), exact: true } : null; }, wallCount: function () { var n = 0; Object.keys(CITY.tiles).forEach(function (k) { CITY.tiles[k].blds.forEach(function (b) { if (b.wall) n++; }); }); return n; }, route: function () { return ROUTE; }, sitAt: sitAt, zone: function (id) { return ZONES.filter(function (z) { return z.id === id; })[0]; } };
  window.addEventListener("beforeunload", save);
  document.addEventListener("visibilitychange", function () { if (document.hidden) save(); });
})();
