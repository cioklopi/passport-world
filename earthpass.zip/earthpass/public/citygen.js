/* EarthPass City: our own designed city (islands, bridges, districts) built in the same tile format the game streams.
   Coordinates: metres from the city centre, x = east, z = south. Everything is deterministic for a city code. */
(function (root) {
  "use strict";
  var TILE = 250;
  function mul(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; var t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  function hstr(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }

  /* ---------- geometry ---------- */
  function smooth(ctrl, step) {
    var out = [], n = ctrl.length;
    for (var i = 0; i < n; i++) {
      var p0 = ctrl[(i - 1 + n) % n], p1 = ctrl[i], p2 = ctrl[(i + 1) % n], p3 = ctrl[(i + 2) % n];
      var L = Math.hypot(p2[0] - p1[0], p2[1] - p1[1]), m = Math.max(2, Math.ceil(L / step));
      for (var k = 0; k < m; k++) {
        var t = k / m, t2 = t * t, t3 = t2 * t;
        out.push([0.5 * (2 * p1[0] + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
          0.5 * (2 * p1[1] + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)]);
      }
    }
    return out;
  }
  function smoothOpen(ctrl, step) {
    var out = [], n = ctrl.length;
    for (var i = 0; i < n - 1; i++) {
      var p0 = ctrl[Math.max(0, i - 1)], p1 = ctrl[i], p2 = ctrl[i + 1], p3 = ctrl[Math.min(n - 1, i + 2)];
      var L = Math.hypot(p2[0] - p1[0], p2[1] - p1[1]), m = Math.max(1, Math.ceil(L / step));
      for (var k = 0; k < m; k++) {
        var t = k / m, t2 = t * t, t3 = t2 * t;
        out.push([0.5 * (2 * p1[0] + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
          0.5 * (2 * p1[1] + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)]);
      }
    }
    out.push(ctrl[n - 1].slice());
    return out;
  }
  function area(P) { var s = 0; for (var i = 0, n = P.length; i < n; i++) { var a = P[i], b = P[(i + 1) % n]; s += a[0] * b[1] - b[0] * a[1]; } return s / 2; }
  function inPoly(P, x, z) { var c = false; for (var i = 0, j = P.length - 1; i < P.length; j = i++) { var xi = P[i][0], zi = P[i][1], xj = P[j][0], zj = P[j][1]; if (((zi > z) !== (zj > z)) && (x < (xj - xi) * (z - zi) / (zj - zi) + xi)) c = !c; } return c; }
  function pidx(P) {
    var bb = bboxOf(P), RH = 10, rows = [], nr = Math.max(1, Math.ceil((bb[3] - bb[1]) / RH) + 1);
    for (var r = 0; r < nr; r++) rows.push([]);
    for (var i = 0, j = P.length - 1; i < P.length; j = i++) { var z1 = Math.min(P[i][1], P[j][1]), z2 = Math.max(P[i][1], P[j][1]); for (var r2 = Math.max(0, Math.floor((z1 - bb[1]) / RH)); r2 <= Math.min(nr - 1, Math.floor((z2 - bb[1]) / RH)); r2++) rows[r2].push(P[i][0], P[i][1], P[j][0], P[j][1]); }
    return { bb: bb, P: P, test: function (x, z) {
      if (x < bb[0] || x > bb[2] || z < bb[1] || z > bb[3]) return false;
      var E = rows[Math.floor((z - bb[1]) / RH)], c = false; if (!E) return false;
      for (var k = 0; k < E.length; k += 4) { var xi = E[k], zi = E[k + 1], xj = E[k + 2], zj = E[k + 3]; if (((zi > z) !== (zj > z)) && (x < (xj - xi) * (z - zi) / (zj - zi) + xi)) c = !c; }
      return c; } };
  }
  function bboxOf(P) { var b = [1e9, 1e9, -1e9, -1e9]; P.forEach(function (p) { if (p[0] < b[0]) b[0] = p[0]; if (p[1] < b[1]) b[1] = p[1]; if (p[0] > b[2]) b[2] = p[0]; if (p[1] > b[3]) b[3] = p[1]; }); return b; }
  /* move every vertex inward (d > 0) along the averaged edge normal; fine for smooth outlines */
  function offset(P, d) {
    var n = P.length, sg = area(P) > 0 ? 1 : -1, out = [];
    for (var i = 0; i < n; i++) {
      var a = P[(i - 1 + n) % n], b = P[i], c = P[(i + 1) % n];
      var e1x = b[0] - a[0], e1z = b[1] - a[1], l1 = Math.hypot(e1x, e1z) || 1, e2x = c[0] - b[0], e2z = c[1] - b[1], l2 = Math.hypot(e2x, e2z) || 1;
      var n1x = -e1z / l1 * sg, n1z = e1x / l1 * sg, n2x = -e2z / l2 * sg, n2z = e2x / l2 * sg, nx = n1x + n2x, nz = n1z + n2z, nl = Math.hypot(nx, nz) || 1; nx /= nl; nz /= nl;
      var k = d / Math.max(0.55, nx * n1x + nz * n1z); out.push([b[0] + nx * k, b[1] + nz * k]);
    }
    return out;
  }
  /* wobble a coastline so it looks natural */
  function wobble(P, amp, rnd) {
    if (!amp) return P;
    var ph = [rnd() * 6.28, rnd() * 6.28, rnd() * 6.28], sg = area(P) > 0 ? 1 : -1, n = P.length, acc = 0, out = [];
    for (var i = 0; i < n; i++) {
      var a = P[(i - 1 + n) % n], c = P[(i + 1) % n], tx = c[0] - a[0], tz = c[1] - a[1], tl = Math.hypot(tx, tz) || 1;
      if (i) acc += Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]);
      var w = amp * (0.55 * Math.sin(acc / 130 + ph[0]) + 0.3 * Math.sin(acc / 57 + ph[1]) + 0.15 * Math.sin(acc / 23 + ph[2]));
      out.push([P[i][0] - tz / tl * sg * w, P[i][1] + tx / tl * sg * w]);
    }
    return out;
  }
  function segDist(px, pz, ax, az, bx, bz) { var ex = bx - ax, ez = bz - az, l2 = ex * ex + ez * ez || 1e-9, t = Math.max(0, Math.min(1, ((px - ax) * ex + (pz - az) * ez) / l2)); return Math.hypot(px - ax - ex * t, pz - az - ez * t); }
  function segX(ax, az, bx, bz, cx, cz, dx, dz) {
    var rx = bx - ax, rz = bz - az, sx = dx - cx, sz = dz - cz, den = rx * sz - rz * sx; if (Math.abs(den) < 1e-9) return null;
    var t = ((cx - ax) * sz - (cz - az) * sx) / den, u = ((cx - ax) * rz - (cz - az) * rx) / den;
    if (t < -1e-6 || t > 1 + 1e-6 || u < -1e-6 || u > 1 + 1e-6) return null; return [t, u];
  }
  function clipRect(P, x1, z1, x2, z2) {
    var E = [[function (p) { return p[0] >= x1; }, function (a, b) { var t = (x1 - a[0]) / (b[0] - a[0]); return [x1, a[1] + t * (b[1] - a[1])]; }],
      [function (p) { return p[0] <= x2; }, function (a, b) { var t = (x2 - a[0]) / (b[0] - a[0]); return [x2, a[1] + t * (b[1] - a[1])]; }],
      [function (p) { return p[1] >= z1; }, function (a, b) { var t = (z1 - a[1]) / (b[1] - a[1]); return [a[0] + t * (b[0] - a[0]), z1]; }],
      [function (p) { return p[1] <= z2; }, function (a, b) { var t = (z2 - a[1]) / (b[1] - a[1]); return [a[0] + t * (b[0] - a[0]), z2]; }]];
    var out = P;
    for (var e = 0; e < 4; e++) { var inp = out; out = []; if (!inp.length) break; var ins = E[e][0], cut = E[e][1];
      for (var i = 0; i < inp.length; i++) { var a = inp[(i + inp.length - 1) % inp.length], b = inp[i]; if (ins(b)) { if (!ins(a)) out.push(cut(a, b)); out.push(b); } else if (ins(a)) out.push(cut(a, b)); } }
    return out;
  }
  function flat(P) { var o = []; P.forEach(function (q) { o.push(Math.round(q[0] * 10) / 10, Math.round(q[1] * 10) / 10); }); return o; }
  function plen(P) { var s = 0; for (var i = 1; i < P.length; i++) s += Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]); return s; }
  /* keep the parts of a polyline for which inside(x, z) holds; ends are found exactly by bisection */
  function clipLine(pts, inside, step) {
    var S = [pts[0]];
    for (var i = 1; i < pts.length; i++) { var a = pts[i - 1], b = pts[i], L = Math.hypot(b[0] - a[0], b[1] - a[1]), m = Math.max(1, Math.ceil(L / step)); for (var k = 1; k <= m; k++) S.push([a[0] + (b[0] - a[0]) * k / m, a[1] + (b[1] - a[1]) * k / m]); }
    var fl = S.map(function (p) { return inside(p[0], p[1]); }), out = [], cur = null;
    function edge(a, b, aIn) { var lo = 0, hi = 1; for (var it = 0; it < 22; it++) { var mid = (lo + hi) / 2, x = a[0] + (b[0] - a[0]) * mid, z = a[1] + (b[1] - a[1]) * mid; if (inside(x, z) === aIn) lo = mid; else hi = mid; } var t = aIn ? lo : hi; return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]; }
    for (var j = 0; j < S.length; j++) {
      if (fl[j]) { if (!cur) { cur = j > 0 ? [edge(S[j - 1], S[j], false)] : []; } cur.push(S[j]); }
      else if (cur) { cur.push(edge(S[j - 1], S[j], true)); out.push(cur); cur = null; }
    }
    if (cur) out.push(cur);
    /* drop the extra sample points again on straight runs */
    return out.map(function (p) { return simplify(p, 0.05); }).filter(function (p) { return p.length >= 2; });
  }
  function simplify(P, tol) {
    if (P.length < 3) return P; var out = [P[0]];
    for (var i = 1; i < P.length - 1; i++) { var a = out[out.length - 1], b = P[i], c = P[i + 1]; if (segDist(b[0], b[1], a[0], a[1], c[0], c[1]) > tol) out.push(b); }
    out.push(P[P.length - 1]); return out;
  }

  /* ---------- the design: land masses, districts, highways ---------- */
  var RW = { 0: 14, 1: 11, 2: 9, 3: 7.5, 4: 4.5, 5: 6, 6: 2.4 };
  function baseDesign() {
    return {
      lands: [
        { id: "ML", wob: 16, ctrl: [[-2300, -2250], [-1760, -2280], [-1500, -1900], [-1620, -1450], [-1480, -1000], [-1560, -500], [-1500, 0], [-1590, 500], [-1480, 1000], [-1320, 1450], [-900, 1720], [-450, 1790], [-60, 1840], [80, 2000], [40, 2280], [-2300, 2290]] },
        { id: "CI", wob: 7, ctrl: [[-1250, -1600], [-700, -1680], [-100, -1630], [215, -1460], [255, -900], [205, -300], [250, 300], [225, 900], [160, 1290], [-300, 1380], [-900, 1335], [-1280, 1150], [-1325, 500], [-1250, -200], [-1335, -900], [-1310, -1350]] },
        { id: "EI", wob: 12, ctrl: [[560, -1500], [1100, -1585], [1700, -1460], [2050, -1100], [2075, -500], [2072, 0], [2090, 420], [1950, 800], [1500, 945], [1000, 905], [610, 830], [495, 400], [545, -200], [480, -800]] },
        { id: "SI", wob: 10, ctrl: [[420, 1350], [900, 1250], [1500, 1285], [2000, 1300], [2255, 1560], [2280, 2000], [2100, 2270], [1500, 2250], [900, 2275], [430, 2200], [385, 1800]] },
        { id: "NI", wob: 14, ctrl: [[-720, -2270], [0, -2300], [700, -2250], [1200, -2150], [1160, -1910], [600, -1860], [0, -1900], [-600, -1950], [-820, -2100]] },
        { id: "LR", wob: 4, ctrl: [[-560, 1520], [-480, 1490], [-430, 1550], [-470, 1620], [-550, 1610]] }
      ],
      /* districts: grid frames inside a land, cut by roads (half planes) */
      districts: [
        { id: "mid", land: "CI", name: "Midtown", type: "midtown", ang: 0, ou: -1190, su: 170, ov: 0, sv: 80, hp: [[0, -1, 0]], avEvery: 1, warp: 0, label: [-420, -520, 1] },
        { id: "dt", land: "CI", name: "Downtown", type: "downtown", ang: 0, ou: -1190, su: 170, ov: 0, sv: 80, hp: [[0, 1, 0]], avEvery: 1, warp: 0, label: [-520, 760, 1] },
        { id: "old", land: "EI", name: "Old Town", type: "oldtown", ang: 0.32, ou: 0, su: 72, ov: 0, sv: 66, hp: [[0, -1, 0], [-1, 0, -1350]], avEvery: 4, warp: 22, label: [920, -820, 1] },
        { id: "bay", land: "EI", name: "Bayside", type: "bayside", ang: -0.18, ou: 20, su: 110, ov: 10, sv: 88, hp: [[0, -1, 0], [1, 0, 1350]], avEvery: 3, warp: 0, label: [1720, -700, 1] },
        { id: "beach", land: "EI", name: "Ocean Beach", type: "beach", ang: 0, ou: 40, su: 120, ov: 0, sv: 95, hp: [[0, 1, 0]], avEvery: 3, warp: 6, label: [1350, 520, 1] },
        { id: "harbor", land: "SI", name: "Harbor", type: "harbor", ang: 0.06, ou: 0, su: 150, ov: 0, sv: 120, hp: [], avEvery: 2, warp: 0, label: [1000, 1800, 1] },
        { id: "hill", land: "NI", name: "Hill Isle", type: "villas", ang: 0.12, ou: 0, su: 120, ov: 0, sv: 95, hp: [], avEvery: 3, warp: 26, label: [250, -2080, 1] },
        { id: "whills", land: "ML", name: "West Hills", type: "hills", ang: 0.4, ou: 0, su: 160, ov: 0, sv: 120, hp: [[0, -1, 1100]], avEvery: 3, warp: 34, label: [-1950, -1650, 1] },
        { id: "west", land: "ML", name: "Westside", type: "suburb", ang: 0.22, ou: 0, su: 62, ov: 0, sv: 118, hp: [[0, 1, -1100], [0, -1, -900]], avEvery: 4, warp: 10, label: [-1950, -150, 1] },
        { id: "iron", land: "ML", name: "Ironworks", type: "industrial", ang: -0.12, ou: 0, su: 140, ov: 0, sv: 105, hp: [[0, 1, 900]], avEvery: 2, warp: 0, label: [-1250, 1950, 1] }
      ],
      /* specials: areas the game builds itself (no buildings or grid streets inside) */
      specials: {
        spaceport: { x: 1990, z: 1930, poly: [[1740, 1560], [2260, 1560], [2260, 2260], [1740, 2260]], name: "Cape Liberty Spaceport" },
        stadium: { x: 1010, z: 250, rx: 78, rz: 58, name: "EarthPass Arena" },
        park: { poly: [[-1020, -1360], [-510, -1360], [-510, -800], [-1020, -800]], name: "Central Park" },
        hall: { poly: [[-340, -240], [-170, -240], [-170, -80], [-340, -80]], name: "City Hall Plaza" },
        lighthouse: { x: -495, z: 1560, name: "Liberty Rock Lighthouse" }
      },
      cuts: [
        { land: "EI", n: "Bayside Boulevard", c: 1, w: 11, pts: [[1350, -1800], [1350, 0]] },
        { land: "ML", n: "Hill Road", c: 2, w: 9, pts: [[-2500, -1100], [-1200, -1100]] },
        { land: "ML", n: "Mill Road", c: 2, w: 9, pts: [[-2500, 900], [-1600, 900]] }
      ],
      highways: [
        { n: "Central Avenue", c: 1, w: 14, pts: [[-2500, 0], [-1500, 0], [-1300, 0], [250, 0], [500, 0], [2300, 0]] },
        { n: "Harbor Expressway", c: 0, w: 14, s: 60, pts: [[-1950, -2420], [-1985, -1500], [-1930, -800], [-1975, 0], [-1925, 900], [-1800, 1650], [-1450, 2000], [-700, 2060], [0, 2010], [250, 2000], [520, 2000], [900, 2060], [1150, 2200], [1250, 2420]] },
        { n: "Union Bridge Road", c: 1, w: 11, pts: [[-1300, -1000], [-1520, -1000], [-1720, -1000]], toRingOf: ["CI", null] },
        { n: "Mill Bridge Road", c: 1, w: 11, pts: [[-1300, 900], [-1500, 900], [-1700, 900]], toRingOf: ["CI", null] },
        { n: "North Bridge", c: 1, w: 11, pts: [[-170, -1480], [-170, -1660], [-170, -1880], [-170, -2000]], toRingOf: ["CI", "NI"] },
        { n: "Isle Bridge", c: 2, w: 9, pts: [[980, -1420], [990, -1600], [1000, -1860], [1000, -1990]], toRingOf: ["EI", "NI"] },
        { n: "South Bridge", c: 1, w: 11, pts: [[-170, 1200], [-170, 1400], [-100, 1480], [180, 1520], [420, 1560], [600, 1600]], toRingOf: ["CI", "SI"] },
        { n: "Beach Bridge", c: 1, w: 11, pts: [[1240, 700], [1240, 960], [1240, 1270], [1240, 1420]], toRingOf: ["EI", "SI"] },
        { n: "Launch Road", c: 2, w: 9, pts: [[1580, 1700], [1760, 1790], [1900, 1880], [1990, 1930]], noTrim: true }
      ],
      names: {
        mid: ["Avenue", "Street"], dt: ["Avenue", "Street"],
        old: ["Baker Street", "Mill Lane", "Chapel Road", "Market Street", "Fisher Lane", "Rope Walk", "Tanner Street", "Bell Street", "Copper Lane", "Old Quay Road", "Lantern Street", "Weaver Lane", "Abbey Road", "Clock Street", "Cobble Lane", "Saddle Street"],
        bay: ["Bay Street", "Harbor View", "Tide Road", "Marina Way", "Pier Street", "Gull Road", "Breeze Avenue", "Sail Street", "Anchor Way", "Lagoon Road", "Reef Street", "Compass Road"],
        beach: ["Palm Avenue", "Coral Way", "Sunset Boulevard", "Sand Street", "Dune Road", "Shell Avenue", "Surf Street", "Lido Way"],
        harbor: ["Dock Road", "Crane Street", "Cargo Way", "Freight Avenue", "Quay Street", "Container Road", "Wharf Street", "Pilot Way"],
        hill: ["Hilltop Drive", "Vine Road", "Laurel Way", "Summit Road", "Cedar Drive", "Oak Ridge"],
        whills: ["Ridge Road", "Pine Way", "Forest Drive", "Valley Road", "Hawk Lane"],
        west: ["Maple Street", "Elm Street", "Birch Lane", "Willow Way", "Rose Street", "Garden Lane", "Lilac Road", "Aspen Way", "Holly Street", "Ivy Lane", "Juniper Road", "Poplar Street", "Hazel Way", "Linden Street", "Spruce Lane", "Cherry Road"],
        iron: ["Foundry Road", "Steel Street", "Forge Way", "Rail Road", "Smelter Lane", "Kiln Street", "Anvil Road", "Boiler Way"]
      },
      shore: { ML: "West Shore Drive", CI: "River Drive", EI: "Ocean Drive", SI: "Harbor Drive", NI: "Isle Drive", LR: null }
    };
  }
  /* every city gets its own layout: the same islands, moved, reshaped and with other districts */
  function designFor(code, rnd) {
    var D = baseDesign(); if (code === "JFK") return D;
    function jit(p, a, keepEast) { return [p[0] + (keepEast && p[0] > 1900 && Math.abs(p[1]) < 700 ? 0 : (rnd() - 0.5) * a), p[1] + (rnd() - 0.5) * a]; }
    D.lands.forEach(function (L) { if (L.id === "LR") return; L.ctrl = L.ctrl.map(function (p) { return jit(p, 140, true); }); L.wob = 8 + rnd() * 18; });
    var swaps = [["oldtown", "bayside"], ["suburb", "hills"], ["midtown", "downtown"]];
    D.districts.forEach(function (d) { d.ang = d.ang + (rnd() - 0.5) * 0.3; d.warp = Math.max(0, d.warp + (rnd() - 0.4) * 14); if (rnd() < 0.3) swaps.forEach(function (s) { if (d.type === s[0]) d.type = s[1]; else if (d.type === s[1]) d.type = s[0]; }); });
    return D;
  }

  /* ---------- road graph: split crossing lines, snap T-junctions, give every junction one node id ---------- */
  function buildGraph(lines) {
    var C = 60, grid = {}, segs = [];
    lines.forEach(function (L, li) { for (var i = 1; i < L.pts.length; i++) { var a = L.pts[i - 1], b = L.pts[i]; var s = { li: li, si: i - 1, ax: a[0], az: a[1], bx: b[0], bz: b[1] }; segs.push(s);
      for (var gx = Math.floor(Math.min(a[0], b[0]) / C); gx <= Math.floor(Math.max(a[0], b[0]) / C); gx++) for (var gz = Math.floor(Math.min(a[1], b[1]) / C); gz <= Math.floor(Math.max(a[1], b[1]) / C); gz++) (grid[gx + "," + gz] || (grid[gx + "," + gz] = [])).push(s); } });
    var splits = lines.map(function (L) { return L.pts.map(function () { return []; }); });
    /* T-junctions: a line end close to another line snaps onto it */
    lines.forEach(function (L, li) {
      [0, L.pts.length - 1].forEach(function (pi) {
        var p = L.pts[pi], best = null, bd = 2.2;
        var cell = grid[Math.floor(p[0] / C) + "," + Math.floor(p[1] / C)] || [];
        for (var gx = -1; gx <= 1; gx++) for (var gz = -1; gz <= 1; gz++) (grid[(Math.floor(p[0] / C) + gx) + "," + (Math.floor(p[1] / C) + gz)] || []).forEach(function (s) {
          if (s.li === li) return; var d = segDist(p[0], p[1], s.ax, s.az, s.bx, s.bz); if (d < bd) { bd = d; best = s; } });
        if (best) { var ex = best.bx - best.ax, ez = best.bz - best.az, l2 = ex * ex + ez * ez || 1, t = Math.max(0, Math.min(1, ((p[0] - best.ax) * ex + (p[1] - best.az) * ez) / l2)); p[0] = best.ax + ex * t; p[1] = best.az + ez * t; splits[best.li][best.si].push(t); }
      });
    });
    /* crossings */
    var seen = {};
    Object.keys(grid).forEach(function (k) {
      var A = grid[k];
      for (var i = 0; i < A.length; i++) for (var j = i + 1; j < A.length; j++) {
        var s = A[i], q = A[j]; if (s.li === q.li && Math.abs(s.si - q.si) < 2) continue;
        var key = s.li + ":" + s.si + "|" + q.li + ":" + q.si; if (seen[key]) continue; seen[key] = 1;
        var r = segX(s.ax, s.az, s.bx, s.bz, q.ax, q.az, q.bx, q.bz); if (!r) continue;
        splits[s.li][s.si].push(r[0]); splits[q.li][q.si].push(r[1]);
      }
    });
    /* nodes by position */
    var NODES = {}, nid = 1, nodePos = {};
    function node(x, z) {
      var kx = Math.round(x * 2), kz = Math.round(z * 2);
      for (var i = -1; i <= 1; i++) for (var j = -1; j <= 1; j++) { var id = NODES[(kx + i) + "," + (kz + j)]; if (id && Math.hypot(nodePos[id][0] - x, nodePos[id][1] - z) < 0.3) return id; }
      var k = kx + "," + kz; if (NODES[k]) return NODES[k]; NODES[k] = nid++; nodePos[NODES[k]] = [x, z]; return NODES[k];
    }
    var edges = [];
    lines.forEach(function (L, li) {
      var cur = [L.pts[0]], curA = node(L.pts[0][0], L.pts[0][1]);
      for (var i = 1; i < L.pts.length; i++) {
        var a = L.pts[i - 1], b = L.pts[i], ts = splits[li][i - 1].filter(function (t) { return t > 1e-4 && t < 1 - 1e-4; }).sort(function (x, y) { return x - y; });
        ts.forEach(function (t) { var p = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t], id = node(p[0], p[1]); cur.push(p); if (id !== curA) edges.push({ a: curA, b: id, pts: cur, L: L }); cur = [p]; curA = id; });
        cur.push(b);
        if (i === L.pts.length - 1 || splits[li][i - 1].some(function (t) { return t >= 1 - 1e-4; }) || (splits[li][i] && splits[li][i].some(function (t) { return t <= 1e-4; }))) {
          var idb = node(b[0], b[1]); if (idb !== curA && plen(cur) > 0.3) edges.push({ a: curA, b: idb, pts: cur, L: L }); cur = [b]; curA = idb;
        }
      }
    });
    /* drop short dead-end stubs left by clipping */
    for (var pass = 0; pass < 4; pass++) {
      var deg = {}; edges.forEach(function (e) { deg[e.a] = (deg[e.a] || 0) + 1; deg[e.b] = (deg[e.b] || 0) + 1; });
      var before = edges.length;
      edges = edges.filter(function (e) { var L = plen(e.pts); return !((deg[e.a] === 1 || deg[e.b] === 1) && L < 26 && !e.L.keep); });
      if (edges.length === before) break;
    }
    return { edges: edges, nodePos: nodePos, node: node };
  }

  /* ---------- the generator ---------- */
  function generate(code, opt) {
    opt = opt || {};
    var t0 = Date.now(), seed = hstr("EarthPass:" + code), rnd = mul(seed), D = designFor(code, rnd), HALF = 2400;
    /* a building-free strip south of Central Avenue for the elevated metro */
    var CORR = [[-2400, -1, 2400, 28]];
    /* land outlines */
    var LAND = {}, LANDS = [];
    D.lands.forEach(function (L) { var P = wobble(smooth(L.ctrl, 18), L.wob, rnd); if (area(P) < 0) P.reverse(); var o = { id: L.id, P: P, bb: bboxOf(P), ix: pidx(P) }; LAND[L.id] = o; LANDS.push(o); });
    /* piers along the harbor coast: fingers of land into the water */
    var PIERS = [];
    (function () {
      var si = LAND.SI; if (!si) return;
      for (var x = 520; x < 1560; x += 120) {
        /* find the north coast at this x */
        var zc = null; for (var z = 1150; z < 1500; z += 2) if (inPoly(si.P, x, z)) { zc = z; break; } if (zc === null) continue;
        var P = [[x - 16, zc + 20], [x + 16, zc + 20], [x + 16, zc - 135], [x - 16, zc - 135]]; P.reverse(); if (area(P) < 0) P.reverse();
        PIERS.push({ id: "pier", P: P, bb: bboxOf(P), pier: true, ix: pidx(P) }); }
    })();
    PIERS.forEach(function (p) { LANDS.push(p); });
    function isLandPre(p) { return isLand(p[0], p[1]); }
    function isLand(x, z) { for (var i = 0; i < LANDS.length; i++) if (LANDS[i].ix.test(x, z)) return true; return false; }
    /* coastal ring roads, 30 m in from the shore */
    var RING = {}; LANDS.forEach(function (L) { if (L.pier || L.id === "LR") return; RING[L.id] = offset(L.P, 30); });
    var INNER = {}, INIX = {}; LANDS.forEach(function (L) { if (RING[L.id]) { INNER[L.id] = RING[L.id]; INIX[L.id] = pidx(RING[L.id]); } });

    var SP = D.specials, reserved = [];
    if (SP.spaceport) reserved.push(SP.spaceport.poly);
    var STLOOP = null; if (SP.stadium) { STLOOP = []; for (var a = 0; a < 40; a++) STLOOP.push([SP.stadium.x + Math.cos(a / 40 * 6.2832) * (SP.stadium.rx + 22), SP.stadium.z + Math.sin(a / 40 * 6.2832) * (SP.stadium.rz + 22)]); reserved.push(STLOOP); }
    var park = SP.park ? SP.park.poly : null, hall = SP.hall ? SP.hall.poly : null;
    var RESIX = null; function inReserved(x, z) { if (!RESIX) RESIX = reserved.map(pidx); for (var i = 0; i < RESIX.length; i++) if (RESIX[i].test(x, z)) return true; return false; }

    /* ---------- road lines ---------- */
    var lines = [];
    function addLine(pts, c, w, n, extra) { if (pts.length < 2 || plen(pts) < 8) return null; var L = { pts: pts, c: c, w: w || RW[c], n: n }; if (extra) for (var k in extra) L[k] = extra[k]; lines.push(L); return L; }
    /* shore drives */
    Object.keys(RING).forEach(function (id) { var R = RING[id].slice(); R.push(R[0].slice()); addLine(R, 2, 9, D.shore[id] || "Shore Drive", { keep: true, ring: id }); });
    /* highways: their parts on land plus bridges over the water between; an end out at sea, or an end named in toRingOf,
       is cut where the line first meets that shore drive so every bridge lands on a road */
    function ringHits(pts, ids) {
      var hits = [], acc = 0;
      for (var i = 1; i < pts.length; i++) { var a = pts[i - 1], b = pts[i], sl = Math.hypot(b[0] - a[0], b[1] - a[1]);
        ids.forEach(function (id) { var R = RING[id]; if (!R) return; for (var k = 0; k < R.length; k++) { var c = R[k], d2 = R[(k + 1) % R.length], x = segX(a[0], a[1], b[0], b[1], c[0], c[1], d2[0], d2[1]); if (x) hits.push({ s: acc + x[0] * sl, p: [a[0] + (b[0] - a[0]) * x[0], a[1] + (b[1] - a[1]) * x[0]], id: id }); } });
        acc += sl; }
      return hits.sort(function (p, q) { return p.s - q.s; });
    }
    function cutAt(pts, s0, s1) { var out = [], acc = 0; for (var i = 1; i < pts.length; i++) { var a = pts[i - 1], b = pts[i], sl = Math.hypot(b[0] - a[0], b[1] - a[1]); for (var k = 0; k <= 20; k++) { var s = acc + sl * k / 20; if (s >= s0 - 1e-6 && s <= s1 + 1e-6) { var p = [a[0] + (b[0] - a[0]) * k / 20, a[1] + (b[1] - a[1]) * k / 20]; if (!out.length || Math.hypot(p[0] - out[out.length - 1][0], p[1] - out[out.length - 1][1]) > 0.01) out.push(p); } } acc += sl; } return simplify(out, 0.02); }
    D.highways.forEach(function (H) {
      var pts = H.s ? smoothOpen(H.pts, H.s) : H.pts.map(function (p) { return p.slice(); });
      if (!H.noTrim) {
        var all = ringHits(pts, Object.keys(RING)), L0 = plen(pts), s0 = 0, s1 = L0;
        var st = H.toRingOf ? H.toRingOf[0] : null, en = H.toRingOf ? H.toRingOf[1] : null;
        if (st) { var h1 = all.filter(function (h) { return h.id === st; }); if (h1.length) s0 = h1[h1.length - 1].s; }
        else if (!isLandPre(pts[0])) { if (all.length) s0 = all[0].s; }
        if (en) { var h2 = all.filter(function (h) { return h.id === en; }); if (h2.length) s1 = h2[0].s; }
        else if (!isLandPre(pts[pts.length - 1])) { if (all.length) s1 = all[all.length - 1].s; }
        if (s1 - s0 < 10) return;
        var cut = cutAt(pts, s0, s1), hs = all.filter(function (h) { return Math.abs(h.s - s0) < 0.01 || Math.abs(h.s - s1) < 0.01; });
        hs.forEach(function (h) { if (Math.abs(h.s - s0) < 0.01) cut[0] = h.p.slice(); else cut[cut.length - 1] = h.p.slice(); });
        pts = cut;
      }
      addLine(pts, H.c, H.w, H.n, { hw: true, keep: true });
    });
    /* district boundary roads */
    (D.cuts || []).forEach(function (C) { var R = RING[C.land]; if (!R) return; var rb2 = bboxOf(R); clipLine(C.pts, function (x, z) { return x >= rb2[0] && x <= rb2[2] && z >= rb2[1] && z <= rb2[3] && inPoly(R, x, z); }, 3).forEach(function (pp) { addLine(pp, C.c, C.w, C.n, { keep: true }); }); });
    /* district grids */
    var DIST = [];
    D.districts.forEach(function (d) {
      var land = LAND[d.land], ring = INNER[d.land], rix = INIX[d.land]; if (!land || !ring) return;
      var ca = Math.cos(d.ang), sa = Math.sin(d.ang), bb = bboxOf(ring), rb = bb;
      var cx = (bb[0] + bb[2]) / 2, cz = (bb[1] + bb[3]) / 2;
      function W(u, v) { var du = 0, dv = 0; if (d.warp) { du = d.warp * Math.sin(v / 173 + d.ou * 0.01 + 1.3) + d.warp * 0.45 * Math.sin(v / 61 + 0.7); dv = d.warp * Math.sin(u / 151 + 2.1) + d.warp * 0.4 * Math.sin(u / 67 + 0.2); } var uu = u + du, vv = v + dv; return [uu * ca - vv * sa, uu * sa + vv * ca]; }
      function inside(x, z) {
        if (!rix.test(x, z)) return false;
        for (var j = 0; j < d.hp.length; j++) { var q = d.hp[j]; if (q[0] * x + q[1] * z < q[2]) return false; }
        if (inReserved(x, z)) return false;
        if (park && d.id === "mid" && inPoly(park, x, z)) return false;
        if (hall && (d.id === "mid") && inPoly(hall, x, z)) return false;
        return true;
      }
      /* u/v ranges that cover the district's box */
      var R = Math.hypot(bb[2] - bb[0], bb[3] - bb[1]) / 2 + 60, uc = cx * ca + cz * sa, vc = -cx * sa + cz * ca;
      var U = [], V = [];
      for (var u = Math.floor((uc - R - d.ou) / d.su) * d.su + d.ou; u <= uc + R; u += d.su) U.push(u);
      for (var v = Math.floor((vc - R - d.ov) / d.sv) * d.sv + d.ov; v <= vc + R; v += d.sv) V.push(v);
      var DD = { d: d, W: W, inside: inside, U: U, V: V, ca: ca, sa: sa, uLine: {}, vLine: {} }; DIST.push(DD);
      var step = d.warp ? 12 : 1e9, nm = D.names[d.id] || [], ni = 0;
      function name(kind, i) {
        if (d.id === "mid" || d.id === "dt") { if (kind === "u") { var k = Math.round((U[i] + 1190) / 170) + 1; return ord(k) + " Avenue"; } var s = Math.round(V[i] / 80); return s === 0 ? "Central Avenue" : (s < 0 ? ord(-s) + " Street" : ord(s) + " Street South"); }
        return nm.length ? nm[(ni++) % nm.length] + (ni > nm.length ? " " + (Math.floor((ni - 1) / nm.length) + 1) : "") : (d.name + " Road");
      }
      U.forEach(function (u0, i) {
        var pts = []; for (var v = V[0]; v <= V[V.length - 1] + 1; v += Math.min(step, V[V.length - 1] - V[0])) pts.push(W(u0, v));
        if (!d.warp) pts = [W(u0, V[0]), W(u0, V[V.length - 1])];
        var av = d.avEvery && (i % d.avEvery === 0), c = av ? (d.type === "suburb" || d.type === "villas" || d.type === "hills" ? 3 : 1) : 3, w = av && c === 1 ? 11 : (d.type === "suburb" || d.type === "villas" || d.type === "hills" ? 6.5 : 7.5);
        var nmU = name("u", i);
        clipLine(pts, inside, 3).forEach(function (pp) { if (plen(pp) > 30) { addLine(pp, c, w, nmU); DD.uLine[i] = w; } });
      });
      V.forEach(function (v0, j) {
        if ((d.id === "mid" || d.id === "dt") && Math.abs(v0) < 1) return; /* Central Avenue is already there */
        var pts = []; for (var u = U[0]; u <= U[U.length - 1] + 1; u += Math.min(step, U[U.length - 1] - U[0])) pts.push(W(u, v0));
        if (!d.warp) pts = [W(U[0], v0), W(U[U.length - 1], v0)];
        var av = d.type === "industrial" || d.type === "harbor" ? j % 3 === 0 : false, c = av ? 2 : 3, w = av ? 9 : (d.type === "suburb" || d.type === "villas" || d.type === "hills" ? 6.5 : 7.5);
        var nmV = name("v", j);
        clipLine(pts, inside, 3).forEach(function (pp) { if (plen(pp) > 30) { addLine(pp, c, w, nmV); DD.vLine[j] = w; } });
      });
    });
    /* roads around the special places */
    if (park) { var pk = park.concat([park[0]]).map(function (p) { return p.slice(); }); addLine(pk, 2, 9, "Park Drive", { keep: true }); }
    if (hall) { var hl = hall.concat([hall[0]]).map(function (p) { return p.slice(); }); addLine(hl, 3, 7.5, "Hall Square", { keep: true }); }
    if (STLOOP) { var st = STLOOP.map(function (p) { return p.slice(); }); st.push(st[0].slice()); addLine(st, 2, 9, "Arena Loop", { keep: true }); }
    if (SP.spaceport) { var sq = SP.spaceport.poly.map(function (p) { return p.slice(); }); sq.push(sq[0].slice()); addLine(sq, 2, 9, "Spaceport Loop", { keep: true }); }

    /* trim highway parts that run off the land into open sea (keep bridges: water between two land points) */
    var G = buildGraph(lines);
    /* ---------- chunk edges, mark bridges, give them ids ---------- */
    var ROADS = [], cid = 900000;
    G.edges.forEach(function (e) {
      var L = e.L, pts = e.pts;
      /* split at the shore so a bridge is its own piece */
      var parts = [], cur = [pts[0]], wet = !isLand(pts[0][0], pts[0][1]);
      for (var i = 1; i < pts.length; i++) {
        var a = pts[i - 1], b = pts[i], sl = Math.hypot(b[0] - a[0], b[1] - a[1]), m = Math.max(1, Math.ceil(sl / 4));
        for (var k = 1; k <= m; k++) {
          var x = a[0] + (b[0] - a[0]) * k / m, z = a[1] + (b[1] - a[1]) * k / m, w2 = !isLand(x, z);
          if (w2 !== wet) {
            var px = a[0] + (b[0] - a[0]) * (k - 1) / m, pz = a[1] + (b[1] - a[1]) * (k - 1) / m, lo = 0, hi = 1;
            for (var it = 0; it < 18; it++) { var mid = (lo + hi) / 2; if ((!isLand(px + (x - px) * mid, pz + (z - pz) * mid)) === wet) lo = mid; else hi = mid; }
            var cp = [px + (x - px) * lo, pz + (z - pz) * lo]; cur.push(cp); parts.push({ p: cur, wet: wet }); cur = [cp]; wet = w2;
          }
        }
        cur.push(b);
      }
      parts.push({ p: cur, wet: wet });
      /* tiny wet bits at a ragged shore are not bridges */
      parts.forEach(function (pt) { pt.len = plen(pt.p); });
      var ids = [e.a]; for (var q = 1; q < parts.length; q++) ids.push(cid++); ids.push(e.b);
      parts.forEach(function (pt, qi) {
        if (pt.wet && pt.len > 40 && !L.hw && !L.ring) return; /* a grid street that runs out over the sea is cut */
        var A = ids[qi], B = ids[qi + 1], P = simplify(pt.p, 0.02);
        /* chunks of at most 110 m */
        var Lp = plen(P), n = Math.max(1, Math.ceil(Lp / 110)), seg = Lp / n, out = [[P[0]]], acc = 0, target = seg;
        for (var j = 1; j < P.length; j++) {
          var a3 = P[j - 1], b3 = P[j], sl3 = Math.hypot(b3[0] - a3[0], b3[1] - a3[1]);
          while (acc + sl3 >= target - 1e-6 && out.length < n) { var tt = (target - acc) / (sl3 || 1), cp2 = [a3[0] + (b3[0] - a3[0]) * tt, a3[1] + (b3[1] - a3[1]) * tt]; out[out.length - 1].push(cp2); out.push([cp2]); target += seg; }
          out[out.length - 1].push(b3); acc += sl3;
        }
        var cids = [A]; for (var c2 = 1; c2 < out.length; c2++) cids.push(cid++); cids.push(B);
        out.forEach(function (op, ci) { op = op.filter(function (p, i2) { return i2 === 0 || Math.hypot(p[0] - op[i2 - 1][0], p[1] - op[i2 - 1][1]) > 0.05; }); if (op.length < 2) return;
          var r = { p: flat(op), w: L.w, c: L.c, d: L.c <= 4 ? 1 : 0, a: cids[ci], b: cids[ci + 1] }; if (L.n) r.n = L.n; if (pt.wet && pt.len >= 6) r.br = 1; ROADS.push(r); });
      });
    });
    /* road clearance index */
    var RC = 40, RG = {};
    ROADS.forEach(function (r) { var p = r.p; for (var i = 2; i < p.length; i += 2) { var s = [p[i - 2], p[i - 1], p[i], p[i + 1], r.w / 2]; for (var gx = Math.floor((Math.min(s[0], s[2]) - 12) / RC); gx <= Math.floor((Math.max(s[0], s[2]) + 12) / RC); gx++) for (var gz = Math.floor((Math.min(s[1], s[3]) - 12) / RC); gz <= Math.floor((Math.max(s[1], s[3]) + 12) / RC); gz++) (RG[gx + "," + gz] || (RG[gx + "," + gz] = [])).push(s); } });
    function clearOfRoads(P, extra) {
      var bb = bboxOf(P), hit = false;
      for (var gx = Math.floor((bb[0] - 12) / RC); gx <= Math.floor((bb[2] + 12) / RC) && !hit; gx++) for (var gz = Math.floor((bb[1] - 12) / RC); gz <= Math.floor((bb[3] + 12) / RC) && !hit; gz++) {
        var A = RG[gx + "," + gz]; if (!A) continue;
        for (var i = 0; i < A.length && !hit; i++) { var s = A[i], need = s[4] + extra;
          if (Math.min(s[0], s[2]) > bb[2] + need || Math.max(s[0], s[2]) < bb[0] - need || Math.min(s[1], s[3]) > bb[3] + need || Math.max(s[1], s[3]) < bb[1] - need) continue;
          if (inPoly(P, s[0], s[1]) || inPoly(P, s[2], s[3])) { hit = true; break; }
          for (var k = 0; k < P.length; k++) { var a = P[k], b = P[(k + 1) % P.length]; if (segDist(a[0], a[1], s[0], s[1], s[2], s[3]) < need || segDist(s[0], s[1], a[0], a[1], b[0], b[1]) < need || segDist(s[2], s[3], a[0], a[1], b[0], b[1]) < need || segX(a[0], a[1], b[0], b[1], s[0], s[1], s[2], s[3])) { hit = true; break; } }
        }
      }
      return !hit;
    }
    function onLandDeep(P, m) { for (var i = 0; i < P.length; i++) { var p = P[i]; if (!isLand(p[0], p[1])) return false; } var c = [0, 0]; P.forEach(function (p) { c[0] += p[0]; c[1] += p[1]; }); c[0] /= P.length; c[1] /= P.length; return isLand(c[0], c[1]); }

    /* ---------- buildings ---------- */
    var BLD = [], GREEN = [], PLAZA = [], SAND = [];
    function addB(P, h, k, extra) {
      if (area(P) < 0) P = P.slice().reverse();
      var b = { p: flat(P), h: Math.round(h * 10) / 10, k: k }; if (extra) for (var q in extra) if (extra[q] !== undefined) b[q] = extra[q]; BLD.push(b); return b;
    }
    var PAL = {
      brick: ["#8a4f3c", "#7c4636", "#965a42", "#6e4034", "#a0644a", "#874c3e"],
      pastel: ["#d9c7a6", "#e3d3b7", "#c9b79a", "#d8b9a0", "#b9c4b0", "#e0c9b0", "#c7cfd6", "#e4cfc0"],
      beach: ["#f2d6c0", "#bfe0dc", "#f4e3a6", "#e8c3d2", "#c9dff0", "#f1efe6", "#ffd9b0"],
      ind: ["#8c9198", "#6f7782", "#9a8f80", "#7e6a5a", "#5f6b75", "#a3a6aa"],
      cont: ["#b3322b", "#1f5fa8", "#2e7d4f", "#e07a1f", "#d4b21f", "#6b3fa0", "#c94f7c", "#3b8fb0"]
    };
    function pick(a) { return a[Math.floor(rnd() * a.length)]; }
    DIST.forEach(function (DD) {
      var d = DD.d, U = DD.U, V = DD.V;
      for (var i = 0; i < U.length - 1; i++) for (var j = 0; j < V.length - 1; j++) {
        var wl = DD.uLine[i] || 7.5, wr = DD.uLine[i + 1] || 7.5, wt = DD.vLine[j] || 7.5, wb = DD.vLine[j + 1] || 7.5;
        var setb = d.type === "suburb" || d.type === "villas" || d.type === "hills" ? 3.5 : 1.2;
        var u0 = U[i] + wl / 2 + 3.3 + setb, u1 = U[i + 1] - wr / 2 - 3.3 - setb, v0 = V[j] + wt / 2 + 3.3 + setb, v1 = V[j + 1] - wb / 2 - 3.3 - setb;
        if (u1 - u0 < 10 || v1 - v0 < 10) continue;
        var cu = (u0 + u1) / 2, cv = (v0 + v1) / 2, cw = DD.W(cu, cv);
        if (!DD.inside(cw[0], cw[1])) continue;
        lotsFor(DD, u0, u1, v0, v1, cw);
      }
    });
    function quad(DD, u0, u1, v0, v1) { return [DD.W(u0, v0), DD.W(u1, v0), DD.W(u1, v1), DD.W(u0, v1)]; }
    function inCorr(P) { var bb = bboxOf(P); for (var i = 0; i < CORR.length; i++) { var c = CORR[i]; if (bb[0] < c[2] && bb[2] > c[0] && bb[1] < c[3] && bb[3] > c[1]) return true; } return false; }
    function okFoot(DD, P, clr) { if (inCorr(P)) return false; for (var i = 0; i < P.length; i++) if (!DD.inside(P[i][0], P[i][1])) return false; return onLandDeep(P) && clearOfRoads(P, clr === undefined ? 3.4 : clr); }
    /* a lot in uv space: try it as drawn, then pulled in from the edges (a wide avenue or a highway next to it) */
    function fitLot(DD, u0, u1, v0, v1, minSide, clr) { for (var k = 0; k < 3; k++) { var m = k * 3.5, P = quad(DD, u0 + m, u1 - m, v0 + m, v1 - m); if (u1 - u0 - 2 * m < minSide || v1 - v0 - 2 * m < minSide) return null; if (okFoot(DD, P, clr)) return P; } return null; }
    function heightAt(x, z, base, peak, R, cx, cz) { var d2 = ((x - cx) * (x - cx) + (z - cz) * (z - cz)) / (R * R); return base + peak * Math.exp(-d2) ; }
    function lotsFor(DD, u0, u1, v0, v1, cw) {
      var d = DD.d, t = d.type, W = u1 - u0, H = v1 - v0, r = rnd();
      /* some blocks are parks or squares */
      var parkChance = t === "midtown" ? 0.05 : t === "downtown" ? 0.04 : t === "oldtown" ? 0.07 : t === "suburb" ? 0.05 : t === "hills" ? 0.45 : t === "villas" ? 0.12 : t === "beach" ? 0.08 : 0.02;
      if (r < parkChance) { var gp = quad(DD, u0 - 1, u1 + 1, v0 - 1, v1 + 1); if (okFoot(DD, gp, 2.6)) GREEN.push({ P: gp, k: t === "hills" ? 1 : 0 }); return; }
      if (t === "downtown" || t === "midtown") {
        if (r < parkChance + 0.05) { var pz = quad(DD, u0 - 1, u1 + 1, v0 - 1, v1 + 1); if (okFoot(DD, pz, 2.6)) PLAZA.push(pz); }
        var nu = W > 95 ? 3 : W > 55 ? 2 : 1, nv = H > 60 ? 2 : 1, gu = W / nu, gv = H / nv;
        for (var a = 0; a < nu; a++) for (var b = 0; b < nv; b++) {
          var lu0 = u0 + a * gu + 1.5, lu1 = u0 + (a + 1) * gu - 1.5, lv0 = v0 + b * gv + 1.5, lv1 = v0 + (b + 1) * gv - 1.5; if (lu1 - lu0 < 9 || lv1 - lv0 < 9) continue;
          var P = fitLot(DD, lu0, lu1, lv0, lv1, 9); if (!P) continue; var sh = (lu1 - lu0 - Math.hypot(P[1][0] - P[0][0], P[1][1] - P[0][1])) / 2; lu0 += sh; lu1 -= sh; lv0 += sh; lv1 -= sh;
          var c = DD.W((lu0 + lu1) / 2, (lv0 + lv1) / 2), h;
          if (t === "downtown") h = heightAt(c[0], c[1], 36, 230, 520, -560, 900) * (0.45 + rnd() * 0.75) + heightAt(c[0], c[1], 0, 120, 380, -120, 420) * rnd();
          else h = heightAt(c[0], c[1], 24, 120, 520, -480, -420) * (0.5 + rnd() * 0.7);
          h = Math.max(t === "downtown" ? 22 : 16, Math.min(390, h));
          if (h > 70 && rnd() < 0.55) {
            /* podium and a slimmer tower */
            addB(P, 14 + rnd() * 6, 2);
            var iu = (lu1 - lu0) * 0.18, iv = (lv1 - lv0) * 0.18, P2 = quad(DD, lu0 + iu, lu1 - iu, lv0 + iv, lv1 - iv); addB(P2, h, 2, rnd() < 0.3 ? { c: pick(["#9fb4c8", "#c8d2dc", "#7f95ab", "#b8c4cc"]) } : null);
          } else addB(P, h, rnd() < 0.7 ? 2 : 1, rnd() < 0.25 ? { c: pick(PAL.pastel) } : null);
        }
        return;
      }
      if (t === "oldtown" || t === "bayside" || t === "beach") {
        var depth = t === "oldtown" ? 11 + rnd() * 3 : 13 + rnd() * 4, wmin = t === "oldtown" ? 7 : 14, wmax = t === "oldtown" ? 13 : 26;
        if (W < depth * 2 + 4 || H < depth * 2 + 4) { var Q = quad(DD, u0, u1, v0, v1); if (okFoot(DD, Q)) addB(Q, t === "oldtown" ? 9 + rnd() * 8 : 14 + rnd() * 16, 1, { c: pick(t === "oldtown" ? PAL.brick : t === "beach" ? PAL.beach : PAL.pastel) }); return; }
        var hb = t === "oldtown" ? [9, 18] : t === "beach" ? [12, 46] : [14, 40];
        var rows = [[u0, u1, v0, v0 + depth], [u0, u1, v1 - depth, v1]], cols = [[u0, u0 + depth, v0 + depth, v1 - depth], [u1 - depth, u1, v0 + depth, v1 - depth]];
        rows.forEach(function (R) { var x = R[0]; while (x < R[1] - 4) { var ww = Math.min(R[1] - x, wmin + rnd() * (wmax - wmin)); if (R[1] - (x + ww) < wmin * 0.7) ww = R[1] - x; var P = quad(DD, x, x + ww - 0.3, R[2], R[3]); if (okFoot(DD, P)) addB(P, hb[0] + rnd() * (hb[1] - hb[0]), t === "beach" ? (rnd() < 0.5 ? 2 : 1) : 1, { c: pick(t === "oldtown" ? PAL.brick : t === "beach" ? PAL.beach : PAL.pastel) }); x += ww; } });
        cols.forEach(function (C) { var z = C[2]; while (z < C[3] - 4) { var hh = Math.min(C[3] - z, wmin + rnd() * (wmax - wmin)); if (C[3] - (z + hh) < wmin * 0.7) hh = C[3] - z; var P = quad(DD, C[0], C[1], z, z + hh - 0.3); if (okFoot(DD, P)) addB(P, hb[0] + rnd() * (hb[1] - hb[0]), 1, { c: pick(t === "oldtown" ? PAL.brick : t === "beach" ? PAL.beach : PAL.pastel) }); z += hh; } });
        /* courtyard: a little green */
        var ci = quad(DD, u0 + depth + 3, u1 - depth - 3, v0 + depth + 3, v1 - depth - 3); if (W > depth * 2 + 14 && H > depth * 2 + 14 && okFoot(DD, ci, 1)) GREEN.push({ P: ci, k: 0, yard: 1 });
        return;
      }
      if (t === "suburb" || t === "villas" || t === "hills") {
        var yard = quad(DD, u0 - 2, u1 + 2, v0 - 2, v1 + 2); if (okFoot(DD, yard, 2.8)) GREEN.push({ P: yard, k: 0, yard: 1 });
        var big = t !== "suburb", hw = big ? 17 + rnd() * 6 : 10 + rnd() * 3, hd = big ? 14 + rnd() * 5 : 9 + rnd() * 3, gap = big ? 16 : 6;
        /* houses along both long sides of the block */
        var alongU = W >= H, Lm = alongU ? W : H, n = Math.max(1, Math.floor((Lm + gap) / (hw + gap)));
        var off = (Lm - (n * hw + (n - 1) * gap)) / 2;
        for (var s = 0; s < 2; s++) for (var q = 0; q < n; q++) {
          if (big && rnd() < 0.25) continue;
          var a0 = (alongU ? u0 : v0) + off + q * (hw + gap), a1 = a0 + hw, P;
          var w2 = hw * (0.85 + rnd() * 0.15), dd = hd * (0.85 + rnd() * 0.15);
          if (alongU) P = s ? quad(DD, a0, a0 + w2, v1 - dd, v1) : quad(DD, a0, a0 + w2, v0, v0 + dd); else P = s ? quad(DD, u1 - dd, u1, a0, a0 + w2) : quad(DD, u0, u0 + dd, a0, a0 + w2);
          if (!alongU && (u1 - u0) < dd * 2 + 4 && s) continue; if (alongU && (v1 - v0) < dd * 2 + 4 && s) continue;
          if (okFoot(DD, P)) addB(P, big ? 7 + rnd() * 5 : 6 + rnd() * 3, 0, { c: pick(PAL.pastel), rs: rnd() < 0.7 ? "gabled" : "hipped" });
        }
        return;
      }
      if (t === "industrial" || t === "harbor") {
        if (t === "harbor" && rnd() < 0.45) {
          /* container yard: rows of stacked boxes */
          PLAZA.push(quad(DD, u0 - 1, u1 + 1, v0 - 1, v1 + 1));
          for (var cu = u0 + 3; cu + 12.4 < u1 - 2; cu += 15) for (var cv = v0 + 3; cv + 2.5 < v1 - 2; cv += 3.4) { if (rnd() < 0.18) continue; var P3 = quad(DD, cu, cu + 12.2, cv, cv + 2.45); if (okFoot(DD, P3, 2.5)) addB(P3, 2.6 * (1 + Math.floor(rnd() * 3)), 3, { c: pick(PAL.cont), cont: 1 }); }
          return;
        }
        var nb = W > 110 ? 2 : 1, gw = W / nb;
        for (var k = 0; k < nb; k++) { var P4 = fitLot(DD, u0 + k * gw + 2, u0 + (k + 1) * gw - 2, v0 + 2, v1 - 2, 14); if (P4) addB(P4, 8 + rnd() * 8, 3, { c: pick(PAL.ind) }); }
        return;
      }
    }
    /* special buildings */
    var SPB = {};
    if (SP.stadium) { var ov2 = []; for (var a3 = 0; a3 < 6.2832; a3 += 6.2832 / 36) ov2.push([SP.stadium.x + Math.cos(a3) * SP.stadium.rx, SP.stadium.z + Math.sin(a3) * SP.stadium.rz]); SPB.stadium = addB(ov2, 27, 4, { n: SP.stadium.name, t: "attraction", c: "#d8dde2" }); }
    if (park) GREEN.push({ P: [[park[0][0] + 9, park[0][1] + 9], [park[1][0] - 9, park[1][1] + 9], [park[2][0] - 9, park[2][1] - 9], [park[3][0] + 9, park[3][1] - 9]], k: 0, park: 1 });
    if (hall) { PLAZA.push([[hall[0][0] + 7, hall[0][1] + 7], [hall[1][0] - 7, hall[1][1] + 7], [hall[2][0] - 7, hall[2][1] - 7], [hall[3][0] + 7, hall[3][1] - 7]]); SPB.hall = addB([[-300, -200], [-210, -200], [-210, -150], [-300, -150]], 30, 4, { n: "City Hall", t: "townhall", c: "#e6e1d6" }); }
    if (SP.spaceport) PLAZA.push(SP.spaceport.poly.map(function (p, i) { return [p[0] + (i === 0 || i === 3 ? 18 : -18), p[1] + (i < 2 ? 18 : -18)]; }));
    /* beaches: a sand strip along the south shore of the beach district */
    (function () {
      var L = LAND.EI; if (!L) return; var P = L.P, run = [];
      for (var i = 0; i < P.length; i++) { var p = P[i]; if (p[1] > 560 && p[0] > 640 && p[0] < 1880) run.push(i); }
      if (run.length < 4) return;
      run.sort(function (a, b) { return P[a][0] - P[b][0]; });
      var outer = run.map(function (i) { return P[i]; }), inner = offset(P, 22), inn = run.map(function (i) { return inner[i]; }).reverse();
      SAND.push(outer.concat(inn));
    })();

    /* ---------- places: shops, offices, services ---------- */
    var POI = [], used = {};
    var NM = {
      "shop:supermarket": ["FreshMart", "Green Basket", "City Grocer", "Harbor Market", "Sunny Foods", "Daily Market"], "shop:convenience": ["Corner Shop", "QuickStop", "24/7 Mini", "Night Owl Store", "Handy Mart", "Pocket Shop"],
      cafe: ["Bean There", "Harbor Brew", "The Daily Grind", "Mocha Moon", "Sunrise Cafe", "Bluebird Coffee", "Cup & Co", "Lighthouse Cafe", "Foam Street", "Golden Bean"],
      restaurant: ["Luigi's", "Ocean Grill", "Tokyo Garden", "Taco Loco", "The Steak House", "Spice Route", "Bistro 21", "Seaside Kitchen", "Golden Dragon", "Olive Tree"], fast_food: ["Burger Bros", "Pizza Planet", "Chicken Shack", "Wrap Star", "Hot Dog Hub", "Fry Day"],
      bank: ["Liberty Bank", "Harbor Trust", "City Savings", "EarthPass Bank"], hotel: ["Grand Harbor Hotel", "Ocean Pearl Hotel", "Skyline Hotel", "Palm Resort", "Hotel Central", "Seabreeze Inn"],
      office: ["Apex Tower", "Nova Center", "Summit Plaza", "Orion Building", "Meridian Tower", "Vertex Offices", "Atlas House", "Zenith Tower"], hospital: ["St. Mary Hospital", "City General Hospital"], clinic: ["Harbor Clinic", "Westside Clinic", "Bayside Medical"],
      school: ["Central High School", "Westside School", "Old Town School", "Bayside Academy"], university: ["EarthPass University"], police: ["Police Precinct 1", "Police Precinct 2", "Harbor Police"], fire_station: ["Fire Station 1", "Fire Station 2"],
      library: ["City Library"], museum: ["City Museum", "Maritime Museum"], theatre: ["Grand Theatre"], cinema: ["Starlight Cinema", "Neon Cinema"], place_of_worship: ["St. Peter Church", "Old Chapel", "Harbor Temple"], fuel: ["Rapid Fuel", "Blue Pump", "Harbor Gas", "Westside Fuel"],
      pharmacy: ["City Pharmacy", "Health Plus", "Care Chemist", "Bay Pharmacy"], post_office: ["Central Post Office"], car_rental: ["Drive Now Rentals", "City Cars"]
    };
    var want = [["shop:supermarket", 6, null], ["shop:convenience", 6, null], ["cafe", 10, null], ["restaurant", 10, null], ["fast_food", 6, null], ["bank", 4, ["downtown", "midtown"]], ["hotel", 6, ["beach", "downtown", "midtown", "bayside"]], ["office", 8, ["downtown", "midtown"]], ["hospital", 2, null], ["clinic", 3, null], ["school", 4, ["suburb", "oldtown", "bayside", "midtown"]], ["university", 1, ["midtown", "oldtown"]], ["police", 3, null], ["fire_station", 2, null], ["library", 1, ["midtown", "downtown"]], ["museum", 2, ["midtown", "oldtown", "downtown"]], ["theatre", 1, ["midtown"]], ["cinema", 2, null], ["place_of_worship", 3, ["oldtown", "suburb", "midtown"]], ["fuel", 4, ["suburb", "industrial", "bayside", "harbor"]], ["pharmacy", 4, null], ["post_office", 1, ["midtown", "downtown"]], ["car_rental", 2, null]];
    /* which district each building is in */
    function distOf(x, z) { for (var i = 0; i < DIST.length; i++) if (DIST[i].inside(x, z)) return DIST[i].d; return null; }
    var cand = BLD.filter(function (b) { return !b.cont && !b.t && b.h > 5 && b.k !== 3 || (b.k === 3 && !b.cont); }).map(function (b) { var p = b.p, x = 0, z = 0, n = p.length / 2; for (var i = 0; i < p.length; i += 2) { x += p[i]; z += p[i + 1]; } x /= n; z /= n; var dd = distOf(x, z); return { b: b, x: x, z: z, t: dd ? dd.type : "" }; });
    want.forEach(function (w) {
      var list = cand.filter(function (c) { return !used[c.x + "," + c.z] && (!w[2] || w[2].indexOf(c.t) >= 0) && c.t !== "harbor" || (w[0] === "fuel" && c.t === "harbor"); });
      var names = NM[w[0]] || [w[0]];
      for (var i = 0; i < w[1] && list.length; i++) {
        /* spread them out: pick from a band around the centre that grows with i */
        var target = 250 + i * 380, best = null, bd = 1e9;
        for (var tries = 0; tries < 40; tries++) { var c = list[Math.floor(rnd() * list.length)]; if (used[c.x + "," + c.z]) continue; var dd = Math.abs(Math.hypot(c.x, c.z) - target) + rnd() * 120; if (POI.some(function (p) { return p.t === w[0] && Math.hypot(p.x - c.x, p.z - c.z) < 300; })) dd += 600; if (dd < bd) { bd = dd; best = c; } }
        if (!best) break; used[best.x + "," + best.z] = 1;
        var nm = names[i % names.length]; best.b.t = w[0]; best.b.n = nm;
        if (w[0] === "hospital" || w[0] === "school" || w[0] === "university" || w[0] === "police" || w[0] === "library" || w[0] === "museum" || w[0] === "fire_station" || w[0] === "post_office") best.b.k = 4; else if (w[0] === "place_of_worship") best.b.k = 5;
        POI.push({ x: Math.round(best.x * 10) / 10, z: Math.round(best.z * 10) / 10, t: w[0], n: nm });
      }
    });
    if (SPB.hall) POI.push({ x: -255, z: -175, t: "townhall", n: "City Hall" });
    if (SPB.stadium) POI.push({ x: SP.stadium.x, z: SP.stadium.z, t: "attraction", n: SP.stadium.name });
    if (SP.spaceport) POI.push({ x: SP.spaceport.x, z: SP.spaceport.z, t: "attraction", n: SP.spaceport.name });
    if (SP.lighthouse) POI.push({ x: SP.lighthouse.x, z: SP.lighthouse.z, t: "attraction", n: SP.lighthouse.name });

    /* ---------- tiles ---------- */
    var N = Math.ceil(HALF * 2 / TILE), TL = {};
    function tk(x, z) { var i = Math.floor((x + HALF) / TILE), j = Math.floor((z + HALF) / TILE); if (i < 0 || j < 0 || i >= N || j >= N) return null; return i + "_" + j; }
    function T(k) { return TL[k] || (TL[k] = { b: [], r: [], rl: [], w: [], g: [], pz: [], poi: [], ld: [], sd: [] }); }
    BLD.forEach(function (b) { var x = 0, z = 0, n = b.p.length / 2; for (var i = 0; i < b.p.length; i += 2) { x += b.p[i]; z += b.p[i + 1]; } var k = tk(x / n, z / n); if (k) T(k).b.push(b); });
    ROADS.forEach(function (r) { var m = Math.floor(r.p.length / 4) * 2, k = tk(Math.max(-HALF, Math.min(HALF - 0.01, r.p[m])), Math.max(-HALF, Math.min(HALF - 0.01, r.p[m + 1]))); if (k) T(k).r.push(r); });
    function clipped(list, P, extra) {
      var bb = bboxOf(P), i1 = Math.max(0, Math.floor((bb[0] + HALF) / TILE)), i2 = Math.min(N - 1, Math.floor((bb[2] + HALF) / TILE)), j1 = Math.max(0, Math.floor((bb[1] + HALF) / TILE)), j2 = Math.min(N - 1, Math.floor((bb[3] + HALF) / TILE));
      for (var i = i1; i <= i2; i++) for (var j = j1; j <= j2; j++) { var x1 = -HALF + i * TILE, z1 = -HALF + j * TILE, c = clipRect(P, x1, z1, x1 + TILE, z1 + TILE); if (c.length >= 3 && Math.abs(area(c)) > 2) { var o = { p: flat(c) }; if (extra) for (var q in extra) o[q] = extra[q]; T(i + "_" + j)[list].push(o); } }
    }
    LANDS.forEach(function (L) { clipped("ld", L.P, L.pier ? { pier: 1 } : null); });
    GREEN.forEach(function (g) { clipped("g", g.P, { k: g.k }); });
    PLAZA.forEach(function (p) { clipped("pz", p); });
    SAND.forEach(function (p) { clipped("sd", p); });
    POI.forEach(function (p) { var k = tk(p.x, p.z); if (k) T(k).poi.push(p); });
    var meta = { lat: opt.lat || 40.7549, lon: opt.lon || -73.984, half: HALF, tile: TILE, n: N, tiles: Object.keys(TL), gen: 1 };
    /* overview for the map screens */
    var ov = { r: [], w: [], g: [], poi: POI.slice(), pl: [], land: LANDS.map(function (L) { return { p: flat(L.P), pier: L.pier ? 1 : 0 }; }), sand: SAND.map(flat) };
    ROADS.forEach(function (r) { if (r.c <= 5) { var o = { p: r.p.map(function (v) { return Math.round(v); }), c: r.c, w: r.w }; if (r.n) o.n = r.n; if (r.br) o.br = 1; ov.r.push(o); } });
    GREEN.forEach(function (g) { if (!g.yard) ov.g.push({ p: flat(g.P).map(function (v) { return Math.round(v); }) }); });
    D.districts.forEach(function (d) { if (d.label) ov.pl.push({ n: d.name, x: d.label[0], z: d.label[1], k: d.label[2] }); });
    [["Central Park", -765, -1080, 2], ["Financial District", -560, 1000, 2], ["City Hall", -255, -300, 2], ["Arena District", 1010, 120, 2], ["Cape Liberty", 1990, 2080, 1], ["Liberty Rock", -495, 1640, 2]].forEach(function (p) { ov.pl.push({ n: p[0], x: p[1], z: p[2], k: p[3] }); });
    var stats = { ms: Date.now() - t0, buildings: BLD.length, roads: ROADS.length, tiles: meta.tiles.length, poi: POI.length, green: GREEN.length };
    return {
      meta: meta, overview: ov, stats: stats, specials: SP, isLand: isLand, lands: LANDS,
      nearRoad: function (x, z, extra) { var A = RG[Math.floor(x / RC) + "," + Math.floor(z / RC)]; if (!A) return false; for (var i = 0; i < A.length; i++) { var q = A[i]; if (segDist(x, z, q[0], q[1], q[2], q[3]) < q[4] + (extra || 0)) return true; } return false; },
      tile: function (k) { var t = TL[k]; if (!t) return null; return { b: t.b.slice(), r: t.r, rl: t.rl, w: t.w, g: t.g, pz: t.pz, poi: t.poi.map(function (p) { return { x: p.x, z: p.z, t: p.t, n: p.n }; }), ld: t.ld, sd: t.sd }; },
      all: function () { return { b: BLD, r: ROADS, g: GREEN, pz: PLAZA, land: LANDS, sand: SAND }; }
    };
  }
  function ord(n) { var s = ["th", "st", "nd", "rd"], v = n % 100; return n + (s[(v - 20) % 10] || s[v] || s[0]); }
  var api = { generate: generate };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.CityGen = api;
})(typeof window !== "undefined" ? window : this);
