/* Passport World - real-map city from OpenStreetMap tiles.
   World.create(opts) -> city object. City coordinates are metres from the centre; the city is placed at (ox, oz) in the game world. */
(function () {
  "use strict";
  var T = THREE;
  function rnd(seed) { var a = seed >>> 0; return function () { a = (a + 0x6d2b79f5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function ctex(w, h, draw, rep, aniso) {
    var c = document.createElement("canvas"); c.width = w; c.height = h; draw(c.getContext("2d"), w, h);
    var t = new T.CanvasTexture(c); t.encoding = T.sRGBEncoding; if (rep) t.wrapS = t.wrapT = T.RepeatWrapping; t.anisotropy = aniso || 8; return t;
  }
  function noise(g, w, h, n, a, col) { for (var i = 0; i < n; i++) { g.fillStyle = col || "rgba(0,0,0," + (Math.random() * a) + ")"; g.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 2, 1 + Math.random() * 2); } }

  /* ---------- materials ---------- */
  function makeMaterials(aniso) {
    var M = {}, night = [];
    /* one facade bay = 4 m wide, one floor = 3.3 m; textures tile with UVs in bays/floors */
    function bay(style) {
      return function (g, w, h) {
        var wall = style.wall, gl = style.glass;
        g.fillStyle = wall; g.fillRect(0, 0, w, h); noise(g, w, h, 900, 0.06);
        if (style.brick) { g.strokeStyle = "rgba(0,0,0,0.10)"; g.lineWidth = 1; for (var y = 0; y < h; y += 6) { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); for (var x = (y / 6) % 2 ? 0 : 9; x < w; x += 18) { g.beginPath(); g.moveTo(x, y); g.lineTo(x, y + 6); g.stroke(); } } }
        var wx = w * style.wx, wy = h * style.wy, ww = w * style.ww, wh = h * style.wh;
        if (style.curtain) { g.fillStyle = gl; g.fillRect(0, 0, w, h); var gr = g.createLinearGradient(0, 0, w, h); gr.addColorStop(0, "rgba(255,255,255,0.18)"); gr.addColorStop(0.5, "rgba(255,255,255,0.02)"); gr.addColorStop(1, "rgba(255,255,255,0.12)"); g.fillStyle = gr; g.fillRect(0, 0, w, h); g.fillStyle = style.mullion; g.fillRect(0, 0, w, 3); g.fillRect(0, 0, 3, h); g.fillRect(w / 2 - 1, 0, 2, h); g.fillRect(0, h * 0.72, w, 5); return; }
        g.fillStyle = "rgba(0,0,0,0.25)"; g.fillRect(wx - 3, wy - 3, ww + 6, wh + 7);
        g.fillStyle = style.frame || "#e9e6df"; g.fillRect(wx - 2, wy - 2, ww + 4, wh + 4);
        var gg = g.createLinearGradient(0, wy, 0, wy + wh); gg.addColorStop(0, "#9fb4c4"); gg.addColorStop(0.5, gl); gg.addColorStop(1, "#1d2733"); g.fillStyle = gg; g.fillRect(wx, wy, ww, wh);
        g.fillStyle = "rgba(255,255,255,0.16)"; g.beginPath(); g.moveTo(wx, wy); g.lineTo(wx + ww * 0.45, wy); g.lineTo(wx, wy + wh * 0.55); g.fill();
        g.fillStyle = style.frame || "#e9e6df"; g.fillRect(wx + ww / 2 - 1.5, wy, 3, wh);
        if (style.sill) { g.fillStyle = "rgba(255,255,255,0.55)"; g.fillRect(wx - 5, wy + wh + 2, ww + 10, 4); }
      };
    }
    function lit(style, seed) {
      return function (g, w, h) {
        g.fillStyle = "#000"; g.fillRect(0, 0, w, h);
        var wx = w * style.wx, wy = h * style.wy, ww = w * style.ww, wh = h * style.wh;
        if (style.curtain) { g.fillStyle = "rgba(255,214,150,0.55)"; g.fillRect(4, 4, w / 2 - 6, h * 0.68); return; }
        g.fillStyle = "#ffd89a"; g.fillRect(wx, wy, ww, wh);
      };
    }
    var STY = {
      res: { wall: "#d8cdb8", glass: "#3b4a5a", wx: 0.24, wy: 0.24, ww: 0.52, wh: 0.5, sill: true, frame: "#f3f0ea" },
      brick: { wall: "#9a5a44", glass: "#33414f", wx: 0.26, wy: 0.22, ww: 0.48, wh: 0.52, brick: true, sill: true, frame: "#efe9de" },
      com: { curtain: true, glass: "#2d4a63", mullion: "#1b232b" },
      gen: { wall: "#c9c4ba", glass: "#34444f", wx: 0.16, wy: 0.26, ww: 0.68, wh: 0.46, frame: "#2a2f33" },
      ind: { wall: "#a7a49b", glass: "#3a4650", wx: 0.1, wy: 0.55, ww: 0.8, wh: 0.18, frame: "#55585b" },
      civ: { wall: "#e4dccb", glass: "#2f3e4c", wx: 0.3, wy: 0.15, ww: 0.4, wh: 0.62, sill: true, frame: "#f6f1e6" }
    };
    function facadeMat(k, seed) {
      var s = STY[k], map = ctex(128, 128, bay(s), true, aniso), em = ctex(64, 64, lit(s, seed), true, 1);
      var m = new T.MeshStandardMaterial({ map: map, roughness: s.curtain ? 0.25 : 0.85, metalness: s.curtain ? 0.45 : 0.02, vertexColors: true, emissive: 0xffffff, emissiveMap: em, emissiveIntensity: 0 });
      night.push(m); return m;
    }
    M.fac = { res: facadeMat("res"), brick: facadeMat("brick"), com: facadeMat("com"), gen: facadeMat("gen"), ind: facadeMat("ind"), civ: facadeMat("civ") };
    M.shop = new T.MeshStandardMaterial({ map: ctex(256, 128, function (g, w, h) {
      g.fillStyle = "#2b2f33"; g.fillRect(0, 0, w, h);
      var gg = g.createLinearGradient(0, 0, 0, h); gg.addColorStop(0, "#c7d6df"); gg.addColorStop(0.4, "#55687a"); gg.addColorStop(1, "#1a222b");
      g.fillStyle = gg; g.fillRect(10, 30, w - 20, h - 36); g.fillStyle = "#2b2f33"; g.fillRect(w / 2 - 3, 30, 6, h - 36);
      g.fillStyle = "rgba(255,240,210,0.35)"; g.fillRect(16, 70, w - 32, 30);
      g.fillStyle = "#1c2024"; g.fillRect(0, 0, w, 26);
    }, true, aniso), roughness: 0.35, metalness: 0.3, vertexColors: true, emissive: 0xffe6b0, emissiveIntensity: 0 });
    /* only the shop windows glow at night, not the whole ground floor */
    M.shop.emissiveMap = ctex(256, 128, function (g, w, h) { g.fillStyle = "#000"; g.fillRect(0, 0, w, h); g.fillStyle = "#b89a6a"; g.fillRect(10, 30, w / 2 - 13, h - 36); g.fillRect(w / 2 + 3, 30, w / 2 - 13, h - 36); g.fillStyle = "#3a3020"; g.fillRect(w / 2 - 3, 30, 6, h - 36); }, true, aniso);
    night.push(M.shop);
    M.roof = new T.MeshStandardMaterial({ side: T.FrontSide, map: ctex(128, 128, function (g, w, h) { g.fillStyle = "#8d8a84"; g.fillRect(0, 0, w, h); noise(g, w, h, 1600, 0.12); g.strokeStyle = "rgba(0,0,0,0.12)"; for (var i = 0; i < w; i += 32) { g.beginPath(); g.moveTo(i, 0); g.lineTo(i, h); g.stroke(); } }, true, aniso), roughness: 0.95, vertexColors: true });
    M.trim = new T.MeshStandardMaterial({ color: 0xffffff, vertexColors: true, roughness: 0.85, side: T.DoubleSide });
    M.door = new T.MeshStandardMaterial({ map: ctex(64, 128, function (g, w, h) { g.fillStyle = "#e8e3d8"; g.fillRect(0, 0, w, h); g.fillStyle = "#3a2a1e"; g.fillRect(6, 10, w - 12, h - 10); g.fillStyle = "#2a3540"; g.fillRect(12, 18, w - 24, 34); g.fillStyle = "rgba(255,255,255,0.18)"; g.fillRect(12, 18, 10, 34); g.fillStyle = "#4a382a"; g.fillRect(12, 62, w - 24, 26); g.fillRect(12, 94, w - 24, 26); g.fillStyle = "#d9b45a"; g.fillRect(w - 18, 76, 4, 8); }, true, aniso), roughness: 0.6, side: T.DoubleSide });
    M.tankWood = new T.MeshStandardMaterial({ color: 0x7d5c40, roughness: 0.95 });
    M.steelDk = new T.MeshStandardMaterial({ color: 0x35383b, roughness: 0.6, metalness: 0.4 });
    M.ac = new T.MeshStandardMaterial({ color: 0x80868a, roughness: 0.55, metalness: 0.3 });
    M.hh = new T.MeshStandardMaterial({ color: 0x86807a, roughness: 0.9 });
    M.tile = new T.MeshStandardMaterial({ side: T.FrontSide, map: ctex(128, 128, function (g, w, h) { g.fillStyle = "#8a3b2a"; g.fillRect(0, 0, w, h); for (var y = 0; y < h; y += 10) { g.fillStyle = "rgba(0,0,0,0.22)"; g.fillRect(0, y, w, 2); for (var x = (y / 10) % 2 ? 0 : 8; x < w; x += 16) g.fillRect(x, y, 1, 10); } noise(g, w, h, 600, 0.12); }, true, aniso), roughness: 0.8, vertexColors: true });
    function roadTex(kind) {
      return ctex(256, 512, function (g, w, h) {
        g.fillStyle = kind === "path" ? "#b7ad9c" : kind === "ped" ? "#a99f93" : "#3a3d40"; g.fillRect(0, 0, w, h);
        noise(g, w, h, 6000, kind === "path" || kind === "ped" ? 0.12 : 0.22);
        noise(g, w, h, 1500, 0.6, "rgba(255,255,255,0.05)");
        if (kind === "path" || kind === "ped") { g.strokeStyle = "rgba(0,0,0,0.14)"; for (var y = 0; y < h; y += 16) { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); } for (var x = 0; x < w; x += 32) for (var y2 = 0; y2 < h; y2 += 16) { g.beginPath(); g.moveTo(x + ((y2 / 16) % 2) * 16, y2); g.lineTo(x + ((y2 / 16) % 2) * 16, y2 + 16); g.stroke(); } return; }
        g.fillStyle = "rgba(240,240,235,0.85)"; g.fillRect(6, 0, 5, h); g.fillRect(w - 11, 0, 5, h);
        if (kind === "major") { g.fillStyle = "#e8b62b"; g.fillRect(w / 2 - 7, 0, 4, h); g.fillRect(w / 2 + 3, 0, 4, h); g.fillStyle = "rgba(240,240,235,0.85)"; g.fillRect(w / 4 - 2, 0, 4, h * 0.45); g.fillRect(w * 3 / 4 - 2, 0, 4, h * 0.45); }
        else if (kind === "minor") { g.fillStyle = "rgba(240,240,235,0.85)"; g.fillRect(w / 2 - 2, 0, 4, h * 0.5); }
      }, true, aniso);
    }
    var road = function (k) { return new T.MeshStandardMaterial({ side: T.DoubleSide, map: roadTex(k), roughness: k === "path" || k === "ped" ? 0.9 : 0.82, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }); };
    M.rMajor = road("major"); M.rMinor = road("minor"); M.rPlain = road("plain"); M.rPath = road("path"); M.rPed = road("ped");
    /* plain asphalt for junctions and joints, white paint for zebra crossings and stop lines */
    M.rJunc = new T.MeshStandardMaterial({ side: T.DoubleSide, map: ctex(256, 256, function (g, w, h) { g.fillStyle = "#3a3d40"; g.fillRect(0, 0, w, h); noise(g, w, h, 6000, 0.22); noise(g, w, h, 1500, 0.6, "rgba(255,255,255,0.05)"); }, true, aniso), roughness: 0.82, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    M.zebra = new T.MeshStandardMaterial({ color: 0xeeeee4, roughness: 0.7, side: T.DoubleSide, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 });
    M.walk = new T.MeshStandardMaterial({ side: T.DoubleSide, map: ctex(128, 128, function (g, w, h) { g.fillStyle = "#b9b4aa"; g.fillRect(0, 0, w, h); noise(g, w, h, 1200, 0.1); g.strokeStyle = "rgba(0,0,0,0.16)"; for (var i = 0; i <= w; i += 32) { g.beginPath(); g.moveTo(i, 0); g.lineTo(i, h); g.stroke(); g.beginPath(); g.moveTo(0, i); g.lineTo(w, i); g.stroke(); } }, true, aniso), roughness: 0.9, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
    M.rail = new T.MeshStandardMaterial({ side: T.DoubleSide, map: ctex(128, 256, function (g, w, h) { g.fillStyle = "#6e665c"; g.fillRect(0, 0, w, h); noise(g, w, h, 3000, 0.3); g.fillStyle = "#4a3b2d"; for (var y = 0; y < h; y += 22) g.fillRect(12, y, w - 24, 10); g.fillStyle = "#b9bcc0"; g.fillRect(w * 0.3, 0, 5, h); g.fillRect(w * 0.7 - 5, 0, 5, h); }, true, aniso), roughness: 0.8, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 });
    M.water = new T.MeshStandardMaterial({ side: T.DoubleSide, color: 0x2f5f78, roughness: 0.08, metalness: 0.35, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
    /* moving waves: the surface normal and colour ripple with time, so rivers look like water, not a road */
    M.waterTime = { value: 0 };
    M.water.onBeforeCompile = function (sh) {
      sh.uniforms.uTime = M.waterTime;
      sh.vertexShader = sh.vertexShader.replace("#include <common>", "#include <common>\nvarying vec3 vWp;").replace("#include <begin_vertex>", "#include <begin_vertex>\nvWp = (modelMatrix * vec4(transformed, 1.0)).xyz;");
      sh.fragmentShader = sh.fragmentShader.replace("#include <common>", "#include <common>\nvarying vec3 vWp; uniform float uTime;\nvec2 wv(vec2 p, vec2 d, float f, float s, float a) { float ph = dot(p, d) * f + uTime * s; return d * (a * f * cos(ph)); }\nfloat wh(vec2 p, vec2 d, float f, float s) { return sin(dot(p, d) * f + uTime * s); }")
        .replace("#include <color_fragment>", "#include <color_fragment>\n{ vec2 p = vWp.xz; float h = wh(p, vec2(0.96, 0.28), 0.32, 1.5) * 0.5 + wh(p, vec2(-0.37, 0.93), 0.55, 2.0) * 0.3 + wh(p, vec2(0.6, -0.8), 1.2, 2.7) * 0.2; diffuseColor.rgb *= 0.86 + 0.16 * h; float crest = smoothstep(0.82, 1.0, h); diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.78, 0.86, 0.9), crest * 0.35); }")
        .replace("#include <normal_fragment_maps>", "#include <normal_fragment_maps>\n{ vec2 p = vWp.xz; vec2 g = wv(p, vec2(0.96, 0.28), 0.32, 1.5, 0.35) + wv(p, vec2(-0.37, 0.93), 0.55, 2.0, 0.18) + wv(p, vec2(0.6, -0.8), 1.2, 2.7, 0.07) + wv(p, vec2(-0.9, -0.44), 2.6, 3.6, 0.03); vec3 nw = normalize(vec3(-g.x, 1.0, -g.y)); normal = normalize((viewMatrix * vec4(nw, 0.0)).xyz); }");
    };
    M.grass = new T.MeshStandardMaterial({ side: T.DoubleSide, map: ctex(128, 128, function (g, w, h) { g.fillStyle = "#5d8a3e"; g.fillRect(0, 0, w, h); noise(g, w, h, 4000, 0.18); noise(g, w, h, 800, 0.5, "rgba(190,220,120,0.12)"); }, true, aniso), roughness: 1, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
    M.plaza = new T.MeshStandardMaterial({ side: T.DoubleSide, map: ctex(128, 128, function (g, w, h) { g.fillStyle = "#a8a297"; g.fillRect(0, 0, w, h); noise(g, w, h, 1500, 0.12); g.strokeStyle = "rgba(0,0,0,0.12)"; for (var i = 0; i <= w; i += 16) { g.beginPath(); g.moveTo(i, 0); g.lineTo(i, h); g.stroke(); g.beginPath(); g.moveTo(0, i); g.lineTo(w, i); g.stroke(); } }, true, aniso), roughness: 0.9, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
    M.trunk = new T.MeshStandardMaterial({ color: 0x5a4330, roughness: 1 });
    M.bwall = new T.MeshStandardMaterial({ map: ctex(128, 64, function (g, w, h) { g.fillStyle = "#ffffff"; g.fillRect(0, 0, w, h); noise(g, w, h, 700, 0.1); g.fillStyle = "rgba(0,0,0,0.10)"; g.fillRect(0, 0, w, 6); for (var x = 0; x < w; x += 32) g.fillRect(x, 0, 2, h); }, true, aniso), vertexColors: true, roughness: 0.92, side: T.DoubleSide });
    M.leaf = new T.MeshStandardMaterial({ color: 0x4f7a34, roughness: 0.9, flatShading: true });
    M.lamp = new T.MeshStandardMaterial({ color: 0x2a2d30, roughness: 0.5, metalness: 0.6 });
    M.bulb = new T.MeshStandardMaterial({ color: 0xfff1cc, emissive: 0xffd28a, emissiveIntensity: 0 });
    night.push(M.bulb);
    /* our own city: land, beach sand and the open sea */
    M.land = new T.MeshStandardMaterial({ side: T.DoubleSide, map: ctex(128, 128, function (g, w, h) { g.fillStyle = "#6f8f4c"; g.fillRect(0, 0, w, h); noise(g, w, h, 4000, 0.16); noise(g, w, h, 900, 0.45, "rgba(170,160,120,0.10)"); }, true, aniso), roughness: 1, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
    M.sand = new T.MeshStandardMaterial({ side: T.DoubleSide, map: ctex(128, 128, function (g, w, h) { g.fillStyle = "#e2cf9c"; g.fillRect(0, 0, w, h); noise(g, w, h, 5000, 0.12); noise(g, w, h, 600, 0.4, "rgba(255,255,255,0.08)"); }, true, aniso), roughness: 1, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
    M.sea = new T.MeshStandardMaterial({ color: 0x24637f, roughness: 0.1, metalness: 0.3, polygonOffset: true, polygonOffsetFactor: 2, polygonOffsetUnits: 4 });
    M.sea.onBeforeCompile = M.water.onBeforeCompile;
    M.night = night;
    return M;
  }

  /* ---------- geometry builders ---------- */
  function GB() { this.p = []; this.n = []; this.u = []; this.c = []; }
  GB.prototype.tri = function (a, b, c, ua, ub, uc, nrm, col) {
    var p = this.p, n = this.n, u = this.u, cl = this.c;
    p.push(a[0], a[1], a[2], b[0], b[1], b[2], c[0], c[1], c[2]);
    n.push(nrm[0], nrm[1], nrm[2], nrm[0], nrm[1], nrm[2], nrm[0], nrm[1], nrm[2]);
    u.push(ua[0], ua[1], ub[0], ub[1], uc[0], uc[1]);
    if (col) cl.push(col[0], col[1], col[2], col[0], col[1], col[2], col[0], col[1], col[2]);
  };
  /* triangle that always faces up (so roofs can be single-sided and never seen from below) */
  GB.prototype.triUp = function (a, b, c, ua, ub, uc, nrm, col, down) { var ny = (b[2] - a[2]) * (c[0] - a[0]) - (b[0] - a[0]) * (c[2] - a[2]); if ((ny < 0) !== !!down) this.tri(a, c, b, ua, uc, ub, nrm, col); else this.tri(a, b, c, ua, ub, uc, nrm, col); };
  GB.prototype.quad = function (a, b, c, d, ua, ub, uc, ud, nrm, col) { this.tri(a, b, c, ua, ub, uc, nrm, col); this.tri(a, c, d, ua, uc, ud, nrm, col); };
  GB.prototype.mesh = function (mat, shadow, recv) {
    if (!this.p.length) return null;
    var g = new T.BufferGeometry();
    g.setAttribute("position", new T.Float32BufferAttribute(this.p, 3)); g.setAttribute("normal", new T.Float32BufferAttribute(this.n, 3)); g.setAttribute("uv", new T.Float32BufferAttribute(this.u, 2));
    if (this.c.length) g.setAttribute("color", new T.Float32BufferAttribute(this.c, 3));
    g.computeBoundingSphere();
    var m = new T.Mesh(g, mat); m.castShadow = !!shadow; m.receiveShadow = recv !== false; m.matrixAutoUpdate = false; return m;
  };

  var PAL = {
    res: [[0.86, 0.82, 0.74], [0.93, 0.9, 0.84], [0.78, 0.72, 0.62], [0.9, 0.86, 0.78], [0.72, 0.7, 0.68]],
    brick: [[1, 1, 1], [0.92, 0.85, 0.82], [0.8, 0.72, 0.66], [1.05, 0.95, 0.9]],
    com: [[1, 1, 1], [0.85, 0.95, 1.05], [0.95, 0.95, 0.95], [0.8, 0.9, 0.95]],
    gen: [[1, 1, 1], [0.92, 0.9, 0.86], [0.85, 0.85, 0.88], [1, 0.96, 0.9]],
    ind: [[1, 1, 1], [0.9, 0.92, 0.95], [0.95, 0.9, 0.85]],
    civ: [[1, 1, 1], [0.95, 0.92, 0.86]]
  };
  function parseCol(s) { try { var c = new T.Color(s); return [c.r * 1.6, c.g * 1.6, c.b * 1.6]; } catch (e) { return null; } }

  function create(o) {
    var scene = o.scene, ox = o.ox || 0, oz = o.oz || 0, base = o.base, code = o.code, aniso = o.aniso || 8, GEN = o.gen || null;
    var M = makeMaterials(aniso), meta = null, tiles = {}, loading = {}, grid = {}, CELL = 24, rgrid = {}, dropTotal = 0, dropList = [], boardTotal = 0;
    var root = new T.Group(); root.position.set(ox, 0, oz); scene.add(root);
    var nodes = {}; /* node id -> list of road refs for traffic */
    var pois = [], style = o.style || {};
    var treeGeo = new T.CylinderGeometry(0.16, 0.22, 2.6, 6); treeGeo.translate(0, 1.3, 0);
    var crownGeo = new T.IcosahedronGeometry(1.9, 1); crownGeo.translate(0, 3.9, 0);
    var lampGeo = new T.CylinderGeometry(0.07, 0.1, 6, 6); lampGeo.translate(0, 3, 0);
    var headGeo = new T.BoxGeometry(0.8, 0.14, 0.32); headGeo.translate(0.35, 6, 0);
    var bulbGeo = new T.BoxGeometry(0.5, 0.06, 0.24); bulbGeo.translate(0.4, 5.92, 0);
    /* rooftop gear: water tanks, AC units, stair houses */
    var tankGeo = new T.CylinderGeometry(1.5, 1.5, 3.2, 12); tankGeo.translate(0, 3.4 + 1.6, 0);
    var tankTopGeo = new T.ConeGeometry(1.65, 1.1, 12); tankTopGeo.translate(0, 3.4 + 3.2 + 0.55, 0);
    var standGeo = new T.CylinderGeometry(1.15, 1.3, 3.4, 6, 1, true); standGeo.translate(0, 1.7, 0);
    var acGeo = new T.BoxGeometry(1.3, 0.9, 1.0); acGeo.translate(0, 0.45, 0);
    var hhGeo = new T.BoxGeometry(3.2, 2.8, 3.6); hhGeo.translate(0, 1.4, 0);
    var SHARED = [treeGeo, crownGeo, lampGeo, headGeo, bulbGeo, tankGeo, tankTopGeo, standGeo, acGeo, hhGeo];

    function addCell(b, ti) {
      var c1 = Math.floor(b.x1 / CELL), c2 = Math.floor(b.x2 / CELL), d1 = Math.floor(b.z1 / CELL), d2 = Math.floor(b.z2 / CELL);
      for (var i = c1; i <= c2; i++) for (var j = d1; j <= d2; j++) { var k = i + "," + j; (grid[k] || (grid[k] = [])).push(b); }
      b.cells = [c1, c2, d1, d2];
    }
    function removeCells(b) { for (var i = b.cells[0]; i <= b.cells[1]; i++) for (var j = b.cells[2]; j <= b.cells[3]; j++) { var k = i + "," + j, a = grid[k]; if (a) { var x = a.indexOf(b); if (x >= 0) a.splice(x, 1); } } }

    function ribbon(gb, p, w, y, vScale, closedUV) {
      var n = p.length / 2; if (n < 2) return;
      var L = [], R = [], dist = [0];
      for (var i = 0; i < n; i++) {
        var x = p[i * 2], z = p[i * 2 + 1], dx, dz;
        if (i === 0) { dx = p[2] - x; dz = p[3] - z; } else if (i === n - 1) { dx = x - p[i * 2 - 2]; dz = z - p[i * 2 - 1]; }
        else { var ax = x - p[i * 2 - 2], az = z - p[i * 2 - 1], bx = p[i * 2 + 2] - x, bz = p[i * 2 + 3] - z, la = Math.hypot(ax, az) || 1, lb = Math.hypot(bx, bz) || 1; dx = ax / la + bx / lb; dz = az / la + bz / lb; }
        var l = Math.hypot(dx, dz) || 1; dx /= l; dz /= l;
        var nx = -dz, nz = dx, k = 1;
        if (i > 0 && i < n - 1) { var ax2 = x - p[i * 2 - 2], az2 = z - p[i * 2 - 1], la2 = Math.hypot(ax2, az2) || 1; var cos = (nx * (-az2 / la2) + nz * (ax2 / la2)); k = Math.min(2.2, 1 / Math.max(0.45, Math.abs(cos))); }
        L.push([x + nx * w / 2 * k, y, z + nz * w / 2 * k]); R.push([x - nx * w / 2 * k, y, z - nz * w / 2 * k]);
        if (i) dist.push(dist[i - 1] + Math.hypot(x - p[i * 2 - 2], z - p[i * 2 - 1]));
      }
      for (var j = 0; j < n - 1; j++) gb.quad(L[j], R[j], R[j + 1], L[j + 1], [0, dist[j] / vScale], [1, dist[j] / vScale], [1, dist[j + 1] / vScale], [0, dist[j + 1] / vScale], [0, 1, 0]);
    }
    function polyFill(gb, p, y, uvS) {
      var pts = []; for (var i = 0; i < p.length; i += 2) pts.push(new T.Vector2(p[i], p[i + 1]));
      if (pts.length < 3) return;
      var tris; try { tris = T.ShapeUtils.triangulateShape(pts, []); } catch (e) { return; }
      tris.forEach(function (t) { var a = pts[t[0]], b = pts[t[1]], c = pts[t[2]]; var cr = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x); var A = [a.x, y, a.y], B = [b.x, y, b.y], C = [c.x, y, c.y]; if (cr < 0) gb.tri(A, B, C, [a.x / uvS, a.y / uvS], [b.x / uvS, b.y / uvS], [c.x / uvS, c.y / uvS], [0, 1, 0]); else gb.tri(A, C, B, [a.x / uvS, a.y / uvS], [c.x / uvS, c.y / uvS], [b.x / uvS, b.y / uvS], [0, 1, 0]); });
    }
    function inPoly(p, x, z) { var c = false; for (var i = 0, j = p.length - 2; i < p.length; j = i, i += 2) { var xi = p[i], zi = p[i + 1], xj = p[j], zj = p[j + 1]; if (((zi > z) !== (zj > z)) && (x < (xj - xi) * (z - zi) / (zj - zi) + xi)) c = !c; } return c; }

    function famOf(b, r) {
      if (b.k === 2) return b.h > 22 || r < 0.5 ? "com" : "gen";
      if (b.k === 3) return "ind";
      if (b.k === 4 || b.k === 5) return "civ";
      if (b.k === 0) return r < (style.brick || 0.35) ? "brick" : "res";
      if (b.k === 1) return r < (style.brick || 0.35) * 0.8 ? "brick" : "res";
      return b.h > 30 ? "com" : r < 0.3 ? "brick" : "gen";
    }

    function buildTile(key, d, nbr) {
      /* roads of this tile plus the neighbouring tiles: a road piece is stored in one tile only, but it can run into the next one */
      var AR = d.r.slice(); (nbr || []).forEach(function (L) { for (var q = 0; q < L.length; q++) AR.push(L[q]); });
      var g = new T.Group(), r = rnd(hashStr(code + key)), fam = {}, shopB = new GB(), roofB = new GB(), tileB = new GB(), trimB = new GB(), doorB = new GB(), stkB = new GB(), cols = [], gear = { tank: [], ac: [], hh: [] };
      if (!M.sticker && window.EP_STICKER_TEX) M.sticker = new T.MeshStandardMaterial({ map: window.EP_STICKER_TEX, alphaTest: 0.4, roughness: 0.6, polygonOffset: true, polygonOffsetFactor: -2 });
      /* a triangle / quad wound so its front faces the given normal */
      function ftri(gb, a, b, c, ua, ub, uc, nrm, col) { var cx = (b[1] - a[1]) * (c[2] - a[2]) - (b[2] - a[2]) * (c[1] - a[1]), cy = (b[2] - a[2]) * (c[0] - a[0]) - (b[0] - a[0]) * (c[2] - a[2]), cz = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]); if (cx * nrm[0] + cy * nrm[1] + cz * nrm[2] < 0) gb.tri(a, c, b, ua, uc, ub, nrm, col); else gb.tri(a, b, c, ua, ub, uc, nrm, col); }
      function fquad(gb, a, b, c, d, nrm, col, uv) { uv = uv || [[0, 0], [1, 0], [1, 1], [0, 1]]; ftri(gb, a, b, c, uv[0], uv[1], uv[2], nrm, col); ftri(gb, a, c, d, uv[0], uv[2], uv[3], nrm, col); }
      function unit(x, y, z) { var l = Math.hypot(x, y, z) || 1; return [x / l, y / l, z / l]; }
      var ROOFC = [[1, 1, 1], [0.6, 0.63, 0.7], [0.8, 0.62, 0.55], [0.55, 0.47, 0.42], [0.9, 0.78, 0.72]];
      ["res", "brick", "com", "gen", "ind", "civ"].forEach(function (f) { fam[f] = new GB(); });
      var blds = [];
      /* a building standing on a street's driving lanes (map errors, passages under buildings) is left out, so streets are always clear */
      var LANE = {}, LC = 12;
      function addL(x, z) { var kk = Math.floor(x / LC) + "," + Math.floor(z / LC); (LANE[kk] || (LANE[kk] = [])).push(x, z); }
      AR.forEach(function (rd) {
        if (!rd.d || rd.c > 4) return; var p = rd.p, lo = rd.w >= 5 && rd.c <= 3 ? rd.w / 4 : 0;
        for (var i = 2; i < p.length; i += 2) {
          var ax = p[i - 2], az = p[i - 1], bx = p[i], bz = p[i + 1], L = Math.hypot(bx - ax, bz - az); if (L < 0.3) continue;
          var nx = -(bz - az) / L, nz = (bx - ax) / L;
          for (var s = 0; s <= L; s += 1.5) { var x = ax + (bx - ax) * s / L, z = az + (bz - az) * s / L; addL(x, z); if (lo) { addL(x + nx * lo, z + nz * lo); addL(x - nx * lo, z - nz * lo); } }
        }
      });
      function onLanes(p, x1, x2, z1, z2) {
        for (var i = Math.floor(x1 / LC); i <= Math.floor(x2 / LC); i++) for (var j = Math.floor(z1 / LC); j <= Math.floor(z2 / LC); j++) {
          var a = LANE[i + "," + j]; if (!a) continue;
          for (var k = 0; k < a.length; k += 2) { var x = a[k], z = a[k + 1]; if (x >= x1 && x <= x2 && z >= z1 && z <= z2 && inPoly(p, x, z)) return true; }
        }
        return false;
      }
      var nDrop = 0, nBoard = 0;
      d.b = d.b.filter(function (b) {
        if (b.m) return true; var p = b.p, x1 = 1e9, x2 = -1e9, z1 = 1e9, z2 = -1e9;
        for (var i = 0; i < p.length; i += 2) { x1 = Math.min(x1, p[i]); x2 = Math.max(x2, p[i]); z1 = Math.min(z1, p[i + 1]); z2 = Math.max(z2, p[i + 1]); }
        if (onLanes(p, x1, x2, z1, z2)) { nDrop++; if (dropList.length < 60) dropList.push([(x1 + x2) / 2 + ox, (z1 + z2) / 2 + oz, x2 - x1, z2 - z1]); return false; } return true;
      });
      if (nDrop) dropTotal += nDrop;
      d.b.forEach(function (b) {
        var p = b.p, n = p.length / 2, rv = r(), f = famOf(b, rv), pal = PAL[f], col = (b.c && parseCol(b.c)) || pal[Math.floor(r() * pal.length)];
        var h = b.h, y0 = b.m || 0, gb = fam[f], ground = (b.k === 2 || (b.k === 6 && b.h > 9) || (b.k === 1 && r() < 0.5)) && h > 7 && !y0;
        var x1 = 1e9, x2 = -1e9, z1 = 1e9, z2 = -1e9, sA = 0;
        for (var i0 = 0; i0 < n; i0++) { var i1 = (i0 + 1) % n; sA += p[i0 * 2] * p[i1 * 2 + 1] - p[i1 * 2] * p[i0 * 2 + 1]; }
        /* walls must face outward: pick the winding from the outline's direction */
        var flip = sA > 0;
        for (var i = 0; i < n; i++) {
          var ax = p[i * 2], az = p[i * 2 + 1], bx = p[((i + 1) % n) * 2], bz = p[((i + 1) % n) * 2 + 1];
          x1 = Math.min(x1, ax); x2 = Math.max(x2, ax); z1 = Math.min(z1, az); z2 = Math.max(z2, az);
          var ex = bx - ax, ez = bz - az, el = Math.hypot(ex, ez); if (el < 0.05) continue;
          var nx = (flip ? 1 : -1) * ez / el, nz = (flip ? -1 : 1) * ex / el, u = Math.max(1, Math.round(el / 4)), gy = ground ? 4.2 : y0;
          var v0 = (gy) / 3.3, v1 = h / 3.3, sc = [col[0] * 0.7, col[1] * 0.7, col[2] * 0.7];
          if (flip) {
            if (ground) shopB.quad([bx, y0, bz], [ax, y0, az], [ax, gy, az], [bx, gy, bz], [u, 0], [0, 0], [0, 1], [u, 1], [nx, 0, nz], sc);
            gb.quad([bx, gy, bz], [ax, gy, az], [ax, h, az], [bx, h, bz], [u, v0], [0, v0], [0, v1], [u, v1], [nx, 0, nz], col);
          } else {
            if (ground) shopB.quad([ax, y0, az], [bx, y0, bz], [bx, gy, bz], [ax, gy, az], [0, 0], [u, 0], [u, 1], [0, 1], [nx, 0, nz], sc);
            gb.quad([ax, gy, az], [bx, gy, bz], [bx, h, bz], [ax, h, az], [0, v0], [u, v0], [u, v1], [0, v1], [nx, 0, nz], col);
          }
        }
        var area = (x2 - x1) * (z2 - z1), cx = 0, cz = 0; for (var q = 0; q < n; q++) { cx += p[q * 2]; cz += p[q * 2 + 1]; } cx /= n; cz /= n;
        var ccw = 0; for (var q2 = 0; q2 < n; q2++) { var q3 = (q2 + 1) % n; ccw += p[q2 * 2] * p[q3 * 2 + 1] - p[q3 * 2] * p[q2 * 2 + 1]; }
        /* outward normal of edge e (works for either winding) */
        function outN(e) { var ax = p[e * 2], az = p[e * 2 + 1], bx = p[((e + 1) % n) * 2], bz = p[((e + 1) % n) * 2 + 1], ex = bx - ax, ez = bz - az, el = Math.hypot(ex, ez) || 1; return ccw > 0 ? [ez / el, -ex / el, el] : [-ez / el, ex / el, el]; }
        var pitched = (b.k === 0 || b.rs || (b.k === 1 && h <= 13)) && area < 450 && n <= 10 && h < 16;
        var rc = ROOFC[Math.floor(r() * ROOFC.length)], wallC = [col[0] * 0.92, col[1] * 0.92, col[2] * 0.92];
        if (pitched && n === 4) {
          /* gable roof along the long side, with eaves overhang and gable-end walls */
          var V = [0, 1, 2, 3].map(function (k) { return [p[k * 2], p[k * 2 + 1]]; });
          var l01 = Math.hypot(V[1][0] - V[0][0], V[1][1] - V[0][1]), l12 = Math.hypot(V[2][0] - V[1][0], V[2][1] - V[1][1]);
          var A = l01 >= l12 ? V[0] : V[1], B = l01 >= l12 ? V[1] : V[2], C = l01 >= l12 ? V[2] : V[3], D = l01 >= l12 ? V[3] : V[0];
          var span = Math.min(l01, l12), rh = Math.min(4.2, Math.max(1.6, span * 0.42)), ov = 0.55;
          var m1 = [(B[0] + C[0]) / 2, (B[1] + C[1]) / 2], m2 = [(D[0] + A[0]) / 2, (D[1] + A[1]) / 2], ux = m1[0] - m2[0], uz = m1[1] - m2[1], ul = Math.hypot(ux, uz) || 1; ux /= ul; uz /= ul;
          function ext(P0, mid, along) { var dx = P0[0] - mid[0], dz = P0[1] - mid[1], dl = Math.hypot(dx, dz) || 1; return [P0[0] + dx / dl * ov + ux * along, P0[1] + dz / dl * ov + uz * along]; }
          var Ae = ext(A, m2, -ov), Be = ext(B, m1, ov), Ce = ext(C, m1, ov), De = ext(D, m2, -ov), R1 = [m1[0] + ux * ov, m1[1] + uz * ov], R2 = [m2[0] - ux * ov, m2[1] - uz * ov], ye = h - ov * rh / (span / 2), yr = h + rh;
          [[Ae, Be, R1, R2], [Ce, De, R2, R1]].forEach(function (Q) {
            var a3 = [Q[0][0], ye, Q[0][1]], b3 = [Q[1][0], ye, Q[1][1]], c3 = [Q[2][0], yr, Q[2][1]], d3 = [Q[3][0], yr, Q[3][1]];
            var e1 = [b3[0] - a3[0], 0, b3[2] - a3[2]], e2 = [d3[0] - a3[0], d3[1] - a3[1], d3[2] - a3[2]], nn = unit(e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]); if (nn[1] < 0) nn = [-nn[0], -nn[1], -nn[2]];
            var lu = Math.hypot(e1[0], e1[2]) / 3, lv = Math.hypot(e2[0], e2[1], e2[2]) / 3;
            fquad(tileB, a3, b3, c3, d3, nn, rc, [[0, 0], [lu, 0], [lu, lv], [0, lv]]);
            fquad(trimB, [a3[0], a3[1] - 0.12, a3[2]], [b3[0], b3[1] - 0.12, b3[2]], b3, a3, unit(nn[0], 0, nn[2]), [0.25, 0.22, 0.2]);
          });
          [[B, C, m1], [D, A, m2]].forEach(function (G3) { var nx2 = G3[2][0] - (A[0] + B[0] + C[0] + D[0]) / 4, nz2 = G3[2][1] - (A[1] + B[1] + C[1] + D[1]) / 4, nl2 = Math.hypot(nx2, nz2) || 1; ftri(gb, [G3[0][0], h, G3[0][1]], [G3[1][0], h, G3[1][1]], [G3[2][0], yr, G3[2][1]], [0, 0.02], [0.3, 0.02], [0.15, 0.2], [nx2 / nl2, 0, nz2 / nl2], col); });
        } else if (pitched) {
          var rh2 = Math.min(5, Math.sqrt(area) * 0.45);
          for (var e = 0; e < n; e++) {
            var a1 = [p[e * 2], h, p[e * 2 + 1]], b1 = [p[((e + 1) % n) * 2], h, p[((e + 1) % n) * 2 + 1]], c1 = [cx, h + rh2, cz];
            var ux2 = b1[0] - a1[0], uz2 = b1[2] - a1[2], vx = c1[0] - a1[0], vy = rh2, vz = c1[2] - a1[2];
            var nn2 = [vy * uz2 - 0 * vz, vz * ux2 - vx * uz2, vx * 0 - vy * ux2]; if (nn2[1] < 0) nn2 = [-nn2[0], -nn2[1], -nn2[2]];
            var nl = Math.hypot(nn2[0], nn2[1], nn2[2]) || 1; nn2 = [nn2[0] / nl, nn2[1] / nl, nn2[2] / nl];
            tileB.triUp(a1, c1, b1, [0, 0], [Math.hypot(ux2, uz2) / 6, Math.hypot(vx, vz) / 3], [Math.hypot(ux2, uz2) / 3, 0], nn2, rc);
          }
        } else {
          var pts = []; for (var t = 0; t < n; t++) pts.push(new T.Vector2(p[t * 2], p[t * 2 + 1]));
          try { var tris = T.ShapeUtils.triangulateShape(pts, []); var rcol = [0.9 + r() * 0.15, 0.9 + r() * 0.12, 0.9 + r() * 0.1]; tris.forEach(function (tr) { var A2 = pts[tr[0]], B2 = pts[tr[1]], C2 = pts[tr[2]]; var a3 = [A2.x, h, A2.y], b3 = [B2.x, h, B2.y], c3 = [C2.x, h, C2.y]; roofB.triUp(a3, b3, c3, [A2.x / 8, A2.y / 8], [B2.x / 8, B2.y / 8], [C2.x / 8, C2.y / 8], [0, 1, 0], rcol); if (y0 > 0.5) roofB.triUp([A2.x, y0, A2.y], [C2.x, y0, C2.y], [B2.x, y0, B2.y], [0, 0], [0, 0], [0, 0], [0, -1, 0], [0.55, 0.55, 0.55], true); }); } catch (er) {}
          /* parapet with a cap, and a cornice ledge on masonry buildings */
          if (h > 5 && n <= 40) {
            var pc = f === "com" ? [0.3, 0.33, 0.36] : f === "brick" ? [col[0] * 0.55, col[1] * 0.38, col[2] * 0.32] : [col[0] * 0.66, col[1] * 0.64, col[2] * 0.6], ph = f === "com" ? 0.5 : 0.8, corn = (f === "brick" || f === "res" || f === "civ" || f === "gen") && h > 8;
            for (var e2 = 0; e2 < n; e2++) {
              var on = outN(e2); if (on[2] < 0.3) continue;
              var ax2 = p[e2 * 2], az2 = p[e2 * 2 + 1], bx2 = p[((e2 + 1) % n) * 2], bz2 = p[((e2 + 1) % n) * 2 + 1], nx3 = on[0], nz3 = on[1], N3 = [nx3, 0, nz3];
              fquad(trimB, [ax2, h, az2], [bx2, h, bz2], [bx2, h + ph, bz2], [ax2, h + ph, az2], N3, pc);
              fquad(trimB, [ax2 - nx3 * 0.3, h, az2 - nz3 * 0.3], [bx2 - nx3 * 0.3, h, bz2 - nz3 * 0.3], [bx2 - nx3 * 0.3, h + ph, bz2 - nz3 * 0.3], [ax2 - nx3 * 0.3, h + ph, az2 - nz3 * 0.3], [-nx3, 0, -nz3], [pc[0] * 0.8, pc[1] * 0.8, pc[2] * 0.8]);
              fquad(trimB, [ax2, h + ph, az2], [bx2, h + ph, bz2], [bx2 - nx3 * 0.3, h + ph, bz2 - nz3 * 0.3], [ax2 - nx3 * 0.3, h + ph, az2 - nz3 * 0.3], [0, 1, 0], [0.5, 0.5, 0.48]);
              if (corn) { var cc = f === "brick" ? [0.78, 0.74, 0.68] : [col[0] * 0.8, col[1] * 0.78, col[2] * 0.74], co = 0.25; fquad(trimB, [ax2 + nx3 * co, h - 0.55, az2 + nz3 * co], [bx2 + nx3 * co, h - 0.55, bz2 + nz3 * co], [bx2 + nx3 * co, h, bz2 + nz3 * co], [ax2 + nx3 * co, h, az2 + nz3 * co], N3, cc); fquad(trimB, [ax2, h - 0.55, az2], [bx2, h - 0.55, bz2], [bx2 + nx3 * co, h - 0.55, bz2 + nz3 * co], [ax2 + nx3 * co, h - 0.55, az2 + nz3 * co], [0, -1, 0], [cc[0] * 0.6, cc[1] * 0.6, cc[2] * 0.6]); }
            }
            /* rooftop gear */
            if (area > 70 && !y0) {
              var tryPt = function (spread) { for (var k2 = 0; k2 < 8; k2++) { var tx = cx + (r() - 0.5) * (x2 - x1) * spread, tz = cz + (r() - 0.5) * (z2 - z1) * spread; if (inPoly(p, tx, tz) && inPoly(p, tx + 1.8, tz) && inPoly(p, tx - 1.8, tz) && inPoly(p, tx, tz + 1.8) && inPoly(p, tx, tz - 1.8)) return [tx, tz]; } return null; };
              if (h > 10 && area > 160 && r() < 0.8) { var hp = tryPt(0.3); if (hp) gear.hh.push([hp[0], h, hp[1], r() * 3]); }
              if ((f === "brick" || f === "res" || f === "gen") && h >= 14 && h <= 75 && r() < (style.tanks || 0.35)) { var tp = tryPt(0.55); if (tp) gear.tank.push([tp[0], h, tp[1], r() * 3]); }
              var nac = Math.min(4, Math.floor(area / 180)); for (var a5 = 0; a5 < nac; a5++) { var ap = tryPt(0.7); if (ap) gear.ac.push([ap[0], h, ap[1], r() * 3]); }
            }
          }
        }
        /* plinth and a front door on the longest wall of buildings without shopfronts */
        if (!y0 && !ground && h > 3 && n <= 40) {
          var best = -1, bl = 0;
          for (var e3 = 0; e3 < n; e3++) { var on2 = outN(e3); if (on2[2] > bl) { bl = on2[2]; best = e3; } var ax3 = p[e3 * 2], az3 = p[e3 * 2 + 1], bx3 = p[((e3 + 1) % n) * 2], bz3 = p[((e3 + 1) % n) * 2 + 1]; if (on2[2] > 0.5) fquad(trimB, [ax3 + on2[0] * 0.06, 0, az3 + on2[1] * 0.06], [bx3 + on2[0] * 0.06, 0, bz3 + on2[1] * 0.06], [bx3 + on2[0] * 0.06, 0.65, bz3 + on2[1] * 0.06], [ax3 + on2[0] * 0.06, 0.65, az3 + on2[1] * 0.06], [on2[0], 0, on2[1]], [col[0] * 0.52, col[1] * 0.5, col[2] * 0.48]); }
          if (best >= 0 && bl > 3.2) {
            var on3 = outN(best), dax = p[best * 2], daz = p[best * 2 + 1], dbx = p[((best + 1) % n) * 2], dbz = p[((best + 1) % n) * 2 + 1], ex4 = (dbx - dax) / bl, ez4 = (dbz - daz) / bl, mxd = (dax + dbx) / 2, mzd = (daz + dbz) / 2, hw = 0.78, off = 0.08, dh = 2.5;
            fquad(doorB, [mxd - ex4 * hw + on3[0] * off, 0.02, mzd - ez4 * hw + on3[1] * off], [mxd + ex4 * hw + on3[0] * off, 0.02, mzd + ez4 * hw + on3[1] * off], [mxd + ex4 * hw + on3[0] * off, dh, mzd + ez4 * hw + on3[1] * off], [mxd - ex4 * hw + on3[0] * off, dh, mzd - ez4 * hw + on3[1] * off], [on3[0], 0, on3[1]], null);
            fquad(trimB, [mxd - ex4 * 1.05 + on3[0] * 0.75, 2.75, mzd - ez4 * 1.05 + on3[1] * 0.75], [mxd + ex4 * 1.05 + on3[0] * 0.75, 2.75, mzd + ez4 * 1.05 + on3[1] * 0.75], [mxd + ex4 * 1.05, 2.75, mzd + ez4 * 1.05], [mxd - ex4 * 1.05, 2.75, mzd - ez4 * 1.05], [0, 1, 0], [0.22, 0.24, 0.26]);
          }
        }
        /* NFT-style murals and stickers on some walls */
        if (!y0 && M.sticker && f !== "com" && h >= 4.5 && n <= 40 && r() < 0.72) {
          for (var si5 = 0, tr5 = 0, ns5 = r() < 0.5 ? 2 : 1; si5 < ns5 && tr5 < 8; tr5++) {
            var e5 = Math.floor(r() * n), on5 = outN(e5); if (on5[2] < 4) continue;
            var s5 = Math.min(on5[2] * 0.55, h * 0.45, 7); if (s5 < 1.6) continue;
            var ax5 = p[e5 * 2], az5 = p[e5 * 2 + 1], bx5 = p[((e5 + 1) % n) * 2], bz5 = p[((e5 + 1) % n) * 2 + 1], t5 = 0.3 + r() * 0.4, mx5 = ax5 + (bx5 - ax5) * t5, mz5 = az5 + (bz5 - az5) * t5;
            var lo5 = ground ? 4.5 : 2.9, cy5 = Math.min(h - s5 / 2 - 0.3, lo5 + s5 / 2 + r() * 1.5); if (cy5 - s5 / 2 < lo5 - 0.01) continue;
            var ci5 = Math.floor(r() * 16), u5 = (ci5 % 4) / 4, v5 = 1 - Math.floor(ci5 / 4) / 4, nx5 = on5[0], nz5 = on5[1], rx5 = nz5, rz5 = -nx5, hh5 = s5 / 2, o5 = 0.07;
            /* solid painted panel behind the mural so it never covers a window */
            var hb5 = Math.max(hh5, Math.min(hh5 * 1.18, h - 0.05 - cy5)), ob5 = 0.045, bg5 = [[0.07, 0.04, 0.14], [0.93, 0.9, 0.84], [0.11, 0.42, 0.46], [0.8, 0.24, 0.42], [0.98, 0.74, 0.2], [0.33, 0.12, 0.55]][ci5 % 6];
            fquad(trimB, [mx5 - rx5 * hb5 + nx5 * ob5, cy5 - hb5, mz5 - rz5 * hb5 + nz5 * ob5], [mx5 + rx5 * hb5 + nx5 * ob5, cy5 - hb5, mz5 + rz5 * hb5 + nz5 * ob5], [mx5 + rx5 * hb5 + nx5 * ob5, cy5 + hb5, mz5 + rz5 * hb5 + nz5 * ob5], [mx5 - rx5 * hb5 + nx5 * ob5, cy5 + hb5, mz5 - rz5 * hb5 + nz5 * ob5], [nx5, 0, nz5], bg5);
            fquad(stkB, [mx5 - rx5 * hh5 + nx5 * o5, cy5 - hh5, mz5 - rz5 * hh5 + nz5 * o5], [mx5 + rx5 * hh5 + nx5 * o5, cy5 - hh5, mz5 + rz5 * hh5 + nz5 * o5], [mx5 + rx5 * hh5 + nx5 * o5, cy5 + hh5, mz5 + rz5 * hh5 + nz5 * o5], [mx5 - rx5 * hh5 + nx5 * o5, cy5 + hh5, mz5 - rz5 * hh5 + nz5 * o5], [nx5, 0, nz5], [1, 1, 1], [[u5, v5 - 0.25], [u5 + 0.25, v5 - 0.25], [u5 + 0.25, v5], [u5, v5]]);
            si5++;
          }
        }
        /* glass office blocks: the sticker goes on a steel billboard standing on the roof, never on the glass */
        if (!y0 && M.sticker && f === "com" && h >= 7 && h <= 70 && n <= 40 && r() < 0.6) {
          var be6 = -1, bl6 = 0;
          for (var e6 = 0; e6 < n; e6++) { var o6 = outN(e6); if (o6[2] > bl6) { bl6 = o6[2]; be6 = e6; } }
          if (be6 >= 0 && bl6 >= 6) {
            var on6 = outN(be6), nx6 = on6[0], nz6 = on6[1], rx6 = nz6, rz6 = -nx6, hh6 = Math.min(bl6 * 0.32, 4.5, 1.6 + h * 0.08);
            var mx6 = (p[be6 * 2] + p[((be6 + 1) % n) * 2]) / 2 - nx6 * 1.1, mz6 = (p[be6 * 2 + 1] + p[((be6 + 1) % n) * 2 + 1]) / 2 - nz6 * 1.1;
            if (inPoly(p, mx6, mz6) && inPoly(p, mx6 - rx6 * hh6 - nx6 * 0.4, mz6 - rz6 * hh6 - nz6 * 0.4) && inPoly(p, mx6 + rx6 * hh6 - nx6 * 0.4, mz6 + rz6 * hh6 - nz6 * 0.4)) {
              var yb6 = h + 1.3, yt6 = yb6 + hh6 * 2, ci6 = Math.floor(r() * 16), u6 = (ci6 % 4) / 4, v6 = 1 - Math.floor(ci6 / 4) / 4, th6 = 0.3, bw6 = hh6 + 0.18;
              var bg6 = [[0.07, 0.04, 0.14], [0.93, 0.9, 0.84], [0.11, 0.42, 0.46], [0.8, 0.24, 0.42], [0.98, 0.74, 0.2], [0.33, 0.12, 0.55]][ci6 % 6], fr6 = [0.17, 0.18, 0.2], N6 = [nx6, 0, nz6], B6 = [-nx6, 0, -nz6], R6 = [rx6, 0, rz6], L6 = [-rx6, 0, -rz6];
              /* s = sideways, d = depth behind the front face */
              var P6 = function (s, y, d) { return [mx6 + rx6 * s - nx6 * d, y, mz6 + rz6 * s - nz6 * d]; };
              var box6 = function (s0, s1, ya, yb, d0, d1, c) {
                fquad(trimB, P6(s0, ya, d0), P6(s1, ya, d0), P6(s1, yb, d0), P6(s0, yb, d0), N6, c); fquad(trimB, P6(s0, ya, d1), P6(s1, ya, d1), P6(s1, yb, d1), P6(s0, yb, d1), B6, c);
                fquad(trimB, P6(s1, ya, d0), P6(s1, ya, d1), P6(s1, yb, d1), P6(s1, yb, d0), R6, c); fquad(trimB, P6(s0, ya, d0), P6(s0, ya, d1), P6(s0, yb, d1), P6(s0, yb, d0), L6, c);
                fquad(trimB, P6(s0, yb, d0), P6(s1, yb, d0), P6(s1, yb, d1), P6(s0, yb, d1), [0, 1, 0], c); fquad(trimB, P6(s0, ya, d0), P6(s1, ya, d0), P6(s1, ya, d1), P6(s0, ya, d1), [0, -1, 0], c);
              };
              box6(-bw6, bw6, yb6 - 0.18, yt6 + 0.18, 0, th6, fr6);
              [-0.62, 0.62].forEach(function (k6) { box6(hh6 * k6 - 0.14, hh6 * k6 + 0.14, h, yb6 - 0.18, th6 * 0.5 - 0.14, th6 * 0.5 + 0.14, fr6); });
              box6(-bw6 + 0.1, bw6 - 0.1, h + 0.55, h + 0.7, th6 * 0.5 - 0.07, th6 * 0.5 + 0.07, fr6);
              fquad(trimB, P6(-hh6, yb6, -0.03), P6(hh6, yb6, -0.03), P6(hh6, yt6, -0.03), P6(-hh6, yt6, -0.03), N6, bg6);
              var hs6 = hh6 * 0.9, cy6 = (yb6 + yt6) / 2;
              fquad(stkB, P6(-hs6, cy6 - hs6, -0.06), P6(hs6, cy6 - hs6, -0.06), P6(hs6, cy6 + hs6, -0.06), P6(-hs6, cy6 + hs6, -0.06), N6, [1, 1, 1], [[u6, v6 - 0.25], [u6 + 0.25, v6 - 0.25], [u6 + 0.25, v6], [u6, v6]]);
              nBoard++;
            }
          }
        }
        if (!y0) { var bb = { p: p, x1: x1, x2: x2, z1: z1, z2: z2, h: h, t: b.t, n: b.n, k: b.k }; blds.push(bb); addCell(bb); }
      });
      /* buildings that stand over the river (piers, waterfront platforms) get a concrete quay around them */
      var piers = [], quayB = new GB(), wallQ = new GB(), WP = (d.w || []).filter(function (w) { return !w.line; });
      if (WP.length) blds.forEach(function (b) {
        var p = b.p, n = p.length / 2, wet = 0, cx = 0, cz = 0; for (var i = 0; i < n; i++) { cx += p[i * 2]; cz += p[i * 2 + 1]; if (WP.some(function (w) { return inPoly(w.p, p[i * 2], p[i * 2 + 1]); })) wet++; } cx /= n; cz /= n;
        var cw = WP.some(function (w) { return inPoly(w.p, cx, cz); }); if (!cw && wet < Math.max(1, n * 0.3)) return;
        var q = []; for (var j = 0; j < n; j++) { var dx = p[j * 2] - cx, dz = p[j * 2 + 1] - cz, l = Math.hypot(dx, dz) || 1; q.push(p[j * 2] + dx / l * 6, p[j * 2 + 1] + dz / l * 6); }
        polyFill(quayB, q, 0.12, 4);
        for (var e = 0; e < n; e++) { var a = [q[e * 2], q[e * 2 + 1]], c2 = [q[((e + 1) % n) * 2], q[((e + 1) % n) * 2 + 1]], ex = c2[0] - a[0], ez = c2[1] - a[1], el = Math.hypot(ex, ez) || 1; wallQ.quad([a[0], -1.2, a[1]], [c2[0], -1.2, c2[1]], [c2[0], 0.12, c2[1]], [a[0], 0.12, a[1]], [0, 0], [el / 4, 0], [el / 4, 0.3], [0, 0.3], [ez / el, 0, -ex / el]); }
        var x1 = 1e9, x2 = -1e9, z1 = 1e9, z2 = -1e9; for (var k = 0; k < q.length; k += 2) { x1 = Math.min(x1, q[k]); x2 = Math.max(x2, q[k]); z1 = Math.min(z1, q[k + 1]); z2 = Math.max(z2, q[k + 1]); }
        piers.push({ p: q, x1: x1, x2: x2, z1: z1, z2: z2 });
      });
      [[quayB, M.plaza, 2], [wallQ, M.plaza, 2]].forEach(function (x) { var m = x[0].mesh(x[1], false, true); if (m) { m.renderOrder = x[2]; g.add(m); } });
      Object.keys(fam).forEach(function (f) { var m = fam[f].mesh(M.fac[f], true); if (m) g.add(m); });
      [[shopB, M.shop, true], [roofB, M.roof, false], [tileB, M.tile, true], [trimB, M.trim, true], [doorB, M.door, false]].forEach(function (x) { var m = x[0].mesh(x[1], x[2]); if (m) g.add(m); });
      if (M.sticker) { var stm = stkB.mesh(M.sticker, false); if (stm) g.add(stm); }
      boardTotal += nBoard;
      [["tank", tankGeo, M.tankWood], ["tank", tankTopGeo, M.steelDk], ["tank", standGeo, M.steelDk], ["ac", acGeo, M.ac], ["hh", hhGeo, M.hh]].forEach(function (x) {
        var L = gear[x[0]]; if (!L.length) return; var im = new T.InstancedMesh(x[1], x[2], L.length), mm = new T.Matrix4(), qq = new T.Quaternion(), up = new T.Vector3(0, 1, 0), one = new T.Vector3(1, 1, 1);
        L.forEach(function (o, i) { qq.setFromAxisAngle(up, o[3]); mm.compose(new T.Vector3(o[0], o[1], o[2]), qq, one); im.setMatrixAt(i, mm); }); im.castShadow = true; im.receiveShadow = true; g.add(im);
      });

      var walkB = new GB(), rMaj = new GB(), rMin = new GB(), rPl = new GB(), rPath = new GB(), rPed = new GB(), railB = new GB(), waterB = new GB(), grassB = new GB(), plazaB = new GB();
      var roads = [];
      d.r.forEach(function (rd) {
        var w = rd.w, c = rd.c;
        if (rd.d && c <= 3) ribbon(walkB, rd.p, w + 6.4, 0.06, 8);
        var gb = c <= 1 ? rMaj : c === 2 ? rMin : c <= 4 ? (c === 3 ? rMin : rPl) : c === 5 ? rPed : rPath;
        ribbon(gb, rd.p, w, c >= 5 ? 0.07 : 0.09, c >= 5 ? 8 : 16);
        if (rd.d) { var ref = { p: rd.p, w: w, a: rd.a, b: rd.b, o: rd.o, c: c, n: rd.n, len: plen(rd.p), tile: key }; roads.push(ref); (nodes[rd.a] || (nodes[rd.a] = [])).push(ref); (nodes[rd.b] || (nodes[rd.b] = [])).push(ref); }
      });
      /* junctions: a clean asphalt patch where roads meet, zebra crossings on the bigger streets, and gap fillers where road pieces join */
      var junB = new GB(), joinB = new GB(), zebB = new GB(), NODE = {};
      d.r.forEach(function (rd) {
        if (!rd.d || rd.c >= 5 || rd.p.length < 4) return;
        [[0, rd.a], [rd.p.length - 2, rd.b]].forEach(function (e) {
          var x = rd.p[e[0]], z = rd.p[e[0] + 1], k = Math.round(x * 2) + "," + Math.round(z * 2), o = NODE[k] || (NODE[k] = { x: x, z: z, n: 0, w: 0, ends: [] });
          var j = e[0] === 0 ? 2 : rd.p.length - 4, dx = rd.p[j] - x, dz = rd.p[j + 1] - z, l = Math.hypot(dx, dz) || 1;
          o.n++; o.w = Math.max(o.w, rd.w); o.ends.push({ dx: dx / l, dz: dz / l, w: rd.w, c: rd.c, len: l });
        });
      });
      d.r.forEach(function (rd) {
        if (!rd.d || rd.c >= 5) return;
        for (var i = 2; i < rd.p.length - 2; i += 2) { var k = Math.round(rd.p[i] * 2) + "," + Math.round(rd.p[i + 1] * 2), o = NODE[k]; if (!o) continue; o.n += 2; o.w = Math.max(o.w, rd.w);
          [[rd.p[i - 2], rd.p[i - 1]], [rd.p[i + 2], rd.p[i + 3]]].forEach(function (q) { var dx = q[0] - o.x, dz = q[1] - o.z, l = Math.hypot(dx, dz) || 1; o.ends.push({ dx: dx / l, dz: dz / l, w: rd.w, c: rd.c, len: l }); }); }
      });
      function disc(gb, x, z, r, y) { var N = 18; for (var q = 0; q < N; q++) { var a1 = q / N * Math.PI * 2, a2 = (q + 1) / N * Math.PI * 2; gb.triUp([x, y, z], [x + Math.cos(a1) * r, y, z + Math.sin(a1) * r], [x + Math.cos(a2) * r, y, z + Math.sin(a2) * r], [x / 8, z / 8], [(x + Math.cos(a1) * r) / 8, (z + Math.sin(a1) * r) / 8], [(x + Math.cos(a2) * r) / 8, (z + Math.sin(a2) * r) / 8], [0, 1, 0]); } }
      Object.keys(NODE).forEach(function (k) {
        var o = NODE[k];
        if (o.n >= 3) {
          var R0 = o.w / 2 + 0.8; disc(junB, o.x, o.z, R0, 0.092);
          o.ends.forEach(function (e) {
            if (e.c > 4 || e.w < 6 || e.len < R0 + 6) return;
            var s0 = R0 + 0.8, s1 = s0 + 3, px = -e.dz, pz = e.dx, half = e.w / 2 - 0.6;
            for (var t = -half; t <= half - 0.45; t += 1.05) {
              var ax = o.x + e.dx * s0 + px * t, az = o.z + e.dz * s0 + pz * t, bx = o.x + e.dx * s1 + px * t, bz = o.z + e.dz * s1 + pz * t;
              zebB.triUp([ax, 0.096, az], [bx, 0.096, bz], [bx + px * 0.5, 0.096, bz + pz * 0.5], [0, 0], [0, 1], [1, 1], [0, 1, 0]); zebB.triUp([ax, 0.096, az], [bx + px * 0.5, 0.096, bz + pz * 0.5], [ax + px * 0.5, 0.096, az + pz * 0.5], [0, 0], [1, 1], [1, 0], [0, 1, 0]);
            }
          });
        } else if (o.n === 2) disc(joinB, o.x, o.z, o.w / 2, 0.089);
      });
      [[joinB, M.rJunc, 2.9], [junB, M.rJunc, 3.5], [zebB, M.zebra, 3.6]].forEach(function (x) { var m = x[0].mesh(x[1], false, true); if (m) { m.renderOrder = x[2]; g.add(m); } });
      d.rl.forEach(function (rl) { ribbon(railB, rl.p, rl.w, 0.1, 6); });
      d.w.forEach(function (w) { if (w.line) ribbon(waterB, w.p, w.line, 0.03, 20); else polyFill(waterB, w.p, 0.03, 30); });
      d.g.forEach(function (gr) { polyFill(grassB, gr.p, 0.04, 6); });
      d.pz.forEach(function (pz) { polyFill(plazaB, pz.p, 0.05, 4); });
      var landB = new GB(), sandB = new GB();
      (d.ld || []).forEach(function (q) { polyFill(landB, q.p, 0.0, 6); });
      (d.sd || []).forEach(function (q) { polyFill(sandB, q.p, 0.02, 5); });
      [[landB, M.land, 0.5], [sandB, M.sand, 0.8]].forEach(function (x) { var m = x[0].mesh(x[1], false, true); if (m) { m.renderOrder = x[2]; g.add(m); } });
      [[walkB, M.walk, 1], [rMaj, M.rMajor, 3], [rMin, M.rMinor, 3], [rPl, M.rPlain, 3], [rPath, M.rPath, 2], [rPed, M.rPed, 2], [railB, M.rail, 4], [waterB, M.water, 1], [grassB, M.grass, 1], [plazaB, M.plaza, 1]].forEach(function (x) { var m = x[0].mesh(x[1], false, true); if (m) { m.renderOrder = x[2]; g.add(m); } });

      /* bridges over the sea: a deck with concrete sides, parapets, piers in the water */
      var brB = new GB();
      d.r.forEach(function (rd) {
        if (!rd.br) return; var p = rd.p, e = rd.w / 2 + (rd.d && rd.c <= 3 ? 3.3 : 0.5), acc = 0, CON = [0.72, 0.71, 0.68], DK = [0.42, 0.42, 0.41];
        for (var i = 2; i < p.length; i += 2) {
          var ax = p[i - 2], az = p[i - 1], bx = p[i], bz = p[i + 1], L = Math.hypot(bx - ax, bz - az); if (L < 0.2) continue;
          var tx = (bx - ax) / L, tz = (bz - az) / L, nx = -tz, nz = tx;
          [-1, 1].forEach(function (sd) {
            var ex = nx * e * sd, ez = nz * e * sd, A = [ax + ex, az + ez], B = [bx + ex, bz + ez], on = [nx * sd, 0, nz * sd];
            fquad(brB, [A[0], -2.2, A[1]], [B[0], -2.2, B[1]], [B[0], 0.1, B[1]], [A[0], 0.1, A[1]], on, DK);
            /* parapet */
            var o2x = nx * sd * 0.35, o2z = nz * sd * 0.35, Ai = [A[0] - o2x, A[1] - o2z], Bi = [B[0] - o2x, B[1] - o2z];
            fquad(brB, [A[0], 0.1, A[1]], [B[0], 0.1, B[1]], [B[0], 1.05, B[1]], [A[0], 1.05, A[1]], on, CON);
            fquad(brB, [Ai[0], 0.1, Ai[1]], [Bi[0], 0.1, Bi[1]], [Bi[0], 1.05, Bi[1]], [Ai[0], 1.05, Ai[1]], [-on[0], 0, -on[2]], CON);
            fquad(brB, [A[0], 1.05, A[1]], [B[0], 1.05, B[1]], [Bi[0], 1.05, Bi[1]], [Ai[0], 1.05, Ai[1]], [0, 1, 0], [0.82, 0.81, 0.78]);
            var wb = { p: [A[0], A[1], B[0], B[1], Bi[0], Bi[1], Ai[0], Ai[1]], x1: Math.min(A[0], B[0], Ai[0], Bi[0]), x2: Math.max(A[0], B[0], Ai[0], Bi[0]), z1: Math.min(A[1], B[1], Ai[1], Bi[1]), z2: Math.max(A[1], B[1], Ai[1], Bi[1]), h: 1.05, wall: true, rail: true };
            blds.push(wb); addCell(wb);
          });
          /* underside */
          fquad(brB, [ax - nx * e, -0.3, az - nz * e], [bx - nx * e, -0.3, bz - nz * e], [bx + nx * e, -0.3, bz + nz * e], [ax + nx * e, -0.3, az + nz * e], [0, -1, 0], DK);
          for (var s2 = (40 - acc % 40) % 40; s2 < L; s2 += 40) {
            var px = ax + tx * s2, pz = az + tz * s2, pw = e - 0.6, pd = 1.6;
            var c1 = [px - nx * pw - tx * pd, pz - nz * pw - tz * pd], c2 = [px + nx * pw - tx * pd, pz + nz * pw - tz * pd], c3 = [px + nx * pw + tx * pd, pz + nz * pw + tz * pd], c4 = [px - nx * pw + tx * pd, pz - nz * pw + tz * pd];
            [[c1, c2, [-tx, 0, -tz]], [c2, c3, [nx, 0, nz]], [c3, c4, [tx, 0, tz]], [c4, c1, [-nx, 0, -nz]]].forEach(function (f) { fquad(brB, [f[0][0], -6, f[0][1]], [f[1][0], -6, f[1][1]], [f[1][0], -0.3, f[1][1]], [f[0][0], -0.3, f[0][1]], f[2], DK); });
          }
          acc += L;
        }
      });
      var brm = brB.mesh(M.trim, true); if (brm) g.add(brm);
      /* trees in parks, lamps along roads */
      var trees = [];
      d.g.forEach(function (gr) {
        var p = gr.p, x1 = 1e9, x2 = -1e9, z1 = 1e9, z2 = -1e9; for (var i = 0; i < p.length; i += 2) { x1 = Math.min(x1, p[i]); x2 = Math.max(x2, p[i]); z1 = Math.min(z1, p[i + 1]); z2 = Math.max(z2, p[i + 1]); }
        var cnt = Math.min(140, Math.floor((x2 - x1) * (z2 - z1) / (gr.k ? 40 : 160)));
        for (var k = 0; k < cnt; k++) { var x = x1 + r() * (x2 - x1), z = z1 + r() * (z2 - z1); if (inPoly(p, x, z)) trees.push([x, z, 0.75 + r() * 0.6]); }
      });
      d.r.forEach(function (rd) {
        if (!rd.d || rd.c > 3 || rd.c === 0) return;
        var p = rd.p, acc = 0;
        for (var i = 2; i < p.length; i += 2) {
          var ax = p[i - 2], az = p[i - 1], bx = p[i], bz = p[i + 1], sl = Math.hypot(bx - ax, bz - az); if (sl < 1) continue;
          var nx = -(bz - az) / sl, nz = (bx - ax) / sl;
          for (var s = (13 - acc % 13); s < sl; s += 13) { var x = ax + (bx - ax) * s / sl, z = az + (bz - az) * s / sl, side = (Math.floor((acc + s) / 13) % 2) ? 1 : -1, tx = x + nx * side * (rd.w / 2 + 2.2), tz = z + nz * side * (rd.w / 2 + 2.2); if (!hitBuilding(tx + ox, tz + oz, 1.4)) trees.push([tx, tz, 0.7 + r() * 0.35, rd.c <= 2 ? "lamp" : null, Math.atan2(-nz * side, nx * side)]); }
          acc += sl;
        }
      });
      /* never put a tree or lamp on a road, rail line or path */
      var SG = {}, SC = 16;
      function addSeg(ax, az, bx, bz, rad) { var sg = [ax, az, bx, bz, rad]; for (var i = Math.floor((Math.min(ax, bx) - rad) / SC); i <= Math.floor((Math.max(ax, bx) + rad) / SC); i++) for (var j = Math.floor((Math.min(az, bz) - rad) / SC); j <= Math.floor((Math.max(az, bz) + rad) / SC); j++) (SG[i + "," + j] || (SG[i + "," + j] = [])).push(sg); }
      AR.forEach(function (rd) { var rad = rd.w / 2 + (rd.c >= 5 ? 0.7 : 1.5); for (var i = 2; i < rd.p.length; i += 2) addSeg(rd.p[i - 2], rd.p[i - 1], rd.p[i], rd.p[i + 1], rad); });
      (d.rl || []).forEach(function (rl) { var pp = rl.p || rl; for (var i = 2; i < pp.length; i += 2) addSeg(pp[i - 2], pp[i - 1], pp[i], pp[i + 1], 3); });
      function onRoad(x, z) { var a = SG[Math.floor(x / SC) + "," + Math.floor(z / SC)]; if (!a) return false; for (var i = 0; i < a.length; i++) { var q = a[i], ex = q[2] - q[0], ez = q[3] - q[1], l2 = ex * ex + ez * ez || 1, t = Math.max(0, Math.min(1, ((x - q[0]) * ex + (z - q[1]) * ez) / l2)), dx = x - q[0] - ex * t, dz = z - q[1] - ez * t; if (dx * dx + dz * dz < q[4] * q[4]) return true; } return false; }
      trees = trees.filter(function (t) { return !onRoad(t[0], t[1]); });
      var tr = trees.filter(function (t) { return !t[3] || Math.random() < 0.55; });
      var nt = tr.filter(function (t) { return t[3] !== "lamp"; }), nl = tr.filter(function (t) { return t[3] === "lamp"; });
      if (nt.length) {
        var im1 = new T.InstancedMesh(treeGeo, M.trunk, nt.length), im2 = new T.InstancedMesh(crownGeo, M.leaf, nt.length), mm = new T.Matrix4(), q = new T.Quaternion(), sc = new T.Vector3(), ps = new T.Vector3();
        nt.forEach(function (t, i) { q.setFromAxisAngle(new T.Vector3(0, 1, 0), r() * 6.28); sc.set(t[2], t[2] * (0.9 + r() * 0.4), t[2]); ps.set(t[0], 0, t[1]); mm.compose(ps, q, sc); im1.setMatrixAt(i, mm); im2.setMatrixAt(i, mm); var cc = new T.Color().setHSL(0.24 + r() * 0.08, 0.35 + r() * 0.2, 0.26 + r() * 0.12); im2.setColorAt(i, cc); });
        im1.castShadow = im2.castShadow = true; im2.receiveShadow = true; g.add(im1); g.add(im2);
        nt.forEach(function (t) { var bb = { p: null, x1: t[0] - 0.3, x2: t[0] + 0.3, z1: t[1] - 0.3, z2: t[1] + 0.3, tree: true }; blds.push(bb); addCell(bb); });
      }
      if (nl.length) {
        var l1 = new T.InstancedMesh(lampGeo, M.lamp, nl.length), l2 = new T.InstancedMesh(headGeo, M.lamp, nl.length), l3 = new T.InstancedMesh(bulbGeo, M.bulb, nl.length), m2 = new T.Matrix4(), q2 = new T.Quaternion(), one = new T.Vector3(1, 1, 1), p2 = new T.Vector3();
        nl.forEach(function (t, i) { q2.setFromAxisAngle(new T.Vector3(0, 1, 0), t[4]); p2.set(t[0], 0, t[1]); m2.compose(p2, q2, one); l1.setMatrixAt(i, m2); l2.setMatrixAt(i, m2); l3.setMatrixAt(i, m2); });
        l1.castShadow = true; g.add(l1); g.add(l2); g.add(l3);
        nl.forEach(function (t) { var bb = { p: null, x1: t[0] - 0.15, x2: t[0] + 0.15, z1: t[1] - 0.15, z2: t[1] + 0.15, tree: true }; blds.push(bb); addCell(bb); });
      }
      /* boundary walls: a yard wall around each building where there is room, with a gate facing the street */
      (function () {
        var WG = {}, WC = 16, wallB = new GB(), WH = 1.7, WT = 0.24;
        AR.forEach(function (rd) { var rad = rd.w / 2 + (rd.d && rd.c <= 3 ? 3.6 : rd.c >= 5 ? 1.0 : 1.8); for (var i = 2; i < rd.p.length; i += 2) { var sg = [rd.p[i - 2], rd.p[i - 1], rd.p[i], rd.p[i + 1], rad, rd.d && rd.c <= 4]; for (var a = Math.floor((Math.min(sg[0], sg[2]) - rad) / WC); a <= Math.floor((Math.max(sg[0], sg[2]) + rad) / WC); a++) for (var b = Math.floor((Math.min(sg[1], sg[3]) - rad) / WC); b <= Math.floor((Math.max(sg[1], sg[3]) + rad) / WC); b++) (WG[a + "," + b] || (WG[a + "," + b] = [])).push(sg); } });
        d.w.forEach(function (w) { if (w.line) { var rad = w.line / 2 + 1; for (var i = 2; i < w.p.length; i += 2) { var sg = [w.p[i - 2], w.p[i - 1], w.p[i], w.p[i + 1], rad, false]; for (var a = Math.floor((Math.min(sg[0], sg[2]) - rad) / WC); a <= Math.floor((Math.max(sg[0], sg[2]) + rad) / WC); a++) for (var b = Math.floor((Math.min(sg[1], sg[3]) - rad) / WC); b <= Math.floor((Math.max(sg[1], sg[3]) + rad) / WC); b++) (WG[a + "," + b] || (WG[a + "," + b] = [])).push(sg); } } });
        var WPOLY = d.w.filter(function (w) { return !w.line; }).map(function (w) { return w.p; }).concat(d.pz.map(function (q) { return q.p; }));
        function clear(x, z) { for (var wi = 0; wi < WPOLY.length; wi++) if (inPoly(WPOLY[wi], x, z)) return false; var a = WG[Math.floor(x / WC) + "," + Math.floor(z / WC)]; if (a) for (var i = 0; i < a.length; i++) { var q = a[i], ex = q[2] - q[0], ez = q[3] - q[1], l2 = ex * ex + ez * ez || 1, t = Math.max(0, Math.min(1, ((x - q[0]) * ex + (z - q[1]) * ez) / l2)), dx = x - q[0] - ex * t, dz = z - q[1] - ez * t; if (dx * dx + dz * dz < q[4] * q[4]) return false; } return !hitBuilding(x + ox, z + oz, 0.3); }
        function nearRoad(x, z) { var best = null, bd = 1e9; for (var ci = -3; ci <= 3; ci++) for (var cj = -3; cj <= 3; cj++) { var a = WG[(Math.floor(x / WC) + ci) + "," + (Math.floor(z / WC) + cj)]; if (a) a.forEach(function (q) { if (!q[5]) return; var ex = q[2] - q[0], ez = q[3] - q[1], l2 = ex * ex + ez * ez || 1, t = Math.max(0, Math.min(1, ((x - q[0]) * ex + (z - q[1]) * ez) / l2)), px = q[0] + ex * t, pz = q[1] + ez * t, dd = Math.hypot(x - px, z - pz); if (dd < bd) { bd = dd; best = [px, pz]; } }); } return best; }
        var PALW = [[0.95, 0.93, 0.88], [0.78, 0.45, 0.36], [0.72, 0.72, 0.7], [0.86, 0.8, 0.68], [0.55, 0.57, 0.6]];
        blds.slice().forEach(function (b) {
          if (!b.p || b.tree || b.wall) return; if (GEN && !(b.k === 0 || b.k === 4 || b.k === 5)) return; var p = b.p, n = p.length / 2, area = (b.x2 - b.x1) * (b.z2 - b.z1); if (area < 30 || area > 6000) return;
          /* oriented box of the footprint, aligned with its longest edge */
          var li = 0, ll = 0; for (var i = 0; i < n; i++) { var j = (i + 1) % n, l = Math.hypot(p[j * 2] - p[i * 2], p[j * 2 + 1] - p[i * 2 + 1]); if (l > ll) { ll = l; li = i; } }
          var ux = (p[((li + 1) % n) * 2] - p[li * 2]) / ll, uz = (p[((li + 1) % n) * 2 + 1] - p[li * 2 + 1]) / ll, vx = -uz, vz = ux, a1 = 1e9, a2 = -1e9, b1 = 1e9, b2 = -1e9;
          for (var k = 0; k < n; k++) { var pu = p[k * 2] * ux + p[k * 2 + 1] * uz, pv = p[k * 2] * vx + p[k * 2 + 1] * vz; a1 = Math.min(a1, pu); a2 = Math.max(a2, pu); b1 = Math.min(b1, pv); b2 = Math.max(b2, pv); }
          var cx = 0, cz = 0; for (var c = 0; c < n; c++) { cx += p[c * 2]; cz += p[c * 2 + 1]; } cx /= n; cz /= n;
          var road = nearRoad(cx, cz); if (!road) return;
          var pick = null;
          [3.2, 2.0, 1.2].some(function (dd) {
            var cs = [[a1 - dd, b1 - dd], [a2 + dd, b1 - dd], [a2 + dd, b2 + dd], [a1 - dd, b2 + dd]].map(function (q) { return [q[0] * ux + q[1] * vx, q[0] * uz + q[1] * vz]; });
            var samples = [], bad = 0;
            for (var e = 0; e < 4; e++) { var A = cs[e], B = cs[(e + 1) % 4], L = Math.hypot(B[0] - A[0], B[1] - A[1]), m = Math.max(2, Math.ceil(L / 1.5)); for (var t = 0; t < m; t++) { var x = A[0] + (B[0] - A[0]) * t / m, z = A[1] + (B[1] - A[1]) * t / m, ok = clear(x, z); if (!ok) bad++; samples.push([x, z, ok, e]); } }
            if (bad / samples.length < 0.45) { pick = { cs: cs, s: samples }; return true; } return false;
          });
          if (!pick) return;
          /* gate: the 3 m of wall closest to the street stays open */
          var gi = 0, gd = 1e9; pick.s.forEach(function (q, i) { var dd = Math.hypot(q[0] - road[0], q[1] - road[1]); if (dd < gd) { gd = dd; gi = i; } });
          var gx = pick.s[gi][0], gz = pick.s[gi][1], col = PALW[Math.floor(r() * PALW.length)];
          for (var i2 = 0; i2 < pick.s.length; i2++) {
            var q0 = pick.s[i2], q1 = pick.s[(i2 + 1) % pick.s.length];
            if (!q0[2] || !q1[2] || Math.hypot((q0[0] + q1[0]) / 2 - gx, (q0[1] + q1[1]) / 2 - gz) < 1.9) continue;
            var sx = q1[0] - q0[0], sz = q1[1] - q0[1], sl = Math.hypot(sx, sz); if (sl < 0.05) continue;
            var nx = -sz / sl * WT / 2, nz = sx / sl * WT / 2, P0 = [q0[0] + nx, q0[1] + nz], P1 = [q1[0] + nx, q1[1] + nz], P2 = [q1[0] - nx, q1[1] - nz], P3 = [q0[0] - nx, q0[1] - nz], u = sl / 4;
            wallB.quad([P0[0], 0, P0[1]], [P1[0], 0, P1[1]], [P1[0], WH, P1[1]], [P0[0], WH, P0[1]], [0, 0], [u, 0], [u, 1], [0, 1], [nx / WT * 2, 0, nz / WT * 2], col);
            wallB.quad([P2[0], 0, P2[1]], [P3[0], 0, P3[1]], [P3[0], WH, P3[1]], [P2[0], WH, P2[1]], [0, 0], [u, 0], [u, 1], [0, 1], [-nx / WT * 2, 0, -nz / WT * 2], col);
            wallB.quad([P0[0], WH, P0[1]], [P1[0], WH, P1[1]], [P2[0], WH, P2[1]], [P3[0], WH, P3[1]], [0, 0], [u, 0], [u, 0.1], [0, 0.1], [0, 1, 0], [col[0] * 0.85, col[1] * 0.85, col[2] * 0.85]);
            var bb = { p: [P0[0], P0[1], P1[0], P1[1], P2[0], P2[1], P3[0], P3[1]], x1: Math.min(P0[0], P1[0], P2[0], P3[0]), x2: Math.max(P0[0], P1[0], P2[0], P3[0]), z1: Math.min(P0[1], P1[1], P2[1], P3[1]), z2: Math.max(P0[1], P1[1], P2[1], P3[1]), h: WH, wall: true };
            blds.push(bb); addCell(bb);
          }
        });
        var wm = wallB.mesh(M.bwall, true, true); if (wm) g.add(wm);
      })();
      d.poi.forEach(function (pp) { pp.tile = key; pois.push(pp); });
      g.updateMatrixWorld(true);
      root.add(g);
      if (o.onTile) try { o.onTile(key, d); } catch (er) {}
      /* drivable road index: driving on a real street is never blocked by building data that overlaps it */
      var rsegs = [];
      d.r.forEach(function (rd) { if (rd.c > 4) return; var hw = rd.w / 2 - 0.4; for (var i = 2; i < rd.p.length; i += 2) { var sg = { a: rd.p[i - 2], b: rd.p[i - 1], c: rd.p[i], d: rd.p[i + 1], w: hw }; sg.cells = []; for (var ci = Math.floor((Math.min(sg.a, sg.c) - hw) / CELL); ci <= Math.floor((Math.max(sg.a, sg.c) + hw) / CELL); ci++) for (var cj = Math.floor((Math.min(sg.b, sg.d) - hw) / CELL); cj <= Math.floor((Math.max(sg.b, sg.d) + hw) / CELL); cj++) { var kk = ci + "," + cj; (rgrid[kk] || (rgrid[kk] = [])).push(sg); sg.cells.push(kk); } rsegs.push(sg); } });
      return { piers: piers, g: g, blds: blds, roads: roads, key: key, rsegs: rsegs, water: d.w || [] };
    }
    function plen(p) { var s = 0; for (var i = 2; i < p.length; i += 2) s += Math.hypot(p[i] - p[i - 2], p[i + 1] - p[i - 1]); return s; }
    function hashStr(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }

    function unload(key) {
      var t = tiles[key]; if (!t) return;
      root.remove(t.g); t.g.traverse(function (m) { if (m.geometry && SHARED.indexOf(m.geometry) < 0) m.geometry.dispose(); if (m.isInstancedMesh) m.dispose && m.dispose(); });
      t.blds.forEach(removeCells);
      (t.rsegs || []).forEach(function (sg) { sg.cells.forEach(function (kk) { var a = rgrid[kk]; if (a) { var x = a.indexOf(sg); if (x >= 0) a.splice(x, 1); } }); });
      t.roads.forEach(function (r) { [r.a, r.b].forEach(function (id) { var a = nodes[id]; if (a) { var x = a.indexOf(r); if (x >= 0) a.splice(x, 1); if (!a.length) delete nodes[id]; } }); });
      pois = pois.filter(function (p) { return p.tile !== key; });
      delete tiles[key];
    }
    /* tile data: fetched once, kept until the tile is built; the roads of every fetched tile are kept a while longer
       so a tile can check its neighbours' roads (no wall or building may stand on any street) */
    var RAWP = {}, ROADS = {}, ROADQ = [];
    function rawTile(key) {
      if (RAWP[key]) return RAWP[key];
      var pr = RAWP[key] = (GEN ? new Promise(function (res, rej) { var d = GEN.tile(key); if (d) res(d); else rej(new Error("no tile")); }) : fetch(base + "/t_" + key + ".json").then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })).then(function (d) {
        if (!ROADS[key]) { ROADQ.push(key); if (ROADQ.length > 200) delete ROADS[ROADQ.shift()]; }
        ROADS[key] = d.r || []; return d;
      });
      pr.catch(function () { if (RAWP[key] === pr) delete RAWP[key]; });
      setTimeout(function () { if (RAWP[key] === pr && !want[key] && !loading[key]) delete RAWP[key]; }, 20000);
      return pr;
    }
    function nbRoads(key) {
      var ij = key.split("_"), i = +ij[0], j = +ij[1], have = [], ps = [];
      for (var di = -1; di <= 1; di++) for (var dj = -1; dj <= 1; dj++) {
        if (!di && !dj) continue; var k = (i + di) + "_" + (j + dj); if (!meta || meta.set[k] === undefined) continue;
        if (ROADS[k]) have.push(ROADS[k]); else ps.push(rawTile(k).then(function (d) { return d.r || []; }, function () { return []; }));
      }
      return Promise.all(ps).then(function (a) { return have.concat(a); });
    }
    function fetchTile(key) {
      loading[key] = true;
      return rawTile(key).then(function (d) {
        return nbRoads(key).then(function (nr) {
          delete loading[key]; delete RAWP[key];
          if (tiles[key] === undefined && want[key]) tiles[key] = buildTile(key, d, nr);
        });
      }).catch(function () { delete loading[key]; delete RAWP[key]; tiles[key] = { g: new T.Group(), blds: [], roads: [], key: key, empty: true }; });
    }
    var want = {}, lastI = null, lastJ = null, queue = [];
    function update(px, pz, radius) {
      if (!meta) return;
      var R = radius || 650, x = px - ox, z = pz - oz, T2 = meta.tile, h = meta.half;
      var ci = Math.floor((x + h) / T2), cj = Math.floor((z + h) / T2);
      if (ci === lastI && cj === lastJ && !queue.length) return;
      lastI = ci; lastJ = cj; want = {};
      var rr = Math.ceil(R / T2), list = [];
      for (var i = ci - rr; i <= ci + rr; i++) for (var j = cj - rr; j <= cj + rr; j++) {
        if (i < 0 || j < 0 || i >= meta.n || j >= meta.n) continue;
        var k = i + "_" + j; if (meta.set[k] === undefined) continue;
        var dx = (i + 0.5) * T2 - h - x, dz = (j + 0.5) * T2 - h - z, dd = Math.hypot(dx, dz);
        if (dd < R + T2 * 0.75) { want[k] = 1; if (!tiles[k] && !loading[k]) list.push([dd, k]); }
      }
      Object.keys(tiles).forEach(function (k) { if (!want[k]) unload(k); });
      list.sort(function (a, b) { return a[0] - b[0]; }); queue = list.map(function (a) { return a[1]; });
    }
    function pump() { var n = 0; while (queue.length && n < 2 && Object.keys(loading).length < 4) { var k = queue.shift(); if (want[k] && !tiles[k] && !loading[k]) { fetchTile(k); n++; } } }
    setInterval(pump, 60);

    function onRoad(px, pz) {
      var x = px - ox, z = pz - oz, a = rgrid[Math.floor(x / CELL) + "," + Math.floor(z / CELL)]; if (!a) return false;
      for (var i = 0; i < a.length; i++) { var q = a[i], ex = q.c - q.a, ez = q.d - q.b, l2 = ex * ex + ez * ez || 1, t = Math.max(0, Math.min(1, ((x - q.a) * ex + (z - q.b) * ez) / l2)), dx = x - q.a - ex * t, dz = z - q.b - ez * t; if (dx * dx + dz * dz < q.w * q.w) return true; }
      return false;
    }
    function hitBuilding(x, z, r) {
      x -= ox; z -= oz;
      var a = grid[Math.floor(x / CELL) + "," + Math.floor(z / CELL)]; if (!a) return false;
      for (var i = 0; i < a.length; i++) { var b = a[i]; if (x < b.x1 - r || x > b.x2 + r || z < b.z1 - r || z > b.z2 + r) continue; if (!b.p || inPoly(b.p, x, z)) return true; }
      return false;
    }
    /* push a circle out of building footprints */
    function collide(p, r) {
      var x = p.x - ox, z = p.z - oz, moved = false;
      for (var it = 0; it < 3; it++) {
        var seen = {}, any = false;
        for (var ci = -1; ci <= 1; ci++) for (var cj = -1; cj <= 1; cj++) {
          var a = grid[(Math.floor(x / CELL) + ci) + "," + (Math.floor(z / CELL) + cj)]; if (!a) continue;
          for (var i = 0; i < a.length; i++) {
            var b = a[i]; if (seen[b.x1 + "|" + b.z1]) continue; seen[b.x1 + "|" + b.z1] = 1;
            if (x < b.x1 - r || x > b.x2 + r || z < b.z1 - r || z > b.z2 + r) continue;
            if (!b.p) { var cx = (b.x1 + b.x2) / 2, cz = (b.z1 + b.z2) / 2, rr = (b.x2 - b.x1) / 2 + r, dx = x - cx, dz = z - cz, dl = Math.hypot(dx, dz); if (dl < rr && dl > 0.0001) { x = cx + dx / dl * rr; z = cz + dz / dl * rr; any = true; } continue; }
            var pp = b.p, ins = inPoly(pp, x, z), best = 1e9, bx = 0, bz = 0;
            for (var e = 0, f = pp.length - 2; e < pp.length; f = e, e += 2) {
              var x1 = pp[f], z1 = pp[f + 1], x2 = pp[e], z2 = pp[e + 1], ex = x2 - x1, ez = z2 - z1, l2 = ex * ex + ez * ez || 1, t = Math.max(0, Math.min(1, ((x - x1) * ex + (z - z1) * ez) / l2)), qx = x1 + ex * t, qz = z1 + ez * t, d = Math.hypot(x - qx, z - qz);
              if (d < best) { best = d; bx = qx; bz = qz; }
            }
            if (ins) { var dx2 = bx - x, dz2 = bz - z, l = Math.hypot(dx2, dz2) || 1; x = bx + dx2 / l * r; z = bz + dz2 / l * r; any = true; }
            else if (best < r) { var dx3 = x - bx, dz3 = z - bz, l3 = Math.hypot(dx3, dz3) || 1; x = bx + dx3 / l3 * r; z = bz + dz3 / l3 * r; any = true; }
          }
        }
        if (!any) break; moved = true;
      }
      p.x = x + ox; p.z = z + oz; return moved;
    }
    /* nearest drivable road point (city coords returned in world space) */
    function nearestRoad(px, pz, maxD, drivable) {
      var x = px - ox, z = pz - oz, best = null, bd = maxD || 300;
      Object.keys(tiles).forEach(function (k) {
        tiles[k].roads.forEach(function (r) {
          if (drivable === 2 && r.c > 3) return;
          var p = r.p, acc = 0;
          for (var i = 2; i < p.length; i += 2) {
            var x1 = p[i - 2], z1 = p[i - 1], x2 = p[i], z2 = p[i + 1], ex = x2 - x1, ez = z2 - z1, l2 = ex * ex + ez * ez || 1, t = Math.max(0, Math.min(1, ((x - x1) * ex + (z - z1) * ez) / l2)), qx = x1 + ex * t, qz = z1 + ez * t, d = Math.hypot(x - qx, z - qz), sl = Math.sqrt(l2);
            if (d < bd) { bd = d; best = { x: qx + ox, z: qz + oz, dx: ex / sl, dz: ez / sl, road: r, s: acc + t * sl, d: d }; }
            acc += sl;
          }
        });
      });
      return best;
    }
    function pointAt(r, s) {
      var p = r.p, acc = 0;
      for (var i = 2; i < p.length; i += 2) { var x1 = p[i - 2], z1 = p[i - 1], x2 = p[i], z2 = p[i + 1], sl = Math.hypot(x2 - x1, z2 - z1); if (acc + sl >= s || i === p.length - 2) { var t = sl ? Math.max(0, Math.min(1, (s - acc) / sl)) : 0; return { x: x1 + (x2 - x1) * t + ox, z: z1 + (z2 - z1) * t + oz, dx: (x2 - x1) / (sl || 1), dz: (z2 - z1) / (sl || 1) }; } acc += sl; }
      return { x: p[0] + ox, z: p[1] + oz, dx: 1, dz: 0 };
    }
    function next(r, atNode) { var a = (nodes[atNode] || []).filter(function (q) { return q !== r && !(q.o && q.b === atNode); }); return a; }
    function setNight(k) { M.night.forEach(function (m) { m.emissiveIntensity = m === M.bulb ? k * 2.2 : m === M.shop ? k * 0.9 : k * 1.1; }); }

    var api = {
      root: root, M: M, ox: ox, oz: oz,
      load: function (onWait) {
        function tryLoad() { return fetch(base + "/meta.json").then(function (r) { if (r.status === 202) return r.json().then(function (j) { if (onWait) onWait(j); return new Promise(function (res) { setTimeout(res, 3000); }).then(tryLoad); }); if (!r.ok) throw new Error("meta " + r.status); return r.json(); }); }
        if (GEN) { meta = GEN.meta; meta.set = {}; meta.tiles.forEach(function (k) { meta.set[k] = 1; }); return Promise.resolve(meta); }
        return tryLoad().then(function (m) { meta = m; meta.set = {}; m.tiles.forEach(function (k) { meta.set[k] = 1; }); return m; });
      },
      meta: function () { return meta; }, update: update, collide: collide, hit: hitBuilding, onRoad: onRoad, nearestRoad: nearestRoad, pointAt: pointAt, next: next, nodes: nodes, pois: function () { return pois; }, tiles: tiles,
      loaded: function () { return Object.keys(tiles).length; }, pending: function () { return queue.length + Object.keys(loading).length; }, setNight: setNight,
      buildingAt: function (px, pz) { var x = px - ox, z = pz - oz, a = grid[Math.floor(x / CELL) + "," + Math.floor(z / CELL)]; if (!a) return null; for (var i = 0; i < a.length; i++) if (a[i].p && !a[i].wall && inPoly(a[i].p, x, z)) return a[i]; return null; },
      buildingsNear: function (px, pz, rad) { var out = [], x = px - ox, z = pz - oz, seen = new Set(); for (var i = Math.floor((x - rad) / CELL); i <= Math.floor((x + rad) / CELL); i++) for (var j = Math.floor((z - rad) / CELL); j <= Math.floor((z + rad) / CELL); j++) (grid[i + "," + j] || []).forEach(function (b) { if (b.p && !b.wall && !seen.has(b)) { seen.add(b); out.push(b); } }); return out; },
      onPier: function (px, pz) { var x = px - ox, z = pz - oz; for (var k in tiles) { var L = tiles[k].piers; if (!L) continue; for (var i = 0; i < L.length; i++) { var q = L[i]; if (x > q.x1 && x < q.x2 && z > q.z1 && z < q.z2 && inPoly(q.p, x, z)) return true; } } return false; },
      waterAt: function (px, pz) { var x = px - ox, z = pz - oz; for (var k in tiles) { var w = tiles[k].water; if (!w) continue; for (var i = 0; i < w.length; i++) { var p = w[i].p; if (!w[i].line) { if (inPoly(p, x, z)) return true; } else for (var j = 2; j < p.length; j += 2) { var ex = p[j] - p[j - 2], ez = p[j + 1] - p[j - 1], l2 = ex * ex + ez * ez || 1, t = Math.max(0, Math.min(1, ((x - p[j - 2]) * ex + (z - p[j - 1]) * ez) / l2)), dx = x - p[j - 2] - ex * t, dz = z - p[j - 1] - ez * t; if (dx * dx + dz * dz < w[i].line * w[i].line / 4) return true; } } } return false; },
      toWorld: function (x, z) { return { x: x + ox, z: z + oz }; },
      dropped: function () { return dropTotal; }, boards: function () { return boardTotal; }, dropList: function () { return dropList; },
      inBounds: function (px, pz) { return meta && Math.abs(px - ox) < meta.half && Math.abs(pz - oz) < meta.half; }
    };
    return api;
  }
  window.World = { create: create };
})();
