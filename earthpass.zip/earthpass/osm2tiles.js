"use strict";
/* Converts OpenStreetMap elements (Overpass JSON or PBF-decoded) into small game tiles.
   Coordinates: metres from the city centre, x = east, z = south. */

const ROAD_W = { motorway: 14, trunk: 12, primary: 11, secondary: 9.5, tertiary: 8, unclassified: 6.5, residential: 6.5, living_street: 5, service: 4.2,
  motorway_link: 7, trunk_link: 7, primary_link: 7, secondary_link: 6.5, tertiary_link: 6, pedestrian: 6, footway: 2.4, path: 2, cycleway: 2.2, track: 3.5 };
const DRIVE = new Set(["motorway", "trunk", "primary", "secondary", "tertiary", "unclassified", "residential", "living_street", "service", "motorway_link", "trunk_link", "primary_link", "secondary_link", "tertiary_link"]);
const RCLASS = { motorway: 0, trunk: 0, primary: 1, secondary: 1, tertiary: 2, unclassified: 3, residential: 3, living_street: 3, service: 4, motorway_link: 1, trunk_link: 1, primary_link: 1, secondary_link: 2, tertiary_link: 2, pedestrian: 5, footway: 6, path: 6, cycleway: 6, track: 6 };
const POI_AMEN = new Set(["bank", "hospital", "clinic", "doctors", "school", "university", "college", "cafe", "restaurant", "fast_food", "bar", "pub", "townhall", "police", "fire_station", "pharmacy", "fuel", "bus_station", "cinema", "theatre", "library", "post_office", "courthouse", "place_of_worship", "marketplace", "car_rental", "parking"]);
const GREEN_LU = new Set(["grass", "forest", "recreation_ground", "meadow", "cemetery", "village_green", "allotments", "orchard", "vineyard", "farmland"]);
const GREEN_LE = new Set(["park", "garden", "pitch", "playground", "golf_course", "nature_reserve", "dog_park", "common"]);
const GREEN_NA = new Set(["wood", "scrub", "grassland", "heath"]);

function num(v) { if (v == null) return NaN; const m = String(v).replace(",", ".").match(/-?\d+(\.\d+)?/); return m ? parseFloat(m[0]) : NaN; }
function kindOf(t) {
  const b = t.building || "", a = t.amenity || "";
  if (/^(house|detached|semidetached_house|terrace|bungalow|residential|apartments|dormitory|hut|cabin)$/.test(b)) return b === "apartments" || b === "residential" || b === "dormitory" ? 1 : 0;
  if (/^(church|cathedral|chapel|mosque|temple|synagogue|shrine)$/.test(b) || a === "place_of_worship") return 5;
  if (/^(school|university|college|hospital|civic|public|government|train_station|transportation|museum)$/.test(b) || /^(school|university|hospital|townhall|courthouse|library|police)$/.test(a)) return 4;
  if (/^(industrial|warehouse|factory|manufacture|hangar|garage|garages|shed|service|storage_tank)$/.test(b)) return 3;
  if (/^(commercial|office|retail|supermarket|hotel|mall|store|kiosk)$/.test(b) || t.shop || t.office) return 2;
  return 6;
}
function heightOf(t, k, rnd) {
  let h = num(t.height); if (!isNaN(h) && h > 2) return Math.min(h, 560);
  const lv = num(t["building:levels"]); if (!isNaN(lv) && lv > 0) return Math.min(lv * 3.3 + 1.2, 560);
  return [6.5, 14, 11, 8, 13, 16, 9][k] * (0.8 + rnd * 0.5);
}
function clipPoly(pts, x1, z1, x2, z2) {
  const edges = [[p => p[0] >= x1, (a, b) => { const t = (x1 - a[0]) / (b[0] - a[0]); return [x1, a[1] + t * (b[1] - a[1])]; }],
    [p => p[0] <= x2, (a, b) => { const t = (x2 - a[0]) / (b[0] - a[0]); return [x2, a[1] + t * (b[1] - a[1])]; }],
    [p => p[1] >= z1, (a, b) => { const t = (z1 - a[1]) / (b[1] - a[1]); return [a[0] + t * (b[0] - a[0]), z1]; }],
    [p => p[1] <= z2, (a, b) => { const t = (z2 - a[1]) / (b[1] - a[1]); return [a[0] + t * (b[0] - a[0]), z2]; }]];
  let out = pts;
  for (const [ins, cut] of edges) {
    const inp = out; out = []; if (!inp.length) break;
    for (let i = 0; i < inp.length; i++) { const a = inp[(i + inp.length - 1) % inp.length], b = inp[i]; if (ins(b)) { if (!ins(a)) out.push(cut(a, b)); out.push(b); } else if (ins(a)) out.push(cut(a, b)); }
  }
  return out;
}
function area(p) { let s = 0; for (let i = 0; i < p.length; i++) { const a = p[i], b = p[(i + 1) % p.length]; s += a[0] * b[1] - b[0] * a[1]; } return s / 2; }
function centroid(p) { let x = 0, z = 0; p.forEach(q => { x += q[0]; z += q[1]; }); return [x / p.length, z / p.length]; }
function flat(p) { const o = []; p.forEach(q => { o.push(Math.round(q[0] * 10) / 10, Math.round(q[1] * 10) / 10); }); return o; }
function hash(n) { n = (n ^ 61) ^ (n >>> 16); n = n + (n << 3); n = n ^ (n >>> 4); n = Math.imul(n, 0x27d4eb2d); n = n ^ (n >>> 15); return ((n >>> 0) % 10000) / 10000; }

function convert(elements, opt) {
  const lat0 = opt.lat, lon0 = opt.lon, half = opt.half || 1500, T = opt.tile || 250;
  const kx = Math.cos(lat0 * Math.PI / 180) * 111320, kz = 110540;
  const N = new Map(), W = new Map(), R = [];
  for (const e of elements) {
    if (e.type === "node") N.set(e.id, e);
    else if (e.type === "way") W.set(e.id, e);
    else if (e.type === "relation") R.push(e);
  }
  const P = id => { const n = N.get(id); return n ? [(n.lon - lon0) * kx, -(n.lat - lat0) * kz] : null; };
  const wayPts = w => { const o = []; for (const id of w.nodes || []) { const p = P(id); if (p) o.push(p); } return o; };
  const n = Math.ceil(half * 2 / T), tiles = new Map();
  const tileOf = (x, z) => { const i = Math.floor((x + half) / T), j = Math.floor((z + half) / T); return i < 0 || j < 0 || i >= n || j >= n ? null : i + "_" + j; };
  const get = k => { let t = tiles.get(k); if (!t) { t = { b: [], r: [], rl: [], w: [], g: [], pz: [], poi: [] }; tiles.set(k, t); } return t; };
  const inside = (x, z) => Math.abs(x) <= half && Math.abs(z) <= half;
  const usedAsBuilding = new Set();

  function addPolyClipped(list, pts, extra) {
    if (pts.length < 3) return;
    let x1 = 1e9, x2 = -1e9, z1 = 1e9, z2 = -1e9; pts.forEach(p => { x1 = Math.min(x1, p[0]); x2 = Math.max(x2, p[0]); z1 = Math.min(z1, p[1]); z2 = Math.max(z2, p[1]); });
    const i1 = Math.max(0, Math.floor((x1 + half) / T)), i2 = Math.min(n - 1, Math.floor((x2 + half) / T)), j1 = Math.max(0, Math.floor((z1 + half) / T)), j2 = Math.min(n - 1, Math.floor((z2 + half) / T));
    for (let i = i1; i <= i2; i++) for (let j = j1; j <= j2; j++) {
      const cx1 = -half + i * T, cz1 = -half + j * T, c = clipPoly(pts, cx1, cz1, cx1 + T, cz1 + T);
      if (c.length >= 3 && Math.abs(area(c)) > 4) get(i + "_" + j)[list].push(Object.assign({ p: flat(c) }, extra || {}));
    }
  }
  function addBuilding(pts, t, id) {
    if (pts.length < 4) return; pts = pts.slice(0, -1);
    const c = centroid(pts); if (!inside(c[0], c[1])) return;
    const a = Math.abs(area(pts)); if (a < 6) return;
    if (area(pts) < 0) pts.reverse();
    const k = kindOf(t), h = heightOf(t, k, hash(id)), key = tileOf(c[0], c[1]); if (!key) return;
    const o = { p: flat(pts), h: Math.round(h * 10) / 10, k: k };
    const mh = num(t.min_height); if (!isNaN(mh) && mh > 0) o.m = mh;
    if (t.name) o.n = t.name;
    const pt = t.amenity || (t.shop ? "shop" : "") || (t.office ? "office" : "") || (t.tourism || "");
    if (pt) o.t = pt;
    if (t["building:colour"]) o.c = t["building:colour"];
    if (t["roof:shape"] && t["roof:shape"] !== "flat") o.rs = t["roof:shape"];
    get(key).b.push(o);
  }
  function joinRings(members) {
    const segs = members.map(m => W.get(m.ref)).filter(Boolean).map(w => w.nodes.slice()), rings = [];
    while (segs.length) {
      let ring = segs.shift(), guard = 0;
      while (ring[0] !== ring[ring.length - 1] && guard++ < 500) {
        const end = ring[ring.length - 1]; let found = false;
        for (let i = 0; i < segs.length; i++) {
          const s = segs[i];
          if (s[0] === end) { ring = ring.concat(s.slice(1)); segs.splice(i, 1); found = true; break; }
          if (s[s.length - 1] === end) { ring = ring.concat(s.slice(0, -1).reverse()); segs.splice(i, 1); found = true; break; }
        }
        if (!found) break;
      }
      if (ring.length > 3) rings.push(ring);
    }
    return rings;
  }
  const isWater = t => t.natural === "water" || t.waterway === "riverbank" || t.landuse === "reservoir" || t.landuse === "basin" || t.water;
  const isGreen = t => GREEN_LE.has(t.leisure) || GREEN_LU.has(t.landuse) || GREEN_NA.has(t.natural);
  const isPlaza = t => (t.highway === "pedestrian" && t.area === "yes") || t.amenity === "parking" || t.place === "square";

  for (const r of R) {
    const t = r.tags || {}; if (t.type !== "multipolygon" && t.type !== "building") continue;
    const outers = (r.members || []).filter(m => m.type === "way" && (m.role === "outer" || m.role === ""));
    const rings = joinRings(outers);
    for (const ring of rings) {
      const pts = ring.map(P).filter(Boolean); if (pts.length < 4) continue;
      if (t.building && t.building !== "no") { addBuilding(pts, t, r.id); outers.forEach(m => usedAsBuilding.add(m.ref)); }
      else if (isWater(t)) addPolyClipped("w", pts);
      else if (isGreen(t)) addPolyClipped("g", pts, { k: t.landuse === "forest" || t.natural === "wood" ? 1 : 0 });
      else if (isPlaza(t)) addPolyClipped("pz", pts);
    }
  }
  for (const w of W.values()) {
    const t = w.tags; if (!t) continue;
    const closed = w.nodes && w.nodes.length > 3 && w.nodes[0] === w.nodes[w.nodes.length - 1];
    if (t.building && t.building !== "no" && closed && !usedAsBuilding.has(w.id)) { addBuilding(wayPts(w), t, w.id); continue; }
    if (t.tunnel && t.tunnel !== "no") continue;
    if (closed && isWater(t)) { addPolyClipped("w", wayPts(w).slice(0, -1)); continue; }
    if (closed && isGreen(t)) { addPolyClipped("g", wayPts(w).slice(0, -1), { k: t.landuse === "forest" || t.natural === "wood" ? 1 : 0 }); continue; }
    if (closed && isPlaza(t)) { addPolyClipped("pz", wayPts(w).slice(0, -1)); continue; }
    let kind = null, width = 0, extra = {};
    if (t.highway && ROAD_W[t.highway] !== undefined && t.area !== "yes") {
      kind = "r"; const ln = num(t.lanes); width = !isNaN(ln) && ln > 0 && DRIVE.has(t.highway) ? Math.max(ROAD_W[t.highway] * 0.7, ln * 3.3) : ROAD_W[t.highway];
      extra = { c: RCLASS[t.highway], d: DRIVE.has(t.highway) ? 1 : 0 }; if (t.oneway === "yes" || t.oneway === "1" || t.junction === "roundabout") extra.o = 1; if (t.name) extra.n = t.name; if (t.bridge && t.bridge !== "no") extra.br = 1;
      if (t.footway === "sidewalk" || t.footway === "crossing") continue;
    } else if (t.railway && /^(rail|light_rail|tram|narrow_gauge|subway|monorail)$/.test(t.railway)) { kind = "rl"; width = t.railway === "tram" ? 2.6 : 4; extra = { k: t.railway === "tram" ? 1 : 0 }; if (t.bridge && t.bridge !== "no") extra.br = 1; }
    else if (t.waterway && /^(river|canal|stream)$/.test(t.waterway)) { kind = "wl"; width = num(t.width) || (t.waterway === "river" ? 24 : t.waterway === "canal" ? 12 : 4); }
    if (!kind) continue;
    const ids = (w.nodes || []).filter(id => N.has(id)); if (ids.length < 2) continue;
    let chunk = [ids[0]], len = 0;
    const flush = () => {
      if (chunk.length < 2) return;
      const pts = chunk.map(P), mid = pts[Math.floor(pts.length / 2)];
      const a = pts[0], b = pts[pts.length - 1];
      if (!inside(mid[0], mid[1]) && !inside(a[0], a[1]) && !inside(b[0], b[1])) return;
      const key = tileOf(Math.max(-half, Math.min(half - 0.01, mid[0])), Math.max(-half, Math.min(half - 0.01, mid[1]))); if (!key) return;
      const o = Object.assign({ p: flat(pts), w: Math.round(width * 10) / 10 }, extra);
      if (kind === "r") { o.a = chunk[0]; o.b = chunk[chunk.length - 1]; get(key).r.push(o); }
      else if (kind === "rl") get(key).rl.push(o);
      else get(key).w.push({ p: o.p, line: o.w });
    };
    for (let i = 1; i < ids.length; i++) {
      const p = P(ids[i]), q = P(ids[i - 1]); len += Math.hypot(p[0] - q[0], p[1] - q[1]); chunk.push(ids[i]);
      if (len > 110 && i < ids.length - 1) { flush(); chunk = [ids[i]]; len = 0; }
    }
    flush();
  }
  const seenPoi = new Set();
  const poiOf = (t, x, z) => {
    let ty = POI_AMEN.has(t.amenity) ? t.amenity : t.shop ? "shop:" + t.shop : t.office ? "office" : t.tourism && /^(hotel|attraction|museum|viewpoint|artwork)$/.test(t.tourism) ? t.tourism : (t.railway === "station" || t.public_transport === "station") ? "station" : t.aeroway === "terminal" ? "airport" : null;
    if (!ty || !inside(x, z)) return; const key = tileOf(x, z); if (!key) return;
    const s = ty + "|" + Math.round(x / 8) + "|" + Math.round(z / 8); if (seenPoi.has(s)) return; seenPoi.add(s);
    const o = { x: Math.round(x * 10) / 10, z: Math.round(z * 10) / 10, t: ty }; if (t.name) o.n = t.name; get(key).poi.push(o);
  };
  for (const e of N.values()) if (e.tags && Object.keys(e.tags).length) { const p = P(e.id); poiOf(e.tags, p[0], p[1]); }
  for (const w of W.values()) if (w.tags && (w.tags.amenity || w.tags.shop || w.tags.tourism || w.tags.office || w.tags.railway === "station")) { const pts = wayPts(w); if (pts.length) { const c = centroid(pts); poiOf(w.tags, c[0], c[1]); } }

  const meta = { lat: lat0, lon: lon0, half, tile: T, n, tiles: [] };
  /* city overview for the map screen: roads, water, parks and places */
  const ov = { r: [], w: [], g: [], poi: [], pl: [] };
  for (const e of N.values()) { const t = e.tags; if (!t || !t.name || !/^(suburb|neighbourhood|quarter|borough)$/.test(t.place || "")) continue; const p = P(e.id); if (p && inside(p[0], p[1])) ov.pl.push({ n: t.name, x: Math.round(p[0]), z: Math.round(p[1]), k: t.place === "neighbourhood" ? 2 : 1 }); }
  for (const t of tiles.values()) {
    t.r.forEach(r => { if (r.c <= 5) ov.r.push({ p: r.p.map(v => Math.round(v)), c: r.c, n: r.n }); });
    t.rl.forEach(r => ov.r.push({ p: r.p.map(v => Math.round(v)), c: 9 }));
    t.w.forEach(w => ov.w.push(w.line ? { p: w.p.map(v => Math.round(v)), line: w.line } : { p: w.p.map(v => Math.round(v)) }));
    t.g.forEach(g => ov.g.push({ p: g.p.map(v => Math.round(v)) }));
    t.poi.forEach(p => ov.poi.push(p));
  }
  for (const [k, t] of tiles) { if (t.b.length || t.r.length || t.w.length || t.g.length || t.rl.length || t.pz.length) meta.tiles.push(k); }
  return { meta, tiles, overview: ov };
}

/* Overpass query for one block (south, west, north, east) */
function overpassQuery(s, w, nn, e) {
  const bb = [s, w, nn, e].map(v => v.toFixed(6)).join(",");
  const q = ["way[building]", "relation[building]", "way[highway]", "way[railway]", "way[natural]", "relation[natural=water]", "way[waterway]", "way[landuse]", "relation[landuse]", "way[leisure]", "relation[leisure]",
    "way[amenity]", "node[amenity]", "node[shop]", "node[office]", "node[tourism]", "way[tourism]", "node[railway=station]", "way[place=square]"].map(x => x + "(" + bb + ");").join("");
  return "[out:json][timeout:180];(" + q + ");out body;>;out skel qt;";
}

module.exports = { convert, overpassQuery };
